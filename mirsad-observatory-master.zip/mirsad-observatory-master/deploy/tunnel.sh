#!/usr/bin/env bash
# رابط عام دائم مجاني لمِرصد عبر نفق Cloudflare مُسمّى (hostname ثابت لا يتغيّر).
#
# لماذا مُسمّى وليس سريعًا؟ `cloudflared tunnel --url` (السريع) يعطي رابطًا عشوائيًّا
# يتغيّر كل تشغيل. النفق المُسمّى يربط نطاقًا تملكه ويثبّت العنوان للأبد.
#
# المتطلبات (مجانية):
#   1. حساب Cloudflare مجاني + نطاق مُدار في Cloudflare (اسم واحد يكفي).
#   2. cloudflared مثبّتًا على الخادم الدائم.
#
# الاستخدام:
#   ./deploy/tunnel.sh login                 # مصادقة تفاعلية (مرّة واحدة)
#   ./deploy/tunnel.sh create mirsad.example.com
#   ./deploy/tunnel.sh service               # تثبيت كخدمة دائمة
set -euo pipefail

TUNNEL_NAME="${TUNNEL_NAME:-mirsad}"
LOCAL_URL="${LOCAL_URL:-http://127.0.0.1:8000}"

case "${1:-}" in
  login)
    cloudflared tunnel login
    ;;
  create)
    HOSTNAME="${2:?usage: $0 create <hostname>}"
    cloudflared tunnel create "$TUNNEL_NAME" || true
    cloudflared tunnel route dns "$TUNNEL_NAME" "$HOSTNAME"
    cat > "$HOME/.cloudflared/config.yml" <<EOF
tunnel: $TUNNEL_NAME
credentials-file: $HOME/.cloudflared/$TUNNEL_NAME.json
ingress:
  - hostname: $HOSTNAME
    service: $LOCAL_URL
  - service: http_status:404
EOF
    echo "created tunnel '$TUNNEL_NAME' -> https://$HOSTNAME"
    echo "next: $0 service"
    ;;
  service)
    sudo cloudflared service install
    sudo systemctl enable --now cloudflared
    echo "cloudflared installed as a permanent service"
    ;;
  run)
    cloudflared tunnel run "$TUNNEL_NAME"
    ;;
  *)
    echo "usage: $0 {login|create <hostname>|service|run}"; exit 1;;
esac
