#!/usr/bin/env bash
# تثبيت مِرصد دائمًا على خادم Linux بنقرة واحدة.
#
# الخيار الموصى به (مجاني تمامًا ودائم): VPS مجاني/رخيص يعمل 24/7، مثل
# Oracle Cloud Always Free، أو GCP e2-micro (Always Free)، أو خادم تملكه.
# ثبّت Ubuntu ثم شغّل هذا السكربت — يعمل بلا Docker وبلا تدخّل لاحق.
#
#   sudo ./deploy/install.sh
#
# بعد التثبيت يعمل الموقع على المنفذ 8000 دائمًا، ويعيد systemd تشغيله تلقائيًّا
# عند أي انقطاع أو إعادة إقلاع. لجعل الرابط العام دائمًا: deploy/tunnel.sh
set -euo pipefail

APP_DIR="${APP_DIR:-/opt/mirsad}"
SERVICE_USER="${SERVICE_USER:-www-data}"

[ "$(id -u)" -eq 0 ] || { echo "run as root: sudo $0"; exit 1; }

echo "== 1/5 تثبيت الحِزم =="
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip rsync

echo "== 2/5 نسخ الملفات إلى $APP_DIR =="
SRC="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$APP_DIR"
rsync -a --delete \
  --exclude '.git' --exclude 'data/' --exclude '__pycache__' \
  --exclude '.env.local' --exclude '*.log' \
  "$SRC/" "$APP_DIR/"

echo "== 3/5 تهيئة الأسرار =="
if [ ! -f "$APP_DIR/.env.local" ]; then
  gen() { python3 -c "import secrets;print(secrets.token_urlsafe(32))"; }
  cat > "$APP_DIR/.env.local" <<EOF
MIRSAD_INGEST_KEY=$(gen)
MIRSAD_ADMIN_KEY=$(gen)
MIRSAD_SECRET_KEY=$(gen)
EOF
  chmod 600 "$APP_DIR/.env.local"
  echo "وُلِّدت مفاتيح جديدة في $APP_DIR/.env.local (احتفظ بها)"
fi

echo "== 4/5 تثبيت التبعيات في venv =="
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install -q --upgrade pip
"$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"
chown -R "$SERVICE_USER:$SERVICE_USER" "$APP_DIR"

echo "== 5/5 تثبيت خدمة systemd =="
cat > /etc/systemd/system/mirsad.service <<EOF
[Unit]
Description=Mirsad Observatory (FastAPI)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$APP_DIR
EnvironmentFile=-$APP_DIR/.env.local
Environment=HOST=0.0.0.0
Environment=PORT=8000
# إنتاج: بوّابة run.sh ترفض الإقلاع بلا مفاتيح INGEST/ADMIN/SECRET.
Environment=MIRSAD_ENV=production
# نُشغّل عبر run.sh (لا uvicorn مباشرة) كي تُطبَّق بوّابة المفاتيح.
Environment=PATH=$APP_DIR/.venv/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=$APP_DIR/run.sh
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now mirsad
sleep 5
systemctl --no-pager --lines=0 status mirsad | head -5

echo
echo "✅ مِرصد يعمل الآن على http://<عنوان-الخادم>:8000"
echo "   تحقّق: curl -s localhost:8000/healthz"
echo "   رابط دائم بنطاق: $APP_DIR/deploy/tunnel.sh"
