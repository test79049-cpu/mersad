"""اختبارات التصنيف الآلي والتصدير (دون شبكة)."""

from app import exports, importers


def test_classify_arabic_human_rights():
    cat, sev, conf = importers.classify("اعتقال تعسفي لناشطين سلميين في العاصمة")
    assert cat == "human_rights"
    assert sev == "high"


def test_classify_english_environment():
    cat, sev, _ = importers.classify("Oil spill pollutes coastal waters")
    assert cat == "environment"
    assert sev in ("medium", "high")


def test_classify_critical_hint():
    cat, sev, _ = importers.classify("Massacre kills dozens in village")
    assert sev == "critical"


def test_classify_default_when_unknown():
    cat, sev, conf = importers.classify("Random unrelated headline")
    assert cat in {c["key"] for c in __import__("app.taxonomy", fromlist=["CATEGORIES"]).CATEGORIES}


def test_gdelt_validator_rejects_error_text():
    import pytest
    with pytest.raises(RuntimeError):
        importers._validate_gdelt_csv("Queries containing OR'd terms must be surrounded by ().")
    with pytest.raises(RuntimeError):
        importers._validate_gdelt_csv("<html>error</html>")
    # نص CSV صالح لا يرفع
    importers._validate_gdelt_csv("URL,MobileURL,Date,Title\nhttp://x,http://x,2026-01-01,hello\n")


def test_export_csv_has_arabic_headers(conn, temp_db):
    rows = temp_db.query_reports(conn, limit=2)
    body = exports.to_csv(rows)
    assert body.splitlines()[0].startswith("المعرّف,العنوان")
    assert len(body.splitlines()) == 3


def test_csv_cell_neutralizes_formula_prefixes():
    from app import exports
    assert exports.csv_cell("=1+1") == "'=1+1"
    assert exports.csv_cell("+SUM(A1)") == "'+SUM(A1)"
    assert exports.csv_cell("-2+3") == "'-2+3"
    assert exports.csv_cell("@cmd") == "'@cmd"
    assert exports.csv_cell("\tx") == "'\tx"
    # القيم العادية (والأرقام السالبة كأرقام) لا تتغيّر عند غياب بادئة صيغة
    assert exports.csv_cell("نص عادي") == "نص عادي"
    assert exports.csv_cell("") == ""
    assert exports.csv_cell(None) == ""


def test_export_csv_neutralizes_formula_injection():
    from app import exports
    rows = [{
        "id": 1,
        "title": '=HYPERLINK("http://evil.example","x")',
        "summary": "+SUM(1+1)*cmd|' /C calc'!A0",
        "source_name": "@cmd",
        "category": "human_rights", "severity": "high", "status": "new",
        "country": "مصر", "region": "", "occurred_on": "", "reported_on": "2026-01-01",
        "verified": 0, "source_url": "https://example.org", "country_code": "EGY",
        "lat": 27.0, "lng": 30.0,
    }]
    line = exports.to_csv(rows).splitlines()[1]
    assert "'=HYPERLINK" in line
    assert "'+SUM(1+1)" in line
    assert "'@cmd" in line


def test_entities_and_members_csv_neutralize_formulas():
    from app import exports
    ent = exports.to_entities_csv(
        [{"name": "=evil()", "kind": "company", "count": 1, "wikidata_id": ""}])
    assert "'=evil()" in ent
    mem = exports.members_to_csv(
        [{"handle": "+h", "display_name": "=x", "verified": 1}])
    assert "'+h" in mem and "'=x" in mem


def test_export_json_metadata(conn, temp_db):
    import json
    rows = temp_db.query_reports(conn, limit=2)
    data = json.loads(exports.to_json(rows, meta={"filter": "test"}))
    assert data["count"] == 2
    assert data["meta"]["filter"] == "test"
    assert data["license"] == "CC BY 4.0"


def test_export_rss_structure(conn, temp_db):
    rows = temp_db.query_reports(conn, limit=2)
    rss = exports.to_rss(rows, "https://example.org/feed.xml")
    assert rss.count("<item>") == 2
    assert "atom:link" in rss


def test_export_json_feed_structure(conn, temp_db):
    import json
    rows = temp_db.query_reports(conn, limit=2)
    feed = json.loads(exports.to_json_feed(rows, "https://example.org/feed.json"))
    assert feed["language"] == "ar"
    assert len(feed["items"]) == 2
    assert feed["items"][0]["tags"]


def test_client_retries_on_429(monkeypatch):
    """عميل HTTP يعيد المحاولة عند 429 ثم ينجح."""
    import urllib.error
    from app import clients

    calls = {"n": 0}

    class FakeResp:
        def __enter__(self):
            return self
        def __exit__(self, *a):
            return False
        def read(self):
            return b"ok-body"

    def fake_urlopen(req, timeout=0):
        calls["n"] += 1
        if calls["n"] == 1:
            raise urllib.error.HTTPError(req.full_url, 429, "Too Many", {}, None)
        return FakeResp()

    monkeypatch.setattr(clients.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(clients.time, "sleep", lambda *_: None)
    out = clients.get_text("https://example.org/x", use_cache=False, retries=2)
    assert out == "ok-body"
    assert calls["n"] == 2


def test_client_gives_up_after_retries(monkeypatch):
    import urllib.error
    import pytest
    from app import clients

    def fake_urlopen(req, timeout=0):
        raise urllib.error.HTTPError(req.full_url, 503, "Unavailable", {}, None)

    monkeypatch.setattr(clients.urllib.request, "urlopen", fake_urlopen)
    monkeypatch.setattr(clients.time, "sleep", lambda *_: None)
    with pytest.raises(RuntimeError):
        clients.get_text("https://example.org/y", use_cache=False, retries=1)


def test_ingest_key_guard(monkeypatch):
    import pytest
    from fastapi import HTTPException
    from app import main

    monkeypatch.setattr(main, "INGEST_KEY", "secret")
    main._require_ingest_key("secret")  # لا يرفع
    with pytest.raises(HTTPException):
        main._require_ingest_key("wrong")
    with pytest.raises(HTTPException):
        main._require_ingest_key(None)

    monkeypatch.setattr(main, "INGEST_KEY", "")
    main._require_ingest_key(None)  # مفتوح في التطوير


def _malicious_row():
    return {
        "id": 7,
        "title": 'Report" }\n@article{pwned, author="attacker"}',
        "source_name": 'Evil" }\n@misc{pwn2',
        "category": "human_rights",
        "severity": "high",
        "status": "new",
        "country": "مصر",
        "occurred_on": "2026-01-01",
        "reported_on": "2026-01-01",
        "summary": "ملخّص عادي\nER  -\n\nTY  - JOUR\nID  - injected\nER  -",
    }


def test_bibtex_export_has_no_injected_lines():
    body = exports.to_bibtex([_malicious_row()])
    lines = body.splitlines()
    # لا يمكن للمحتوى المحقون أن يفتح مدخلًا في بداية سطر جديد.
    assert [ln for ln in lines if ln.startswith("@")] == ["@misc{mirsad7,"]
    assert not any(ln.startswith("@article") for ln in lines)
    assert not any(ln.startswith("@misc{pwn2") for ln in lines)


def test_ris_export_has_no_injected_entries():
    body = exports.to_ris([_malicious_row()])
    lines = body.splitlines()
    # لا يظهر سطر TY  - أو ER  - إضافي من المحتوى المحقون.
    assert sum(ln.startswith("TY  - ") for ln in lines) == 1
    assert sum(ln.startswith("ER  - ") for ln in lines) == 1
    assert not any(ln.startswith("ID  - ") for ln in lines)


def test_citation_fields_strip_control_characters():
    row = _malicious_row()
    for fn in (exports.to_bibtex, exports.to_ris, exports.to_apa, exports.to_mla,
               exports.to_chicago):
        out = fn([row])
        assert "\r" not in out and "\x00" not in out
        assert "\n\n\n" not in out

