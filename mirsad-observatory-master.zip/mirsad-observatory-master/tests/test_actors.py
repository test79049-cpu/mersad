"""اختبارات سجل الجهات الفاعلة (actors) والمطابقة النصّية."""

from app import actors


def test_actors_unique_names():
    names = [a["name"] for a in actors.ACTORS]
    assert len(names) == len(set(names)), "أسماء الكيانات يجب ألا تتكرّر"


def test_actors_have_required_fields():
    for a in actors.ACTORS:
        assert a["name"]
        assert a["kind"] in {"person", "company", "organization", "government", "other"}
        assert "aliases" in a


def test_match_actors_arabic_and_english():
    hits = actors.match_actors("وثّق تحقيق مخالفات شركة شل و Rio Tinto في المنطقة")
    names = {h["name"] for h in hits}
    assert "شل" in names
    assert "ريو تينتو" in names


def test_match_actors_alias_case_insensitive():
    hits = actors.match_actors("HRW and Amnesty International published reports")
    names = {h["name"] for h in hits}
    assert "هيومن رايتس ووتش" in names
    assert "منظمة العفو الدولية" in names


def test_match_actors_empty():
    assert actors.match_actors("") == []


def test_by_name_and_counts():
    assert actors.by_name("Shell")["name"] == "شل"
    assert actors.by_name("لا يوجد") is None
    counts = actors.counts_by_kind()
    assert counts.get("company", 0) >= 10
    assert counts.get("person", 0) >= 5
