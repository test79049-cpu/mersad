"""اختبارات تطبيع النص العربي."""

from app.textutils import build_search_text, normalize_arabic, tokenize


def test_alef_variants_unified():
    assert normalize_arabic("أحمد") == normalize_arabic("احمد") == "احمد"
    assert normalize_arabic("إبراهيم") == "ابراهيم"
    assert normalize_arabic("آدم") == "ادم"


def test_diacritics_and_tatweel_removed():
    assert normalize_arabic("مِيَاهْ") == "مياه"
    assert normalize_arabic("كتـــاب") == "كتاب"


def test_teh_marbuta_and_yeh():
    assert normalize_arabic("أقلية") == "اقليه"
    assert normalize_arabic("مصطفى") == "مصطفي"


def test_tokenize():
    assert tokenize("أطفالٌ في المَدرسة!") == ["اطفال", "في", "المدرسه"]


def test_build_search_text_joins_and_normalizes():
    blob = build_search_text("عنوان", "ملخّص", "الأردن")
    assert "عنوان" in blob and "الاردن" in blob
    assert "ّ" not in blob


def test_empty_input():
    assert normalize_arabic("") == ""
    assert tokenize("") == []
