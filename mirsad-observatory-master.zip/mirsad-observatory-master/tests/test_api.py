"""اختبارات واجهة البرمجة والصفحات."""

from app.taxonomy import CATEGORIES


def test_home_page(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "مِرصد" in r.text


def test_dates_render_localized_not_iso(client):
    """تُعرض التواريخ بأسماء الأشهر حسب اللغة، لا بصيغة ISO الخام."""
    from app import db
    from app.i18n import format_date
    conn = db.connect()
    try:
        row = db.get_report(conn, 1)
        latest = db.query_reports(conn, sort="recent", limit=6)
    finally:
        conn.close()
    ar = client.get("/reports/1").text
    en = client.get("/reports/1?lang=en").text
    # صفّ البيانات في اللوحة الجانبية يستخدم الصيغة المقروءة لا ISO
    assert format_date(row["occurred_on"], "ar") in ar
    assert format_date(row["occurred_on"], "en") in en
    assert f'<dd class="mono">{row["occurred_on"]}</dd>' not in ar
    # أحدث البلاغات في الرئيسية أيضاً (بالعربية صراحةً؛ طلب en أعلاه ثبّت الكوكي)
    home = client.get("/?lang=ar").text
    assert format_date(latest[0]["reported_on"], "ar") in home
    # بيانات JSON-LD المهيكلة تبقى بصيغة ISO (قراءة آلية)
    assert f'"dateCreated": "{row["occurred_on"]}"' in ar


def test_ticker_items_unique_and_localized(client):
    """شريط «عاجل» لا يكرّر أي بلاغ، ويعرض التواريخ المنسّقة."""
    html = client.get("/").text
    import re
    hrefs = re.findall(r'class="ticker__item"><a href="/reports/(\d+)"', html)
    assert hrefs, "شريط عاجل فارغ"
    assert len(hrefs) == len(set(hrefs)), f"تكرار في الشريط: {hrefs}"
    # البلاغ 57 حالة حرجة وأيضاً من أحدث البلاغات — يجب أن يظهر مرة واحدة.
    assert hrefs.count("57") == 1


def test_english_page_shows_english_content(client):
    """النسخة الإنجليزية تعرض عناوين وملخّصات إنجليزية لا النصّ العربي."""
    en = client.get("/?lang=en").text
    assert "Arbitrary arrest of activists on the anniversary of past protests" in en
    assert "اعتقال تعسفي لناشطين في ذكرى احتجاجات سابقة" not in en
    # تفاصيل البلاغ بالإنجليزية أيضاً
    detail = client.get("/reports/1?lang=en").text
    assert "Security forces detained several human-rights activists" in detail
    # النسخة العربية تبقى عربية
    ar = client.get("/?lang=ar").text
    assert "اعتقال تعسفي لناشطين في ذكرى احتجاجات سابقة" in ar


def test_country_flags_and_localized_names(client):
    """صفحة الدول تعرض أعلاماً وأسماء دول مترجمة."""
    en = client.get("/countries?lang=en").text
    assert "🇪🇬" in en and "Egypt" in en
    ar = client.get("/countries?lang=ar").text
    assert "🇪🇬" in ar and "مصر" in ar



def test_reports_page_and_filters(client):
    assert client.get("/reports").status_code == 200
    r = client.get("/reports?category=environment&severity=high")
    assert r.status_code == 200
    assert "البيئة" in r.text


def test_verified_filter_and_chips(client):
    # مرشّح التوثيق يقيّد النتائج ويعرض رقاقة نشطة قابلة للإزالة في الحالتين.
    verified = client.get("/api/reports", params={"verified": "1", "limit": 100}).json()
    assert verified["total"] > 0
    assert all(item["verified"] for item in verified["items"])

    unverified = client.get("/api/reports", params={"verified": "0", "limit": 100}).json()
    assert all(not item["verified"] for item in unverified["items"])

    chip_v = client.get("/reports", params={"verified": "1"}).text
    assert "الموثّق فقط" in chip_v
    chip_u = client.get("/reports", params={"verified": "0"}).text
    assert "غير موثّق" in chip_u


def test_report_detail(client):
    r = client.get("/reports/1")
    assert r.status_code == 200
    assert "بيانات البلاغ" in r.text


def test_report_detail_404(client):
    assert client.get("/reports/999999").status_code == 404


def test_map_and_sources_pages(client):
    assert client.get("/map").status_code == 200
    assert client.get("/sources").status_code == 200


def test_category_pages(client):
    from app.taxonomy import CATEGORIES
    for c in CATEGORIES:
        r = client.get(f"/category/{c['key']}")
        assert r.status_code == 200
        assert c["name"] in r.text
    assert client.get("/category/does_not_exist").status_code == 404


def test_category_pagination(client):
    # الترقيم يجزّئ بلاغات المجال دون تكرار بين الصفحات.
    import re
    from app.config import PAGE_SIZE
    first = re.findall(r"/reports/(\d+)", client.get("/category/environment").text)
    assert 0 < len(first) <= PAGE_SIZE
    second = re.findall(r"/reports/(\d+)", client.get("/category/environment?page=2").text)
    assert not (set(first) & set(second))
    # صفحة خارج المدى تُعيد 200 بلا بلاغات (لا خطأ).
    assert client.get("/category/environment?page=999").status_code == 200
    assert client.get("/category/environment?page=0").status_code == 200


def test_api_reports_pagination(client):
    r = client.get("/api/reports?limit=3")
    data = r.json()
    assert r.status_code == 200
    assert data["count"] == 3
    assert data["total"] > 3


def test_api_report_detail_has_entities(client):
    r = client.get("/api/reports/1")
    assert r.status_code == 200
    assert "entities" in r.json()


def test_api_stats(client):
    data = client.get("/api/stats").json()
    assert data["total"] > 0
    assert len(data["by_category"]) == len(CATEGORIES)


def test_api_taxonomy(client):
    data = client.get("/api/taxonomy").json()
    assert len(data["categories"]) == len(CATEGORIES)
    assert len(data["severities"]) == 4


def test_api_search_arabic(client):
    r = client.get("/api/search", params={"q": "مياه"})
    assert r.status_code == 200
    assert r.json()["count"] >= 1


def test_api_geo_is_geojson(client):
    data = client.get("/api/geo").json()
    assert data["type"] == "FeatureCollection"
    assert data["features"]
    feat = data["features"][0]
    assert feat["geometry"]["type"] == "Point"
    assert len(feat["geometry"]["coordinates"]) == 2


def test_api_countries_search(client):
    data = client.get("/api/countries", params={"q": "مصر"}).json()
    assert any(c["iso2"] == "EG" for c in data["items"])


def test_export_csv(client):
    r = client.get("/api/export.csv?limit=2")
    assert r.status_code == 200
    assert "text/csv" in r.headers["content-type"]
    assert "العنوان" in r.text


def test_export_csv_neutralizes_formula_injection(client, conn, temp_db):
    temp_db.insert_report(conn, {
        "title": '=HYPERLINK("http://evil.example/leak","x")',
        "category": "human_rights", "severity": "high", "status": "new",
        "country": "مصر", "region": "",
        "occurred_on": None, "reported_on": "2026-01-01",
        "summary": "+SUM(1+1)*cmd|' /C calc'!A0",
        "details": "", "source_name": "@cmd", "source_url": "", "verified": 0,
    })
    body = client.get("/api/export.csv?q=HYPERLINK").text
    # لا تبدأ أي خلية بصيغة قابلة للتنفيذ في جدول البيانات
    for line in body.splitlines()[1:]:
        for cell in line.split(","):
            assert not cell.lstrip('"').startswith(("=", "+", "@")), cell
    assert "'=HYPERLINK" in body and "'+SUM(1+1)" in body and "'@cmd" in body


def test_export_json(client):
    data = client.get("/api/export.json?limit=2").json()
    assert data["count"] == 2
    assert data["items"][0]["category_label"]


def test_feed_rss_and_json(client):
    rss = client.get("/feed.xml")
    assert rss.status_code == 200
    assert "<rss" in rss.text and "<item>" in rss.text
    feed = client.get("/feed.json").json()
    assert feed["version"].startswith("https://jsonfeed.org")


def test_feeds_accept_filters(client):
    from app.taxonomy import category_name
    all_items = client.get("/feed.json?limit=50").json()["items"]
    env_items = client.get("/feed.json?category=environment&limit=50").json()["items"]
    assert env_items and len(env_items) < len(all_items)
    env_label = category_name("environment", "ar")
    assert all(env_label in i["tags"] for i in env_items)


def test_citation_exports(client):
    bib = client.get("/api/cite.bib?limit=3")
    assert bib.status_code == 200
    assert "@misc{" in bib.text and "title" in bib.text

    ris = client.get("/api/cite.ris?limit=3")
    assert ris.status_code == 200
    assert "TY  - NEWS" in ris.text and "ER  - " in ris.text

    apa = client.get("/api/cite.txt?limit=3")
    assert apa.status_code == 200
    assert apa.text.strip()


def test_citation_single_report(client):
    one = client.get("/api/cite.bib?id=1")
    assert one.status_code == 200
    assert one.text.count("@misc{") == 1
    assert "mirsad1," in one.text


def test_report_detail_shows_citation(client):
    r = client.get("/reports/1")
    assert r.status_code == 200
    assert "/api/cite.bib?id=1" in r.text


def test_entities_directory(client):
    page = client.get("/entities")
    assert page.status_code == 200
    assert "/entity/" in page.text

    orgs = client.get("/entities?kind=organization")
    assert orgs.status_code == 200

    detail = client.get("/entity/مِرصد")
    assert detail.status_code in (200, 404)  # الكيان قد لا يوجد في البيانات الأولية


def test_entity_page_for_seeded_country(client):
    from app import db
    c = db.connect()
    try:
        ent = db.entities_summary(c, kind="country", limit=1)
    finally:
        c.close()
    assert ent, "يجب أن تحتوي البيانات الأولية على كيانات دولة"
    name = ent[0]["name"]
    r = client.get(f"/entity/{name}")
    assert r.status_code == 200
    assert name in r.text


def test_report_detail_links_entities(client):
    from app import db
    c = db.connect()
    try:
        ents = db.entities_for(c, 1)
    finally:
        c.close()
    assert ents, "يجب أن يحتوي البلاغ 1 على كيانات مرتبطة"
    r = client.get("/reports/1")
    assert f"/entity/{ents[0]['name']}" in r.text


def test_submit_valid_creates_report(client):
    before = client.get("/api/stats").json()["total"]
    r = client.post("/submit", data={
        "title": "تسريب اختباري في نهر محلي",
        "category": "environment", "severity": "high",
        "country": "الأردن", "region": "الزرقاء",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب في هذا الحقل.",
    }, follow_redirects=False)
    assert r.status_code == 303
    assert client.get("/api/stats").json()["total"] == before + 1


def test_submit_invalid_rejected(client):
    before = client.get("/api/stats").json()["total"]
    r = client.post("/submit", data={
        "title": "قصير", "category": "environment", "severity": "high",
        "country": "الأردن", "summary": "قصير",
    })
    assert r.status_code == 400
    assert client.get("/api/stats").json()["total"] == before


def test_healthz(client):
    assert client.get("/healthz").json()["status"] == "ok"


def test_security_headers_present(client):
    r = client.get("/")
    assert r.headers.get("x-content-type-options") == "nosniff"
    assert r.headers.get("x-frame-options") == "SAMEORIGIN"
    assert "referrer-policy" in r.headers


def test_static_assets_cacheable(client):
    r = client.get("/static/css/style.css")
    assert r.status_code == 200
    assert "max-age" in r.headers.get("cache-control", "")


def test_submit_rejects_future_date_and_bad_url(client):
    r = client.post("/submit", data={
        "title": "واقعة بتاريخ مستقبلي",
        "category": "environment", "severity": "high",
        "country": "الأردن", "occurred_on": "2099-01-01",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب في هذا الحقل.",
    })
    assert r.status_code == 400 and "المستقبل" in r.text
    r2 = client.post("/submit", data={
        "title": "رابط مصدر غير صالح",
        "category": "environment", "severity": "high",
        "country": "الأردن", "source_url": "javascript:alert(1)",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب في هذا الحقل.",
    })
    assert r2.status_code == 400 and "http" in r2.text


def test_submit_rejects_unknown_country(client):
    before = client.get("/api/stats").json()["total"]
    r = client.post("/submit", data={
        "title": "دولة غير معروفة إطلاقاً",
        "category": "environment", "severity": "high",
        "country": "أطلانطس المفقودة",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب في هذا الحقل.",
    })
    assert r.status_code == 400 and "الدولة" in r.text
    assert client.get("/api/stats").json()["total"] == before


def test_countries_index_and_detail(client):
    idx = client.get("/countries")
    assert idx.status_code == 200 and "الدول والمِناطق" in idx.text
    # اختر دولة موجودة من ملف تعريف السجل
    rep = client.get("/api/reports?limit=1").json()["items"][0]
    country = rep["country"]
    detail = client.get(f"/country/{country}")
    assert detail.status_code == 200
    assert country in detail.text
    assert "التوزّع حسب المجال" in detail.text
    missing = client.get("/country/لايوجد-هنا")
    assert missing.status_code == 404


def test_sitemap_includes_countries(client):
    sm = client.get("/sitemap.xml")
    assert "/countries" in sm.text and "/country/" in sm.text


def test_sitemap_and_robots(client):
    sm = client.get("/sitemap.xml")
    assert sm.status_code == 200
    assert "<urlset" in sm.text and "/reports/1" in sm.text
    rb = client.get("/robots.txt")
    assert "Sitemap:" in rb.text


def test_report_page_has_structured_data(client):
    r = client.get("/reports/1")
    assert 'application/ld+json' in r.text
    assert '"@type": "NewsArticle"' in r.text


def test_home_has_search_box_and_og_tags(client):
    r = client.get("/")
    assert "masthead__search" in r.text
    assert 'property="og:title"' in r.text
    assert 'rel="alternate"' in r.text


def test_entities_page_and_kind_filter(client):
    r = client.get("/entities")
    assert r.status_code == 200
    assert "الكيانات" in r.text
    # مرشّح الشركات يعرض كيانات من نوع شركة
    comp = client.get("/entities?kind=company")
    assert comp.status_code == 200
    assert "شركة" in comp.text


def test_entity_page_lists_reports(client):
    client.get("/api/refresh")  # لضمان اكتمال الربط
    import urllib.parse
    name = urllib.parse.quote("شل")
    r = client.get(f"/entity/{name}")
    assert r.status_code == 200
    assert "شل" in r.text
    # كيان غير موجود يعيد 404
    assert client.get("/entity/كيان-وهمي-xyz").status_code == 404


def test_api_entities_and_status(client):
    e = client.get("/api/entities")
    assert e.status_code == 200
    body = e.json()
    assert "counts" in body and "items" in body
    assert body["counts"].get("company", 0) >= 5

    s = client.get("/api/status")
    assert s.status_code == 200
    sb = s.json()
    assert "stats" in sb and "scheduler" in sb
    assert sb["scheduler"]["interval_seconds"] == 60


def test_api_refresh_endpoint(client):
    r = client.get("/api/refresh")
    assert r.status_code == 200
    assert "ran_at" in r.json()


def test_sources_page_shows_registry_stats(client):
    r = client.get("/sources")
    assert r.status_code == 200
    assert "مجموعات البيانات" in r.text
    assert "60" in r.text


def test_entities_export_csv_and_json(client):
    csv = client.get("/api/entities.csv")
    assert csv.status_code == 200
    assert "text/csv" in csv.headers["content-type"]
    assert "الاسم" in csv.text
    js = client.get("/api/entities.json")
    assert js.status_code == 200
    body = js.json()
    assert body["count"] > 0
    assert all("kind_label" in it for it in body["items"])


def test_entities_export_filtered_by_kind(client):
    r = client.get("/api/entities.json?kind=country")
    assert r.status_code == 200
    body = r.json()
    assert body["meta"]["kind"] == "country"
    assert all(it["kind"] == "country" for it in body["items"])


def test_entities_unknown_kind_is_graceful(client):
    """نوع كيان غير معروف لا يرفع 500؛ يعرض صفحة/قائمة فارغة."""
    assert client.get("/entities?kind=bogus").status_code == 200
    assert client.get("/api/entities?kind=bogus").json()["items"] == []
    assert client.get("/api/entities.csv?kind=bogus").status_code == 200
    body = client.get("/api/entities.json?kind=bogus").json()
    assert body["count"] == 0 and body["items"] == []


def test_export_csv_ids_ignores_non_decimal(client):
    """معرّف غير قابل للتحويل (محارف digit غير عشرية) يُتجاهل بدل ردّ 500."""
    r = client.get("/api/export.csv?ids=1,²,⁰")
    assert r.status_code == 200


def test_oversized_int_params_return_400_not_500(client):
    """قيم عددية تتجاوز نطاق SQLite (2^63-1) تعطي 400 لا 500.

    `int` في مسارات FastAPI بلا حدّ أعلى، فتمرير قيمة ضخمة إلى SQLite يرفع
    OverflowError. نضمن تحويلها إلى طلب غير صالح بدل عطل داخلي.
    """
    huge = "9" * 20
    for path in (
        f"/reports/{huge}",
        f"/post/{huge}",
        f"/vault/{huge}",
        f"/api/reports/{huge}",
        f"/api/reports/{huge}/verification",
        f"/api/vault/items/{huge}",
        f"/api/posts/{huge}/comments",
        f"/api/export.csv?ids={huge}",
        f"/reports?page={huge}",
        f"/api/reports?offset={huge}",
    ):
        r = client.get(path)
        assert r.status_code == 400, f"{path} أعاد {r.status_code} بدل 400"


def test_oversized_query_params_are_clamped_not_500(client):
    """قيم `limit`/`hours` الضخمة في واجهات القراءة تُقصّ ولا تُعطي 500.

    هذه نقاط لم يشملها معالج OverflowError لأن الخطأ داخلها مختلف:
    `discovered_sources` تُدرج الرقم في جملة SQL فيرفع SQLite
    `IntegrityError: datatype mismatch`، و`urgent_reports` تحسب `timedelta(hours=…)`
    فيرفع `OverflowError` من داخل المعالِج نفسه. نضمن القصّ إلى حدّ آمن.
    """
    huge = "9" * 20
    for path in (
        f"/api/discovery?limit={huge}",
        f"/api/urgent?hours={huge}",
        f"/api/urgent?limit={huge}&hours={huge}",
    ):
        r = client.get(path)
        assert r.status_code == 200, f"{path} أعاد {r.status_code} بدل 200"
        assert isinstance(r.json().get("items", r.json().get("sources")), list)


def test_negative_limit_is_clamped_across_read_endpoints(client):
    """`limit=-1` لا يتجاوز حدّ الاستجابة (LIMIT -1 في SQLite = بلا حدّ).

    قبل الإصلاح كانت القيم السالبة تُمرَّر كما هي عبر `min(limit, …)` فيبقى
    `LIMIT -1` (بلا حدّ) وتُرجع النقطة السجلّ كاملًا (تسريب عرض/حمل). بعد الإصلاح
    تُقصّ السالبة إلى الحدّ الأدنى (صفّ واحد) والقيم الضخمة إلى `API_MAX_LIMIT`.
    """
    from app.config import API_MAX_LIMIT

    # بلاغات: السالبة تُقصّ إلى 1، وoffset السالب يصبح 0، والضخمة إلى الحدّ الأقصى
    neg = client.get("/api/reports?limit=-1&offset=-5").json()
    cap = client.get(f"/api/reports?limit={API_MAX_LIMIT}").json()
    assert len(neg["items"]) == 1
    assert neg["offset"] == 0
    assert len(cap["items"]) <= API_MAX_LIMIT
    assert len(neg["items"]) < len(cap["items"])  # لا تُرجع السجلّ كاملًا

    # بحث موحّد: السالبة تُقصّ إلى 1، والضخمة لا تتجاوز الحدّ
    assert client.get("/api/search?q=أطفال&limit=-1").json()["count"] == 1
    assert client.get(f"/api/search?q=أطفال&limit=99999").json()["count"] <= API_MAX_LIMIT

    # دول: السالبة تُقصّ إلى 1، والضخمة إلى الحدّ الأقصى (لا 250 بلا حدّ)
    assert len(client.get("/api/countries?limit=-1").json()["items"]) == 1
    assert len(client.get(f"/api/countries?limit=1000000").json()["items"]) == API_MAX_LIMIT

    # كيانات: السالبة تُقصّ إلى 1
    assert len(client.get("/api/entities?limit=-1").json()["items"]) == 1

    # تصدير CSV: صفّ بيانات واحد فقط عند limit=-1
    r = client.get("/api/export.csv?limit=-1")
    assert r.status_code == 200
    data_rows = [ln for ln in r.text.splitlines() if ln.strip()]
    assert len(data_rows) - 1 == 1  # مطروحًا صفّ الرؤوس


def test_entity_related_endpoint(client):
    r = client.get("/api/entities/شل/related")
    assert r.status_code == 200
    body = r.json()
    assert body["name"] == "شل"
    assert isinstance(body["items"], list)


def test_entity_related_unknown_returns_404(client):
    r = client.get("/api/entities/كيان-غير-موجود-أبداً/related")
    assert r.status_code == 404


def test_entity_page_has_relation_network(client):
    r = client.get("/entity/شل")
    assert r.status_code == 200
    assert "شبكة الارتباط" in r.text


def test_local_fonts_no_google_dependency(client):
    css = client.get("/static/css/style.css")
    assert css.status_code == 200
    assert "fonts.googleapis.com" not in css.text
    assert "/static/fonts/fonts.css" in css.text
    fonts = client.get("/static/fonts/fonts.css")
    assert fonts.status_code == 200
    assert "gstatic.com" not in fonts.text
    woff = client.get("/static/fonts/plex-arabic-400-normal-arabic.woff2")
    assert woff.status_code == 200
    assert len(woff.content) > 1000


# ---------------------------------------------------------------------------
# دعم اللغة (i18n)
# ---------------------------------------------------------------------------

def test_english_home_and_dir(client):
    r = client.get("/", params={"lang": "en"})
    assert r.status_code == 200
    assert 'lang="en"' in r.text
    assert 'dir="ltr"' in r.text
    assert "We document what someone" in r.text
    assert "Report a violation" in r.text
    # العربية تبقى متاحة RTL
    ar = client.get("/", params={"lang": "ar"})
    assert 'dir="rtl"' in ar.text and 'lang="ar"' in ar.text


def test_language_switch_link_and_route(client):
    r = client.get("/reports", params={"lang": "en"})
    assert "Switch to Arabic" in r.text
    assert 'hreflang="ar"' in r.text
    # مسار التبديل يثبّت الكوكي ويعيد التوجيه
    red = client.get("/lang/ar", params={"next": "/reports"}, follow_redirects=False)
    assert red.status_code == 303
    assert red.headers["location"] == "/reports"
    assert "mirsad_lang=ar" in red.headers.get("set-cookie", "")


def test_english_taxonomy_labels(client):
    r = client.get("/reports", params={"lang": "en"})
    assert "Human rights" in r.text
    assert "Environment" in r.text
    assert "Critical" in r.text
    assert "Report registry" in r.text


def test_english_map_and_stats(client):
    m = client.get("/map", params={"lang": "en"})
    assert "Violations map" in m.text and "Heatmap" in m.text and "3D globe" in m.text
    assert "Month" in m.text
    s = client.get("/stats", params={"lang": "en"})
    assert "Data dashboard" in s.text and "chart-cats" in s.text


def test_english_detail_pages(client):
    assert "Report data" in client.get("/reports/1", params={"lang": "en"}).text
    about = client.get("/about", params={"lang": "en"}).text
    assert "Why Mirsad?" in about and "Documentation scope" in about


# ---------------------------------------------------------------------------
# الخرائط: مكتبات مضمّنة محلياً + تتبّع زمني
# ---------------------------------------------------------------------------

def test_vendored_libraries_served(client):
    for path in (
        "/static/vendor/leaflet/leaflet.js",
        "/static/vendor/leaflet/leaflet.css",
        "/static/vendor/leaflet-markercluster/leaflet.markercluster.js",
        "/static/vendor/leaflet-markercluster/MarkerCluster.css",
        "/static/vendor/leaflet-heat/leaflet-heat.js",
        "/static/vendor/chartjs/chart.umd.min.js",
    ):
        r = client.get(path)
        assert r.status_code == 200, path
        assert len(r.content) > 200


def test_map_basemap_is_keyless_and_legible(client):
    r = client.get("/map")
    assert "arcgisonline.com" in r.text and "World_Dark_Gray_Base" in r.text
    # الطبقية الأساسية لا تحتاج مفتاح API
    assert "api_key" not in r.text and "access_token" not in r.text


def test_static_assets_cache_busted(client):
    r = client.get("/")
    assert "style.css?v=" in r.text


def test_map_has_cluster_heat_and_timeline(client):
    r = client.get("/map")
    assert r.status_code == 200
    assert "markerClusterGroup" in r.text
    assert "heatLayer" in r.text
    assert "map-range" in r.text and "map-play" in r.text
    # الكرة الأرضية ثلاثية الأبعاد + شريط زمني شهري
    assert "globe.gl.min.js" in r.text
    assert "Globe()" in r.text
    assert "pointsData" in r.text
    assert 'id="globe"' in r.text
    assert 'data-view="globe"' in r.text
    # الشريط الزمني يتدرّج شهريًا لا سنويًا
    assert "monthLabel" in r.text
    assert 'p.month > activeMonth' in r.text
    # الكرة الأرضية هي العرض الافتراضي عند توفّر WebGL، مع إمكانية فرض الخريطة المسطّحة عبر الرابط
    assert 'urlView ? urlView : (HAS_WEBGL ? "globe" : "flat")' in r.text
    # الخريطة المسطّحة لا تكرّر العالم
    assert "noWrap: true" in r.text
    # حدود الدول + نبض النقاط على الكرة
    assert "polygonsData" in r.text and "countries-110m.geojson" in r.text
    assert "ringsData" in r.text and "ringPropagationSpeed" in r.text
    # لا اعتماد على شبكات توصيل خارجية للمكتبات
    assert "unpkg.com" not in r.text and "cdn.jsdelivr.net" not in r.text


def test_globe_assets_served(client):
    for path in (
        "/static/vendor/globe.gl/globe.gl.min.js",
        "/static/vendor/globe.gl/earth-night.jpg",
    ):
        r = client.get(path)
        assert r.status_code == 200, path
        assert len(r.content) > 1000


def test_map_satellite_basemap_and_texture(client):
    r = client.get("/map")
    # بلاطات الصور الجوية للقمر الصناعي (بدون مفتاح) + نسيج الكوكب المحلي
    assert "World_Imagery" in r.text
    assert 'data-basemap="satellite"' in r.text
    assert "earth-blue-marble.jpg" in r.text
    assert "applyBasemap" in r.text and "applyGlobeTexture" in r.text


def test_map_severity_filter_and_country_selector(client):
    r = client.get("/map")
    assert 'id="sev-group"' in r.text
    assert 'data-sev="critical"' in r.text
    assert 'id="country-select"' in r.text
    assert 'id="provinces-toggle"' in r.text
    # منطق الاختيار والتكبير والولاية
    assert "selectCountry" in r.text and "loadCountryProvinces" in r.text
    assert "function focusCountry" in r.text
    assert "globe.pointOfView({ lat: c[0], lng: c[1]" in r.text


def test_map_search_and_reset_controls(client):
    r = client.get("/map")
    assert 'id="map-search"' in r.text
    assert 'id="map-reset"' in r.text
    assert 'id="map-no-results"' in r.text
    # المرشّح النصّي وإعادة الضبط مرتبطان بمنطق التصفية وإعادة الرسم
    assert "activeQ" in r.text
    assert "function syncToolbar" in r.text
    # تلميح التمرير فوق النقاط
    assert "bindTooltip" in r.text and "map-tip" in r.text


def test_map_shareable_url_state(client):
    r = client.get("/map")
    assert 'id="map-share"' in r.text
    # حالة الخريطة تُكتب في الرابط وتُستعاد منه عند التحميل
    assert "function updateUrl" in r.text
    assert "function applyUrlState" in r.text
    assert "history.replaceState" in r.text
    # الرابط يحفظ اللغة عند المشاركة
    assert 'p.set("lang", lang)' in r.text
    # طريقة العرض (مسطّحة) تُحفظ في الرابط
    assert 'p.set("view", "flat")' in r.text
    # اختصار "/" للتركيز على البحث
    assert 'e.key !== "/"' in r.text


def test_map_report_deeplink_highlights(client):
    r = client.get("/map", params={"r": "1"})
    assert "highlightReport" in r.text
    assert "is-selected" in r.text


def test_report_detail_links_to_map(client):
    r = client.get("/reports/1")
    assert 'href="/map?r=1"' in r.text


def test_map_country_param_prefills_initial_country(client):
    r = client.get("/map", params={"country": "eg"})
    assert 'INITIAL_COUNTRY = "EG"' in r.text
    # اختيار الدولة عبر الرابط يُفعّل التصفية على النقاط
    assert "activeCountryIso && isoForCountry(p.country) !== activeCountryIso" in r.text


def test_map_country_click_filter(client):
    r = client.get("/map")
    # طبقة حدود الدول قابلة للنقر لتحديد الدولة/إلغائها
    assert "countriesClickLayer" in r.text
    assert "function toggleCountryFromMap" in r.text
    assert "L.DomEvent.stopPropagation" in r.text
    # الكرة الأرضية تدعم النقر على الدول أيضاً
    assert "onPolygonClick" in r.text
    assert "isSelectedCountry" in r.text
    # تلميح الاستخدام ظاهر في المفتاح
    assert "اضغط على دولة لتحديدها" in r.text


def test_map_export_filtered(client):
    r = client.get("/map")
    assert 'id="map-export"' in r.text
    assert "function exportFiltered" in r.text
    assert 'data-exp="csv"' in r.text and 'data-exp="json"' in r.text
    # CSV بترميز متوافق مع Excel وبناء اسم الملف من المرشّحات
    assert "text/csv;charset=utf-8" in r.text
    assert "function exportName" in r.text
    assert "function csvCell" in r.text


def test_map_panel_redesign_markup(client):
    r = client.get("/map")
    # عناصر التصميم الجديد لللوحة البلاغات
    for cls in ("map-panel__flagwrap", "map-panel__titles", "map-panel__chips",
                "map-panel__item-tag", "map-panel__sev", "map-panel__list"):
        assert cls in r.text
    # قائمة التصدير المنسدلة
    assert "map-export-menu" in r.text


def test_map_country_bubbles_layer(client):
    r = client.get("/map")
    # طبقة الفقاعات: حجم حسب العدد ولون حسب المجال السائد
    assert 'data-layer="countries"' in r.text
    assert "function countryAggregates" in r.text
    assert "function bubbleRadius" in r.text
    assert "function renderBubbles" in r.text
    # الافتراضي هو فقاعات الدول
    assert 'class="map-toolbar__btn is-active" data-layer="countries"' in r.text
    assert 'var mode = "countries"' in r.text
    # النقر على الفقاعة يفتح بلاغات الدولة، وطبقة الفقاعات تُقبل في الرابط
    assert '"points", "countries", "clusters", "heat"' in r.text
    assert "updateLegendHint" in r.text


def test_map_bubble_count_numbers(client):
    r = client.get("/map")
    # رقم عدد البلاغات داخل دائرة الفقاعة على الخريطة المسطّحة
    assert "map-bubble-num" in r.text
    assert "L.divIcon" in r.text
    # ورقم مطابق على الكرة الأرضية عبر عناصر HTML
    assert "globe-num" in r.text
    assert "function bubbleNumEl" in r.text
    assert "function syncGlobeNumEls" in r.text
    assert ".htmlElementsData(" in r.text
    assert ".htmlElementVisibilityModifier(" in r.text


def test_map_globe_uses_round_bubbles_not_columns(client):
    r = client.get("/map")
    # الكرة تعتمد فقاعات دائرية (نصف قطر ثابت الارتفاع) بدل الأعمدة الرأسية
    assert "function globeBubbles" in r.text
    assert "d.radius != null ? d.radius : 0.24" in r.text
    assert "pointAltitude(0.012)" in r.text
    # لم تعد الكرة تستخدم ارتفاع/نصف قطر حسب الخطورة (الأعمدة)
    assert "SEV_ALT" not in r.text
    assert "SEV_GR" not in r.text


def test_province_geojson_files_served(client):
    r = client.get("/static/vendor/natural-earth/provinces/EG.geojson")
    assert r.status_code == 200
    body = r.json()
    assert body["type"] == "FeatureCollection" and len(body["features"]) > 5
    # خصائص الاسم العربي/الإنجليزي متوفّرة للتلميحات
    props = body["features"][0]["properties"]
    assert "name" in props and "iso" in props


def test_geo_api_includes_year(client):
    r = client.get("/api/geo")
    assert r.status_code == 200
    feats = r.json()["features"]
    assert feats
    assert all("year" in f["properties"] for f in feats)
    assert all(f["properties"]["year"] is not None for f in feats)
    years = [f["properties"]["year"] for f in feats]
    assert all(1900 <= y <= 2100 for y in years)
    # البيانات موزّعة على عدة سنوات ليعمل شريط السنة
    assert len(set(years)) >= 3


def test_stats_uses_chartjs(client):
    r = client.get("/stats")
    assert r.status_code == 200
    assert "/static/vendor/chartjs/chart.umd.min.js" in r.text
    assert "chart-month" in r.text


def test_no_external_library_cdn_in_pages(client):
    for path in ("/", "/stats", "/map", "/reports"):
        html = client.get(path).text
        assert "cdn.jsdelivr.net" not in html
        assert "unpkg.com" not in html
        assert "cdnjs.cloudflare.com" not in html


def test_sources_registry_lists_new_libs(client):
    from app import sources_registry
    names = {s["name"] for s in sources_registry.OPEN_SOFTWARE}
    assert "Chart.js" in names
    assert "Leaflet.heat" in names
    assert "Leaflet.markercluster" in names
    assert "globe.gl" in names
    assert "Natural Earth" in names


def test_natural_earth_geojson_served(client):
    r = client.get("/static/vendor/natural-earth/countries-110m.geojson")
    assert r.status_code == 200
    data = r.json()
    assert data["type"] == "FeatureCollection"
    assert len(data["features"]) > 150
    # حدّ أدنى من المتانة: الاسم موجود في الخصائص
    assert any((f.get("properties") or {}).get("name") for f in data["features"])


def test_theme_toggle_present_and_prepaint(client):
    for path in ("/", "/reports", "/map", "/stats"):
        html = client.get(path).text
        # زر تبديل السمة في الترويسة
        assert "data-theme-toggle" in html
        # سكربت يطبّق السمة قبل الرسم لمنع وميض السمة الخاطئة
        assert "mirsad.theme" in html
        assert "document.documentElement.dataset.theme" in html
        # خصائص الوصول
        assert 'aria-pressed="false"' in html


def test_theme_toggle_i18n(client):
    ar = client.get("/").text
    en = client.get("/?lang=en").text
    assert "الوضع النهاري" in ar
    assert "Light mode" in en
    # السكربت يعرف التسميات بالعربية والإنجليزية
    js = client.get("/static/js/app.js").text
    assert "التبديل إلى الوضع النهاري" in js
    assert "Switch to light mode" in js


def test_light_theme_css_variables_present(client):
    css = client.get("/static/css/style.css").text
    assert ':root[data-theme="light"]' in css
    # ألوان الوضع النهاري والليلي معرّفة كمتغيّرات
    assert "--masthead-bg" in css
    assert "--globe-bg" in css
    assert "--grain-blend" in css
    # زر السمة منسّق
    assert ".theme-toggle" in css
    assert ".theme-toggle__icon--sun" in css


def test_map_basemap_is_theme_aware(client):
    html = client.get("/map").text
    # طبقة فاتحة جديدة للوضع النهاري
    assert "World_Light_Gray_Base" in html
    assert "function isLightTheme" in html
    assert "function baseLayerFor" in html
    # قوام فاتح للكرة الأرضية
    assert "light: \"/static/vendor/globe.gl/earth-blue-marble.jpg\"" in html
    # يستمع لحدث تبديل السمة
    assert '"mirsad:theme"' in html


def test_stats_charts_are_theme_aware(client):
    html = client.get("/stats").text
    # ألوان الرسوم تُقرأ من متغيّرات السمة لا من قيم ثابتة
    assert "function themeColors" in html
    assert "getComputedStyle(document.documentElement)" in html
    # تُحدَّث عند تبديل السمة
    assert '"mirsad:theme"' in html
    assert 'c.update("none")' in html


def test_static_assets_are_cache_busted(client):
    html = client.get("/").text
    # ملفات CSS و JS تحمل نسخة لطرد الكاش عند تغيير الأصول
    assert "/static/css/style.css?v=" in html
    assert "/static/js/app.js?v=" in html


def test_arabic_orthography_consistency(client):
    """لا تُستخدم صيغة التنوين القديمة (اً) على الألف في نصوص الواجهة العربية."""
    from app.i18n import STRINGS
    bad = [k for k, v in STRINGS.items() if "اً" in v.get("ar", "")]
    assert bad == [], f"تواريخ تنوين قديمة في: {bad}"
    # توحيد مصطلح إعادة الضبط في شاشة السجل
    assert STRINGS["reports.reset"]["ar"] == "إعادة الضبط"
    assert "إعادة الضبط" in STRINGS["map.reset"]["ar"]


def test_arabic_action_verbs_consistent(client):
    """أفعال الإرشاد على الخريطة موحّدة على «اضغط» بدل «انقر»."""
    from app.i18n import STRINGS
    assert "انقر" not in STRINGS["map.lede"]["ar"]
    assert "انقر" not in STRINGS["map.bubble_hint"]["ar"]
    assert "اضغط" in STRINGS["map.lede"]["ar"]
    assert "اضغط" in STRINGS["map.bubble_hint"]["ar"]


def test_command_palette_and_new_count(client):
    """قائمة الأوامر موجودة، وعدّاد «جديد» يعمل عبر /api/new-count."""
    html = client.get("/").text
    assert 'id="command-palette"' in html
    assert "data-command-open" in html
    assert "navItems" in html
    # عدّاد الجديد: بلا معامل ⇒ صفر، ومع since قديم ⇒ عدد موجب.
    base = client.get("/api/new-count").json()
    assert base["new"] == 0 and base["latest"]
    after = client.get("/api/new-count", params={"since": "2000-01-01 00:00:00"}).json()
    assert after["new"] > 0


def test_compact_header_and_footer_columns(client):
    """الترويسة المضغوطة وأعمدة التذييل القابلة للطيّ موجودة في كل الصفحات."""
    html = client.get("/reports").text
    assert "footer__col" in html
    assert "data-footer-toggle" in html
    assert "cmd-trigger" in html


def test_reports_facets_and_breadcrumbs(client):
    """سجل البلاغات: فتات تنقّل، شريط أوجه قابل للنقر، ومرشّح نشط."""
    html = client.get("/reports?category=environment").text
    assert 'class="breadcrumbs"' in html
    assert 'data-filters-toggle' in html
    assert 'class="facet is-active"' in html
    assert "facet__n" in html
    # الحالة الفارغة تعرض إجراءات بديلة.
    empty = client.get("/reports?q=zzzzzznomatch").text
    assert "empty-state__actions" in empty
    assert "reports.empty_title" not in empty


def test_report_card_enrichment(client):
    """بطاقة البلاغ تعرض شارة «جديد» وعدّاد المصادر."""
    html = client.get("/reports").text
    assert "report-card__chips" in html
    assert "source-count" in html


def test_report_detail_actions_and_ref(client):
    """تفاصيل البلاغ: إجراءات توثيق/مصدر/تصحيح، وتلميح البلاغ المرجعي في نموذج الإرسال."""
    detail = client.get("/reports/9").text  # بلاغ غير موثّق
    assert "intent=validate" in detail
    assert "intent=source" in detail
    assert "intent=correction" in detail
    verified = client.get("/reports/1").text
    assert "intent=validate" not in verified
    ref = client.get("/submit?ref=1&intent=source").text
    assert "notice--ref" in ref
    assert "submit.ref_title" not in ref


def test_stats_kpi_and_derived_metrics(client):
    """لوحة البيانات: مؤشرات مشتقّة (نسبة التوثيق، المتوسط، أعلى مجال/شهر)."""
    html = client.get("/stats").text
    assert "kpi-grid" in html
    assert "kpi__val" in html
    assert "data-geo-toggle" in html
    assert "data-summary-text" in html
    assert "stats.kpi_hint" not in html
    assert "data-table" in html


def test_countries_filters_and_counts(client):
    """صفحة الدول: عدّاد نتائج، زر مسح، وترتيب حسب التوثيق."""
    html = client.get("/countries").text
    assert "data-country-count" in html
    assert "data-country-clear" in html
    assert "data-country-empty" in html
    assert 'value="verified"' in html


def test_entities_filters_and_counts(client):
    """صفحة الكيانات: عدّاد نتائج وزر مسح."""
    html = client.get("/entities").text
    assert "data-entity-count" in html
    assert "data-entity-clear" in html
    assert "data-entity-empty" in html


def test_submit_counters_consent_and_clear(client):
    """نموذج الإرسال: عدّادات أحرف، إقرار، وزر مسح المسودة."""
    html = client.get("/submit").text
    assert "data-counter" in html
    assert "field__count" in html
    assert "data-consent" in html
    assert "data-draft-clear" in html
    assert "submit.consent" not in html


def test_country_cards_verified_badge(client):
    """بطاقات بلاغات صفحة الدولة تعرض شارة موثّق عند التوفّر."""
    html = client.get("/country/سوريا").text
    assert "report-card__chips" in html
    assert "chip--verified" in html


def test_error_page_has_search_and_links(client):
    """صفحة الخطأ تعرض بحثًا وروابط مساعدة."""
    html = client.get("/no-such-page-xyz", headers={"accept": "text/html"}).text
    assert "error-state__search" in html
    assert "error-state__links" in html


def test_map_filters_toggle_and_panel_sort(client):
    """الخريطة: زر طيّ المرشّحات وترتيب لوحة الدولة بالخطورة/التاريخ."""
    html = client.get("/map").text
    assert "map-filters-toggle" in html
    assert "map-filters" in html
    assert "data-panel-sort" in html
    assert "map.panel_sort_sev" not in html
    assert "map.panel_sort_date" not in html


def test_report_detail_confidence_and_toc(client):
    """تفاصيل البلاغ: شريحة درجة الثقة وفهرس المحتويات."""
    html = client.get("/reports/1").text
    assert "conf-chip" in html
    assert "doc-toc" in html
    assert "sec-details" in html
    assert "report.toc" not in html


def test_home_quicknav(client):
    """الرئيسية: تصفّح سريع إلى الأقسام الأساسية."""
    html = client.get("/").text
    assert "hero__quicknav" in html
    assert 'href="/entities"' in html
    assert "home.quicknav" not in html


def test_category_empty_state_and_badges(client):
    """صفحة المجال: حالة فارغة غنية وشارة موثّق على البطاقات."""
    html = client.get("/category/environment").text
    assert "empty-state__actions" in html or "report-card__chips" in html


def test_base_has_live_region(client):
    """التخطيط الأساسي: منطقة إعلان حيّة لقارئات الشاشة."""
    html = client.get("/").text
    assert 'data-live-region' in html
    assert 'aria-live="polite"' in html


def test_reports_density_and_sources_column(client):
    """سجل البلاغات: مفتاح كثافة العرض وعمود المصادر في الجدول."""
    html = client.get("/reports").text
    assert "data-density-btn" in html
    assert 'data-density-btn="compact"' in html
    assert "reports.density" not in html
    assert "reports.col_sources" not in html
    # عمود المصادر يُضاف إلى الجدول.
    assert "data-report-table" in html


def test_tables_have_accessible_caption(client):
    """جداول المصادر والبلاغات تحمل وصفًا مخفيًّا لقارئات الشاشة."""
    assert "visually-hidden" in client.get("/sources").text
    assert "visually-hidden" in client.get("/reports").text


def test_offline_quick_links(client):
    """صفحة عدم الاتصال: روابط سريعة للأقسام الأساسية."""
    html = client.get("/offline").text
    assert "offline-links" in html
    assert "ui.offline_try" not in html


def test_entity_empty_state_and_badges(client):
    """صفحة الكيان: بطاقات بلاغات بشارة «جديد»/«موثّق» أو حالة فارغة غنية."""
    html = client.get("/entity/سوريا").text
    assert ("report-card__chips" in html) or ("empty-state__actions" in html)


def test_report_detail_doc_toc_active(client):
    """تفاصيل البلاغ: الفهرس يدعم تمييز القسم الحالي (is-active)."""
    html = client.get("/reports/1").text
    assert "doc-toc" in html
    assert "IntersectionObserver" in html


def test_report_detail_occurrence_timeline(client):
    """تفاصيل البلاغ: مسار الوقوع/التوثيق/التحقق يحمل تواريخ العرض."""
    html = client.get("/reports/1").text
    assert "report-timeline" in html
    assert "report.timeline_when" not in html
    # يظهر مسار الحالة إلى جانب المسار الزمني
    assert "status-path" in html


# ---------------------------------------------------------------------------
# الخط الزمني: صفحة مستقلة + عدم تكرار «الأحدث» في الرئيسية
# ---------------------------------------------------------------------------

def test_timeline_page_renders(client):
    """صفحة /timeline تعمل وتعرض محطات زمنية مجمَّعة."""
    r = client.get("/timeline")
    assert r.status_code == 200
    assert "timeline--full" in r.text
    assert "timeline__group" in r.text
    assert "timeline__group-date" in r.text
    # التجميع الافتراضي شهري
    assert 'href="/timeline?granularity=month"' in r.text


def test_timeline_granularity_variants(client):
    """التجميع يدعم اليوم/الشهر/السنة بلا خطأ."""
    import re
    for unit in ("day", "month", "year"):
        r = client.get("/timeline", params={"granularity": unit})
        assert r.status_code == 200, unit
        keys = re.findall(r'<time class="timeline__group-date" datetime="([^"]+)"', r.text)
        assert keys, unit
        # مفتاح التجميع يطابق الطول المتوقّع (4/7/10)
        assert all(len(k) == {"year": 4, "month": 7, "day": 10}[unit] for k in keys), (unit, keys[:3])
    # قيمة غير صالحة ترجع للافتراضي بلا خطأ
    assert client.get("/timeline", params={"granularity": "hour"}).status_code == 200


def test_timeline_filters(client):
    """مرشّحات المجال والخطورة والدولة تُطبَّق على الخط الزمني."""
    r = client.get("/timeline", params={"category": "human_rights"})
    assert r.status_code == 200
    assert "timeline__group" in r.text
    empty = client.get("/timeline", params={"category": "no_such_category"})
    assert empty.status_code == 200
    assert "empty-state__actions" in empty.text


def test_home_timeline_distinct_from_latest(client):
    """الخط الزمني في الرئيسية يختلف عن قسم «الأحدث»: محطات موزّعة زمنيًا."""
    import re
    html = client.get("/?lang=ar").text
    assert 'id="home-latest-grid"' in html
    assert "timeline__relative" in html
    assert "timeline__item" in html
    # المحطات موزّعة على أشهر مختلفة، لا تكرار لأحدث ستة بلاغات نفسها
    months = re.findall(r'<time class="timeline__date" datetime="(\d{4}-\d{2})', html)
    assert len(set(months)) >= 3, months


def test_home_timeline_uses_occurrence_date(client):
    """الخط الزمني يعرض تاريخ الوقوع (occurred_on) داخل عنصر <time>."""
    import re
    html = client.get("/?lang=ar").text
    m = re.search(r'<ol class="timeline">.*?</ol>', html, re.S)
    assert m, "قسم الخط الزمني غير موجود"
    assert re.search(r'<time class="timeline__date" datetime="\d{4}-\d{2}-\d{2}"', m.group(0))


def test_map_month_timeline_filter(client):
    """الخريطة: الشريط الزمني شهري ويعرض اسم الشهر."""
    r = client.get("/map", params={"lang": "ar"})
    assert "monthLabel" in r.text
    assert "timelineMonths" in r.text
    # لا يتبقّى منطق سنة قديم في الشريط
    assert "applyYear" not in r.text


def test_stats_timeline_two_datasets(client):
    """لوحة البيانات: رسم الاتجاه يعرض الإجمالي والموثّقة معًا."""
    r = client.get("/stats")
    assert r.status_code == 200
    assert "monthsVerified" in r.text
    assert "الإجمالي" in r.text and "الموثّقة" in r.text
    assert "stats.timeline_verified" not in r.text


def test_timeline_in_nav_and_sitemap(client):
    """الخط الزمني مُدرَج في التنقّل وملف الموقع."""
    assert 'href="/timeline"' in client.get("/").text
    assert "/timeline" in client.get("/sitemap.xml").text


def test_reports_occurred_sort(client):
    """سجل البلاغات يدعم الترتيب بتاريخ الوقوع (المستخدم في الخط الزمني)."""
    r = client.get("/reports", params={"sort": "occurred"})
    assert r.status_code == 200
    assert 'value="occurred" selected' in r.text


# ---------------------------------------------------------------------------
# المجتمع: الأعضاء (الدفعة 1 من المنصّة الاجتماعية)
# ---------------------------------------------------------------------------

def test_members_page_ok(client):
    """صفحة الأعضاء تعمل وتُدرج بطاقات وعدّادًا."""
    r = client.get("/members")
    assert r.status_code == 200
    assert "member-grid" in r.text
    assert "member-card" in r.text
    assert "members.roles_title" not in r.text  # مفاتيح غير مترجمة لا تظهر


def test_members_are_seeded(conn):
    """البيانات الأولية للأعضاء موجودة عبر أدوار متعدّدة."""
    from app import social
    assert social.count_members(conn) >= 20
    roles = social.member_counts(conn)["role"]
    for key in ("admin", "moderator", "verifier", "activist", "member"):
        assert roles.get(key, 0) >= 1, key


def test_members_public_fields_only(client):
    """واجهة الأعضاء لا تكشف أي حقول خاصّة أو شخصية."""
    data = client.get("/api/members").json()
    assert data["count"] >= 20
    allowed = {"handle", "display_name", "role", "status", "country",
               "langs", "interests", "org", "verified"}
    for m in data["members"]:
        assert set(m) == allowed


def test_members_filter_role(client):
    """مرشّح الدور يعمل ويعيد أعضاء ذلك الدور فقط."""
    data = client.get("/api/members", params={"role": "verifier"}).json()
    assert data["count"] >= 1
    assert all(m["role"] == "verifier" for m in data["members"])


def test_member_detail_and_404(client):
    """صفحة عضو موجود تعمل، وغير الموجود تُعيد 404."""
    ok = client.get("/member/mirsad_admin")
    assert ok.status_code == 200
    assert "mirsad_admin" in ok.text
    missing = client.get("/member/does-not-exist")
    assert missing.status_code == 404
    assert "member.not_found" not in missing.text


def test_members_csv_export(client):
    """تصدير CSV للأعضاء يعمل ويحوي رأس الأعمدة."""
    r = client.get("/api/members.csv")
    assert r.status_code == 200
    assert "text/csv" in r.headers["content-type"]
    assert "المعرّف" in r.text and "الدور" in r.text


def test_members_in_nav_and_sitemap(client):
    """رابط المجتمع مُدرَج في التنقّل وملف الموقع."""
    assert 'href="/members"' in client.get("/").text
    assert "/members" in client.get("/sitemap.xml").text


def test_members_page_english(client):
    """النسخة الإنجليزية تُعرّب التسميات وتستخدم المحتوى الإنجليزي."""
    r = client.get("/members", params={"lang": "en"})
    assert r.status_code == 200
    assert "Community members" in r.text
    assert "Verifier" in r.text


# ---------------------------------------------------------------------------
# المجتمع: المنشورات والتغذية (الدفعة 2)
# ---------------------------------------------------------------------------

def test_posts_feed_ok(client):
    """تغذية المجتمع تعمل وتعرض بطاقات منشورات."""
    r = client.get("/posts")
    assert r.status_code == 200
    assert "post-feed" in r.text and "post-card" in r.text
    assert "posts.title" not in r.text


def test_posts_are_seeded(conn):
    """المنشورات الأولية موجودة عبر أنواع متعدّدة."""
    from app import social
    assert social.count_posts(conn) >= 15
    kinds = social.post_counts(conn)["kind"]
    for key in ("update", "news", "analysis", "testimony", "call", "campaign"):
        assert kinds.get(key, 0) >= 1, key


def test_posts_filter_kind(client):
    """مرشّح نوع المنشور يعمل."""
    data = client.get("/api/posts", params={"kind": "call"}).json()
    assert data["count"] >= 1
    assert all(p["kind"] == "call" for p in data["posts"])


def test_posts_search_arabic_normalized(client):
    """البحث في المنشورات يطبّع النصّ العربي (اطفال يطابق أطفال)."""
    data = client.get("/api/posts", params={"q": "تحليل"}).json()
    assert data["count"] >= 1


def test_post_detail_and_404(client):
    """صفحة منشور موجود تعمل وغير الموجود تُعيد 404."""
    ok = client.get("/post/1")
    assert ok.status_code == 200
    missing = client.get("/post/999999")
    assert missing.status_code == 404
    assert "posts.not_found" not in missing.text


def test_posts_hidden_not_listed(conn):
    """الحذف الناعم يُخفي المنشور من التغذية العامة."""
    from app import social
    before = social.count_posts(conn)
    pid = social.insert_post(conn, author_handle="noor.mod", title="منشور مؤقّت",
                             body="سيُخفى فورًا للاختبار")
    assert social.count_posts(conn) == before + 1
    assert social.hide_post(conn, pid) is True
    assert social.count_posts(conn) == before
    assert social.post_by_id(conn, pid)["status"] == "hidden"


def test_posts_in_sitemap_and_nav(client):
    """روابط المنشورات مُدرَجة في التنقّل وملف الموقع."""
    assert 'href="/posts"' in client.get("/").text
    assert "/posts" in client.get("/sitemap.xml").text


def test_posts_page_english(client):
    """النسخة الإنجليزية للتغذية تستخدم الترجمة."""
    r = client.get("/posts", params={"lang": "en"})
    assert r.status_code == 200
    assert "Community feed" in r.text


# ---------------------------------------------------------------------------
# المجتمع: التفاعل والتعليقات (الدفعة 3)
# ---------------------------------------------------------------------------

def test_post_detail_shows_reactions_and_comments(client):
    """صفحة المنشور تعرض أزرار التفاعل وقائمة التعليقات."""
    r = client.get("/post/1")
    assert r.status_code == 200
    assert "data-post-actions" in r.text
    assert 'data-react="support"' in r.text
    assert "comment-list" in r.text


def test_react_toggle_api(client, conn):
    """نقطة التفاعل تبدّل الحالة وتُحدّث العدّاد."""
    from app import ratelimit, social
    ratelimit.reset()
    before = social.reaction_count(conn, 1, "like")
    r = client.post("/api/posts/1/react", params={"handle": "noor.mod", "kind": "like"})
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] and body["active"] is True
    assert body["count"] == before + 1
    r2 = client.post("/api/posts/1/react", params={"handle": "noor.mod", "kind": "like"})
    assert r2.json()["active"] is False
    assert r2.json()["count"] == before


def test_react_rejects_unknown_member(client):
    """التفاعل يتطلّب عضوًا صالحًا نشطًا."""
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/posts/1/react", params={"handle": "ghost", "kind": "like"})
    assert r.status_code == 400
    assert r.json()["error"] == "invalid_member"


def test_add_comment_and_tree(client, conn):
    """إضافة تعليق وردّ يبنيان شجرة صحيحة."""
    from app import ratelimit, social
    ratelimit.reset()
    before = social.count_comments(conn, 2)
    r = client.post("/api/posts/2/comment", params={"handle": "noor.mod", "body": "تعليق اختباري"})
    assert r.status_code == 200
    cid = r.json()["id"]
    r2 = client.post("/api/posts/2/comment", params={"handle": "sami.verify",
                                                     "body": "ردّ اختباري", "parent_id": cid})
    assert r2.status_code == 200
    assert social.count_comments(conn, 2) == before + 2
    tree = social.comment_tree(conn, 2)
    root = next(c for c in tree if c["id"] == cid)
    assert any(rep["id"] == r2.json()["id"] for rep in root["replies"])


def test_comment_validation(client):
    """التعليق الفارغ أو الطويل جدًّا يُرفض."""
    from app import ratelimit
    ratelimit.reset()
    assert client.post("/api/posts/2/comment", params={"handle": "noor.mod", "body": "x"}).status_code == 400
    assert client.post("/api/posts/2/comment", params={"handle": "noor.mod", "body": "ا" * 2500}).status_code == 400


def test_report_post_queues_for_moderation(client, conn):
    """الإبلاغ عن منشور يُدرج في طابور الإشراف."""
    from app import ratelimit, social
    ratelimit.reset()
    before = social.count_content_reports(conn)
    r = client.post("/api/posts/3/report", params={"handle": "noor.mod", "reason": "spam"})
    assert r.status_code == 200
    assert social.count_content_reports(conn) == before + 1
    data = client.get("/api/content-reports").json()
    assert data["count"] >= 1


def test_report_requires_reason(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/posts/3/report", params={"handle": "noor.mod"})
    assert r.status_code == 400


def test_block_and_unblock_member(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/members/sami.verify/block", params={"owner": "noor.mod"})
    assert r.status_code == 200 and r.json()["changed"] is True
    assert "sami.verify" in social.blocked_handles(conn, "noor.mod")
    r2 = client.post("/api/members/sami.verify/block", params={"owner": "noor.mod", "action": "unblock"})
    assert r2.json()["changed"] is True
    assert "sami.verify" not in social.blocked_handles(conn, "noor.mod")


def test_react_rate_limited(client, conn):
    """حدّ المعدّل يمنع الطلبات المفرطة (حدّ التفاعل 40/دقيقة)."""
    from app import ratelimit
    ratelimit.reset()
    codes = []
    for i in range(45):
        r = client.post("/api/posts/1/react",
                        params={"handle": "noor.mod", "kind": "support"})
        codes.append(r.status_code)
    assert 429 in codes


def test_comments_api_404(client):
    assert client.get("/api/posts/999999/comments").status_code == 404


# ---------------------------------------------------------------------------
# المجتمع: المجموعات (الدفعة 4)
# ---------------------------------------------------------------------------

def test_groups_directory_ok(client):
    r = client.get("/groups")
    assert r.status_code == 200
    assert "group-card" in r.text
    assert "groups.title" not in r.text


def test_groups_are_seeded(conn):
    from app import social
    assert social.count_groups(conn) >= 6
    kinds = social.group_counts(conn)["kind"]
    assert kinds.get("working", 0) >= 1 and kinds.get("verification", 0) >= 1


def test_secret_group_hidden_from_listing(client, conn):
    """المجموعة السرّية لا تظهر في الدليل ولا عبر الـ API."""
    from app import social
    slugs = [g["slug"] for g in social.query_groups(conn)]
    assert "crisis-response" not in slugs
    assert "/group/crisis-response" not in client.get("/groups").text
    assert client.get("/group/crisis-response").status_code == 404
    assert client.get("/api/groups/crisis-response").status_code == 404


def test_group_detail_shows_roster_and_feed(client):
    r = client.get("/group/water-watch")
    assert r.status_code == 200
    assert "roster-list" in r.text
    assert "post-feed" in r.text
    assert "data-group-actions" in r.text


def test_group_join_public_and_private(client, conn):
    """الانضمام مباشر للعام وبانتظار الموافقة للخاص."""
    from app import ratelimit, social
    ratelimit.reset()
    pub = social.group_by_slug(conn, "translation-desk")
    priv = social.group_by_slug(conn, "moderation-council")
    r = client.post("/api/groups/translation-desk/join", params={"handle": "maya.act"})
    assert r.status_code == 200 and r.json()["status"] == "active"
    r2 = client.post("/api/groups/moderation-council/join", params={"handle": "maya.act"})
    assert r2.json()["status"] == "pending"
    assert social.group_member_status(conn, priv["id"], "maya.act") == "pending"
    assert social.group_member_status(conn, pub["id"], "maya.act") == "active"


def test_group_approve_and_leave(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    priv = social.group_by_slug(conn, "moderation-council")
    client.post("/api/groups/moderation-council/join", params={"handle": "maya.act"})
    assert social.approve_group_member(conn, priv["id"], "maya.act") is True
    assert social.group_role(conn, priv["id"], "maya.act") == "member"
    r = client.post("/api/groups/moderation-council/leave", params={"handle": "maya.act"})
    assert r.json()["left"] is True


def test_group_owner_cannot_leave(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    owner = social.group_by_slug(conn, "water-watch")["owner"]
    r = client.post("/api/groups/water-watch/leave", params={"handle": owner})
    assert r.json()["left"] is False


def test_group_api_requires_member(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/groups/water-watch/join", params={"handle": "ghost"})
    assert r.status_code == 400


def test_groups_in_sitemap_and_nav(client):
    assert 'href="/groups"' in client.get("/").text
    assert "/groups" in client.get("/sitemap.xml").text


def test_groups_page_english(client):
    r = client.get("/groups", params={"lang": "en"})
    assert r.status_code == 200
    assert "Groups &amp; communities" in r.text or "Groups & communities" in r.text


# ---------------------------------------------------------------------------
# المجتمع: الرسائل والمحادثات (الدفعة 5)
# ---------------------------------------------------------------------------

def test_messages_page_ok(client):
    r = client.get("/messages", params={"handle": "sami.verify"})
    assert r.status_code == 200
    assert "messages-layout" in r.text
    assert "messages.privacy_note" not in r.text


def test_conversations_seeded(conn):
    from app import social
    convos = social.conversations_for_member(conn, "sami.verify")
    assert len(convos) >= 2
    assert all(c["message_count"] >= 1 for c in convos)


def test_conversation_access_requires_membership(conn):
    from app import social
    convos = social.conversations_for_member(conn, "sami.verify")
    cid = convos[0]["id"]
    assert social.conversation_for_member(conn, cid, "sami.verify") is not None
    assert social.conversation_for_member(conn, cid, "lina.act") is None


def test_send_message_requires_participant(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    convos = social.conversations_for_member(conn, "sami.verify")
    cid = convos[0]["id"]
    r = client.post(f"/api/conversations/{cid}/messages",
                    params={"handle": "lina.act", "body": "مرحبا"})
    assert r.status_code == 404
    r2 = client.post(f"/api/conversations/{cid}/messages",
                     params={"handle": "sami.verify", "body": "رسالة اختبار"})
    assert r2.status_code == 200 and r2.json()["ok"] is True


def test_send_message_validation(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    cid = social.conversations_for_member(conn, "sami.verify")[0]["id"]
    assert client.post(f"/api/conversations/{cid}/messages",
                       params={"handle": "sami.verify", "body": "  "}).status_code == 400


def test_conversation_api_404_for_outsider(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.get("/api/conversations/1", params={"handle": "lina.act"})
    assert r.status_code == 404


def test_start_direct_conversation(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/conversations/direct",
                    params={"handle": "sami.verify", "target": "dina.act"})
    assert r.status_code == 200 and r.json()["ok"] is True
    cid = r.json()["id"]
    assert social.conversation_for_member(conn, cid, "dina.act") is not None
    # إعادة الطلب تعيد نفس المحادثة
    r2 = client.post("/api/conversations/direct",
                     params={"handle": "sami.verify", "target": "dina.act"})
    assert r2.json()["id"] == cid


def test_start_direct_self_rejected(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/conversations/direct",
                    params={"handle": "sami.verify", "target": "sami.verify"})
    assert r.status_code == 400


def test_messages_in_nav(client):
    assert 'href="/messages"' in client.get("/").text


# ---------------------------------------------------------------------------
# التحقّق من الحقائق والتوثيق (الدفعة 6)
# ---------------------------------------------------------------------------

def test_verification_page_ok(client):
    r = client.get("/verification")
    assert r.status_code == 200
    assert "claim-card" in r.text
    assert "verify.title" not in r.text


def test_claims_seeded(conn):
    from app import social
    assert social.count_claims(conn) >= 5
    counts = social.claim_counts(conn)["status"]
    assert counts.get("verified", 0) >= 1 and counts.get("debunked", 0) >= 1


def test_claim_detail_shows_sources_and_timeline(client):
    r = client.get("/verification/CLM-0001")
    assert r.status_code == 200
    assert "source-list" in r.text
    assert "verify-timeline" in r.text
    assert "data-claim-actions" in r.text


def test_claim_404(client):
    assert client.get("/verification/CLM-9999").status_code == 404
    assert client.get("/api/claims/CLM-9999").status_code == 404


def test_claim_confidence_scores(conn):
    from app import social
    row = social.claim_by_ref(conn, "CLM-0001")
    sources = social.claim_sources(conn, row["id"])
    conf = social._claim_confidence(row["status"], sources)
    assert conf["level"] == "high" and conf["score"] >= 70
    deb = social.claim_by_ref(conn, "CLM-0006")
    assert social._claim_confidence(deb["status"], [])["level"] == "debunked"


def test_approve_requires_two_sources(client, conn):
    """التوثيق يتطلّب مصدرين على الأقلّ؛ بمصدر واحد يبقى قيد المراجعة."""
    from app import ratelimit, social
    ratelimit.reset()
    # ادّعاء بمصدر واحد (CLM-0005) -> التأكيد يبقى pending
    r = client.post("/api/claims/CLM-0005/review",
                    params={"handle": "sami.verify", "decision": "approve", "note": "ok"})
    assert r.status_code == 200 and r.json()["status"] == "pending"
    # إضافة مصدر ثانٍ ثم التأكيد -> verified
    client.post("/api/claims/CLM-0005/sources",
                params={"handle": "sami.verify", "label": "مصدر ثانٍ"})
    r2 = client.post("/api/claims/CLM-0005/review",
                     params={"handle": "sami.verify", "decision": "approve"})
    assert r2.json()["status"] == "verified"


def test_debunk_decision(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/claims/CLM-0002/review",
                    params={"handle": "hala.verify", "decision": "debunk", "note": "مصدر مزوّر"})
    assert r.json()["status"] == "debunked"
    assert social.claim_by_ref(conn, "CLM-0002")["status"] == "debunked"


def test_review_invalid_decision(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/claims/CLM-0001/review",
                    params={"handle": "sami.verify", "decision": "nonsense"})
    assert r.status_code == 400


def test_assign_claim(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/claims/CLM-0005/assign",
                    params={"handle": "sami.verify", "assignee": "ziad.act"})
    assert r.json()["ok"] is True
    assert social.claim_by_ref(conn, "CLM-0005")["assignee_handle"] == "ziad.act"


def test_claim_review_requires_member(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/claims/CLM-0001/review",
                    params={"handle": "ghost", "decision": "approve"})
    assert r.status_code == 400


def test_verification_in_nav_and_sitemap(client):
    assert 'href="/verification"' in client.get("/").text
    assert "/verification" in client.get("/sitemap.xml").text


def test_verification_page_english(client):
    r = client.get("/verification", params={"lang": "en"})
    assert r.status_code == 200
    assert "Fact-checking" in r.text


# ---------------------------------------------------------------------------
# الإشراف والحوكمة (الدفعة 7)
# ---------------------------------------------------------------------------

def test_moderation_page_ok(client):
    r = client.get("/moderation")
    assert r.status_code == 200
    assert "data-mod-console" in r.text
    assert "mod.title" not in r.text


def test_moderation_seeded(conn):
    from app import social
    stats = social.moderation_stats(conn)
    assert stats["by_action"].get("warn", 0) >= 1
    assert stats["by_action"].get("hide_content", 0) >= 1
    assert social.recent_audit(conn)


def test_moderation_requires_moderator_role(client):
    """عضو عادي لا يستطيع تطبيق إجراء إشراف (403)."""
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/moderation/actions",
                    params={"handle": "sami.verify", "target_kind": "member",
                            "target_handle": "omar.act", "action": "warn",
                            "reason": "سبب كافٍ للتجربة"})
    assert r.status_code == 403


def test_moderation_reason_mandatory(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/moderation/actions",
                    params={"handle": "noor.mod", "target_kind": "member",
                            "target_handle": "omar.act", "action": "warn", "reason": "خ"})
    assert r.status_code == 400 and r.json()["error"] == "reason_required"


def test_moderation_escalation_required(client, conn):
    """التعليق/الحظر يتطلّبان سابقة إشرافية (educate-first)."""
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/moderation/actions",
                    params={"handle": "noor.mod", "target_kind": "member",
                            "target_handle": "dina.act", "action": "ban",
                            "reason": "سبب مطوّل بما يكفي للحظر الدائم هنا"})
    assert r.status_code == 400 and r.json()["error"] == "escalation_required"
    # بعد تحذير مسبق يُسمح بالتعليق المؤقّت
    client.post("/api/moderation/actions",
                params={"handle": "noor.mod", "target_kind": "member",
                        "target_handle": "dina.act", "action": "warn", "reason": "تحذير أوّلي"})
    r2 = client.post("/api/moderation/actions",
                     params={"handle": "noor.mod", "target_kind": "member",
                             "target_handle": "dina.act", "action": "mute",
                             "reason": "تكرار الإزعاج", "days": 3})
    assert r2.status_code == 200 and r2.json()["ok"] is True
    assert social.active_restriction(conn, "dina.act") is not None


def test_ban_reason_must_be_long(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/moderation/actions",
                    params={"handle": "noor.mod", "target_kind": "member",
                            "target_handle": "khaled.act", "action": "ban",
                            "reason": "سبب قصير جدًا هنا"})
    assert r.status_code == 400 and r.json()["error"] == "ban_reason_too_short"


def test_report_state_requires_moderator(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    rid = social.report_content(conn, "post", 1, "spam", "sami.verify")
    assert client.post(f"/api/moderation/reports/{rid}/state",
                       params={"handle": "sami.verify", "state": "resolved"}).status_code == 403
    ok = client.post(f"/api/moderation/reports/{rid}/state",
                     params={"handle": "noor.mod", "state": "resolved"})
    assert ok.status_code == 200 and ok.json()["ok"] is True


def test_appeal_flow(client, conn):
    """عضو يقدّم استئنافًا؛ مشرف يقبله فيُرفع إجراء المحتوى."""
    from app import ratelimit, social
    ratelimit.reset()
    res = social.apply_moderation(conn, target_kind="member", target_id=0,
                                  target_handle="fadi.act", action="warn",
                                  reason="تحذير أوّلي للاختبار", moderator="noor.mod")
    assert res["ok"] is True
    action_id = res["id"]
    # عضو آخر لا يستطيع الاستئناف عن غير نفسه
    assert client.post("/api/appeals",
                       params={"handle": "sami.verify", "action_id": action_id,
                               "statement": "أستأنف هذا القرار جملة كافية"}).status_code == 400
    r = client.post("/api/appeals",
                    params={"handle": "fadi.act", "action_id": action_id,
                            "statement": "أطلب مراجعة القرار لأنّه غير متناسب مع الواقعة."})
    assert r.status_code == 200 and r.json()["ok"] is True
    aid = r.json()["id"]
    # مراجعة الاستئناف تتطلّب مشرفًا
    assert client.post(f"/api/appeals/{aid}/review",
                       params={"handle": "sami.verify", "decision": "accepted"}).status_code == 403
    ok = client.post(f"/api/appeals/{aid}/review",
                     params={"handle": "noor.mod", "decision": "accepted", "note": "قبول"})
    assert ok.status_code == 200 and ok.json()["status"] == "accepted"


def test_appeal_statement_validation(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    res = social.apply_moderation(conn, target_kind="member", target_id=0,
                                  target_handle="fadi.act", action="warn",
                                  reason="تحذير أوّلي للاختبار", moderator="noor.mod")
    r = client.post("/api/appeals",
                    params={"handle": "fadi.act", "action_id": res["id"], "statement": "قصير"})
    assert r.status_code == 400 and r.json()["error"] == "statement_too_short"


def test_moderation_stats_api(client):
    r = client.get("/api/moderation/stats")
    assert r.status_code == 200
    assert "stats" in r.json() and "by_action" in r.json()["stats"]


def test_moderation_in_nav_and_sitemap(client):
    assert 'href="/moderation"' in client.get("/").text
    assert "/moderation" in client.get("/sitemap.xml").text


def test_moderation_page_english(client):
    r = client.get("/moderation", params={"lang": "en"})
    assert r.status_code == 200
    assert "Moderation &amp; governance" in r.text or "Moderation & governance" in r.text


# ---------------------------------------------------------------------------
# السمعة والثقة (الدفعة 8)
# ---------------------------------------------------------------------------

def test_trust_page_ok(client):
    r = client.get("/trust")
    assert r.status_code == 200
    assert "trust.title" not in r.text
    assert "trust_levels" not in r.text  # لا أسماء متغيّرات في المخرج


def test_trust_seeded(conn):
    from app import social
    e = social.endorsements_for(conn, "sami.verify")
    assert e, "expected seeded endorsements"
    assert social.vouches_for(conn, "dina.act")
    assert social.badges_for(conn, "sami.verify")


def test_trust_score_explainable(client):
    r = client.get("/api/members/sami.verify/trust")
    assert r.status_code == 200
    d = r.json()
    assert 0 <= d["score"] <= 100
    assert d["level"] in {"0", "1", "2", "3", "4", "5"}
    assert set(d["breakdown"]) >= {"verified", "endorsements", "penalty"}
    assert d["endorsements"] >= 1


def test_trust_score_missing_member(client):
    assert client.get("/api/members/nobody/trust").status_code == 404


def test_self_endorsement_blocked(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = social.add_endorsement(conn, "sami.verify", "sami.verify", "accuracy")
    assert r["ok"] is False and r["error"] == "self_endorsement"


def test_endorsement_weight_lower_for_unverified(conn):
    """المُقيِّم غير الموثّق وزنه أقلّ (منع التلاعب بالسمعة)."""
    from app import social
    w_unver = social._endorser_weight(conn, "adam.mem")
    w_ver = social._endorser_weight(conn, "noor.mod")
    assert w_unver < w_ver


def test_endorse_via_api(client, conn):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/members/mona.mem/endorse",
                    params={"handle_by": "noor.mod", "dimension": "accuracy"})
    assert r.status_code == 200 and r.json()["ok"] is True
    # تكرار نفس التأييد يُرفض
    r2 = client.post("/api/members/mona.mem/endorse",
                     params={"handle_by": "noor.mod", "dimension": "accuracy"})
    assert r2.status_code == 400 and r2.json()["error"] == "already_endorsed"


def test_vouch_requires_trusted_voucher(client, conn):
    """ضمان الأقران يتطلّب ضامنًا موثوقًا (trust ≥ 40)."""
    from app import ratelimit
    ratelimit.reset()
    # عضو غير موثوق يحاول ضمان آخر
    r = client.post("/api/members/hamza.mem/vouch",
                    params={"handle_by": "adam.mem", "kind": "peer"})
    assert r.status_code == 400 and r.json()["error"] == "voucher_not_trusted"


def test_vouch_self_blocked(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/members/noor.mod/vouch",
                    params={"handle_by": "noor.mod", "kind": "peer"})
    assert r.status_code == 400 and r.json()["error"] == "self_vouch"


def test_trust_network(client):
    r = client.get("/api/members/dina.act/trust")
    assert r.status_code == 200
    assert r.json()["network_degree"] >= 1


def test_trust_leaderboard_api(client):
    r = client.get("/api/trust/leaderboard", params={"limit": 5})
    assert r.status_code == 200
    data = r.json()
    assert 1 <= data["count"] <= 5
    scores = [m["score"] for m in data["leaderboard"]]
    assert scores == sorted(scores, reverse=True)


def test_member_page_shows_trust(client):
    r = client.get("/member/sami.verify")
    assert r.status_code == 200
    assert "data-trust-panel" in r.text
    assert "trust.breakdown" not in r.text


def test_trust_in_nav_and_sitemap(client):
    assert 'href="/trust"' in client.get("/").text
    assert "/trust" in client.get("/sitemap.xml").text


def test_trust_page_english(client):
    r = client.get("/trust", params={"lang": "en"})
    assert r.status_code == 200
    assert "Reputation" in r.text


# ---------------------------------------------------------------------------
# الإشعارات والتنبيهات (الدفعة 9)
# ---------------------------------------------------------------------------

def test_notifications_page_ok(client):
    r = client.get("/notifications", params={"handle": "sami.verify"})
    assert r.status_code == 200
    assert "data-notif-center" in r.text
    assert "notif.title" not in r.text


def test_notifications_page_without_identity(client):
    r = client.get("/notifications")
    assert r.status_code == 200
    assert "notif.choose_identity" not in r.text


def test_notifications_seeded(conn):
    from app import social
    items = social.notifications_for(conn, "sami.verify")
    assert items
    assert social.subscriptions_for(conn, "sami.verify")
    assert social.quiet_hours_for(conn, "noor.mod")


def test_notifications_api(client):
    r = client.get("/api/notifications", params={"handle": "sami.verify"})
    assert r.status_code == 200
    d = r.json()
    assert d["count"] >= 1 and "unread" in d
    r2 = client.get("/api/notifications", params={"handle": "nobody"})
    assert r2.status_code == 404


def test_notification_count_and_read(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    before = client.get("/api/notifications/count", params={"handle": "sami.verify"}).json()["unread"]
    assert before >= 1
    r = client.post("/api/notifications/read", params={"handle": "sami.verify"})
    assert r.status_code == 200 and r.json()["updated"] >= 1
    after = client.get("/api/notifications/count", params={"handle": "sami.verify"}).json()["unread"]
    assert after == 0


def test_notification_read_requires_member(client):
    r = client.post("/api/notifications/read", params={"handle": "nobody"})
    assert r.status_code == 400


def test_notify_respects_prefs(client, conn):
    """إشعار مكتوم لا يُنشأ (احترام التفضيلات)."""
    from app import social
    social.set_notification_pref(conn, "mona.mem", "system", "inapp", enabled=False)
    nid = social.notify(conn, "mona.mem", "test", "مكتوم", category="system")
    assert nid is None
    nid2 = social.notify(conn, "mona.mem", "test", "مسموح", category="interaction")
    assert nid2 is not None


def test_notify_respects_muted_until(conn):
    """الكتم المؤقّت (muted_until) يُحترم: سارٍ الآن يمنع، ومنقضٍ يسمح."""
    from app import social
    # كتم سارٍ (تاريخ مستقبلي) → يُمنع
    social.set_notification_pref(conn, "adam.mem", "system", "inapp",
                                 enabled=True, muted_until="2099-01-01")
    assert social.notify(conn, "adam.mem", "x", "مكتوم مؤقّتًا", category="system") is None
    # كتم منقضٍ (تاريخ ماضٍ) → يُسمح
    social.set_notification_pref(conn, "adam.mem", "tasks", "inapp",
                                 enabled=True, muted_until="2000-01-01")
    assert social.notify(conn, "adam.mem", "y", "مسموح", category="tasks") is not None
    # قيمة غير صالحة → تُهمَل ولا تمنع
    social.set_notification_pref(conn, "adam.mem", "interaction", "inapp",
                                 enabled=True, muted_until="not-a-date")
    assert social.notify(conn, "adam.mem", "z", "مسموح", category="interaction") is not None


def test_muted_until_active_helper():
    """دالّة حساب سريان الكتم المؤقّت."""
    from app import social
    assert social._muted_until_active(None) is False
    assert social._muted_until_active("") is False
    assert social._muted_until_active("2099-01-01") is True
    assert social._muted_until_active("2099-01-01 12:00:00") is True
    assert social._muted_until_active("2000-01-01") is False
    assert social._muted_until_active("garbage") is False


def test_security_notification_bypasses_quiet_hours(conn, monkeypatch):
    """الإشعارات الأمنية لا تُكتم بساعات الهدوء."""
    from app import social
    # نثبّت الساعة الحالية داخل نافذة الهدوء كي لا يعتمد الاختبار على ساعة الجدار.
    monkeypatch.setattr(social, "_hour_in_tz", lambda tz, now=None: 3)
    social.set_quiet_hours(conn, "adam.mem", 22, 7, tz="Asia/Damascus")
    assert social.notify(conn, "adam.mem", "x", "عادي", category="system") is None
    assert social.notify(conn, "adam.mem", "y", "أمني", category="security") is not None


def test_quiet_hours_calculation(conn):
    from app import social
    social.set_quiet_hours(conn, "ziad.act", 22, 7)
    assert social._in_quiet_hours(conn, "ziad.act", now_hour=23) is True
    assert social._in_quiet_hours(conn, "ziad.act", now_hour=3) is True
    assert social._in_quiet_hours(conn, "ziad.act", now_hour=12) is False


def test_quiet_hours_use_stored_timezone(conn):
    """ساعات الهدوء تُحسب بالمنطقة الزمنية المخزَّنة، لا بـUTC."""
    from app import social
    from datetime import datetime, timezone
    # 23:30 UTC = 02:30 في الرياض (+3) → داخل نافذة 00–06، لكن UTC ساعته 23.
    moment = datetime(2026, 1, 1, 23, 30, tzinfo=timezone.utc)
    assert social._hour_in_tz("Asia/Riyadh", moment) == 2
    assert social._hour_in_tz("UTC", moment) == 23
    # منطقة غائبة أو تالفة أو فارغة ترجع إلى UTC بلا انهيار.
    assert social._hour_in_tz("Not/AZone", moment) == 23
    assert social._hour_in_tz(None, moment) == 23
    # الربط الكامل: نفس اللحظة تُكتَم في الرياض ولا تُكتَم بـUTC.
    social.set_quiet_hours(conn, "adam.mem", 0, 6, tz="Asia/Riyadh")
    assert social._in_quiet_hours(conn, "adam.mem", now=moment) is True
    social.set_quiet_hours(conn, "adam.mem", 0, 6, tz="UTC")
    assert social._in_quiet_hours(conn, "adam.mem", now=moment) is False


def test_quiet_hours_full_day_covers_all_hours(conn):
    """نافذة 0→23 تغطّي الساعة 23 أيضًا (الطرف شامل؛ لا تسريب عند آخر ساعة)."""
    from app import social
    social.set_quiet_hours(conn, "adam.mem", 0, 23)
    for h in range(24):
        assert social._in_quiet_hours(conn, "adam.mem", now_hour=h) is True, h
    # الطرف النهائي شامل أيضًا لنافذة لا تعبر منتصف الليل
    social.set_quiet_hours(conn, "adam.mem", 8, 17)
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=17) is True
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=18) is False
    # نافذة قصيرة لا تغطّي إلا ساعتها
    social.set_quiet_hours(conn, "adam.mem", 15, 15)
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=15) is True
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=14) is False


def test_quiet_hours_window_is_inclusive(conn):
    """ساعات الهدوء تشمل طرفَي النافذة، فلا تفلت الساعة النهائية (انحدار زمني)."""
    from app import social
    social.set_quiet_hours(conn, "adam.mem", 0, 23)  # كل اليوم هدوء
    for hour in range(24):
        assert social._in_quiet_hours(conn, "adam.mem", now_hour=hour) is True
    social.set_quiet_hours(conn, "adam.mem", 22, 7)
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=7) is True
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=8) is False


def test_quiet_hours_window_includes_end_hour(conn):
    """النافذة شاملة لساعة النهاية، و(0,23) تغطّي اليوم كاملًا."""
    from app import social
    social.set_quiet_hours(conn, "adam.mem", 0, 23)
    assert all(social._in_quiet_hours(conn, "adam.mem", now_hour=h) for h in range(24))
    # نافذة نقطية (البداية == النهاية) تغطّي ساعتها الوحيدة فقط (النافذة شاملة الطرفين).
    social.set_quiet_hours(conn, "adam.mem", 3, 3)
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=3) is True
    assert social._in_quiet_hours(conn, "adam.mem", now_hour=4) is False


def test_mute_all_leaves_security(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/notifications/mute-all", params={"handle": "hala.verify"})
    assert r.status_code == 200
    assert social.notify(conn, "hala.verify", "x", "عادي", category="system") is None
    assert social.notify(conn, "hala.verify", "y", "أمني", category="security") is not None


def test_subscribe_and_unsubscribe(client, conn):
    from app import ratelimit, social
    ratelimit.reset()
    r = client.post("/api/subscriptions",
                    params={"handle": "omar.act", "kind": "category", "value": "torture"})
    assert r.status_code == 200 and r.json()["ok"] is True
    assert "omar.act" in social.subscribers_for(conn, "category", "torture")
    # نوع غير صالح مرفوض
    bad = client.post("/api/subscriptions",
                      params={"handle": "omar.act", "kind": "bogus", "value": "x"})
    assert bad.status_code == 400
    d = client.delete("/api/subscriptions",
                      params={"handle": "omar.act", "kind": "category", "value": "torture"})
    assert d.status_code == 200 and d.json()["ok"] is True


def test_notify_subscribers(conn):
    from app import social
    n = social.notify_subscribers(conn, "category", "disinformation",
                                  title="بلاغ جديد في مجال تتابعه", category="system")
    assert n >= 1
    assert social.notifications_for(conn, "sami.verify", unread_only=True)


def test_digest_orders_by_priority(client):
    r = client.get("/api/notifications/digest", params={"handle": "sami.verify"})
    assert r.status_code == 200
    d = r.json()
    assert "total" in d and "by_category" in d
    ranks = {"critical": 0, "important": 1, "normal": 2}
    prios = [ranks.get(i["priority"], 3) for i in d["items"]]
    assert prios == sorted(prios)


def test_purge_old_notifications(conn):
    from app import social
    conn.execute("UPDATE notifications SET read=1")
    conn.commit()
    conn.execute("UPDATE notifications SET created_at=datetime('now','-200 days') WHERE member='sami.verify'")
    conn.commit()
    removed = social.purge_old_notifications(conn, days=90)
    assert removed >= 1


def test_notifications_stats_api(client):
    r = client.get("/api/notifications/stats")
    assert r.status_code == 200
    d = r.json()
    assert "total" in d and "by_category" in d


def test_notifications_rss(client):
    r = client.get("/notifications.rss", params={"handle": "sami.verify"})
    assert r.status_code == 200
    assert "<rss" in r.text and "<item>" in r.text


def test_notifications_in_nav_and_sitemap(client):
    assert 'href="/notifications"' in client.get("/").text
    assert "/notifications" in client.get("/sitemap.xml").text


def test_notifications_page_english(client):
    r = client.get("/notifications", params={"handle": "sami.verify", "lang": "en"})
    assert r.status_code == 200
    assert "Notification center" in r.text


# ---------------------------------------------------------------------------
# البحث والاكتشاف (الدفعة 10)
# ---------------------------------------------------------------------------

def test_discover_page_ok(client):
    r = client.get("/discover")
    assert r.status_code == 200
    assert "discover.title" not in r.text
    assert "boards" in r.text


def test_discover_with_query(client):
    r = client.get("/discover", params={"q": "أطفال"})
    assert r.status_code == 200
    assert "discover.no_results" not in r.text


def test_unified_search_spans_kinds(client):
    r = client.get("/api/search/unified", params={"q": "اعتقال"})
    assert r.status_code == 200
    d = r.json()
    assert d["total"] >= 1
    assert isinstance(d["groups"], dict)


def test_unified_search_report_urls_resolve(client):
    """روابط نتائج البحث الموحّد للبلاغات تشير إلى المسار الصحيح /reports/{id}."""
    r = client.get("/api/search/unified", params={"q": "أطفال", "kind": "report"})
    assert r.status_code == 200
    items = r.json()["groups"].get("report", [])
    assert items, "لا نتائج بلاغات للاستعلام"
    for it in items:
        assert it["url"] == f"/reports/{it['id']}"
        assert client.get(it["url"]).status_code == 200


def test_discover_boards_links_resolve(client):
    """روابط لوحات الاكتشاف لا تستخدم المسار الخاطئ /report/ (404)."""
    r = client.get("/discover")
    assert r.status_code == 200
    assert 'href="/report/' not in r.text
    assert 'href="/reports/' in r.text


def test_search_arabic_normalization(client):
    """«اطفال» بلا همزة تطابق «أطفال» (تطبيع عربي)."""
    r = client.get("/api/search/unified", params={"q": "اطفال", "kind": "report"})
    assert r.status_code == 200
    assert r.json()["counts"].get("report", 0) >= 1


def test_search_kind_filter(client):
    r = client.get("/api/search/unified", params={"q": "أطفال", "kind": "entity"})
    assert r.status_code == 200
    d = r.json()
    assert set(d["groups"]).issubset({"entity"})


def test_unified_search_all_kinds_return_without_error(conn):
    """كل أنواع البحث الموحّد السبعة تعمل بلا استثناء (لا فشل صامت).

    يحرس تراجعًا سابقًا: كانت _search_claims/_search_sources/_search_groups
    تنهار بـ AttributeError ('sqlite3.Row' بلا .get) فيُبتلع الخطأ ويعود النوع فارغًا.
    """
    from app import search
    from app.textutils import tokenize
    for kind, fn in search._SEARCHERS.items():
        res = fn(conn, tokenize("حقوق"), 12)  # يجب ألا يرفع استثناءً
        assert isinstance(res, list), kind
    # أنواع كان بها العطل تُرجع الآن نتائج فعلية من بيانات البذور.
    assert search._search_claims(conn, tokenize("فيديو"), 12)
    assert search._search_sources(conn, tokenize("نزاعات"), 12)
    assert search._search_groups(conn, tokenize("مجلس"), 12)


def test_unified_search_claim_kind_via_api(client):
    """نوع الادّعاءات يُرجع نتائج عبر الـ API (لا صفرًا صامتًا)."""
    r = client.get("/api/search/unified", params={"q": "فيديو", "kind": "claim"})
    assert r.status_code == 200
    d = r.json()
    assert d["counts"].get("claim", 0) >= 1
    assert any(it["kind"] == "claim" for g in d["groups"].values() for it in g)


def test_unified_search_hides_secret_groups(client):
    """المجموعات السرّية لا تظهر في نتائج البحث الموحّد."""
    r = client.get("/api/search/unified",
                   params={"q": "الاستجابة للطوارئ", "kind": "group"})
    assert r.status_code == 200
    d = r.json()
    assert d["counts"].get("group", 0) == 0
    assert "crisis-response" not in r.text


def test_safe_search_hides_unverified_critical(conn):
    from app import search
    data_all = search.unified_search(conn, "قصف", safe=False)
    data_safe = search.unified_search(conn, "قصف", safe=True)
    assert data_safe["counts"].get("report", 0) <= data_all["counts"].get("report", 0)


def test_search_suggest_api(client):
    r = client.get("/api/search/suggest", params={"q": "اعت"})
    assert r.status_code == 200
    d = r.json()
    assert "completions" in d and "queries" in d and "related" in d


def test_search_correction_suggested(conn):
    from app import search
    corr = search.suggest_correction(conn, "اعتقالل")
    # إمّا تصحيح مقترح أو لا شيء — لا استثناء
    assert corr is None or isinstance(corr, str)


def test_highlight_and_snippet(conn):
    from app import search
    from app.textutils import tokenize
    toks = tokenize("أطفال")
    html = search._highlight("انتهاكات ضد أطفال في المخيم", toks)
    assert "<mark>" in html
    snip = search._snippet("نصّ طويل جدًّا عن انتهاكات ضد أطفال في المخيم والمنطقة", toks)
    assert snip


def test_highlight_spans_align_with_original_text(conn):
    """حارس انحدار: الإبراز يقيس على النصّ الأصلي لا المطبَّع.

    التطبيع يغيّر الطول (يحذف التشكيل/التطويل ويطوي المسافات)، فكان الإبراز
    يزيح فيظهر «أطفا» بدل «أطفال». نتحقّق من أنّ الكلمة المطابقة كاملةً داخل
    الوسم، وأنّ إزالة الوسوم تعيد النصّ الأصلي كما هو.
    """
    import re

    from app import search
    from app.textutils import tokenize

    cases = [
        ("أطفال في مناجم صغيرة", "أطفال"),
        ("عمّال أطفال في أعمال خطرة", "أطفال"),   # تشديد يُحذَف قبل الكلمة
        ("استخدام عمال اطفال في المصانع", "عمال"),
        ("كتـــابٌ عن الأطفال", "كتاب"),          # تطويل + تشكيل داخل الكلمة
        ("أطفالٌ في المَدرسة!", "اطفال"),         # بحث بغير همزة/تشكيل
        ("نص بمسافات   مكررة  أطفال هنا", "أطفال"),  # مسافات مكرّرة
    ]
    for text, query in cases:
        toks = tokenize(query)
        out = search._highlight(text, toks)
        # الوسوم تُزال فتعود الحروف الأصلية كاملةً (لا اقتطاع ولا إزاحة).
        assert re.sub(r"</?mark>", "", out) == text
        marks = re.findall(r"<mark>(.*?)</mark>", out)
        assert marks, (text, out)
        # كل وسم يحتوي كلمة كاملة لا تمتدّ عبر مسافة.
        assert all(" " not in m for m in marks)
        assert all(any(tok in search.normalize_arabic(m) for tok in toks) for m in marks)


def test_snippet_centers_on_original_match(conn):
    """حارس انحدار: المقتطف يتمركز حول المطابقة الأصلية لا موضعها المطبَّع."""
    from app import search
    from app.textutils import tokenize

    # بادئة ثقيلة بالتشكيل تُقلّص النصّ المطبَّع كثيرًا فينحرف الموضع الخام.
    text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ " * 8 + "أطفال في المخيم"
    snip = search._snippet(text, tokenize("أطفال"), width=40)
    assert "أطفال" in snip


def test_highlight_escapes_html(conn):
    """حارس XSS: الإبراز يُهرّب أي وسوم من المحتوى."""
    from app import search
    from app.textutils import tokenize
    toks = tokenize("خطر")
    out = search._highlight("<b>خطر</b> & <script>alert(1)</script>", toks)
    assert "<mark>خطر</mark>" in out
    assert "<b>" not in out and "<script>" not in out
    assert "&lt;b&gt;" in out and "&amp;" in out


def test_discover_escapes_search_highlight_xss(client):
    """لا يُسمح بحقن HTML عبر عنوان بلاغ مُرسَل ثم إبرازه في نتائج البحث."""
    payload = "<img src=x onerror=alert(1)>مرصداختبار"
    r = client.post("/submit", data={
        "title": payload,
        "category": "expression",
        "severity": "high",
        "country": "مصر",
        "summary": "ملخص تجريبي طويل بما يكفي لتجاوز الحد الأدنى المطلوب في النموذج.",
        "source_name": "test",
        "source_url": "https://example.org/x",
    }, follow_redirects=False)
    assert r.status_code == 303
    page = client.get("/discover", params={"q": "مرصداختبار"})
    assert page.status_code == 200
    assert "<img src=x onerror=alert(1)>" not in page.text
    assert "&lt;img src=x onerror=alert(1)&gt;" in page.text


def test_trending_and_boards(client):
    t = client.get("/api/search/trending", params={"limit": 5}).json()
    assert "terms" in t
    b = client.get("/api/discover/boards").json()
    assert set(b) >= {"most_verified", "urgent", "top_categories", "regions"}


def test_saved_searches_seeded(conn):
    from app import search
    assert search.saved_searches(conn, "sami.verify")


def test_save_and_unsave_search(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/search/saved",
                    params={"handle": "omar.act", "q": "اعتقال", "kinds": "report"})
    assert r.status_code == 200 and r.json()["ok"] is True
    dup = client.post("/api/search/saved",
                      params={"handle": "omar.act", "q": "اعتقال", "kinds": "report"})
    assert dup.status_code == 400 and dup.json()["error"] == "already_saved"
    saved = client.get("/api/search/saved", params={"handle": "omar.act"}).json()
    sid = saved["saved"][0]["id"]
    d = client.delete("/api/search/saved", params={"handle": "omar.act", "id": sid})
    assert d.json()["ok"] is True


def test_save_search_requires_member(client):
    r = client.post("/api/search/saved", params={"handle": "nobody", "q": "x"})
    assert r.status_code == 400


def test_search_export_json_and_csv(client):
    j = client.get("/api/search/export", params={"q": "أطفال", "fmt": "json"})
    assert j.status_code == 200 and "results" in j.json()
    c = client.get("/api/search/export", params={"q": "أطفال", "fmt": "csv"})
    assert c.status_code == 200 and "kind,title,url,snippet" in c.text


def test_search_index_status(client):
    r = client.get("/api/search/index")
    assert r.status_code == 200
    d = r.json()
    assert d["reports"] >= 1 and d["rebuildable"] is True


def test_discover_in_nav_and_sitemap(client):
    assert 'href="/discover"' in client.get("/").text
    assert "/discover" in client.get("/sitemap.xml").text


def test_discover_page_english(client):
    r = client.get("/discover", params={"lang": "en"})
    assert r.status_code == 200
    assert "Search &amp; discovery" in r.text or "Search & discovery" in r.text


# ---------------------------------------------------------------------------
# الحملات والمناصرة (الدفعة 11)
# ---------------------------------------------------------------------------

def test_campaigns_page_ok(client):
    r = client.get("/campaigns")
    assert r.status_code == 200
    assert "camp.title" not in r.text
    assert "camp-card" in r.text


def test_campaigns_seeded(conn):
    from app import campaigns
    rows = campaigns.query_campaigns(conn)
    assert len(rows) >= 3
    c = campaigns.campaign_by_slug(conn, "end-child-detention")
    assert c and c["ethics_ack"] == 1
    assert campaigns.signature_count(conn, c["id"]) >= 5


def test_campaign_detail_page(client):
    r = client.get("/campaign/end-child-detention")
    assert r.status_code == 200
    assert "data-campaign" in r.text
    assert "camp.progress" not in r.text


def test_campaign_detail_missing(client):
    assert client.get("/campaign/nope").status_code == 404


def test_campaign_progress(conn):
    from app import campaigns
    c = campaigns.campaign_by_slug(conn, "end-child-detention")
    p = campaigns.progress(conn, c)
    assert p["goal"] == 10000 and p["count"] >= 5
    assert 0 < p["percent"] < 100


def test_campaign_api(client):
    r = client.get("/api/campaigns")
    assert r.status_code == 200 and r.json()["count"] >= 3
    one = client.get("/api/campaigns/end-child-detention")
    assert one.status_code == 200
    assert "progress" in one.json()


def test_campaign_sign_and_duplicate(client, conn):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/campaigns/stop-hate-speech/sign", params={"handle": "omar.act"})
    assert r.status_code == 200 and r.json()["ok"] is True
    dup = client.post("/api/campaigns/stop-hate-speech/sign", params={"handle": "omar.act"})
    assert dup.status_code == 400 and dup.json()["error"] == "already_signed"


def test_campaign_anonymous_signature_hides_identity(conn):
    """التوقيع المجهول يخفي الاسم والمعرّف."""
    from app import campaigns
    c = campaigns.campaign_by_slug(conn, "end-child-detention")
    campaigns.sign_campaign(conn, c["id"], "hamza.mem", anonymous=True)
    sigs = campaigns.campaign_signatures(conn, c["id"])
    anon = [s for s in sigs if s["anonymous"]]
    assert anon and anon[0]["member"] is None
    assert anon[0]["display_name"] == campaigns.ANON_LABEL


def test_campaign_sign_requires_member(client):
    r = client.post("/api/campaigns/stop-hate-speech/sign", params={"handle": "nobody"})
    assert r.status_code == 400


def test_campaign_update_requires_coordinator(client):
    from app import ratelimit
    ratelimit.reset()
    # عضو نشط ليس منسّقًا
    r = client.post("/api/campaigns/end-child-detention/updates",
                    params={"handle": "ziad.act", "title": "تحديث"})
    assert r.status_code == 403
    # المنسّق مسموح
    ok = client.post("/api/campaigns/end-child-detention/updates",
                     params={"handle": "dina.act", "title": "تحديث من المنسّق"})
    assert ok.status_code == 200 and ok.json()["ok"] is True


def test_campaign_wave_send_throttled(conn):
    from app import campaigns
    c = campaigns.campaign_by_slug(conn, "end-child-detention")
    wid = campaigns.schedule_wave(conn, c["id"], "موجة اختبار", "2026-08-01")
    res = campaigns.send_wave(conn, wid, max_send=3)
    assert res["ok"] is True and res["sent"] == 3 and res["throttled"] is True
    # لا إرسال ثانٍ لموجة مُرسَلة
    again = campaigns.send_wave(conn, wid)
    assert again["ok"] is False and again["error"] == "wave_not_scheduled"


def test_campaign_pledge_state(client, conn):
    from app import campaigns
    c = campaigns.campaign_by_slug(conn, "stop-hate-speech")
    pid = campaigns.campaign_pledges(conn, c["id"])[0]["id"]
    # المنسّق (yara.act) مسموح له بتعديل حالة الوعد.
    r = client.post(f"/api/campaigns/pledges/{pid}/state",
                    params={"state": "kept", "handle": "yara.act"})
    assert r.status_code == 200 and r.json()["ok"] is True
    bad = client.post(f"/api/campaigns/pledges/{pid}/state",
                      params={"state": "bogus", "handle": "yara.act"})
    assert bad.status_code == 400


def test_campaign_pledge_state_requires_coordinator(client, conn):
    """لا يُقبل تعديل حالة وعد بلا هوية أو من عضو غير منسّق للحملة."""
    from app import campaigns
    c = campaigns.campaign_by_slug(conn, "stop-hate-speech")
    pid = campaigns.campaign_pledges(conn, c["id"])[0]["id"]
    original = conn.execute(
        "SELECT state FROM campaign_pledges WHERE id=?", (pid,)).fetchone()["state"]

    # بلا هوية: مرفوض.
    r = client.post(f"/api/campaigns/pledges/{pid}/state", params={"state": "broken"})
    assert r.status_code == 400
    # عضو نشط لكنه ليس منسّق هذه الحملة: مرفوض.
    r = client.post(f"/api/campaigns/pledges/{pid}/state",
                    params={"state": "broken", "handle": "omar.act"})
    assert r.status_code == 403
    # الحالة لم تتغيّر.
    assert conn.execute(
        "SELECT state FROM campaign_pledges WHERE id=?", (pid,)).fetchone()["state"] == original


def test_campaign_pledge_state_unknown_pledge(client):
    r = client.post("/api/campaigns/pledges/99999/state",
                    params={"state": "kept", "handle": "yara.act"})
    assert r.status_code == 404


def test_campaign_impact_and_risk(client):
    r = client.get("/api/campaigns/end-child-detention/impact")
    assert r.status_code == 200
    d = r.json()
    assert d["impact"]["signatures"] >= 5
    assert d["risk"]["level"] in {"low", "medium", "high"}
    assert d["risk"]["advice"]


def test_campaign_stats_api(client):
    r = client.get("/api/campaigns/stats")
    assert r.status_code == 200
    d = r.json()
    assert d["total"] >= 3 and d["signatures"] >= 5


def test_campaigns_suggestions_and_opportunities(conn):
    from app import campaigns
    assert isinstance(campaigns.suggested_campaigns(conn), list)
    assert isinstance(campaigns.opportunities(conn), list)


def test_campaigns_in_nav_and_sitemap(client):
    assert 'href="/campaigns"' in client.get("/").text
    assert "/campaigns" in client.get("/sitemap.xml").text


def test_campaigns_page_english(client):
    r = client.get("/campaigns", params={"lang": "en"})
    assert r.status_code == 200
    assert "Campaigns &amp; advocacy" in r.text or "Campaigns & advocacy" in r.text


# ---------------------------------------------------------------------------
# التكامل والأتمتة (الدفعة 12)
# ---------------------------------------------------------------------------

def test_integrations_page_ok(client):
    r = client.get("/integrations")
    assert r.status_code == 200
    assert "integ.title" not in r.text
    assert "data-integrations" in r.text


def test_integrations_seeded(conn):
    from app import integrations
    assert len(integrations.query_api_keys(conn)) >= 4
    assert len(integrations.query_webhooks(conn)) >= 3
    assert len(integrations.query_connectors(conn)) >= 9
    assert len(integrations.query_rules(conn)) >= 4
    assert len(integrations.query_jobs(conn)) >= 5


def test_api_key_scopes(conn):
    from app import integrations
    assert integrations.key_has_scope(conn, "mrsd_ed", "write") is True
    assert integrations.key_has_scope(conn, "mrsd_pub", "write") is False
    # إصدار مهمل لا يعمل
    assert integrations.key_has_scope(conn, "mrsd_old", "read") is False


def test_api_rate_limit(conn):
    from app import integrations
    assert integrations.within_rate_limit(conn, "mrsd_old") is True
    for _ in range(11):
        integrations.record_api_usage(conn, "mrsd_old")
    assert integrations.within_rate_limit(conn, "mrsd_old") is False


def test_webhook_signature_hmac(conn):
    from app import integrations
    sig = integrations.sign_payload("whsec_demo_secret", '{"event":"x"}')
    assert sig.startswith("sha256=")
    assert sig == integrations.sign_payload("whsec_demo_secret", '{"event":"x"}')
    assert sig != integrations.sign_payload("other", '{"event":"x"}')


def test_webhook_dispatch_and_deliver(conn):
    from app import integrations
    sent = integrations.dispatch_event(conn, "report.created", {"id": 1})
    assert sent and all(s["signature"].startswith("sha256=") for s in sent)
    integrations.deliver(conn, sent[0]["delivery_id"], ok=True)
    rows = integrations.webhook_deliveries(conn, limit=10)
    delivered = [r for r in rows if r["state"] == "delivered"]
    assert delivered


def test_webhook_retry_until_failed(conn):
    from app import integrations
    sent = integrations.dispatch_event(conn, "security.alert", {})
    did = sent[0]["delivery_id"]
    for _ in range(integrations.MAX_JOB_ATTEMPTS):
        integrations.deliver(conn, did, ok=False)
    row = conn.execute("SELECT * FROM webhook_deliveries WHERE id=?", (did,)).fetchone()
    assert row["state"] == "failed" and row["attempts"] == integrations.MAX_JOB_ATTEMPTS


def test_webhook_test_api(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/integrations/webhooks/test", params={"event": "report.created"})
    assert r.status_code == 200 and r.json()["delivered"] >= 1
    bad = client.post("/api/integrations/webhooks/test", params={"event": "bogus"})
    assert bad.status_code == 400


def test_connector_sync_api(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/integrations/connectors/1/sync")
    assert r.status_code == 200 and r.json()["ok"] is True


def test_rule_validate(conn):
    from app import integrations
    assert integrations.validate_rule("report.created", "notify")["valid"] is True
    bad = integrations.validate_rule("nope", "notify")
    assert bad["valid"] is False and "unknown_trigger" in bad["errors"]
    assert integrations.validate_rule("report.created", "")["errors"] == ["no_actions"]


def test_rule_run_and_toggle(client, conn):
    from app import integrations
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/integrations/rules/1/run")
    assert r.status_code == 200 and r.json()["ok"] is True
    assert client.post("/api/integrations/rules/1/toggle", params={"enabled": 0}).json()["ok"]
    disabled = client.post("/api/integrations/rules/1/run")
    assert disabled.status_code == 400 and disabled.json()["error"] == "disabled"


def test_rule_runs_logged(conn):
    from app import integrations
    integrations.run_rule(conn, 2)
    assert integrations.rule_runs(conn, rid=2)


def test_queue_enqueue_and_finish(client, conn):
    from app import integrations
    from app import ratelimit
    ratelimit.reset()
    before = integrations.queue_depth(conn)
    r = client.post("/api/integrations/queue/enqueue", params={"kind": "test_job", "priority": 1})
    assert r.status_code == 200
    jid = r.json()["id"]
    assert integrations.queue_depth(conn) == before + 1
    job = integrations.dequeue_job(conn, "worker-1")
    assert job and job["priority"] == 1
    assert integrations.finish_job(conn, jid, ok=True) is True
    row = conn.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
    assert row["state"] == "done"


def test_queue_failure_requeue(conn):
    from app import integrations
    jid = integrations.enqueue_job(conn, "flaky", "{}", 5)
    integrations.dequeue_job(conn, "worker-1")
    integrations.finish_job(conn, jid, ok=False)
    row = conn.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
    assert row["state"] == "queued" and row["attempts"] == 1
    n = integrations.requeue_failed(conn)
    assert n >= 1


def test_integration_health_and_stats(client):
    s = client.get("/api/integrations/stats").json()
    assert s["stats"]["api_keys"] >= 4
    assert "healthy" in s["health"]
    h = client.get("/api/integrations/health").json()
    assert "webhooks" in h and "queue" in h


def test_integration_list_apis(client):
    assert client.get("/api/integrations/keys").json()["count"] >= 4
    assert client.get("/api/integrations/webhooks").json()["webhooks"]
    assert client.get("/api/integrations/connectors").json()["connectors"]
    assert client.get("/api/integrations/rules").json()["rules"]
    assert client.get("/api/integrations/queue").json()["jobs"]


def test_webhook_secret_not_exposed(client):
    """لا يُكشف السرّ التوقيعي للـ webhooks في الواجهة/الـ API ولا في الصفحة."""
    data = client.get("/api/integrations/webhooks").json()
    assert data["webhooks"]
    for h in data["webhooks"]:
        assert "secret" not in h
    page = client.get("/integrations")
    assert "whsec_demo_secret" not in page.text


def test_openapi_alias_and_docs(client):
    r = client.get("/api/openapi.json")
    assert r.status_code == 200
    assert "paths" in r.json()
    docs = client.get("/api/docs")
    assert docs.status_code == 200
    assert "integ.docs_title" not in docs.text


def test_integrations_in_nav_and_sitemap(client):
    assert 'href="/integrations"' in client.get("/").text
    assert "/integrations" in client.get("/sitemap.xml").text


def test_integrations_page_english(client):
    r = client.get("/integrations", params={"lang": "en"})
    assert r.status_code == 200
    assert "Integration &amp; automation" in r.text or "Integration & automation" in r.text


# ---------------------------------------------------------------------------
# الإدارة والتشغيل والتحليلات (الدفعة 13)
# ---------------------------------------------------------------------------

def test_admin_page_ok(client):
    r = client.get("/admin")
    assert r.status_code == 200
    assert "admin.title" not in r.text
    assert "data-admin" in r.text


def test_public_status_page(client):
    r = client.get("/status")
    assert r.status_code == 200
    assert "status.title" not in r.text


def test_ops_seeded(conn):
    from app import ops
    assert ops.query_service_health(conn)
    assert ops.query_incidents(conn)
    assert ops.query_roadmap(conn)
    assert ops.query_volunteers(conn)


def test_system_status(conn):
    from app import ops
    st = ops.system_status(conn)
    assert st["state"] in {"ok", "degraded", "down"}
    assert st["services"] and "open_incidents" in st


def test_flags_and_maintenance_gate(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    assert ops.in_maintenance(conn) is False
    # تفعيل الصيانة بمشرف
    r = client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "maintenance_mode", "value": "1"})
    assert r.status_code == 200 and r.json()["flags"]["maintenance_mode"] == "1"
    # صفحة عادية → 503
    assert client.get("/reports").status_code == 503
    # مسار مستثنى → 200
    assert client.get("/healthz").status_code == 200
    assert client.get("/status").status_code == 200
    # API → 503 JSON
    api = client.get("/api/reports")
    assert api.status_code == 503 and api.json()["error"] == "maintenance"
    # إيقاف الصيانة
    client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "maintenance_mode", "value": "0"})
    assert client.get("/reports").status_code == 200


def test_read_only_gate(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "read_only", "value": "1"})
    # الكتابة ممنوعة
    w = client.post("/api/search/saved", params={"handle": "omar.act", "q": "x"})
    assert w.status_code == 403 and w.json()["error"] == "read_only"
    # القراءة مسموحة
    assert client.get("/reports").status_code == 200
    client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "read_only", "value": "0"})


def test_flag_requires_moderator(client):
    r = client.post("/api/admin/flags", params={"handle": "omar.act", "key": "read_only", "value": "1"})
    assert r.status_code == 403


def test_flag_validation(client, conn):
    from app import ratelimit
    ratelimit.reset()
    bad = client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "nope", "value": "1"})
    assert bad.status_code == 400 and bad.json()["error"] == "unknown_flag"
    badv = client.post("/api/admin/flags", params={"handle": "noor.mod", "key": "read_only", "value": "yes"})
    assert badv.status_code == 400


def test_incident_lifecycle(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    open_i = ops.query_incidents(conn, state="open")
    assert open_i
    r = client.post(f"/api/admin/incidents/{open_i[0]['id']}/state",
                    params={"handle": "noor.mod", "state": "resolved", "postmortem": "سُوّي الأمر."})
    assert r.status_code == 200 and r.json()["ok"] is True
    row = conn.execute("SELECT * FROM incidents WHERE id=?", (open_i[0]["id"],)).fetchone()
    assert row["state"] == "resolved" and row["resolved_at"] and row["postmortem"]


def test_incident_requires_moderator(client):
    r = client.post("/api/admin/incidents/1/state", params={"handle": "omar.act", "state": "resolved"})
    assert r.status_code == 403


def test_audit_log_recorded(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    before = len(ops.query_audit(conn, limit=200))
    client.post("/api/admin/announcements", params={"handle": "noor.mod", "level": "warning", "title": "إعلان اختبار"})
    after = ops.query_audit(conn, limit=200)
    assert len(after) > before
    assert any(e["action"] == "announcement.post" for e in after)


def test_announcement_requires_title(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/admin/announcements", params={"handle": "noor.mod", "title": ""})
    assert r.status_code == 400


def test_retention_report_and_set(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    rep = ops.retention_report(conn)
    assert rep and all("compliant" in r for r in rep)
    r = client.post("/api/admin/retention", params={"handle": "noor.mod", "cls": "notifications", "days": 120})
    assert r.status_code == 200 and r.json()["ok"] is True
    bad = client.post("/api/admin/retention", params={"handle": "noor.mod", "cls": "bogus", "days": 10})
    assert bad.status_code == 400
    bad2 = client.post("/api/admin/retention", params={"handle": "noor.mod", "cls": "notifications", "days": 0})
    assert bad2.status_code == 400


def test_archive_candidates(conn):
    from app import ops
    cand = ops.archive_candidates(conn)
    assert "notifications" in cand and all(isinstance(v, int) for v in cand.values())


def test_privacy_preserving_analytics(conn):
    from app import ops
    # حزمة غير معروفة تُحوّل إلى other (لا تتبّع مسار حرّ)
    ops.record_view(conn, "/report/12345?user=secret")
    summary = ops.analytics_summary(conn)
    buckets = {b["path_bucket"] for b in summary["by_bucket"]}
    assert buckets.issubset(set(ops.PATH_BUCKETS))
    assert summary["total"] > 0


def test_kpis_and_ops_report(client):
    k = client.get("/api/admin/kpis").json()
    assert "growth" in k["kpis"] and "verification" in k["kpis"]
    rep = client.get("/api/admin/ops-report").json()
    assert "status" in rep and "retention" in rep


def test_anomalies_and_trends(client):
    d = client.get("/api/admin/kpis").json()
    assert isinstance(d["anomalies"], list)
    assert isinstance(d["trends"], list)


def test_roadmap_and_volunteers(client, conn):
    rm = client.get("/api/admin/roadmap").json()
    assert rm["roadmap"] and rm["governance"]
    v = client.get("/api/admin/volunteers").json()
    assert v["stats"]["volunteers"] >= 1


def test_volunteer_hours_requires_moderator(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/admin/volunteers/hours",
                    params={"handle": "omar.act", "member": "rana.act", "hours": 3})
    assert r.status_code == 403
    ok = client.post("/api/admin/volunteers/hours",
                     params={"handle": "noor.mod", "member": "rana.act", "hours": 3})
    assert ok.status_code == 200 and ok.json()["ok"] is True


def test_admin_in_nav_and_sitemap(client):
    home = client.get("/").text
    assert 'href="/admin"' in home and 'href="/status"' in home
    assert "/status" in client.get("/sitemap.xml").text


def test_admin_page_english(client):
    r = client.get("/admin", params={"lang": "en"})
    assert r.status_code == 200
    assert "Admin &amp; operations console" in r.text or "Admin & operations console" in r.text


def test_maintenance_page_english(client, conn):
    from app import ops, ratelimit
    ratelimit.reset()
    ops.set_flag(conn, "maintenance_mode", "1")
    r = client.get("/reports")
    assert r.status_code == 503
    assert "maintenance" in r.text.lower() or "صيانة" in r.text
    ops.set_flag(conn, "maintenance_mode", "0")


# ---------------------------------------------------------------------------
# الملفات الحسّاسة (الدفعة 14) — محاكاة فقط
# ---------------------------------------------------------------------------

def test_vault_page_ok(client):
    r = client.get("/vault")
    assert r.status_code == 200
    assert "vault.title" not in r.text
    assert "data-vault" in r.text


def test_vault_seeded(conn):
    from app import sensitive
    assert len(sensitive.query_items(conn)) >= 4
    assert sensitive.policies(conn)["allow_download"] == "0"


def test_crypto_not_ready(conn):
    from app import sensitive
    assert sensitive.crypto_ready() is False
    assert sensitive.vault_stats(conn)["crypto_ready"] is False


def test_fake_digest_is_synthetic(conn):
    from app import sensitive
    items = sensitive.query_items(conn)
    assert all(i["fake_digest"].startswith(sensitive.FAKE_DIGEST_PREFIX) for i in items)


def test_create_item_metadata_only(conn):
    from app import sensitive
    iid = sensitive.create_item(conn, "rana.act", "وثيقة تجريبية", "document", "internal")
    assert iid
    it = sensitive.item_by_id(conn, iid)
    assert it["state"] == "draft" and it["fake_size"] == 0
    # نوع غير معروف يُرفض
    assert sensitive.create_item(conn, "rana.act", "x", "bogus", "internal") is None


def test_item_title_required(conn):
    from app import sensitive
    assert sensitive.create_item(conn, "rana.act", "   ", "document", "internal") is None


def test_max_items_per_owner(conn):
    from app import sensitive
    for i in range(sensitive.MAX_ITEMS_PER_OWNER + 5):
        sensitive.create_item(conn, "adam.mem", f"عنصر {i}", "document", "internal")
    n = conn.execute("SELECT COUNT(*) AS n FROM vault_items WHERE owner='adam.mem'").fetchone()["n"]
    assert n == sensitive.MAX_ITEMS_PER_OWNER


def test_access_starts_pending(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    ok = sensitive.request_access(conn, item["id"], "salma.mem", "مراجعة")
    assert ok
    acc = sensitive.query_access(conn, item["id"])
    assert any(a["member"] == "salma.mem" and a["state"] == "pending" for a in acc)


def test_no_access_before_approval(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    sensitive.request_access(conn, item["id"], "salma.mem", "x")
    assert sensitive.can_access(conn, item["id"], "salma.mem") is False
    # المالك يملك دائمًا
    assert sensitive.can_access(conn, item["id"], item["owner"]) is True


def test_owner_cannot_request_own_item(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    assert sensitive.request_access(conn, item["id"], item["owner"]) is False


def test_decide_access_and_can_access(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    sensitive.request_access(conn, item["id"], "salma.mem", "x")
    acc = [a for a in sensitive.query_access(conn, item["id"]) if a["member"] == "salma.mem"][0]
    assert sensitive.decide_access(conn, acc["id"], "approved", actor=item["owner"]) is True
    assert sensitive.can_access(conn, item["id"], "salma.mem") is True


def test_requester_cannot_decide_own_request(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    sensitive.request_access(conn, item["id"], "salma.mem", "x")
    acc = [a for a in sensitive.query_access(conn, item["id"]) if a["member"] == "salma.mem"][0]
    # الطالب نفسه لا يصدر قرارًا
    assert sensitive.decide_access(conn, acc["id"], "approved", actor="salma.mem") is False


def test_revoked_item_blocks_access(conn):
    from app import sensitive
    item = sensitive.query_items(conn)[0]
    sensitive.request_access(conn, item["id"], "salma.mem", "x")
    acc = [a for a in sensitive.query_access(conn, item["id"]) if a["member"] == "salma.mem"][0]
    sensitive.decide_access(conn, acc["id"], "approved", actor=item["owner"])
    sensitive.set_item_state(conn, item["id"], "revoked", item["owner"])
    assert sensitive.can_access(conn, item["id"], "salma.mem") is False


def test_receipts_recorded(conn):
    from app import sensitive
    iid = sensitive.create_item(conn, "rana.act", "إيصال تجريبي", "document", "internal")
    rec = sensitive.query_receipts(conn, iid)
    assert any(r["kind"] == "upload" for r in rec)


def test_policy_cannot_enable_download(conn):
    from app import sensitive
    assert sensitive.set_policy(conn, "allow_download", "1") is False
    assert sensitive.set_policy(conn, "retention_days", "180") is True
    assert sensitive.set_policy(conn, "bogus", "x") is False


def test_vault_api_create_requires_identity(client):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/vault/items", params={"handle": "nobody", "title": "x"})
    assert r.status_code == 403


def test_vault_api_create_and_state(client, conn):
    from app import ratelimit
    ratelimit.reset()
    r = client.post("/api/vault/items",
                    params={"handle": "rana.act", "title": "عبر API", "kind": "image"})
    assert r.status_code == 200 and r.json()["ok"] is True
    iid = r.json()["id"]
    s = client.post(f"/api/vault/items/{iid}/state", params={"handle": "rana.act", "state": "sealed"})
    assert s.status_code == 200
    row = conn.execute("SELECT state FROM vault_items WHERE id=?", (iid,)).fetchone()
    assert row["state"] == "sealed"


def test_vault_state_only_owner(client, conn):
    from app import ratelimit
    ratelimit.reset()
    item = conn.execute("SELECT id, owner FROM vault_items LIMIT 1").fetchone()
    other = "noor.mod" if item["owner"] != "noor.mod" else "adam.mem"
    r = client.post(f"/api/vault/items/{item['id']}/state",
                    params={"handle": other, "state": "revoked"})
    assert r.status_code == 403


def test_vault_request_and_decide_api(client, conn):
    from app import ratelimit
    ratelimit.reset()
    item = conn.execute("SELECT id, owner FROM vault_items WHERE owner='rana.act' LIMIT 1").fetchone()
    req = client.post(f"/api/vault/items/{item['id']}/request",
                      params={"handle": "salma.mem", "purpose": "تحقّق"})
    assert req.status_code == 200 and req.json()["state"] == "pending"
    acc = conn.execute(
        "SELECT id FROM vault_access WHERE item_id=? AND member='salma.mem'",
        (item["id"],)).fetchone()
    dec = client.post(f"/api/vault/access/{acc['id']}/decide",
                      params={"handle": "rana.act", "state": "approved"})
    assert dec.status_code == 200 and dec.json()["ok"] is True


def test_vault_lists(client):
    assert client.get("/api/vault/items").json()["items"]
    assert client.get("/api/vault/policies").json()["crypto_ready"] is False
    assert client.get("/api/vault/stats").json()["items"] >= 4
    assert "pending" in client.get("/api/vault/access/pending").json()


def test_vault_detail_page(client, conn):
    item = conn.execute("SELECT id FROM vault_items LIMIT 1").fetchone()
    r = client.get(f"/vault/{item['id']}")
    assert r.status_code == 200
    assert "data-vault-item" in r.text


def test_vault_in_nav_and_sitemap(client):
    assert 'href="/vault"' in client.get("/").text
    assert "/vault" in client.get("/sitemap.xml").text


def test_vault_page_english(client):
    r = client.get("/vault", params={"lang": "en"})
    assert r.status_code == 200
    assert "Sensitive files vault" in r.text


def test_admin_key_guard(client, monkeypatch):
    """عند ضبط MIRSAD_ADMIN_KEY يُشترط ترويسة X-Admin-Key."""
    from app import main, ratelimit
    ratelimit.reset()
    monkeypatch.setattr(main, "ADMIN_KEY", "secret-admin")
    denied = client.post("/api/admin/flags", params={"key": "read_only", "value": "1"})
    assert denied.status_code == 401
    allowed = client.post("/api/admin/flags", params={"key": "read_only", "value": "1"},
                          headers={"X-Admin-Key": "secret-admin"})
    assert allowed.status_code == 200
    client.post("/api/admin/flags", params={"key": "read_only", "value": "0"},
                headers={"X-Admin-Key": "secret-admin"})
    monkeypatch.setattr(main, "ADMIN_KEY", "")


# ---------------------------------------------------------------------------
# جلسة التحسينات: i18n، إتاحة، PWA، الخط الزمني
# ---------------------------------------------------------------------------

def test_no_literal_i18n_keys_in_templates():
    """كل مفاتيح t('...') الحرفية في القوالب موجودة في قاموس الترجمة."""
    import re
    from pathlib import Path
    from app.i18n import STRINGS
    missing = {}
    for f in Path("app/templates").glob("*.html"):
        s = f.read_text(encoding="utf-8")
        for m in re.finditer(r"t\(\s*'([a-z0-9_.]+)'\s*\)", s):
            k = m.group(1)
            if k not in STRINGS:
                missing.setdefault(k, []).append(f.name)
    assert not missing, f"مفاتيح ترجمة ناقصة: {missing}"


def test_search_submit_renders_text(client):
    """زر البحث في /discover يعرض نصًّا مترجمًا لا اسم المفتاح."""
    r = client.get("/discover")
    assert r.status_code == 200
    assert "search.submit" not in r.text
    assert "ابحث" in r.text


def test_map_slider_has_label_and_valuetext(client):
    r = client.get("/map")
    assert r.status_code == 200
    assert 'aria-valuetext' in r.text
    assert 'for="map-range"' in r.text


def test_pwa_icons_exist_and_are_png(client):
    import struct
    from pathlib import Path
    for size in (192, 512):
        p = Path(f"app/static/img/icon-{size}.png")
        assert p.exists()
        d = p.read_bytes()
        assert d[:8] == b"\x89PNG\r\n\x1a\n"
        w, h = struct.unpack(">II", d[16:24])
        assert (w, h) == (size, size)


def test_manifest_uses_square_png_icons(client):
    import json
    m = json.loads(client.get("/static/manifest.webmanifest").text)
    srcs = {i["src"] for i in m["icons"]}
    assert "/static/img/icon-192.png" in srcs
    assert "/static/img/icon-512.png" in srcs
    assert all(i["type"] == "image/png" for i in m["icons"])
    assert any(i["purpose"] == "maskable" for i in m["icons"])


def test_apple_touch_icon_present(client):
    assert 'rel="apple-touch-icon"' in client.get("/").text
    assert client.get("/static/img/icon-192.png").status_code == 200


def test_timeline_has_anchors_and_jump(client):
    r = client.get("/timeline")
    assert r.status_code == 200
    assert 'class="timeline-jump"' in r.text
    assert 'id="g-' in r.text
    assert "#g-" in r.text


def test_timeline_export_csv_keeps_filters(client):
    r = client.get("/api/export.csv?category=environment")
    assert r.status_code == 200
    assert "text/csv" in r.headers.get("content-type", "")


def test_sitemap_urls_are_encoded(client):
    """كل <loc> في sitemap.xml مُرمَّز (لا فراغات أو محارف عربية خام)."""
    import re
    from urllib.parse import unquote
    r = client.get("/sitemap.xml")
    assert r.status_code == 200
    locs = re.findall(r"<loc>(.*?)</loc>", r.text)
    assert locs, "sitemap فارغ"
    for loc in locs:
        assert " " not in loc, f"فراغ خام في: {loc}"
        assert all(ord(c) < 128 for c in loc), f"محارف غير مُرمَّزة في: {loc}"
    # رابط دولة عربية مُرمَّز ويُحلّ بنجاح
    country = next(l for l in locs if "/country/" in l)
    path = country.split("testserver", 1)[-1]
    assert client.get(path).status_code == 200
    assert unquote(path) != path  # فعلاً مُرمَّز


def test_icon_only_controls_have_labels(client):
    """أزرار/روابط الأيقونات فقط تحمل aria-label أو title."""
    from pathlib import Path
    assert 'aria-label="{{ t(\'notif.mark_read\') }}"' in Path("app/templates/notifications.html").read_text(encoding="utf-8")
    assert 'aria-label="{{ t(\'report.source\') }}"' in Path("app/templates/claim.html").read_text(encoding="utf-8")
    # زرّا البحث الأيقونيان في السجل وصفحة الخطأ (تُقدَّم HTML عند طلب text/html)
    assert 'aria-label="ابحث"' in client.get("/reports").text
    r404 = client.get("/nope-404-page", headers={"accept": "text/html"})
    assert r404.status_code == 404
    assert 'aria-label="ابحث"' in r404.text
