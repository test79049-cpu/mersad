"""اختبارات التحديث الدوري وسجل المصادر الموسّع."""

from app import refresh as refresh_mod
from app import sources_registry
from app.taxonomy import ENTITY_KINDS


def test_refresh_runs_without_news(conn):
    result = refresh_mod.refresh(conn, pull_news=False)
    assert "ran_at" in result
    assert result["entities_linked"] >= 0
    assert "search_reindexed" in result
    # تُسجَّل آخر عملية تحديث
    assert refresh_mod.last_refresh(conn)


def test_refresh_is_idempotent(conn):
    first = refresh_mod.refresh(conn, pull_news=False)
    second = refresh_mod.refresh(conn, pull_news=False)
    # إعادة الربط ثانيةً لا تُضيف كيانات جديدة للأسماء الموجودة
    assert second["entities_linked"] == 0
    assert first["entities_linked"] >= 0


def test_relink_adds_actor_to_manual_report(conn, temp_db):
    # بلاغ جديد لا يحتوي كيانات من نوع شركة/فرد
    rid = temp_db.insert_report(conn, {
        "title": "مخالفات بيئية من شركة شل في خليج المكسيك",
        "category": "environment", "severity": "high", "status": "new",
        "country": "المكسيك", "region": None, "occurred_on": None,
        "reported_on": "2026-01-01",
        "summary": "تسرّب نفطي واسع من منشأة شركة شل.",
        "details": "", "source_name": "اختبار", "source_url": None,
        "source_id": None, "external_id": "test:relink", "verified": 0,
    })
    added = refresh_mod.relink_entities(conn)
    assert added >= 1
    ents = temp_db.entities_for(conn, rid)
    assert any(e["name"] == "شل" and e["kind"] == "company" for e in ents)


def test_sources_registry_expanded():
    st = sources_registry.stats()
    assert st["datasets"] >= 35
    assert st["software"] >= 15
    # كل مصدر يحمل حقولاً أساسية ورخصة
    for d in sources_registry.OPEN_DATASETS:
        assert d["license"]
        assert d["key"]
        assert d["url"].startswith("http")


def test_doc_resources_registry():
    """الموارد المنهجية المرجعية (HURIDOCS) مُدرجة ومكتملة الحقول."""
    assert len(sources_registry.DOC_RESOURCES) >= 8
    keys = {d["key"] for d in sources_registry.DOC_RESOURCES}
    assert "huridocs_esf" in keys
    assert "huridocs_microthesauri" in keys
    for d in sources_registry.DOC_RESOURCES:
        assert d["key"] and d["name"] and d["name_en"]
        assert d["url"].startswith("https://huridocs.org/")
        assert d["kind"] in sources_registry.DOC_RESOURCE_KINDS
    # كل مورد يخدم مجالاً واحداً على الأقل من مجالات المنصة
    from app.taxonomy import CATEGORY_BY_KEY
    for d in sources_registry.DOC_RESOURCES:
        cats = sources_registry.DOC_RESOURCE_CATEGORIES.get(d["key"], [])
        assert cats, d["key"]
        assert all(c in CATEGORY_BY_KEY for c in cats), d["key"]
    # الدالة المساعدة لصفحة المجال تعمل
    assert sources_registry.doc_resources_for_category("human_rights")
    assert sources_registry.stats()["resources"] == len(sources_registry.DOC_RESOURCES)


def test_gdelt_raw_parse_and_country():
    """تحليل صفوف GDELT الخام: تُقبل الجذور العنفية فقط وتُترجم رموز FIPS."""
    from app import gdelt_raw

    # صفّ GDELT بأعمدة CAMEO المطلوبة (17 = إكراه) وعمود GLOBALEVENTID أولاً
    fields = [""] * 61
    fields[0] = "987654321"
    fields[1] = "20260102"
    fields[5] = "GOV"
    fields[15] = "PROTESTER"
    fields[26] = "172"
    fields[28] = "17"
    fields[30] = "-5.0"
    fields[31] = "3"
    fields[52] = "Cairo, Egypt"
    fields[53] = "EG"
    fields[56] = "30.05"
    fields[57] = "31.23"
    fields[60] = "https://example.org/a"
    non_violent = list(fields)
    non_violent[28] = "04"  # جذر غير عنفي (تشاور)

    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("x.export.CSV", "\t".join(fields) + "\n" + "\t".join(non_violent) + "\n")

    events = gdelt_raw.parse_export(buf.getvalue())
    assert len(events) == 1
    assert events[0]["event_id"] == "987654321"
    assert events[0]["root"] == "17"
    assert gdelt_raw.country_from_fips("EG") == "مصر"
    assert gdelt_raw.country_from_fips("ZZ") == ""
    # البصمة ثابتة لنفس الحدث ومختلفة عند تغيّر الرابط
    fp = gdelt_raw._fingerprint(events[0])
    assert fp == gdelt_raw._fingerprint(dict(events[0]))
    other = dict(events[0]); other["url"] = "https://example.org/b"
    assert fp != gdelt_raw._fingerprint(other)


def test_gdelt_raw_ingest_dedups(conn, temp_db, monkeypatch):
    """إدراج حدث GDELT مرّتين لا يُنشئ بلاغاً مكرّراً (بصمة المحتوى)."""
    from app import gdelt_raw

    ev = {"event_id": "1", "date": "20260102", "root": "18", "goldstein": "-8",
          "mentions": "2", "actor1": "MIL", "actor2": "CIV",
          "location": "Gaza", "fips": "GZ", "lat": "31.5", "lng": "34.4",
          "url": "https://example.org/x"}
    monkeypatch.setattr(gdelt_raw, "export_urls_range", lambda *a, **k: ["u1"])
    monkeypatch.setattr(gdelt_raw, "_download", lambda *a, **k: b"")
    monkeypatch.setattr(gdelt_raw, "parse_export", lambda *a, **k: [ev, dict(ev)])

    result = gdelt_raw.ingest_gdelt_raw(conn, days=1)
    assert result["inserted"] == 1
    assert result["skipped"] == 1

    second = gdelt_raw.ingest_gdelt_raw(conn, days=1)
    assert second["inserted"] == 0
    assert second["skipped"] == 2


def test_entity_kinds_taxonomy():
    keys = {k["key"] for k in ENTITY_KINDS}
    assert {"person", "company", "organization", "government", "country"} <= keys
    for k in ENTITY_KINDS:
        assert k["label"] and k["singular"] and k["color"]


def test_entity_counts_after_seed(conn, temp_db):
    counts = temp_db.entity_counts(conn)
    assert counts.get("company", 0) >= 8
    assert counts.get("person", 0) >= 5
    assert counts.get("organization", 0) >= 20
