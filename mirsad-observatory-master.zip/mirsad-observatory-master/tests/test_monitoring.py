"""اختبارات منظومة الرصد والتحقق والتحديث الآلي.

تغطّي: كشف التكرار متعدّد المستويات، محرّك الثقة والتحقق، خط المعالجة الموحّد،
الاستيراد التاريخي القابل للاستئناف، ومنسّق الرصد (طابور المهام والتنبيهات).
"""

from app import backfill, connectors, db, dedup, monitoring, pipeline, verification


# --- كشف التكرار (القسم 5) ---

def test_dedup_exact_by_external_id(conn):
    rid = db.insert_report(conn, {
        "title": "اعتقال ناشط في القاهرة", "category": "human_rights",
        "severity": "high", "status": "new", "country": "مصر",
        "occurred_on": "2026-02-01", "reported_on": "2026-02-02",
        "summary": "ملخص", "details": "تفاصيل", "verified": 0, "source_name": "مصدر",
        "source_url": "https://news.example.com/1", "external_id": "ext:1"})
    idx = dedup.build_index(conn)
    res = dedup.find_duplicate(conn, {"title": "أي عنوان", "external_id": "ext:1"}, idx)
    assert res.decision == dedup.EXACT and res.report_id == rid


def test_dedup_exact_by_canonical_url(conn):
    rid = db.insert_report(conn, {
        "title": "واقعة", "category": "human_rights", "severity": "high",
        "status": "new", "country": "مصر", "occurred_on": "2026-02-01",
        "reported_on": "2026-02-02", "summary": "s", "details": "d", "verified": 0, "source_name": "مصدر",
        "source_url": "https://www.example.com/story/", "external_id": "x"})
    idx = dedup.build_index(conn)
    res = dedup.find_duplicate(conn, {"title": "z", "url": "http://example.com/story"}, idx)
    assert res.decision == dedup.EXACT and res.report_id == rid


def test_dedup_exact_by_digest(conn):
    rid = db.insert_report(conn, {
        "title": "قصف مدني", "category": "human_rights", "severity": "critical",
        "status": "new", "country": "سوريا", "occurred_on": "2026-01-01",
        "reported_on": "2026-01-02", "summary": "قصف", "details": "قصف مدني",
        "verified": 0, "source_name": "مصدر", "source_url": "https://a.org/1", "external_id": "a1"})
    # بصمة المحتوى تُكتب عادةً عبر خط المعالجة؛ نحاكيها هنا.
    conn.execute("UPDATE reports SET content_digest = ? WHERE id = ?",
                 (dedup.content_digest("قصف مدني", "قصف مدني"), rid))
    conn.commit()
    idx = dedup.build_index(conn)
    res = dedup.find_duplicate(conn, {
        "title": "قصف مدني", "body": "قصف مدني", "url": "https://b.org/2",
        "external_id": "b2"}, idx)
    assert res.decision == dedup.EXACT and res.report_id == rid


def test_dedup_probable_prevents_merge_on_doubt(conn):
    """عنوان متطابق بوقائع مختلفة لا يُدمج نهائيًّا — يُحال للمراجعة."""
    db.insert_report(conn, {
        "title": "اعتقال ناشط في القاهرة", "category": "human_rights",
        "severity": "high", "status": "new", "country": "مصر",
        "occurred_on": "2026-02-01", "reported_on": "2026-02-02",
        "summary": "s", "details": "d", "verified": 0, "source_name": "مصدر",
        "source_url": "https://a.org/1", "external_id": "a1"})
    idx = dedup.build_index(conn)
    res = dedup.find_duplicate(conn, {
        "title": "اعتقال ناشط في القاهرة", "body": "حدث مختلف تمامًا",
        "url": "https://b.org/2", "external_id": "b2",
        "country": "الأردن", "category": "environment", "occurred_on": "2024-11-11"}, idx)
    assert res.decision == dedup.PROBABLE


def test_dedup_detects_correction_and_update(conn):
    is_update, is_corr = dedup.detect_update("تصحيح: نفى المتحدث الخبر")
    assert is_corr is True
    is_update2, is_corr2 = dedup.detect_update("تحديث جديد بشأن الواقعة")
    assert is_update2 is True and is_corr2 is False


def test_canonical_url_normalization():
    assert dedup.canonical_url("https://www.Example.com/a/?q=1") == "example.com/a"


# --- محرّك التحقق والثقة (القسمان 8 و9) ---

def test_verification_single_source_is_checking(conn):
    rid = _seed(conn)
    db.add_evidence(conn, rid, source_name="أ", source_url="https://a.org/1",
                    source_kind="primary", reliability=0.7)
    res = verification.apply(conn, rid)
    assert res["state"] == "checking" and res["badge"] == 0


def test_verification_two_independent_sources_verifies(conn):
    rid = _seed(conn)
    db.add_evidence(conn, rid, source_name="أ", source_url="https://a.org/1",
                    source_kind="primary", reliability=0.8)
    db.add_evidence(conn, rid, source_name="ب", source_url="https://b.org/2",
                    source_kind="primary", reliability=0.8)
    res = verification.apply(conn, rid)
    assert res["state"] == "verified"
    assert res["badge"] == 1
    assert res["independent_sources"] == 2
    row = conn.execute("SELECT verified, badge FROM reports WHERE id = ?", (rid,)).fetchone()
    assert row["verified"] == 1 and row["badge"] == 1


def test_verification_derived_sources_not_independent(conn):
    """مصدران من المضيف نفسه لا يُحتسبان مستقلّين."""
    rid = _seed(conn)
    db.add_evidence(conn, rid, source_name="أ", source_url="https://a.org/1",
                    source_kind="primary", reliability=0.8)
    db.add_evidence(conn, rid, source_name="ناقل", source_url="https://a.org/mirror",
                    source_kind="secondary", reliability=0.6)
    res = verification.apply(conn, rid)
    assert res["independent_sources"] == 1
    assert res["state"] != "verified"


def test_verification_contradiction_disputes(conn):
    rid = _seed(conn)
    db.add_evidence(conn, rid, source_name="أ", source_url="https://a.org/1",
                    source_kind="primary", reliability=0.8)
    db.add_evidence(conn, rid, source_name="معارض", source_url="https://b.org/2",
                    supports="contradicts")
    res = verification.apply(conn, rid)
    assert res["state"] == "disputed" and res["badge"] == 0


def test_badge_explanation(conn):
    rid = _seed(conn)
    db.add_evidence(conn, rid, source_name="أ", source_url="https://a.org/1",
                    source_kind="primary", reliability=0.8)
    db.add_evidence(conn, rid, source_name="ب", source_url="https://b.org/2",
                    source_kind="primary", reliability=0.8)
    verification.apply(conn, rid)
    ex = verification.badge_explanation(conn, rid)
    assert ex["badge"] == 1 and ex["independent_sources"] == 2
    assert any(s["independence"] == "independent" for s in ex["sources"])


# --- خط المعالجة الموحّد (القسم 3) ---

def test_pipeline_ingest_dedups_same_source_item(conn):
    src = {"key": "t1", "name": "مصدر"}
    item = {"title": "خبر", "url": "https://t.org/1", "external_id": "t:1"}
    did, dup = pipeline.ingest_item(conn, src, item)
    assert did and not dup
    did2, dup2 = pipeline.ingest_item(conn, src, item)
    assert did2 == did and dup2 is True


def test_pipeline_full_cycle_creates_report(conn):
    src = {"key": "t2", "name": "مصدر رسمي", "domain": "human_rights",
           "severity": "high", "source_kind": "official"}
    did, _ = pipeline.ingest_item(conn, src, {
        "title": "اعتقال ناشط في تونس", "body": "اعتقلت السلطات ناشطًا في 2026-04-01",
        "url": "https://t.org/a", "external_id": "t:a", "published_on": "2026-04-02"})
    res = pipeline.process_document(conn, did, source=src)
    assert res["decision"] == "new" and res["report_id"]
    assert res["stages"] == ["ingested", "normalized", "extracted", "classified",
                             "deduped", "verified", "actioned", "audited"]
    doc = db.document_by_id(conn, did)
    assert doc["state"] == "processed" and doc["stage"] == "audited"


def test_pipeline_second_source_links_not_duplicates(conn):
    """مصدران مستقلان لنفس الواقعة → سجل واحد وأدلّة متعدّدة (استقلال)."""
    src1 = {"key": "s1", "name": "أ", "domain": "human_rights",
            "source_kind": "primary"}
    src2 = {"key": "s2", "name": "ب", "domain": "human_rights",
            "source_kind": "primary"}
    body = "اعتقلت قوات الأمن ناشطًا في القاهرة في 2026-03-04"
    d1, _ = pipeline.ingest_item(conn, src1, {
        "title": "اعتقال ناشط في القاهرة", "body": body,
        "url": "https://a.org/1", "external_id": "a1", "published_on": "2026-03-05"})
    r1 = pipeline.process_document(conn, d1, source=src1)
    d2, _ = pipeline.ingest_item(conn, src2, {
        "title": "اعتقال ناشط في القاهرة", "body": body,
        "url": "https://b.org/2", "external_id": "b2", "published_on": "2026-03-06"})
    r2 = pipeline.process_document(conn, d2, source=src2)
    assert r2["report_id"] == r1["report_id"]
    n = conn.execute("SELECT COUNT(*) n FROM reports WHERE title = ?",
                     ("اعتقال ناشط في القاهرة",)).fetchone()["n"]
    assert n == 1
    counts = db.evidence_counts(conn, r1["report_id"])
    assert counts["supports"] == 2 and counts["independent"] == 2


def test_pipeline_reprocess_is_idempotent(conn):
    src = {"key": "t3", "name": "م", "domain": "human_rights"}
    did, _ = pipeline.ingest_item(conn, src, {
        "title": "واقعة فريدة", "url": "https://t.org/x", "external_id": "t:x"})
    r1 = pipeline.process_document(conn, did, source=src)
    r2 = pipeline.process_document(conn, did, source=src)
    assert r1["report_id"] == r2["report_id"]
    n = conn.execute("SELECT COUNT(*) n FROM reports WHERE id = ?",
                     (r1["report_id"],)).fetchone()["n"]
    assert n == 1


# --- الاستيراد التاريخي القابل للاستئناف (القسم 2.3) ---

def test_backfill_resumes_from_cursor(conn, monkeypatch):
    items = [{"title": f"أرشيف {i}", "url": f"https://arch.org/{i}",
              "external_id": f"a{i}", "published_on": "2024-05-01"} for i in range(7)]
    monkeypatch.setattr(pipeline.connectors, "collect_source",
                        lambda src, maxrecords=40: items)
    src = {"key": "arch", "name": "أرشيف", "url": "https://arch.org"}
    r1 = backfill.backfill_source(conn, src, batch_items=3, max_batches=1)
    assert r1["status"] == "running" and r1["imported"] == 3
    r2 = backfill.backfill_source(conn, src, batch_items=3, max_batches=1)
    assert r2["imported"] == 3  # يستأنف من الموضع لا من البداية
    r3 = backfill.backfill_source(conn, src, batch_items=3, max_batches=5)
    assert r3["status"] == "done"
    prog = db.archive_for_source(conn, "arch")
    assert prog["items_imported"] == 7
    assert prog["status"] == "done"


def test_backfill_blocked_source_is_recorded(conn, monkeypatch):
    def boom(src, maxrecords=40):
        raise RuntimeError("404 not found")
    monkeypatch.setattr(pipeline.connectors, "collect_source", boom)
    res = backfill.backfill_source(conn, {"key": "dead", "name": "معطّل",
                                          "url": "https://dead.org"})
    assert res["status"] == "blocked"
    assert "تعذّر الوصول" in db.archive_for_source(conn, "dead")["note"]


# --- منسّق الرصد (الأقسام 2.2، 7، 11، 13) ---

def test_monitor_tick_respects_intervals(conn, monkeypatch):
    monkeypatch.setattr(pipeline.connectors, "collect_source",
                        lambda src, maxrecords=12: [])
    first = monitoring.monitor_tick(conn)
    assert "collect" in first["ran"]
    # مباشرة بعده: لا شيء مستحق (الفترات لم تنقضِ).
    second = monitoring.monitor_tick(conn)
    assert second["ran"] == []


def test_monitor_collect_queues_and_processes(conn, monkeypatch):
    items = [{"title": f"خبر {i}", "url": f"https://m.org/{i}",
              "external_id": f"m{i}", "published_on": "2026-04-02"} for i in range(3)]
    monkeypatch.setattr(pipeline.connectors, "collect_source",
                        lambda src, maxrecords=12: items)
    conn.execute("UPDATE source_catalog SET enabled = 1, next_run = NULL, "
                 "feed_url = 'https://m.org/feed' WHERE id = "
                 "(SELECT id FROM source_catalog LIMIT 1)")
    conn.commit()
    res = monitoring.run_now(conn, "collect")
    assert res["fetched"] >= 3
    assert res["processed"] >= 3
    assert res["new"] >= 1


def test_reconcile_resets_stale_tasks(conn):
    db.enqueue_task(conn, "stale:1", "process")
    db.claim_tasks(conn, "process", limit=1)  # تصبح running
    conn.execute("UPDATE task_queue SET locked_at = datetime('now','-60 minutes') "
                 "WHERE task_id = 'stale:1'")
    conn.commit()
    res = monitoring.reconcile_cycle(conn)
    assert res["stale_tasks"] >= 1


def test_task_queue_lifecycle(conn):
    assert db.enqueue_task(conn, "t:1", "process", priority=1) is True
    assert db.enqueue_task(conn, "t:1", "process") is False  # لا تكرار
    tasks = db.claim_tasks(conn, "process", limit=5)
    assert len(tasks) == 1
    db.finish_task(conn, "t:1", ok=True)
    stats = db.task_queue_stats(conn)
    assert stats["done"] == 1 and stats["queued"] == 0


# --- واجهة API والصفحات ---

def test_monitor_api_endpoints(client):
    for path in ("/api/monitoring", "/api/monitoring/metrics",
                 "/api/monitoring/tasks", "/api/monitoring/alerts",
                 "/api/monitoring/changes", "/api/monitoring/archive"):
        assert client.get(path).status_code == 200


def test_monitor_and_audit_pages(client):
    assert client.get("/monitor").status_code == 200
    assert client.get("/audit").status_code == 200
    assert client.get("/monitor?lang=en").status_code == 200


def test_report_verification_api(client):
    r = client.get("/api/reports/1/verification")
    assert r.status_code == 200
    assert "explanation" in r.json()


def test_monitor_run_requires_no_key_when_unset(client):
    """نقاط التشغيل مفتوحة للتطوير عند غياب MIRSAD_INGEST_KEY."""
    r = client.post("/api/monitoring/run?task=reconcile")
    assert r.status_code == 200


# --- أدوات مساعدة ---

def _seed(conn) -> int:
    return db.insert_report(conn, {
        "title": "واقعة اختبار", "category": "human_rights", "severity": "high",
        "status": "new", "country": "مصر", "occurred_on": "2026-02-01",
        "reported_on": "2026-02-02", "summary": "s", "details": "d", "verified": 0, "source_name": "مصدر",
        "source_url": "https://seed.example/1", "external_id": "seed:1"})
