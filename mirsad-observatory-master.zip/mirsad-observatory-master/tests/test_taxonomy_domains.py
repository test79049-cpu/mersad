"""اختبارات توسيع التصنيف: المجالات الجديدة والتسلسل الهرمي والترجمة."""

from app import taxonomy
from app.taxonomy import CATEGORIES, CATEGORY_BY_KEY, CHILD_CATEGORIES, PARENT_CATEGORIES

# المجالات المطلوبة صراحةً (المفاتيح) — تُحمى من الحذف أو إعادة التسمية.
EXPECTED_KEYS = {
    "human_rights", "environment", "labor_rights", "animal_rights", "ai_ethics",
    "minorities", "women_children", "refugees_migrants", "expression",
    "transitional_justice", "economic_social", "health", "education_culture",
    "poverty_food", "criminal_justice", "prisoners_rights", "disability_rights",
    "peace_security", "inclusivity", "elderly_rights",
}


def test_expected_domains_present():
    keys = {c["key"] for c in CATEGORIES}
    assert EXPECTED_KEYS <= keys


def test_category_keys_unique_and_complete():
    keys = [c["key"] for c in CATEGORIES]
    assert len(keys) == len(set(keys))
    for c in CATEGORIES:
        for field in ("name", "name_en", "short", "short_en", "icon", "color", "description"):
            assert c.get(field), f"{c['key']} missing {field}"


def test_parents_are_valid_and_acyclic():
    for c in CATEGORIES:
        p = c.get("parent")
        assert p is None or p in CATEGORY_BY_KEY
        assert p != c["key"]


def test_hierarchy_partitions_categories():
    assert len(PARENT_CATEGORIES) + len(CHILD_CATEGORIES) == len(CATEGORIES)
    for child in CHILD_CATEGORIES:
        assert child["parent"] in {p["key"] for p in PARENT_CATEGORIES}


def test_every_category_has_seed_data(conn, temp_db):
    st = temp_db.stats(conn)
    for c in CATEGORIES:
        assert st["by_category"].get(c["key"], 0) > 0, c["key"]


def test_every_category_has_english_seed():
    from app.seed_data import SEED_ROWS
    from app.seed_en import SEED_EN
    for title, cat, *_ in SEED_ROWS:
        assert title in SEED_EN, f"no EN translation for {cat}: {title}"


def test_classifier_covers_all_categories():
    from app.importers import CATEGORY_KEYWORDS, GDELT_QUERIES
    for c in CATEGORIES:
        assert c["key"] in CATEGORY_KEYWORDS, c["key"]
        assert c["key"] in GDELT_QUERIES, c["key"]


def test_classifier_reaches_new_domains():
    from app.importers import classify
    cases = {
        "Child marriage of girls rises in region": "women_children",
        "Migrant boat capsizes, refugees missing": "refugees_migrants",
        "Journalist jailed under censorship law": "expression",
        "Truth commission recommends reparations": "transitional_justice",
        "Forced eviction leaves families without housing": "economic_social",
        "Patients denied healthcare in hospital": "health",
        "Girls barred from school and university": "education_culture",
        "Famine deepens food insecurity": "poverty_food",
        "Death penalty imposed after unfair trial": "criminal_justice",
        "Prison conditions deteriorate for detainees": "prisoners_rights",
        "Accessibility denied to persons with disabilities": "disability_rights",
        "Disarmament talks as civilians suffer war crimes": "peace_security",
        "Older persons denied pension and retirement": "elderly_rights",
        "Hate speech targets diversity and inclusion": "inclusivity",
    }
    for title, expected in cases.items():
        got, _sev, _conf = classify(title)
        assert got == expected, f"{title!r} → {got}, expected {expected}"


def test_category_name_localized():
    assert taxonomy.category_name("health", "ar") == "الحق في الصحة"
    assert taxonomy.category_name("health", "en") == "Health"
    assert taxonomy.category_name("women_children", "en").startswith("Women")


def test_home_and_footer_show_all_domains(client):
    html = client.get("/").text
    for c in CATEGORIES:
        assert f"/category/{c['key']}" in html


def test_home_has_no_nested_anchors(client):
    """بطاقات المجالات تحمل روابط فرعية — يجب ألّا تُتداخل <a> داخل <a>."""
    from html.parser import HTMLParser

    class _Nest(HTMLParser):
        def __init__(self):
            super().__init__()
            self.stack = []
            self.nested = 0

        def handle_starttag(self, tag, attrs):
            if tag == "a":
                if "a" in self.stack:
                    self.nested += 1
                self.stack.append("a")
            elif tag in ("div", "ul", "li", "section", "article", "nav"):
                self.stack.append(tag)

        def handle_endtag(self, tag):
            if tag in ("a", "div", "ul", "li", "section", "article", "nav") and tag in self.stack:
                while self.stack:
                    if self.stack.pop() == tag:
                        break

    for path in ("/", "/about"):
        parser = _Nest()
        parser.feed(client.get(path).text)
        assert parser.nested == 0, f"nested <a> in {path}"


def test_child_domains_linked_from_home(client):
    html = client.get("/").text
    for child in CHILD_CATEGORIES:
        assert f"/category/{child['key']}" in html
        assert child["name"] in html


def test_new_category_page_renders(client):
    for key in ("health", "disability_rights", "prisoners_rights", "elderly_rights"):
        r = client.get(f"/category/{key}")
        assert r.status_code == 200
        assert CATEGORY_BY_KEY[key]["name"] in r.text


def test_domain_count_is_dynamic_not_seven(client):
    """لا يبقى النصّ مقيّدًا بعدد المجالات القديم (سبعة/7)."""
    from app.taxonomy import CATEGORIES as _C
    n = len(_C)
    for path in ("/", "/about"):
        html = client.get(path).text
        assert f"{n} domains" in html or f"{n} مجالًا" in html or f"{n} مجالات" in html


def test_taxonomy_api_exposes_parent_field(client):
    cats = client.get("/api/taxonomy").json()["categories"]
    by_key = {c["key"]: c for c in cats}
    assert by_key["prisoners_rights"]["parent"] == "criminal_justice"
    assert by_key["elderly_rights"]["parent"] == "inclusivity"
