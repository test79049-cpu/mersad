"""اختبارات فهرس المصادر الواسع (catalog) ومحرّك الجمع (harvest) ونافذة العاجل."""

from app import catalog, db
from app.rss_feeds import parse_feed, parse_iso_date
from app.taxonomy import CATEGORIES


def test_catalog_exceeds_1000_sources():
    """الفهرس يضمّ 1000+ مصدر ويغطّي كل مجالات التصنيف."""
    entries = catalog.build_catalog()
    assert len(entries) >= 1000
    domains = {e["domain"] for e in entries}
    assert domains == {c["key"] for c in CATEGORIES}
    # مفاتيح فريدة لكل مصدر
    keys = [e["key"] for e in entries]
    assert len(keys) == len(set(keys))


def test_catalog_every_entry_has_required_fields():
    for e in catalog.build_catalog():
        assert e["key"] and e["name"] and e["url"]
        assert e["kind"] in {"feed", "search", "dataset", "api"}
        assert e["domain"] in {c["key"] for c in CATEGORIES}
        assert e["severity"] in {"critical", "high", "medium", "low"}


def test_catalog_synced_into_db(conn):
    """init_db يزامن الفهرس إلى جدول source_catalog."""
    health = db.catalog_health(conn)
    assert health["total"] >= 1000
    assert health["enabled"] > 0
    assert health["ok"] == 0 and health["failed"] == 0


def test_catalog_due_and_mark_run(conn):
    """دوران المصادر: المصادر الجديدة «مستحقّة»، وبعد التشغيل تُعلَّم بنتيجتها."""
    due = db.catalog_due(conn, limit=5)
    assert due, "لا مصادر مستحقّة في فهرس جديد"
    key = due[0]["key"]
    db.mark_catalog_run(conn, key, status="ok", fetched=5, inserted=3)
    row = conn.execute(
        "SELECT last_status, inserted_total, items_total FROM source_catalog WHERE key = ?",
        (key,)).fetchone()
    assert row["last_status"] == "ok"
    assert row["inserted_total"] == 3
    assert row["items_total"] == 5
    # مصدر فشل يُعلَّم فاشلاً مع عدّاد تراجع
    key2 = due[1]["key"]
    db.mark_catalog_run(conn, key2, status="error", error="boom")
    row2 = conn.execute(
        "SELECT last_status, last_error, fail_count FROM source_catalog WHERE key = ?",
        (key2,)).fetchone()
    assert row2["last_status"] == "error"
    assert row2["last_error"] == "boom"
    assert row2["fail_count"] == 1


def test_urgent_reports_shape(conn):
    items = db.urgent_reports(conn, limit=5)
    assert items
    # إمّا بلاغات حرجة/مرتفعة حديثة، أو أحدث البلاغات عند خلوّ النطاق (سلوك بديل).
    severities = {r["severity"] for r in items}
    if severities - {"critical", "high"}:
        # سقطنا إلى البديل: يجب أن تكون مرتّبة بالأحدث.
        reported = [r["reported_on"] for r in items]
        assert reported == sorted(reported, reverse=True)
    else:
        assert severities <= {"critical", "high"}


def test_collection_stats_shape(conn):
    stats = db.collection_stats(conn)
    for k in ("added_1h", "added_24h", "critical_24h", "verified", "latest"):
        assert k in stats
    assert stats["added_24h"] >= stats["added_1h"]


def test_count_reports_matches_query(conn):
    """العدّ السريع (SQL COUNT) يطابق عدّ الصفوف الفعلي لكل المرشّحات."""
    for filters in ({}, {"severity": "critical"}, {"category": "human_rights"},
                    {"verified": True}, {"verified": False},
                    {"search": "حقوق"}, {"country": "مصر"}):
        expected = len(db.query_reports(conn, **filters))
        assert db.count_reports(conn, **filters) == expected, filters


def test_timeline_milestones_one_per_month(conn):
    items = db.timeline_milestones(conn, limit=6)
    assert 0 < len(items) <= 6
    months = [(r["occurred_on"] or r["reported_on"])[:7] for r in items]
    assert len(months) == len(set(months)), "أكثر من محطة في الشهر نفسه"
    assert months == sorted(months, reverse=True)


def test_parse_iso_date_handles_rss_and_atom():
    assert parse_iso_date("Wed, 26 Aug 2026 10:00:00 GMT") == "2026-08-26"
    assert parse_iso_date("2026-08-26T10:00:00Z") == "2026-08-26"
    assert parse_iso_date("2026-08-26") == "2026-08-26"
    assert parse_iso_date("") == ""
    assert parse_iso_date("not a date") == ""


def test_parse_feed_normalizes_dates():
    """التغذية تُحلَّل وتُخزَّن تواريخها ISO لا مقتطعة."""
    xml = """<?xml version="1.0"?>
    <rss version="2.0"><channel>
      <item>
        <title>انتهاك تجريبي</title>
        <link>https://example.org/a</link>
        <description>وصف</description>
        <pubDate>Wed, 26 Aug 2026 10:00:00 GMT</pubDate>
      </item>
    </channel></rss>"""
    items = parse_feed(xml)
    assert len(items) == 1
    assert items[0]["date"] == "2026-08-26"


def test_repair_bad_dates_fixes_and_rekeys(conn):
    """التواريخ المشوّهة تُصلح ويُعاد حساب بصمة التكرار."""
    rid = conn.execute(
        """INSERT INTO reports (title, category, severity, status, country,
                                reported_on, summary, occurred_on, dedup_key)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        ("بلاغ بتاريخ مشوّه", "human_rights", "medium", "new", "مصر",
         "Wed, 26 Au", "ملخّص", "Wed, 26 Au", "قديم"),
    ).lastrowid
    conn.commit()
    fixed = db.repair_bad_dates(conn)
    assert fixed >= 1
    row = conn.execute(
        "SELECT occurred_on, reported_on, dedup_key FROM reports WHERE id = ?",
        (rid,)).fetchone()
    assert len(row["occurred_on"]) == 10 and row["occurred_on"][4] == "-"
    assert len(row["reported_on"]) == 10 and row["reported_on"][4] == "-"
    assert row["dedup_key"] != "قديم"


def test_api_urgent_endpoint(client):
    r = client.get("/api/urgent?limit=3")
    assert r.status_code == 200
    data = r.json()
    assert data["count"] <= 3
    assert "collection" in data and "catalog" in data
    for it in data["items"]:
        assert it["id"] and it["title"] and it["severity"]


def test_api_collection_endpoint(client):
    r = client.get("/api/collection")
    assert r.status_code == 200
    data = r.json()
    assert "collection" in data and "catalog" in data
    assert data["catalog"]["total"] >= 1000


def test_home_renders_urgent_window(client):
    html = client.get("/").text
    assert "urgent__status" in html
    assert "data-urgent-list" in html
    assert 'data-urgent-added-1h' in html
    assert "/api/urgent" in html  # نقطة التحديث التلقائي في تهيئة JS
