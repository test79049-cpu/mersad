"""إعداد مشترك للاختبارات: قاعدة بيانات مؤقّتة وعميل اختبار FastAPI."""

import importlib
import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def temp_db(monkeypatch):
    """قاعدة بيانات مؤقّتة معبّأة، معزولة لكل اختبار."""
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    os.environ["MIRSAD_DB"] = tmp.name

    from app import config, db
    importlib.reload(config)
    importlib.reload(db)
    db.init_db(force=True)

    yield db

    try:
        os.remove(tmp.name)
    except OSError:
        pass
    os.environ.pop("MIRSAD_DB", None)


@pytest.fixture()
def conn(temp_db):
    c = temp_db.connect()
    yield c
    c.close()


@pytest.fixture()
def client(temp_db):
    from fastapi.testclient import TestClient
    from app import main
    importlib.reload(main)
    with TestClient(main.app) as tc:
        yield tc
