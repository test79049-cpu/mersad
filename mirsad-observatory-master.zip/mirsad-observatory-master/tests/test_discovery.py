"""اختبارات نظام اكتشاف المصادر الدوري (discovery).

تتحقّق من: تغطية التصنيفات الـ15، معايير القبول (مجاني/مفتوح)، منع التكرار
بالاسم والرابط، الإضافة الفعلية إلى فهرس المصادر وقائمة المصادر، تسجيل التقرير،
والدورة الدورية (due)، وسطح الموقع (صفحة المصادر + واجهة API).
"""

from app import db, discovery
from app.taxonomy import CATEGORY_KEYS


def test_covers_all_fifteen_groups():
    """التصنيفات المرجعية 15 كاملة، وكل مجموعة مربوطة بمجالات صالحة."""
    assert len(discovery.DISCOVERY_GROUPS) == 15
    keys = [g["key"] for g in discovery.DISCOVERY_GROUPS]
    assert len(keys) == len(set(keys))
    for g in discovery.DISCOVERY_GROUPS:
        assert g["name"] and g["name_en"] and g["desc"]
        assert g["categories"], f"مجموعة بلا مجالات: {g['key']}"
        for c in g["categories"]:
            assert c in CATEGORY_KEYS


def test_reference_examples_present():
    """أمثلة الطلب المرجعية موجودة فعليًّا ضمن المرشّحين."""
    text = " ".join(f"{c[1]} {c[2]} {c[5]}" for c in discovery.CANDIDATES).lower()
    for needle in ("ddosecrets", "icij", "opensanctions", "opencorporates",
                   "huridocs", "bellingcat", "ohchr", "amnesty", "hrw",
                   "ejatlas", "globalforestwatch", "unep", "incidentdatabase",
                   "algorithmwatch", "accessnow", "eff", "indigenousnavigator",
                   "iwgia", "ilga", "outright", "minorityrights", "uscirf",
                   "rsf", "cpj", "ituc", "business-humanrights",
                   "internationaldisabilityalliance", "witness",
                   "unwomen", "oecd", "unhcr", "missingmigrants", "bvmn",
                   "unicef", "childrightsconnect", "helpage", "mnemonic"):
        assert needle in text, f"مثال مرجعي مفقود: {needle}"


def test_candidate_fields_valid():
    """كل مرشّح بمجالات صالحة ونوع صالح ورخصة معرّفة."""
    for c in discovery.CANDIDATES:
        (key, name_ar, name_en, group, kind, url, license, coverage, access, feed) = c
        assert key and name_ar and name_en and url.startswith("http")
        assert group in discovery.GROUP_BY_KEY, f"مجموعة غير معروفة: {group}"
        assert kind in discovery.SOURCE_KINDS, f"نوع غير معروف: {kind}"
        assert coverage and access
        # كل مرشّح يجب أن يجتاز معايير القبول (مجاني/مفتوح).
        assert discovery.license_is_open(license), f"رخصة غير مقبولة: {key} → {license}"
        if feed:
            assert feed.startswith("http")
    # مفاتيح فريدة
    keys = [c[0] for c in discovery.CANDIDATES]
    assert len(keys) == len(set(keys))


def test_license_gate_rejects_closed():
    assert discovery.license_is_open("CC BY 4.0")
    assert discovery.license_is_open("ODbL 1.0 (بيانات مفتوحة)")
    assert discovery.license_is_open("MIT")
    assert discovery.license_is_open("ملكية عامة")
    assert not discovery.license_is_open("جميع الحقوق محفوظة")
    assert not discovery.license_is_open("اشتراك مدفوع")
    assert not discovery.license_is_open("")


def test_discover_adds_and_dedups(conn):
    """الدورة تُضيف مصادر جديدة، ثم لا تُكرّرها في دورة ثانية."""
    first = discovery.discover(conn)
    assert first["added_count"] > 0
    assert first["rejected_count"] == 0
    # كل مصدر مُضاف بمجال صالح ومجموعة صالحة.
    for a in first["added"]:
        assert a["domain"] in CATEGORY_KEYS
        assert a["group"] in discovery.GROUP_BY_KEY

    total_after_first = db.discovered_count(conn)
    assert total_after_first == first["added_count"]

    second = discovery.discover(conn)
    assert second["added_count"] == 0, "الدورة الثانية أضافت مصادر مكرّرة"
    assert second["duplicate_count"] == len(discovery.CANDIDATES)
    assert db.discovered_count(conn) == total_after_first


def test_dedup_against_existing_sources(conn):
    """لا يُضاف مصدر موجود مسبقًا في `sources` (تطابق المضيف/الاسم)."""
    # OpenSanctions مدرج مسبقًا في OPEN_SOURCES/OPEN_DATASETS.
    assert discovery.is_duplicate(conn, "أوبن سانكشنز", "https://www.opensanctions.org/")
    # اسم جديد تمامًا بمضيف جديد لا يُعدّ مكرّرًا.
    assert discovery.is_duplicate(conn, "مصدر ابتكاري للاختبار", "https://example-unique.test/") is None


def test_discovered_sources_persisted_and_listed(conn):
    """المصادر المكتشفة تُخزَّن في فهرس المصادر وتظهر في قائمة المصادر."""
    report = discovery.discover(conn)
    assert report["added_count"] > 0
    discovered = db.discovered_sources(conn)
    assert len(discovered) == report["added_count"]
    # كل مصدر مكتشف له تغطية ورخصة ومجالات.
    for d in discovered:
        assert d["coverage"] and d["license"] and d["categories"]
    # المصادر ذات التغذية مُفعّلة في فهرس المصادر (لتُجمع دوريًّا)، والمرجعية معطّلة.
    feed_keys = [d["key"] for d in discovered if d["feed_url"]]
    assert feed_keys, "لا مصادر ذات تغذية بين المكتشفة"
    for k in feed_keys:
        row = conn.execute("SELECT enabled, kind FROM source_catalog WHERE key = ?",
                           (k,)).fetchone()
        assert row["enabled"] == 1 and row["kind"] == "feed"


def test_report_logged_and_history(conn):
    """كل دورة تُسجَّل، ويُسترجَع أحدث تقرير كامل."""
    discovery.discover(conn)
    history = db.discovery_history(conn)
    assert len(history) >= 1
    latest = db.latest_discovery_report(conn)
    assert latest is not None
    assert latest["added_count"] > 0
    assert latest["by_group"] and latest["by_kind"]


def test_dry_run_adds_nothing(conn):
    """التشغيل الجاف لا يضيف ولا يسجّل."""
    report = discovery.discover(conn, dry_run=True)
    assert report["added_count"] > 0
    assert db.discovered_count(conn) == 0
    assert db.discovery_history(conn) == []


def test_due_and_interval(conn, monkeypatch):
    """الدورة الدورية: تُشغَّل أول مرّة ثم لا تتكرّر قبل انقضاء الفترة."""
    monkeypatch.setattr(discovery, "DISCOVERY_INTERVAL", 3600)
    assert discovery.is_due(conn) is True
    first = discovery.maybe_discover(conn)
    assert first is not None and first["added_count"] > 0
    assert discovery.is_due(conn) is False
    assert discovery.maybe_discover(conn) is None


def test_sources_page_shows_discovery(client):
    """صفحة المصادر تعرض قسم الاكتشاف وبياناته."""
    html = client.get("/sources").text
    assert "data-disc-grid" in html
    assert "data-discovery-run" in html
    assert "discovery.title" not in html
    assert "data-disc-count" in html


def test_discovery_api(client):
    r = client.get("/api/discovery")
    assert r.status_code == 200
    d = r.json()
    assert len(d["groups"]) == 15
    assert d["discovered_count"] > 0
    assert d["latest_report"] is not None
    assert d["kinds"] == discovery.SOURCE_KINDS


def test_discovery_run_api(client):
    r = client.post("/api/discovery/run")
    assert r.status_code == 200
    d = r.json()
    assert "added_count" in d and "duplicate_count" in d
    # الدورة الثانية عبر API لا تُكرّر.
    r2 = client.post("/api/discovery/run")
    assert r2.json()["added_count"] == 0
