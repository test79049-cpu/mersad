"""اختبارات أمنية: حجب الواجهات الإدارية وترويسات الأمان.

تتحقّق من:
- ترويسة Content-Security-Policy على استجابات HTML.
- ترويسة Strict-Transport-Security فقط عند HTTPS.
- حجب /api/admin/* و/api/monitoring واللوحات الإدارية عند ضبط MIRSAD_ADMIN_KEY،
  وعدم تأثّر النقاط العامة.
"""


def test_csp_header_present(client):
    r = client.get("/")
    csp = r.headers.get("content-security-policy", "")
    assert "default-src 'self'" in csp
    assert "object-src 'none'" in csp
    assert "frame-ancestors 'self'" in csp


def test_csp_on_api_json(client):
    r = client.get("/api/reports", params={"limit": 1})
    assert "content-security-policy" in {k.lower() for k in r.headers}


def test_hsts_only_over_https(client):
    plain = client.get("/")
    assert "strict-transport-security" not in {k.lower() for k in plain.headers}
    proxied = client.get("/", headers={"X-Forwarded-Proto": "https"})
    assert proxied.headers.get("strict-transport-security", "").startswith("max-age=")


def _enable_admin_key(monkeypatch):
    from app import main
    monkeypatch.setattr(main, "ADMIN_KEY", "secret-admin")


def test_admin_read_endpoints_blocked_without_key(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    for path in ("/api/admin/kpis", "/api/admin/analytics", "/api/admin/flags",
                 "/api/admin/audit", "/api/admin/status", "/api/monitoring",
                 "/api/monitoring/metrics", "/api/monitoring/changes"):
        r = client.get(path)
        assert r.status_code == 401, f"{path} => {r.status_code}"


def test_operator_pages_blocked_without_key(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    for path in ("/admin", "/monitor", "/audit"):
        r = client.get(path)
        assert r.status_code == 403, f"{path} => {r.status_code}"


def test_admin_allowed_with_key(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    headers = {"X-Admin-Key": "secret-admin"}
    assert client.get("/api/admin/kpis", headers=headers).status_code == 200
    assert client.get("/api/monitoring", headers=headers).status_code == 200
    assert client.get("/admin", headers=headers).status_code == 200


def test_ops_unlock_sets_cookie_and_grants_access(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    # مفتاح خاطئ: لا كوكي، ويبقى الحاجز قائمًا.
    bad = client.get("/ops/unlock", params={"key": "nope", "next": "/admin"},
                     follow_redirects=False)
    assert bad.status_code == 303
    assert client.get("/admin").status_code == 403
    # مفتاح صحيح: يُعيَّن الكوكي وتُفتح اللوحة.
    ok = client.get("/ops/unlock", params={"key": "secret-admin", "next": "/admin"},
                    follow_redirects=False)
    assert ok.status_code == 303
    assert ok.cookies.get("mirsad_admin") == "secret-admin"
    assert client.get("/admin").status_code == 200


def test_ops_unlock_rejects_external_next(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    r = client.get("/ops/unlock", params={"key": "secret-admin", "next": "//evil.com"},
                   follow_redirects=False)
    assert r.headers.get("location") == "/"


def test_public_endpoints_unaffected_by_admin_key(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    for path in ("/", "/reports", "/api/reports", "/api/status", "/healthz",
                 "/api/stats", "/sitemap.xml"):
        assert client.get(path).status_code == 200, path


def test_const_eq_handles_non_ascii():
    """المقارنة ثابتة الزمن يجب ألّا تنكسر مع محارف غير ASCII."""
    from app import auth
    assert auth.const_eq("é.é", "é.é") is True
    assert auth.const_eq("é.é", "e.e") is False
    assert auth.const_eq("س", "س") is True
    assert auth.const_eq("س", "ص") is False
    assert auth.const_eq(None, None) is True
    assert auth.const_eq(None, "x") is False
    assert auth.const_eq("abc", "abc") is True


def test_auth_callback_non_ascii_state_no_500(client):
    """حالة OAuth غير ASCII يجب ألّا تسبّب خطأ 500 (كانت TypeError في compare_digest)."""
    r = client.get("/auth/google/callback",
                   params={"state": "é.é", "code": "x"},
                   follow_redirects=False)
    assert r.status_code == 303, r.status_code
    assert r.headers.get("location", "").startswith("/auth/login")


def test_ops_unlock_non_ascii_key_no_500(client, monkeypatch):
    """مفتاح غير ASCII في /ops/unlock يجب أن يُرفض بلا خطأ 500."""
    _enable_admin_key(monkeypatch)
    r = client.get("/ops/unlock", params={"key": "é.é", "next": "/admin"},
                   follow_redirects=False)
    assert r.status_code == 303, r.status_code
    assert client.get("/admin").status_code == 403


def test_admin_header_non_ascii_key_no_500(client, monkeypatch):
    """ترويسة مفتاح إدارية غير ASCII يجب أن تُرفض بـ401 لا 500.

    تُرسَل البايتات الخام لأن ترويسات HTTP تُفكّ بـlatin-1 فتُنتج محارف غير ASCII.
    """
    _enable_admin_key(monkeypatch)
    r = client.get("/api/admin/kpis", headers={"X-Admin-Key": b"\xe9\xe9"})
    assert r.status_code == 401, r.status_code


def test_admin_cookie_non_ascii_key_no_500(client, monkeypatch):
    """كوكي إداري غير ASCII يجب أن يُرفض بـ401 لا 500."""
    _enable_admin_key(monkeypatch)
    r = client.get("/api/admin/kpis", headers={"Cookie": b"mirsad_admin=\xe9\xe9"})
    assert r.status_code == 401, r.status_code


# ---------------------------------------------------------------------------
# منع التوجيه المفتوح (Open Redirect / CWE-601)
# ---------------------------------------------------------------------------
# المتصفّحات تعامل الشرطة المائلة العكسية (`\`) والمحارف الضابطة (TAB/CR/LF)
# كـ`/` في عنوان Location، فـ`/\evil.com` و`/<TAB>/evil.com` تصيران `//evil.com`
# (توجيه خارجي). نتحقّق من تحييدها في كل نقاط إعادة التوجيه التي تقبل `next`.

_OPEN_REDIRECT_PAYLOADS = [
    "//evil.com",
    "/\\evil.com",
    "/\\/evil.com",
    "/\\/\\evil.com",
    "/\t/evil.com",
    "/\r/evil.com",
    "/\n/evil.com",
    "/\x0b/evil.com",
    "/\x0c/evil.com",
]


def _assert_internal(location: str):
    # القيمة النهائية يجب ألا تبدأ بـ`//` ولا تحوي `\` أو محارف ضابطة، وإلا
    # فسّرت المتصفّحات الوجهة كخارجية.
    assert location.startswith("/"), location
    assert not location.startswith("//"), location
    assert "\\" not in location, location
    assert not any(c in location for c in "\t\r\n\x0b\x0c"), repr(location)


def test_safe_next_rejects_backslash_and_control_bypass():
    """`_safe_next` نفسها تحيّد الشرطة العكسية والمحارف الضابطة."""
    from app.main import _safe_next
    for p in _OPEN_REDIRECT_PAYLOADS:
        _assert_internal(_safe_next(p))
    # المسارات الداخلية المشروعة تبقى كما هي.
    assert _safe_next("/reports?x=1") == "/reports?x=1"
    assert _safe_next("/admin") == "/admin"
    assert _safe_next(None) == "/"


def test_lang_switch_no_open_redirect(client):
    """/lang/{code}?next= لا يسمح بتوجيه خارجي عبر `\\` أو محارف ضابطة."""
    for p in _OPEN_REDIRECT_PAYLOADS:
        r = client.get("/lang/ar", params={"next": p}, follow_redirects=False)
        assert r.status_code == 303, (p, r.status_code)
        _assert_internal(r.headers.get("location"))
    ok = client.get("/lang/en", params={"next": "/reports?x=1"}, follow_redirects=False)
    assert ok.headers.get("location") == "/reports?x=1"


def test_auth_logout_no_open_redirect(client):
    for p in _OPEN_REDIRECT_PAYLOADS:
        r = client.get("/auth/logout", params={"next": p}, follow_redirects=False)
        assert r.status_code == 303, (p, r.status_code)
        _assert_internal(r.headers.get("location"))


def test_ops_unlock_no_open_redirect(client, monkeypatch):
    _enable_admin_key(monkeypatch)
    for p in _OPEN_REDIRECT_PAYLOADS:
        r = client.get("/ops/unlock", params={"key": "secret-admin", "next": p},
                       follow_redirects=False)
        assert r.status_code == 303, (p, r.status_code)
        _assert_internal(r.headers.get("location"))

