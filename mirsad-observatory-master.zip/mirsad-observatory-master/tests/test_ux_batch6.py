"""اختبارات تحسينات الواجهة — الدفعة السادسة (الأقسام 701–1000)."""


def test_error_pages_are_friendly(client):
    """صفحات الخطأ تحمل عنوانًا ودّيًّا وروابط مساعدة."""
    html = client.get("/no-such-page", headers={"accept": "text/html"}).text
    assert "error-state" in html
    assert "error-state__links" in html
    assert "error.not_found" not in html


def test_error_page_has_copy_link(client):
    """صفحة الخطأ تعرض زر نسخ الرابط الحالي."""
    html = client.get("/no-such-page", headers={"accept": "text/html"}).text
    assert "data-copy=" in html


def test_category_has_on_page_toc(client):
    """صفحة المجال: فهرس داخلي بأقسام قابلة للربط المباشر."""
    html = client.get("/category/human_rights").text
    assert 'class="toc"' in html
    assert 'id="cat-reports"' in html
    assert "scroll-margin-top" in html


def test_country_has_section_anchors(client):
    """صفحة الدولة: معرّفات أقسام للمراسي المباشرة."""
    html = client.get("/country/سوريا").text
    assert 'id="c-reports"' in html
    assert 'id="c-entities"' in html


def test_countries_and_entities_sync_url(client):
    """صفحتا الدول والكيانات تزامنان الحالة مع الرابط."""
    assert "syncUrl" in client.get("/countries").text
    assert "syncUrl" in client.get("/entities").text


def test_sources_reliability_filter(client):
    """صفحة المصادر: مرشّح الموثوقية مربوط بصفوف الجدول."""
    html = client.get("/sources").text
    assert "data-rel" in html


def test_base_has_og_image_and_twitter(client):
    """التخطيط الأساسي: صورة OG وبطاقة تويتر للأرشفة والمشاركة."""
    html = client.get("/").text
    assert 'property="og:image"' in html
    assert 'name="twitter:card"' in html
    assert "/static/img/og.png" in html


def test_og_image_is_served(client):
    """صورة OG متاحة كملف PNG."""
    r = client.get("/static/img/og.png")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("image/png")


def test_versioned_assets_are_immutable(client):
    """الأصول المثبّتة بإصدار تُخزَّن مؤقّتًا مدة طويلة."""
    r = client.get("/static/css/style.css?v=test")
    assert "immutable" in r.headers.get("cache-control", "")


def test_map_globe_is_lazy_loaded(client):
    """الخريطة: مكتبة الكرة الأرضية تُحمَّل عند الطلب لا مسبقًا."""
    html = client.get("/map").text
    assert "function ensureGlobe" in html
    assert '<script src="/static/vendor/globe.gl/globe.gl.min.js"></script>' not in html


def test_map_preconnects_tile_server(client):
    """الخريطة: تسريع الاتصال بخادم البلاطات."""
    html = client.get("/map").text
    assert 'rel="preconnect" href="https://server.arcgisonline.com"' in html


def test_table_sort_is_keyboard_accessible(client):
    """فرز الجداول متاح بلوحة المفاتيح (tabindex و Enter/المسافة)."""
    html = client.get("/sources").text
    assert 'aria-sort' in html or "sortable" in html


def test_shortcuts_include_scroll_and_filters(client):
    """قائمة الاختصارات تعرض اختصارات التمرير والمرشّحات الجديدة."""
    html = client.get("/").text
    assert "ui.shortcut_scroll" not in html
    assert "shortcut_filters" not in html
    assert "<kbd>j</kbd>" in html


def test_submit_review_has_edit_links(client):
    """نموذج الإرسال: خطوة المراجعة تعرض أزرار تعديل للحقول."""
    html = client.get("/submit").text
    assert "FIELD_STEP" in html
    assert "submit.edit" not in html


def test_submit_validation_marks_aria_invalid(client):
    """تحقّق النموذج يضبط aria-invalid وينقل التركيز لأول حقل ناقص."""
    html = client.get("/submit").text
    assert "aria-invalid" in html
    assert "submit.fix_fields" not in html


def test_error_page_500_has_retry(client):
    """صفحة الخطأ 500 تعرض زر إعادة المحاولة (عبر قالب الخطأ)."""
    html = client.get("/no-such-page", headers={"accept": "text/html"}).text
    assert "error.back_home" not in html


def _css():
    from pathlib import Path
    return Path(__file__).resolve().parent.parent.joinpath(
        "app", "static", "css", "style.css").read_text(encoding="utf-8")


def test_global_svg_sizing_rule_exists():
    """قاعدة عامة تُحجّم كل svg افتراضيًّا، وإلا انفجرت أيقونة بلا قاعدة بالحجم الافتراضي."""
    css = _css()
    assert "svg { width: var(--icon-md); height: var(--icon-md)" in css


def test_icon_scale_tokens_defined():
    """سلّم أحجام الأيقونات معرّف في :root."""
    css = _css()
    for tok in ("--icon-xs:", "--icon-sm:", "--icon-md:", "--icon-lg:",
                "--icon-xl:", "--icon-2xl:", "--icon-3xl:"):
        assert tok in css


def test_icon_sizes_use_tokens_not_hardcoded_px():
    """لا حجم svg ثابت بالبكسل خارج القاعدة العامة (ما عدا 100% للحاويات)."""
    import re
    css = _css()
    offenders = []
    for sel, body in re.findall(r"([^{}]+)\{([^}]*)\}", css):
        if "svg" not in sel or "#map" in sel or "#globe" in sel:
            continue
        m = re.search(r"width:\s*([\d.]+)px", body)
        if m and "var(--icon" not in body:
            offenders.append(sel.strip())
    assert offenders == [], offenders


def test_icon_stroke_width_is_uniform():
    """كل أيقونات الماكرو بسماكة خطّ موحّدة."""
    import re
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    widths = set()
    for name in ("app/templates/_icons.html", "app/templates/base.html"):
        text = root.joinpath(name).read_text(encoding="utf-8")
        widths.update(re.findall(r'stroke-width="([\d.]+)"', text))
    assert widths == {"1.6"}, widths


def test_icon_macros_have_no_hardcoded_dimensions():
    """أيقونات الماكرو لا تحمل width/height ثابتة (يتولّاها CSS)."""
    import re
    from pathlib import Path
    text = Path(__file__).resolve().parent.parent.joinpath(
        "app", "templates", "_icons.html").read_text(encoding="utf-8")
    for tag in re.findall(r"<svg[^>]*>", text):
        assert not re.search(r'(?<!stroke-)\bwidth\s*=', tag), tag
        assert not re.search(r'(?<!stroke-)\bheight\s*=', tag), tag


def test_timeline_date_avoids_mono_font(client):
    """تاريخ الخط الزمني بخطّ النصّ لا الأحادي (الأحادي بلا محارف عربية)."""
    css = _css()
    import re
    rule = re.search(r"\.timeline__date\s*\{([^}]*)\}", css).group(1)
    assert "font-mono" not in rule
    assert "font-body" in rule


# ---------------------------------------------------------------------------
# خرائط Leaflet: قاعدة تحجيم الأيقونات العامة يجب ألا تمسّ أي حاوية خريطة.
# ---------------------------------------------------------------------------

def test_leaflet_svg_excluded_from_global_icon_sizing():
    """لا تُطبَّق قاعدة الأيقونة العامة على svg داخل أي حاوية Leaflet.

    القاعدة العامة تُحجّم كل svg إلى --icon-md (16px)، فتتجاوز حجم svg طبقة
    الرسم الذي يضبطه Leaflet بنفسه، فتنكمش الطبقة إلى 16×16 وتختفي العلامات.
    كان الاستثناء مقتصرًا على #map و#globe فتعطّلت خريطة الرئيسية (#home-map)
    والخريطة المصغّرة في صفحة البلاغ (#report-map).
    """
    css = _css()
    assert ".leaflet-container svg" in css
    # القاعدة العامة تبقى (تُحجّم أيقونات الموقع).
    assert "svg { width: var(--icon-md); height: var(--icon-md)" in css
    # ولا يوجد استثناء قاصر على معرّف واحد بعد الآن.
    assert "#map svg, #globe svg" not in css
    # كل قالب يستدعي L.map يجب أن يحمّل Leaflet أيضًا.
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    for name in ("index.html", "map.html", "report_detail.html"):
        text = root.joinpath("app", "templates", name).read_text(encoding="utf-8")
        if "L.map(" in text:
            assert "leaflet.js" in text, f"{name}: خريطة بلا تحميل Leaflet"


def test_report_detail_loads_leaflet_only_when_map_present(client):
    """صفحة البلاغ تحمّل Leaflet عند وجود إحداثيات فقط (لا طلبات زائدة)."""
    from app import db
    conn = db.connect()
    try:
        with_coords = conn.execute(
            "SELECT id FROM reports WHERE lat IS NOT NULL AND lng IS NOT NULL LIMIT 1"
        ).fetchone()
        without = conn.execute(
            "SELECT id FROM reports WHERE lat IS NULL OR lng IS NULL LIMIT 1"
        ).fetchone()
    finally:
        conn.close()
    if with_coords:
        html = client.get(f"/reports/{with_coords['id']}").text
        assert "/static/vendor/leaflet/leaflet.js" in html
        assert "/static/vendor/leaflet/leaflet.css" in html
        assert 'id="report-map"' in html
    if without:
        html = client.get(f"/reports/{without['id']}").text
        assert "/static/vendor/leaflet/leaflet.js" not in html

