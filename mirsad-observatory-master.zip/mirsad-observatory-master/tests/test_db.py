"""اختبارات طبقة قاعدة البيانات: المخطّط، البحث، الإحصاءات، والإدراج."""

from app.taxonomy import CATEGORIES


def test_seed_populates(conn):
    assert conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()["n"] > 20
    assert conn.execute("SELECT COUNT(*) AS n FROM sources").fetchone()["n"] >= 8


def test_fts_arabic_normalization(conn, temp_db):
    # البحث بلا همزة يجد الكلمة بالهمزة
    hits = temp_db.query_reports(conn, search="اطفال")
    titles = " ".join(h["title"] for h in hits)
    assert "أطفال" in titles


def test_fts_prefix_match(conn, temp_db):
    hits = temp_db.query_reports(conn, search="خوارزم")
    assert any("خوارزم" in h["title"] for h in hits)


def test_fts_combined_with_category(conn, temp_db):
    hits = temp_db.query_reports(conn, search="مياه", category="environment")
    assert hits and all(h["category"] == "environment" for h in hits)


def test_filter_by_severity_and_status(conn, temp_db):
    crit = temp_db.query_reports(conn, severity="critical")
    assert crit and all(h["severity"] == "critical" for h in crit)
    new = temp_db.query_reports(conn, status="new")
    assert all(h["status"] == "new" for h in new)


def test_date_range_filter(conn, temp_db):
    rows = temp_db.query_reports(conn, sort="recent")
    latest = rows[0]["reported_on"]
    hits = temp_db.query_reports(conn, date_from=latest)
    assert hits and all(h["reported_on"] >= latest for h in hits)


def test_sort_severity_orders_critical_first(conn, temp_db):
    rows = temp_db.query_reports(conn, sort="severity", limit=5)
    assert rows[0]["severity"] == "critical"


def test_insert_report_computes_geo_and_blob(conn, temp_db):
    rid = temp_db.insert_report(conn, {
        "title": "واقعة اختبار للتلوث الصناعي",
        "category": "environment", "severity": "high", "status": "new",
        "country": "الأردن", "region": "الزرقاء",
        "occurred_on": None, "reported_on": "2026-01-01",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب هنا.",
        "details": "", "source_name": "", "source_url": "", "verified": 0,
    })
    row = temp_db.get_report(conn, rid)
    assert row["country_code"] == "JOR"
    assert row["country"] == "الأردن"
    assert row["region"] == "الزرقاء"
    assert row["lat"] is not None and row["lng"] is not None
    assert row["search_blob"]
    # البحث الفوري يجد السجل الجديد
    assert any(h["id"] == rid for h in temp_db.query_reports(conn, search="اختبار"))


def test_insert_normalizes_country_and_region(conn, temp_db):
    rid = temp_db.insert_report(conn, {
        "title": "واقعة باسم دولة بصيغة إنجليزية",
        "category": "environment", "severity": "low", "status": "new",
        "country": "Jordan", "region": "",
        "occurred_on": None, "reported_on": "2026-01-01",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب هنا.",
        "details": "", "source_name": "", "source_url": "", "verified": 0,
    })
    row = temp_db.get_report(conn, rid)
    assert row["country"] == "الأردن"
    assert row["country_code"] == "JOR"
    assert row["region"]  # امتلأت تلقائياً
    assert row["lat"] is not None and row["lng"] is not None


def test_stats_shape(conn, temp_db):
    st = temp_db.stats(conn)
    for key in ("total", "verified", "by_category", "by_severity", "by_status",
                "by_country", "by_month", "country_count"):
        assert key in st
    assert st["total"] == sum(st["by_category"].values())


def test_geo_points_have_coords(conn, temp_db):
    pts = temp_db.geo_points(conn)
    assert pts and all(p["lat"] is not None and p["lng"] is not None for p in pts)


def test_external_id_dedup(conn, temp_db):
    assert not temp_db.report_exists(conn, "gdelt:test")
    temp_db.insert_report(conn, {
        "title": "خبر مستورد للتكرار", "category": "environment",
        "severity": "medium", "status": "new", "country": "الأردن",
        "region": None, "occurred_on": None, "reported_on": "2026-01-01",
        "summary": "ملخّص اختباري كافٍ للطول المطلوب هنا.",
        "details": "", "source_name": "", "source_url": "",
        "external_id": "gdelt:test", "verified": 0,
    })
    assert temp_db.report_exists(conn, "gdelt:test")


def test_all_categories_have_seed_data(conn, temp_db):
    st = temp_db.stats(conn)
    for cat in CATEGORIES:
        assert st["by_category"].get(cat["key"], 0) > 0


def test_entities_summary_unknown_kind_returns_empty(conn, temp_db):
    """نوع غير معروف يعيد قائمة فارغة بدل رفع استثناء."""
    assert temp_db.entities_summary(conn, kind="bogus") == []
    # الأنواع المعروفة ما زالت تعمل
    assert temp_db.entities_summary(conn, kind="company")
