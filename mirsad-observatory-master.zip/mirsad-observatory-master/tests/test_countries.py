"""اختبارات مجموعة الدول: المطابقة بالعربية والإنجليزية ورموز ISO والمرادفات."""

from app import countries as cd


def test_find_by_english_and_iso():
    assert cd.find("Mexico")["iso3"] == "MEX"
    assert cd.find("MEX")["en"] == "Mexico"


def test_find_common_arabic_names():
    # أسماء عربية شائعة تختلف عن تسمية المجموعة الأصلية
    assert cd.find("المكسيك")["iso3"] == "MEX"
    assert cd.find("تايلاند")["iso3"] == "THA"
    assert cd.find("هنغاريا")["iso3"] == "HUN"
    assert cd.find("ساحل العاج")["iso3"] == "CIV"
    assert cd.find("الكونغو")["iso3"] == "COD"


def test_find_without_hamza_normalization():
    # «اوكرانيا» بلا همزة يجب أن تطابق «أوكرانيا»
    assert cd.find("اوكرانيا") is not None


def test_coords_and_region():
    assert cd.coords("France")
    assert cd.region_of("Japan") == "Asia"
