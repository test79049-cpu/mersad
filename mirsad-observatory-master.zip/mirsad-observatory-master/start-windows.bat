@echo off
REM ============================================================
REM   تشغيل مِرصد على جهازك (Windows) — انقر هذا الملف مرّتين فقط
REM   كل الخطوات تُسجَّل في mirsad-start.log
REM ============================================================
chcp 65001 >nul
cd /d "%~dp0"
set "LOG=mirsad-start.log"
echo ===== مِرصد بدء التشغيل %DATE% %TIME% ===== > "%LOG%"

echo.
echo ============================================
echo    مِرصد — تشغيل محلي
echo ============================================
echo.

REM --- 1) إيجاد Python: نجرّب py ثم python ثم python3 ---
set "PY="
py -3 --version >nul 2>>"%LOG%" && set "PY=py -3"
if not defined PY ( python --version >nul 2>>"%LOG%" && set "PY=python" )
if not defined PY ( python3 --version >nul 2>>"%LOG%" && set "PY=python3" )

if not defined PY (
  echo.
  echo ############################################################
  echo #  خطأ: لم أجد Python على جهازك.
  echo #
  echo #  الحل:
  echo #   1. افتح:  https://www.python.org/downloads/
  echo #   2. نزّل Python 3.10 أو أحدث وثبّته.
  echo #   3. ^(مهم جدًّا^) أثناء التثبيت فعّل خيار:
  echo #        [v] Add python.exe to PATH
  echo #   4. أغلق هذه النافذة وأعد النقر على start-windows.bat
  echo #
  echo #  إن كان Python مثبّتًا بالفعل، فقد لا يكون على PATH:
  echo #  أعد تثبيته واختر "Add to PATH".
  echo ############################################################
  echo.
  pause
  exit /b 1
)

echo [1/4] Python موجود: %PY%
%PY% --version

REM --- 2) تجهيز البيئة لأول مرّة فقط ---
if not exist ".venv\Scripts\python.exe" (
  echo [2/4] تجهيز البيئة لأول مرّة... ^(قد يأخذ دقيقتين، انتظر^)
  %PY% -m venv .venv >>"%LOG%" 2>&1
  if errorlevel 1 (
    echo ############################################################
    echo #  خطأ: فشل إنشاء البيئة ^(.venv^).
    echo #  تفاصيل الخطأ في الملف: %LOG%
    echo ############################################################
    pause & exit /b 1
  )
  ".venv\Scripts\python" -m pip install --upgrade pip -q >>"%LOG%" 2>&1
  echo [3/4] تثبيت المتطلّبات... ^(انتظر^)
  ".venv\Scripts\python" -m pip install -r requirements.txt -q >>"%LOG%" 2>&1
  if errorlevel 1 (
    echo ############################################################
    echo #  خطأ: فشل تثبيت المتطلّبات. تأكّد من اتّصال الإنترنت.
    echo #  تفاصيل الخطأ في الملف: %LOG%
    echo ############################################################
    pause & exit /b 1
  )
  echo       تمّ التجهيز.
) else (
  echo [2/4] البيئة جاهزة مسبقًا.
)

REM --- 3) أسرار محلية إن لم توجد ---
if not exist ".env.local" (
  ".venv\Scripts\python" -c "import secrets;open('.env.local','w').write('MIRSAD_INGEST_KEY=%s\nMIRSAD_ADMIN_KEY=%s\nMIRSAD_SECRET_KEY=%s\n'%(secrets.token_urlsafe(32),secrets.token_urlsafe(32),secrets.token_urlsafe(48)))" >>"%LOG%" 2>&1
  echo [4/4] وُلِّدت مفاتيح محلية.
) else (
  echo [4/4] المفاتيح موجودة مسبقًا.
)

REM --- 4) التشغيل ---
set MIRSAD_PUBLIC_URL=http://localhost:8000
echo.
echo ============================================
echo    مِرصد يعمل الآن على:  http://localhost:8000
echo.
echo    افتح المتصفّح على هذا العنوان.
echo    لإيقاف الموقع: أغلق هذه النافذة ^(أو Ctrl+C^).
echo ============================================
echo.
start "" http://localhost:8000
".venv\Scripts\python" -m uvicorn app.main:app --host 0.0.0.0 --port 8000

echo.
echo توقّف الموقع.
pause
