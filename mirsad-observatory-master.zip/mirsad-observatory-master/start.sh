#!/usr/bin/env bash
# ============================================================
#   تشغيل مِرصد على جهازك (macOS / Linux) — أمر واحد
#   الاستخدام:  ./start.sh
# ============================================================
set -e
cd "$(dirname "$0")"

echo
echo "============================================"
echo "   مِرصد — تشغيل محلي"
echo "============================================"
echo

# --- 1) التحقّق من Python ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "[خطأ] Python غير مثبّت."
  echo "  macOS:  brew install python3"
  echo "  Linux:  sudo apt install python3 python3-venv"
  exit 1
fi

# --- 2) تجهيز البيئة لأول مرّة فقط ---
if [ ! -d ".venv" ]; then
  echo "تجهيز البيئة لأول مرّة... (قد يأخذ دقيقتين)"
  python3 -m venv .venv
  ./.venv/bin/python -m pip install --upgrade pip -q
  ./.venv/bin/python -m pip install -r requirements.txt -q
  echo "تمّ التجهيز."
fi

# --- 3) أسرار محلية إن لم توجد ---
if [ ! -f ".env.local" ]; then
  ./.venv/bin/python -c "import secrets;open('.env.local','w').write('MIRSAD_INGEST_KEY=%s\nMIRSAD_ADMIN_KEY=%s\nMIRSAD_SECRET_KEY=%s\n'%(secrets.token_urlsafe(32),secrets.token_urlsafe(32),secrets.token_urlsafe(48)))"
  chmod 600 .env.local
  echo "وُلِّدت مفاتيح محلية في .env.local"
fi

# --- 4) التشغيل ---
export MIRSAD_PUBLIC_URL="${MIRSAD_PUBLIC_URL:-http://localhost:8000}"
echo
echo "============================================"
echo "   مِرصد يعمل الآن على:  http://localhost:8000"
echo "   لإيقافه: اضغط Ctrl + C"
echo "============================================"
echo
( sleep 3; (command -v open >/dev/null && open http://localhost:8000) || (command -v xdg-open >/dev/null && xdg-open http://localhost:8000) || true ) >/dev/null 2>&1 &
exec ./.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
