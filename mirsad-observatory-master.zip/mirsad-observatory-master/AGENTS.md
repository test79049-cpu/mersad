# AGENTS.md — دليل العمل على مشروع «مِرصد»

## نظرة عامة
منصة ويب عربية (RTL) لتوثيق الانتهاكات في 21 مجالًا، مع واجهة إنجليزية (LTR) اختيارية.
مبنية بـ **FastAPI + Jinja2 + SQLite (FTS5)**، دون أي مكتبات JavaScript أو CSS من CDN خارجي؛
كل المكتبات (Leaflet، Leaflet.markercluster، Leaflet.heat، Chart.js، globe.gl) والخطوط **مُضمّنة محليًّا**
في `app/static/vendor/` و`app/static/fonts/`، مع حدود الدول والمحافظات (Natural Earth GeoJSON) مخزَّنة محليًّا أيضًا.
(الاستثناء الوحيد لطلبات خارجية: بلاطات خريطة Esri المجانية بدون مفتاح على الخريطة المسطّحة.)

## الأوامر الأساسية
```bash
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --port 8000
python -m app.cli init --force          # إعادة تهيئة القاعدة
python -m app.cli stats                 # الإحصاءات
python -m app.cli catalog               # معاينة فهرس المصادر الواسع (1000+ مصدر)
python -m app.cli catalog --write       # كتابة الفهرس إلى app/data/source_catalog.json
python -m app.cli harvest --sources 120 --max 8   # دفعة جمع من المصادر المستحقّة
python -m app.cli harvest --dry-run     # معاينة بلا كتابة
python -m app.cli dedup                 # إصلاح التواريخ المشوّهة + منع التكرار
python -m pytest tests/ -q              # الاختبارات (يلزم requirements-dev.txt)
```
- `uvicorn` قد لا يكون على PATH؛ استخدم `python -m uvicorn`.
- الخادم يعمل على المنفذ 12000 في بيئة العرض عبر `https://work-1-<id>.prod-runtime.all-hands.dev/`.
- **تشغيل بيئة العرض (مهم):** استخدم `./run.sh` — يضبط تهيئة الأتمتة المتوازنة ثم يشغّل الخادم
  على المنفذ 12000. لا يبقى الخادم حيًّا بين الجلسات، فالرابط الحيّ يعطي «لا يعمل» حتى يُعاد التشغيل:
  ```bash
  nohup ./run.sh > /tmp/mirsad-12000.log 2>&1 &
  curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:12000/healthz   # يجب أن يعطي 200
  ```
  وللتأكّد من الوصول العام: `curl -s -o /dev/null -w "%{http_code}\n" https://work-1-<id>.prod-runtime.all-hands.dev/`.

## موازنة أتمتة التحديث (مهم)
- **القاعدة:** معدّل الاستيراد يجب ألا يتجاوز معدّل المعالجة، وإلا تراكم `documents.pending` بلا حدّ.
- الافتراضيات في الكود (`MIRSAD_COLLECT_SOURCES=8`, `MIRSAD_PROCESS_BATCH=25`) تُدخل ~50–95 مستندًا/دقيقة
  وتُفرّغ 25/دقيقة فقط → المخزون ينمو ~25–35/دقيقة. فهرس المصادر (2300+) يُستنزف 8/دقيقة فقط
  (~4.3 ساعة للدورة) فلا يلحق أبدًا.
- `run.sh` يعكس المعادلة: `COLLECT_SOURCES=4` + `PROCESS_BATCH=100` + `VERIFY_BATCH=60` +
  `BACKLOG_THRESHOLD=2000` → ينكمش المخزون (~50/دقيقة) ويلحق بالمصادر.
- المقاييس الحيّة: `/api/status` (المجدول) و`/api/monitoring` (المستندات/المصادر/المهام).
  مؤشّر الصحّة: `documents.pending` يجب أن ينخفض لا أن يرتفع.

## النشر العام والأسرار
- **`run.sh` يحمّل `.env.local`** (مُستبعَد من git) إن وُجد، ويضبط تهيئة الأتمتة المتوازنة،
  ثم يشغّل الخادم. انسخ `.env.local.example` واملأ المفاتيح.
- **⚠️ تحذير صريح — قبل النشر العام أو تشغيل الأتمتة على بيانات إنتاج حقيقية:**
  بدون ضبط `MIRSAD_INGEST_KEY` و`MIRSAD_ADMIN_KEY` تبقى نقاط الكتابة `/api/ingest/*` و`/api/admin/*`
  **مفتوحة للعالم بلا أي مصادقة** (الافتراضي للتطوير) — أي طلب مجهول يستطيع الكتابة/التعديل/الحذف.
  **يجب ضبط هذين المفتاحين أولًا** قبل أي نشر عام أو أي أتمتة (مجدول/جمع/مهام) تتعامل مع بيانات
  إنتاج حقيقية؛ لا تبدأ الأتمتة قبل التحقّق من ضبطهما.
  - ولّد المفاتيح بـ `python3 -c "import secrets;print(secrets.token_urlsafe(32))"`.
  - اضبط أيضًا `MIRSAD_SECRET_KEY` (توقيع الجلسة) و`MIRSAD_PUBLIC_URL` (canonical/sitemap/الاستشهاد).
  - **التحقّق قبل التشغيل:** تأكّد أن `/api/admin/status` تُرجع `401 admin_key_required` بلا ترويسة
    `X-Admin-Key`؛ إن أعادت `200` فالمفتاح غير مضبوط وتلك النقاط مكشوفة.
- **بوّابة إقلاع في `run.sh` (تنفيذ لا توثيق):** عند `MIRSAD_ENV=production` **يرفض `run.sh` الإقلاع
  (`exit 1`)** إن غاب `MIRSAD_INGEST_KEY`/`MIRSAD_ADMIN_KEY` أو كان `MIRSAD_SECRET_KEY` افتراضيًّا/
  فارغًا؛ وفي التطوير يطبع تحذيرًا فقط ثم يُقلع. لا تُطبع قيم المفاتيح أبدًا. منصّات النشر تضبط
  `MIRSAD_ENV=production` (`docker-compose.yml`، `render.yaml`، `deploy/mirsad.service`،
  `deploy/install.sh` — الأخير صار يُشغّل عبر `run.sh` لا `uvicorn` مباشرة). أي أتمتة تنطلق من
  `run.sh` ترث البوّابة تلقائيًّا.
- **Dockerfile** للنشر على أي منصّة تدعم Docker؛ القاعدة في `/app/data` (اربط وحدة تخزين
  دائمة، وإلا فُقدت البيانات مع الحاوية). **`render.yaml`** Blueprint مجاني لـRender
  (الطبقة المجانية تُنيم الخدمة بعد خمول ~15 دقيقة).
- **رابط عام فوري للتجربة:** نفق Cloudflare مجاني بلا حساب
  (`cloudflared tunnel --url http://127.0.0.1:12000`) — مؤقّت، يزول بزوال العملية.
- استضافة بيئة العرض (`work-1-*.prod-runtime.all-hands.dev`) مؤقّتة وتُفقد الحِزم مع الجلسة؛
  أعد `pip install -r requirements.txt` عند الحاجة.

### التشغيل الدائم (24/7)
> روابط بيئة العرض و`trycloudflare` **مؤقّتة** وتزول بانتهاء الجلسة. الدوام يحتاج خادمًا مملوكًا.
- `docker-compose.yml` — `restart: unless-stopped` + وحدة تخزين دائمة → تشغيل دائم بأمر واحد.
- `deploy/install.sh` — تثبيت بنقرة على VPS (Oracle Cloud Always Free / GCP e2-micro): venv +
  خدمة systemd `Restart=always` + توليد المفاتيح تلقائيًّا.
- `deploy/mirsad.service` — وحدة systemd مرجعية (بلا Docker).
- `deploy/tunnel.sh` — نفق Cloudflare **مُسمّى** يثبّت hostname دائمًا بنطاق تملكه
  (بعكس النفق السريع العشوائي).
- `render.yaml` — بديل: Render مجاني (يُنيم الخدمة عند الخمول، فليس دوامًا حقيقيًّا).

## البنية
- `app/taxonomy.py` — **المصدر الوحيد للحقيقة** للمجالات ومستويات الخطورة والحالات.
  أي إضافة لمجال جديد تبدأ من هنا.
- `app/db.py` — المخطّط + FTS5، البيانات الأولية (`seed_data.SEED_ROWS`)، ودوال الاستعلام.
  `SCHEMA_VERSION` يُستخدم لإعادة البناء التلقائي عند تغيّر المخطّط.
- `app/seed_data.py` — صفوف البيانات الأولية (150+ بلاغًا عبر كل مجالات التصنيف). أضف الصفوف هنا.
- `app/actors.py` — سجل الجهات الفاعلة (شركات/أفراد/منظّمات/حكومات) مع المرادفات،
  و`match_actors()` للمطابقة النصّية. تُستخدم في `_seed_entities()` و`refresh.relink_entities()`.
- `app/refresh.py` — دورة تحديث واحدة (`refresh()`): ربط الجهات، إثراء ويكيداتا، سحب GDELT،
  سحب دفعة من فهرس المصادر الواسع (`harvest`)، وإعادة فهرسة. `recompute_aggregates(limit=400)`
  محدود للحفاظ على الأداء مع عشرات آلاف الصفوف.
- `app/catalog.py` — مولّد **فهرس المصادر الواسع** (2000+ مصدر عبر كل المجالات):
  `build_catalog()` يُنتج صفوفًا (key/name/domain/severity/kind/url/feed_url/region)؛
  تُبنى من `EN_EDITIONS` (طبعات إقليمية لمحرّكات بحث الأخبار) + قوالب استعلام لكل مجال +
  تغذيات/datasets معروفة. المفتاح فريد لكل مصدر.
- `app/harvest.py` — محرّك الجمع الآلي: `harvest_batch(conn, ...)` يسحب دفعة محدودة من
  المصادر المستحقّة (`db.catalog_due`) بتدوير (rotation) وتراجع أسّي عند الفشل، يُصنّف
  ويُدرج بمنع تكرار (`dedup_key`/`external_id`)، ويسجّل صحة كل مصدر (`db.mark_catalog_run`).
  الوضع الجاف عبر `dry_run=True`.
- `app/scheduler.py` — المجدول الداخلي (`Scheduler`) الذي يستدعي `refresh()` كل 60 ثانية.
  يُشغَّل في `lifespan` عبر `scheduler.start()` ويُوقف في `finally`.
- `app/main.py` — مسارات الصفحات وواجهة REST. الدالة `_enrich()` تضيف حقول العرض المشتقّة.
  دورة الحياة عبر `lifespan` (لا `@app.on_event` المهجورة).
- `app/templates/` — قوالب Jinja2. الأيقونات في `_icons.html` كـ macro باسم `icon(name)`.
- `app/static/css/style.css` — نظام التصميم بالكامل (متغيّرات CSS في `:root`).
- `app/textutils.py` — تطبيع النص العربي؛ أساس البحث النصّي.
- `app/countries.py` — مجموعة الدول (تُحمَّل من `app/data/countries.json`).
- `app/clients.py` — عميل HTTP مع تخزين مؤقّت وتقييد معدّل ومُدقّق استجابة اختياري.
- `app/importers.py` — مستوردات المصادر المفتوحة والتصنيف الآلي.
- `app/exports.py` — تصدير CSV/JSON/JSON Feed/RSS والاستشهاد، وتصدير فهرس الكيانات.
- `app/i18n.py` — **مصدر الترجمة الوحيد**: قاموس `STRINGS` (مفاتيح → {ar, en})،
  `LANG_META` (الاتجاه واللغة)، ودالة `t(key, lang, **kw)` ودالة القوالب `translator(lang)`.
- `app/sources_registry.py` — سجل المصادر المفتوحة ورخصها.
- `app/static/vendor/` — مكتبات JS/CSS مضمّنة محليًّا (Leaflet، markercluster، leaflet-heat، Chart.js، globe.gl مع قوام الأرض داكن/قمر صناعي)،
  وحدود الدول `natural-earth/countries-110m.geojson` (Natural Earth، ملكية عامة) لطبقة حدود الكرة الأرضية،
  ومحافظات مقسّمة لكل بلد `natural-earth/provinces/<ISO2>.geojson` (Natural Earth admin-1، ملكية عامة، مبسَّطة).
- `app/static/fonts/` — الخطوط العربية (Reem Kufi، IBM Plex Sans/Mono Arabic، Aref Ruqaa)
  مستضافة **محليًّا** كـ woff2 مع `fonts.css`؛ لا طلبات لخطوط خارجية (خصوصية + عمل دون اتصال).

## تعدد اللغات (i18n)
- اللغة الافتراضية `ar` (RTL). الإنجليزية `en` (LTR) اختيارية.
- الكشف: وسيط `security_headers` يضبط `request.state.lang` من `?lang=` أو الكوكي `mirsad_lang`.
  المسار `/lang/{code}?next=/path` يثبّت الكوكي ويعيد التوجيه. `_lang(request)` يقرأ اللغة الحالية.
- في القوالب: `t('key')` للنصوص، و`lang_dir`/`html_lang`/`og_locale`/`lang_switch_url`/`alt_urls`
  (روابط hreflang) متاحة من `_base_context`.
- تسميات التصنيف (المجالات/الخطورة/الحالة/أنواع الكيانات) مترجمة عبر `_localized_taxonomy(lang)`
  التي تنتج نسخًا عربية أو إنجليزية من `taxonomy`، وتُمرَّر للقوالب كـ `categories/severities/statuses/entity_kinds`.
- `taxonomy` يحمل حقول `*_en` ودوال `category_name/severity_label/status_label/entity_kind_label(key, lang)`
  للاستخدام في `_enrich()` والـ API.

## اصطلاحات مهمة
- **قالب Starlette الحديث**: استدعِ `templates.TemplateResponse(request, "x.html", ctx)`
  وليس `TemplateResponse("x.html", ctx)` — الصيغة القديمة تفشل بـ `unhashable type: 'dict'`.
- كل نصوص الواجهة تُكتب في القوالب عبر `t('key')` وتُرجم إلى العربية والإنجليزية عبر `app/i18n.py`
  (لا نصوص عربية/إنجليزية مكتوبة مباشرة في القوالب إلا للبيانات نفسها).
- أسماء الحقول في قاعدة البيانات بالإنجليزية، والتسميات العربية تُشتقّ عبر دوال `taxonomy`.
- تصميم RTL: استخدم الخصائص المنطقية (`margin-inline-start`, `inset-inline`) لا `left/right`.

## السمة (الوضع الليلي/النهاري)
- المفتاح في `localStorage` اسمه `mirsad.theme` بقيمتَي `light`/`dark`؛ الافتراضي `dark`
  مع متابعة `prefers-color-scheme` عند غياب اختيار صريح.
- سكربت مبكّر في `<head>` داخل `base.html` يطبّق السمة قبل الرسم لمنع وميض السمة الخاطئة (FOUC).
- منطق التبديل في `app.js`: `applyTheme(t, persist)` + `currentTheme()` + زر `[data-theme-toggle]`،
  ويُطلق حدث `mirsad:theme` على `document` عند التبديل.
- ألوان الوضعين كمتغيّرات CSS: `:root` (ليلي) و`:root[data-theme="light"]` (نهاري) في `style.css`.
  **لا تُكتب ألوان ثابتة** في CSS أو القوالب؛ استخدم المتغيّرات.
- الخريطة/الكرة الأرضية (`map.html`) ورسوم Chart.js (`stats.html`) تستمع لحدث `mirsad:theme`
  وتعيد تطبيق الطبقة/القوام/ألوان الرسوم. رسوم Chart.js تقرأ الألوان عبر `themeColors()`
  من متغيّرات CSS وقت التشغيل.
- عند تغيير أي أصل ثابت (CSS/JS) ارفع `ASSET_VER` في `main.py` لطرد كاش المتصفّح؛
  كل روابط الأصول تحمل `?v={{ asset_ver }}` (بما فيها `app.js`).
- معيار كتابة العربية: استخدم التنوين الحديث على الألف (`تمامًا`) لا الصيغة القديمة
  (تنوين فوق الألف مباشرة)، ووحّد أفعال الإرشاد على «اضغط» بدل «انقر».
  تحرسها اختبارات في `tests/test_api.py`.

## التصنيف (المجالات) — 21 مجالًا
- `app/taxonomy.py:CATEGORIES` هو المصدر الوحيد للحقيقة. كل مجال يحمل: `key`، `name`/`name_en`،
  `short`/`short_en`، `icon`، `color`، `accent`، `description`/`description_en`، و`parent`.
- **تسلسل هرمي خفيف:** `parent=None` لمجال حاوٍ، أو مفتاح مجال أعلى. حاليًّا:
  `prisoners_rights → criminal_justice` و`elderly_rights → inclusivity`. مشتقّات جاهزة:
  `PARENT_CATEGORIES`، `CHILD_CATEGORIES`، `CATEGORY_KEYS`. يُمرَّر `cat_groups` (كل حاوٍ مع `children`)
  للقوالب عبر `_localized_taxonomy()`، ويُعرض في بطاقات الرئيسية/«حول» (`.cat-card__subs`) والتذييل
  (`.footer__subs`).
- **إضافة مجال جديد تتطلّب:** (1) مدخلًا في `CATEGORIES`، (2) أيقونة في `_icons.html` (أو يعود لـ dot)،
  (3) صفوفًا في `seed_data.py` + ترجماتها في `seed_en.py` (اختبار `test_taxonomy_domains` يفرض ذلك)،
  (4) مفاتيح في `importers.CATEGORY_KEYWORDS` و`GDELT_QUERIES`، (5) استعلامات في `catalog.DOMAIN_QUERIES`،
  (6) ربطًا في `sources_registry.DOC_RESOURCE_CATEGORIES`.
- **لا تكتب عدد المجالات ثابتًا** في النصوص: استخدم `t(..., n=domain_count)`؛ المفاتيح المعنية
  `footer.tagline`، `home.domains_eyebrow`، `home.meta_domains_val`، `about.scope_eyebrow`،
  `country.domains_sub`، و`exports.SITE_DESC`.
- **زرع المجالات الجديدة دون حذف البيانات:** `db._seed_missing_categories()` تُستدعى من `init_db()`
  حين يكون الجدول غير فارغ، فتزرع فقط المجالات التي لا بلاغات لها. `_seed_entities()` صارت
  تلقائية الفحص (لا تكرّر كيانات بلاغٍ له كيانات).

## البحث النصّي (FTS5)
- الجدول الافتراضي `reports_fts` يفهرس عمودًا واحدًا `search_blob` (نص **مطبَّع**).
- `search_blob` يُبنى عبر `textutils.build_search_text()` عند الإدراج، ويُحدَّث تلقائيًّا
  بواسطة مُشغّلات SQLite (ai/ad/au).
- التطبيع يوحّد الألف/الهمزة/التاء المربوطة/الياء ويزيل التشكيل، لذا «اطفال» يطابق «أطفال».
- استعلامات البحث تُبنى في `_fts_query()`: كل كلمة بادئة مطابقة، مع تهريب آمن.

## قاعدة البيانات
- المسار: `data/violations.db` (مستبعد من git). يُمكن تجاوزه عبر متغيّر `MIRSAD_DB`.
- تُنشأ وتُعبّأ تلقائيًّا عند أول تشغيل عبر `db.init_db()`.
- `insert_report()` يحسب `country_code` والإحداثيات و`search_blob` تلقائيًّا.
- منع التكرار في الاستيراد عبر `external_id` (فهرس فريد جزئي).

## المصادر الخارجية
- GDELT يفرض **حدًّا صعبًا على معدّل الطلبات** (طلب كل 5 ثوانٍ) وقد يردّ 429؛
  كل شروط `OR` في الاستعلام يجب أن تُحاط بأقواس وإلا يرفض الطلب.
- استجابات GDELT الخاطئة (نص خطأ/HTML) تُرفض عبر `_validate_gdelt_csv` فلا تُخزَّن مؤقتًا.
- عند تقييد/حجب GDELT DOC API (`api.gdeltproject.org`) تبقى ملفات الأحداث الخام متاحة عبر
  `app/gdelt_raw.py` (`http://data.gdeltproject.org/gdeltv2/…export.CSV.zip`، رخصة CC BY 4.0):
  نُبقي الجذور العنفية فقط (CAMEO 17/18/19/20 = إكراه/اعتداء/اشتباك/عنف جماعي)، ونحوّلها إلى بلاغات
  غير موثّقة (تتطلّب مراجعة بشرية). تُترجم رموز FIPS عبر `app/data/fips_iso3.json`
  (مولَّدة من `datasets/country-codes`). معرّف الحدث = `GLOBALEVENTID` (العمود 0)، والمنع من التكرار
  ببصمة محتوى `_fingerprint()` (تاريخ+جذر+موقع+رابط) لأن GDELT يعيد الحدث بمعرّفات مختلفة بين الملفات.
  الأحداث متفرّقة (‏~10–15 حدثاً عنفياً فريداً لكل ملف 15 دقيقة) لذا تُؤخذ عيّنات موزّعة عبر
  `export_urls_range(days, step_windows)`. الأوامر: `python -m app.cli ingest-gdelt-raw [--days N --step N --max N --dry-run]`.
  ودورة `refresh(pull_news=True)` تسحب نوافذ خام حديثة كمسار بديل تلقائي.
- ويكيداتا موثوق (بلا مفتاح). التخزين المؤقّت في `data/cache/` (مستبعد من git).
- **تغذيات RSS/Atom** (`app/rss_feeds.py`): ~25 تغذية موثوقة بلا مفتاح تغطّي المجالات الأساسية
  (HRW/Amnesty/OHCHR/FIDH/UN News/Greenpeace/UNEP/Solidarity Center/TNH/USCIRF/Pew/Religion News/
  Stanford HAI/AI Now/Access Now/EFF/PETA/Sea Shepherd/Animal Equality/VegNews…). يُحلَّل RSS 2.0 وAtom
  بلا مكتبات خارجية، ويُصنَّف كل عنصر عبر `importers.classify` مع ترجيح المجال المرجعي للتغذية عند غياب
  إشارات واضحة. الأمر: `python -m app.cli ingest-rss [--max N --dry-run]`. كثرة الروابط 403/404 من
  المنظّمات الكبرى متوقّعة؛ التغذيات المدرجة مُختبرة وتعمل.
- كل عملية استيراد تُسجَّل في جدول `ingest_log`.
- `clients._fetch` يعيد المحاولة عند 429/5xx بتراجع أسّي (بلا شبكة في الوقت الحاضر من هذه البيئة).
- WHO GHO (`ghoapi.azureedge.net`) يعمل بلا مفتاح؛ UCDP يتطلب مفتاحًا (401 بلا تسجيل).

## نقاط انتباه
- **⚠️ نقاط الاستيراد `/api/ingest/*` ونقاط الإدارة `/api/admin/*` محمية بالترويسة
  (`X-Ingest-Key`/`X-Admin-Key`) أو الكوكي **فقط عند** ضبط `MIRSAD_INGEST_KEY`/`MIRSAD_ADMIN_KEY`؛
  وإلا تبقى **مفتوحة للعالم** (الافتراضي للتطوير). لا تُشغّل الأتمتة على بيانات إنتاج حقيقية
  قبل ضبط المفتاحين والتحقّق من أن `/api/admin/status` تُرجع `401`.
- أي إدخال ديناميكي يُدرَج في DOM عبر `innerHTML` (اقتراحات البحث في `app.js`) يجب
  تهريبه (`esc`) لمنع XSS.
- صفحات `/countries` و `/country/{name}` مبنية على `db.countries_summary()`.
- الاستشهاد الأكاديمي: `exports.to_bibtex/to_ris/to_apa` + نقاط `/api/cite.*` (تقبل `id` لبلاغ واحد).
- الكيانات: `db.entities_summary()`/`entity_reports()`/`entity_kind()`/`entity_counts()` +
  صفحات `/entities` و `/entity/{name}`. الأنواع في `taxonomy.ENTITY_KINDS`
  (person/company/organization/government/country/other). `entities_summary` توحّد نوع كل
  اسم عبر `_KIND_RANK` (أعلى أولوية: person > company > government > organization > country).
- شبكة الارتباط: `db.cooccurring_entities(conn, name)` تعيد الكيانات المتشاركة في البلاغات؛
  تُعرض في `/entity/{name}` وتُتاح عبر `/api/entities/{name}/related`.
- `_site_url(request)` يثبّت العنوان العام (sitemap/robots/canonical/استشهاد) عبر
  `MIRSAD_PUBLIC_URL` عند التشغيل خلف وسيط عكسي؛ وإلا يعود إلى `request.base_url`.
- البيانات الأولية في `seed_data.py`؛ يُربط كل بلاغ بالمصدر + الدولة + الجهات المطابقة آليًّا
  عبر `actors.match_actors()` داخل `db._seed_entities()`.
- المجدول يعمل تلقائيًّا كل 60 ثانية؛ عطّله بـ `MIRSAD_REFRESH=0` واضبط الفترة بـ
  `MIRSAD_REFRESH_INTERVAL`. الحالة في `/api/status`، وتشغيل فوري عبر `/api/refresh` أو `app.cli refresh`.
- `refresh.relink_entities()` يعيد ربط الجهات بالبلاغات التي ينقصها كيان من نوع person/company/government
  (مفيد للبلاغات المستوردة من GDELT).
- ترويسات الأمان وضغط GZip و`Cache-Control` للأصول الثابتة تُضاف عبر وسائط في `main.py`.
- `db.connect()` يفعّل WAL و`busy_timeout` لتحمّل التزامن.
- **منع التكرار على مستويين**: `external_id` (فهرس فريد جزئي) وبصمة محتوى `dedup_key`.
  `db.compute_dedup_key()` تبني البصمة (تطبيع العنوان+الدولة+تاريخ الوقوع)، و`db.report_exists()`
  تمنع الإدراج المكرّر، و`db.deduplicate_reports()` تدمج المجموعات المتطابقة في الأقدم وتنقل
  المصادر الإضافية إلى `report_sources` (`external_id='merged:<id>'`). الأمر: `python -m app.cli dedup`.
  لبلاغات GDELT الخام بصمة خاصة = بصمة الحدث (`_fingerprint`) لأن صيغة العنوان مولّدة ومتشابهة.
- **حدود الأداء عند عشرات آلاف البلاغات**: الخريطة (`/map`) تُحمّل `MAP_POINT_LIMIT` نقطة كحدّ أقصى
  مع لافتة `map.points_capped`، والخط الزمني (`/timeline`) مرقّم بـ `TIMELINE_PAGE_SIZE`،
  والمعاينة الجغرافية في الرئيسية و`/api/geo` محدودة. ماكرو الترقيم `_pager.html` بنافذة (±2 صفحات)
  لتفادي آلاف الروابط. راجع هذه الحدود عند إضافة صفحات تعرض كل البلاغات.
- بيئة التشغيل تُفقد الحِزم بعد إعادة التشغيل؛ أعد `pip install -r requirements.txt -r requirements-dev.txt`.

## اختبار سريع
```bash
curl -s localhost:12000/healthz
curl -s "localhost:12000/api/reports?limit=2"
curl -G "localhost:12000/api/search" --data-urlencode "q=أطفال"
curl -s "localhost:12000/api/stats" | python -m json.tool
```

## المكوّنات الجديدة (تحسينات UX/PWA)
- PWA: `app/static/manifest.webmanifest` + `app/static/sw.js` (يُخدَم عبر `/sw.js`)؛
  تسجيله في `base.html`. صفحات `/offline` و`error.html` (خطأ ودّي لطلبات HTML عبر
  معالج `StarletteHTTPException`).
- `base.html`: مجموعات تنقّل (`nav__group`) مع `aria-current`، شريط تقدّم القراءة،
  زر «إلى الأعلى»، لافتة عدم الاتصال، وكتل `{% block ticker %}`/`{% block scripts %}`.
- `reports.html`: تبديل بطاقات/جدول (`data-view-btn`)، شرائح مرشّحات نشطة
  (`active_filters`)، ترقيم كامل (first/last)، تحديد جماعي (`data-select`/`data-bulk-bar`)،
  عرض سريع (`data-qv*`)، هياكل تحميل. قالب الجدول `data-sortable`.
- `submit.html`: معالج 4 خطوات (`data-step`/`data-wizard-*`) مع تحقّق لكل خطوة،
  مسودة تلقائية في `localStorage` (`mirsad.submitDraft`)، ومعاينة مرفقات محليّة.
- `report_detail.html`: مسار الحالة (`status_path`)، تبويبات استشهاد (`data-cite`)،
  خريطة مصغّرة، مشاركة/طباعة، «أبلغ عن تصحيح» عبر `/submit?correction=ID`.
- `stats.html`: ملخّص نصّي (`stats.summary*`)، خريطة حرارائية تقويمية (`#cal-heat`، تواريخ
  مترجمة عبر `MIRSAD_I18N.months`/`heatDay`)، رسم أعمدة مركّبة للمجالات×الخطورة
  (`#chart-matrix` من `matrix`)، تنزيل الرسوم PNG (`data-chart-png`)، زر أرقام عربية
  (`data-numerals-toggle`).
- `map.html`: أدوات تكبير/تصغير/إعادة عرض/ملء شاشة/وضع خفيف؛ الدوال العامة
  `window._mirsadFlat`/`_mirsadFit`/`_mirsadInvalidate`.
- الاستشهاد: `exports.to_apa/to_mla/to_chicago` (بالإضافة إلى BibTeX/RIS).
- مخطط مصغّر في `index.html` يُبنى من `stats.by_month` في `main.home`.
- نافذة اختصارات لوحة المفاتيح (`<dialog id="shortcuts">` في `base.html`): تُفتح بزرٍّ في
  التذييل (`data-shortcuts-open`) أو بمفتاح `?`؛ الاختصارات: `/` بحث، `g m` الخريطة،
  `g t` الأعلى، `d` تبديل السمة، `Esc` إغلاق. منطقها في `app.js`.
- صفحات فرعية أثريت: `about.html` (فهرس `toc` + إحصاءات حيّة + `faq` + ترخيص)،
  `category.html` (فتات `breadcrumbs`، شرائح خطورة، مجالات ذات صلة، **ترقيم** عبر `?page=`
  مع `PAGE_SIZE` و`current_page`/`pages`)،
  `country.html` (فتات، spark، جهات مرتبطة، دول مقارنة)، `entity.html` (فتات، نسخ رابط، حالة فارغة).
  المكوّنات المشتركة: `.breadcrumbs`، `.toc`، `.faq`، `.spark`، `.cat-card__foot`.
- `report_detail.html`: فتات عبر `{% block breadcrumbs %}` + زمن قراءة (`reading_minutes`
  يُحسب في `report_detail` ≈200 كلمة/دقيقة، مفتاح `ui.reading_time`) + تنقّل السابق/التالي
  (`db.adjacent_reports` → `adjacent`، العنصر `.report-nav`، روابط `--prev`/`--next`).
  بيانات منظّمة `NewsArticle` JSON-LD في `{% block head %}`
  (`@type`: NewsArticle)؛ تنقّل بالأسهم ←/→ بين البلاغات (يحترم RTL) وزر مشاركة يفتح نافذة
  خيارات (`#share-dialog`) تشمل المشاركة الأصلية عند دعم المتصفّح وروابط المنصّات والبريد.
- `reports.html`: عناصر `<select data-nav-param="…">` تُحدّث معامل URL مع الحفاظ على بقية
  المعاملات (`data-nav-reset` يحذف `page` عند تغيير الترتيب)؛ روابط CSV/JSON تستخدم
  `request.query_params` لتشمل كل المرشّحات. أعداد البلاغات تُعرض بجانب كل خيار في مرشّحات
  المجال والخطورة والحالة والدولة والتوثيق (`db.filter_counts` → `counts`). مرشّح التوثيق
  `?verified=1|0` مدعوم في `query_reports`/`count_reports` وواجهات `/api/reports` و
  `/api/export.csv` و`/api/export.json`. رقاقات المرشّحات النشطة
  (`active_filters`، تشمل التاريخ والتوثيق) تُزال بـ `[data-remove-filter]` في `app.js`.
  إبراز كلمات البحث يتمّ في نهاية `app.js`
  عبر `<mark>`، وسجلّ «تابعت مؤخرًا» (`data-recent` + `localStorage["mirsad.recent"]`)
  يُكتب من صفحة التفاصيل (عنصر `.dossier` يحمل `data-report-id`/`data-report-title`).
  الفتات (breadcrumbs) متاحة في كل الصفحات عبر `{% block breadcrumbs %}`.
- بحث الجداول العام: أي جدول يحمل `id` يمكن ربطه بحقل `[data-table-search="<table-id>"]`؛
  يخفي الصفوف غير المطابقة نصيًّا ويعرض صفًّا برسالة عند غياب النتائج
  (`I18N.noMatch` → `sources.no_match`). صفّ الرسالة `.table-empty-note` يُستثنى من الفرز.
  مطبَّق على جدول المصادر (`sources.html`).
- شريط تصفية السجل: القوائم تُرسل تلقائيًّا (`data-autosubmit`)، وحقل البحث النصّي
  (`data-live-submit`) يُرسل بعد توقّف الكتابة 550ms مع استعادة التركيز بعد إعادة التحميل.

## نقاط يجب الحذر منها
- **لا تُتداخل روابط `<a>` داخل `<a>`** (HTML غير صالح): المتصفّح يُنهي البطاقة الأب مبكّرًا فتخرج
  الروابط الفرعية من الشبكة وتظهر مبعثرة/مخفيّة. بطاقات المجالات (`index.html`/`about.html`) تُغلَّف
  في `.cat-card-wrap` وتُعرض المجالات الفرعية (`.cat-card__subs`) كأشقّاء للبطاقة لا أبناء لها.
  يحرس ذلك اختبار `test_home_has_no_nested_anchors`.
- عند تغيير تصنيف، تأكّد من تحديث `SEVERITIES`/`CATEGORIES`/`STATUSES` وأي عرض يعتمد عليها.
- `db.count_reports()` يعيد استخدام `query_reports` ثم يحصي — مناسب لحجم البيانات الحالي فقط.
- عند تغيير مخطّط `reports` أو جداول FTS، ارفع `SCHEMA_VERSION` ليعاد البناء تلقائيًّا.
- أدوات المحرّر: `file_editor` لا يستطيع الكتابة فوق ملف موجود (احذف أولًا)، و`TerminalAction`
  ينفّذ أمرًا واحدًا فقط (اربط الأوامر بـ `&&` أو `;`).
- **الفرع الرئيسي الموحَّد**: `master` هو النسخة الرئيسية الوحيدة ويضم كل العمل
  (`integration/all` + `feat/social-platform` + `data-rss-cross-domain-dedup`). لا تبنِ ميزات جديدة
  على الفروع القديمة؛ ابدأ من `master`. `integration/all` يبقى مرجعًا تاريخيًّا فقط.

## تنسيق التواريخ
- تُخزَّن التواريخ في قاعدة البيانات بصيغة ISO (`YYYY-MM-DD`) دائماً؛ لا تُعرض خامّة للمستخدم.
- للعرض استخدم `i18n.format_date()` (تاريخ) و`format_datetime()` (طابع زمني)، وهما متاحتان في
  القوالب عبر `fmt_date`/`fmt_datetime`. أسماء الأشهر في `i18n.MONTHS`، وتُمرَّر للقوالب عبر `months`.
- `_enrich()` يضيف `occurred_display`/`reported_display` لكل بلاغ؛ استخدمهما في القوالب بدل
  `occurred_on`/`reported_on`. نقاط الخريطة تحصل على `reported_display` في مسار `/map`، مع
  `fmtDate()`/`pointDate()` كبديل في JS.
- تواريخ العرض تُوضع في عنصر بخط النصّ (`.date-val`) لا `.mono`: خط `plex-mono` لا يحوي محارف
  عربية فتظهر أسماء الأشهر العربية مشوّهة داخل العنصر الأحادي.
- بيانات JSON-LD المهيكلة (`dateCreated`/`datePublished`) تبقى بصيغة ISO عمداً (قراءة آلية).
- شريط «عاجل» في الرئيسية: `ticker_items` = الحالات الحرجة ثم أحدث البلاغات دون تكرار، ويُكرَّر
  المسار مرّتين في القالب لحركة متواصلة بلا فجوة (`@keyframes ticker`/`ticker-rtl`).

## الترجمة والمحتوى الإنجليزي
- حقول `title_en`/`summary_en` في جدول `reports` تحمل المحتوى الإنجليزي للبيانات الأولية،
  والترجمات في `app/seed_en.py` بمفتاح العنوان العربي (`SEED_EN`).
- `_enrich(report, lang)` يستبدل `title`/`summary`/`details` بالنسخة الإنجليزية عند `lang == "en"`،
  ويضيف `country_display` (اسم الدولة بلغة الواجهة + علمها). القوالب تستخدم `r.country_display`.
- `_flag_emoji()` يحوّل رمز ISO2 إلى علم إيموجي؛ تُعرض الأعلام في `/countries` و`/country/{name}`.
- الخريطة: `geo_points()` يعيد `title_en`، ومسار `/map` يستبدل العنوان والدولة بالنسخة الإنجليزية،
  وقائمة الدول تُعرض بأسماء مترجمة.
- عند إضافة بلاغ جديد إلى `SEED_ROWS` أضف ترجمته إلى `SEED_EN` وإلا ظهر النصّ العربي في النسخة
  الإنجليزية. أي تغيير في مخطّط `reports` يتطلّب رفع `SCHEMA_VERSION` لإعادة بناء القاعدة.

## تحسينات الواجهة (UI/UX)
- **قائمة الأوامر (Command Palette)**: `Ctrl/⌘ + K` أو زر `[data-command-open]`، تعرض تنقّلًا
  (`navItems` المُصدَّرة من القالب) وإجراءات (سمة/لغة/اختصارات/أعلى الصفحة). منطقها في `app.js`
  ويعتمد `window.MIRSAD_I18N`.
- **الترويسة المضغوطة**: `.masthead.is-scrolled` عند تمرير > 12px (تُضاف عبر `app.js`).
- **شارة «جديد»**: عنصر `[data-new-badge]` في التنقّل، يستدعي `/api/new-count?since=<iso>` مقابل
  `localStorage["mirsad.lastVisit"]`. الخادم: `db.count_since()`.
- **أعمدة التذييل القابلة للطيّ**: `[data-footer-toggle]` + `.footer__col.is-collapsed` (تظهر على الجوال فقط).
- **الرئيسية**: شريط إعلان قابل للإغلاق (`[data-announce]`, يُحفظ في `localStorage`)، شرائح جمهور،
  شارات اتجاه لكل مجال (`cat_trend`)، شارة موثّق/يحتاج توثيقًا (`verified_recent`/`needs_verification`)،
  تغطية جغرافية + بحث فوري عن دولة (`countryList` المُصدَّرة)، حالة النظام (`sources_healthy`/`sources_stale`)،
  شركاء/مصادر، أسئلة شائعة (`faq_items`)، وعدّاد تحديث تنازلي بلا طلب شبكة (`[data-refresh-countdown]`).
- **دفعة 1-ج/1-د**: سجل البلاغات — فتات تنقّل، أوجه سريعة (`[data-facets]`)، طيّ المرشّحات
  (`[data-filters-toggle]`)، حالة فارغة غنية (`empty-state__actions`). بطاقة البلاغ: `report-card__chips`
  (شارة «جديد» + الخطورة) وعدّاد المصادر (`source-count`). تفاصيل البلاغ: `share-row` بإجراءات
  `intent=validate|source|correction`، وتلميح البلاغ المرجعي في `submit.html` (`notice--ref`).
- **دفعة 2 — لوحة البيانات (`stats.html`)**: صف مؤشرات مشتقّة `kpi-grid` (نسبة التوثيق، المتوسط الشهري،
  أعلى مجال، أعلى شهر) محسوبة في مسار `/stats` من `st["by_month"]` و`by_category`؛ `[data-summary-text]`
  + `[data-copy-target]` لنسخ الخلاصة؛ توسيع/طيّ قائمة الدول `[data-geo-toggle]`؛ جدول رقمي بديل للرسوم
  (`data-table`). البحث/الترتيب في `countries.html` و`entities.html` صار مع عدّاد نتائج (`data-*-count`)
  وزر مسح (`data-*-clear`) وحالة فارغة (`data-*-empty`)؛ ترتيب الدول حسب التوثيق (`value="verified"`).
- **دفعة 2 — نموذج الإرسال**: عدّادات أحرف (`[data-counter]`/`.field__count.is-over`)، إقرار إلزامي
  (`[data-consent]`)، وزر مسح المسودة (`[data-draft-clear]`). صفحة الخطأ: بحث + روابط مساعدة
  (`.error-state__search`/`.error-state__links`). صفحة عدم الاتصال: ملاحظة عودة الاتصال (`ui.back_online`).
- **لمسات عامة**: رأس جدول لاصق (`position: sticky`) داخل الحاويات القابلة للتمرير، `::selection`
  متّسق مع السمة، `overflow-wrap: anywhere` للنصوص الطويلة، وقواعد طباعة تُخفي الأوجه/المؤشرات.
- **دفعة 3 — الخريطة (`map.html`)**: زر طيّ المرشّحات على الجوال (`[data-filters-toggle]`/`.map-filters.is-open`)،
  وترتيب قائمة بلاغات لوحة الدولة (`[data-panel-sort]` = severity|date عبر `panelSort`). أيقونات جديدة
  في `_icons.html`: `sliders`، `filter`، `sort`، `expand`، `copy`، `print`.
- **دفعة 3 — تفاصيل البلاغ**: شريحة درجة الثقة `.conf-chip` (مرتفعة/متوسّطة/قيد التحقّق)، فهرس محتويات
  `.doc-toc` بروابط مراسي (`#sec-details/#sec-context/#sec-sources/#sec-map`)، وشارة «جديد» على بطاقات
  البلاغات ذات الصلة.
- **دفعة 3 — الرئيسية/المجال**: تصفّح سريع `.hero__quicknav`، وشارات موثّق/جديد + قصّ الملخّص على بطاقات
  «الأحدث»؛ حالة فارغة غنية في `category.html`.
- **دفعة 3 — JS/إتاحة عامة**: منطقة إعلان حيّة `[data-live-region]` في `base.html` يُحدّثها `app.js` عند
  النسخ؛ معالج مشاركة مركزي في `app.js` لأي عنصر يحمل `[data-share]` (الصفحات) أو
  `[data-card-share]` (بطاقات السجل) يفتح نافذة `#share-dialog` بخيارات المنصّات ونسخ الرابط،
  مع الرجوع التلقائي إلى المشاركة الأصلية أو نسخ الرابط عند غياب النافذة؛
  `scroll-padding-top` للمراسي.
- **دفعة 4 — سجل البلاغات**: مفتاح كثافة العرض (`[data-density-btn]` = comfortable|compact، يُحفظ في
  `localStorage["mirsad.density"]` ويطبّق `.report-grid.is-compact`)، ووصف جدول مخفي (`<caption>`)،
  وعمود المصادر في جدول البلاغات.
- **دفعة 4 — تفاصيل البلاغ**: تمييز فهرس المحتويات بالتمرير (scroll-spy عبر `IntersectionObserver`،
  `.doc-toc a.is-active`).
- **دفعة 4 — الكيانات/المصادر/عدم الاتصال**: حالات فارغة غنية (`empty-state__actions`) في `entities.html`
  و`entity.html` مع شارات «جديد»/«موثّق» وقصّ الملخّص؛ وصف جدول المصادر؛ روابط سريعة `.offline-links`
  في `offline.html`.
- أصول الواجهة مربوطة بـ `ASSET_VER` في `main.py`؛ ارفعه عند تغيير CSS/JS لإبطال الكاش.

## الخط الزمني (موحَّد)
- **صفحة مستقلة `/timeline`**: كل البلاغات مرتّبة تصاعديًا بتاريخ الوقوع (`sort="occurred_asc"`) ومجمَّعة
  في محطات عبر `_group_timeline(items, key_len)` (4=سنة، 7=شهر، 10=يوم؛ مفتاح التجميع = بادئة تاريخ الوقوع
  مع الرجوع لتاريخ النشر). المرشّحات: `granularity`/`category`/`severity`/`country`، وروابط التجميع
  (`links`) تُبنى في المسار بـ `urlencode` وتحفظ المرشّحات. القالب `timeline.html` والأنماط `.timeline--full`
  /`.timeline__group*`.
- **الرئيسية**: قسم «الخط الزمني» يستخدم `db.timeline_milestones(conn, limit)` — بلاغ بارز واحد لكل شهر
  (الأعلى خطورة ثم الأحدث عبر `ROW_NUMBER()`)، فلا يكرّر قسم «الأحدث». يعرض `timeline__date` (تاريخ الوقوع
  داخل `<time>`) + `timeline__relative` (`fmt_relative`).
- **الخريطة**: الشريط الزمني شهري (`timelineMonths`، `monthLabel()`، `applyMonth()`، `PANEL_BY_MONTH`) بدل
  السنوي؛ `geo_points()` يعيد `month` (`substr(reported_on,1,7)`) إلى جانب `year`. معامل URL `month`.
- **لوحة البيانات**: رسم الاتجاه `#chart-month` يعرض مجموعتين: الإجمالي (`by_month`) والموثّقة
  (`by_month_verified`) — مفتاحا `stats.timeline_total`/`stats.timeline_verified` في i18n.
- **تفاصيل البلاغ**: مسار `.report-timeline` (الوقوع ← التوثيق ← التحقق) فوق مسار الحالة `.status-path`.
- **التنقّل/الموقع**: رابط `/timeline` في `base.html` (تنقّل + تذييل + `navItems`) وفي `sitemap.xml`.
- `db.query_reports` يدعم `sort="occurred"`/`"occurred_asc"`؛ وخيار الترتيب «تاريخ الوقوع» متاح في
  `reports.html` (`reports.sort_occurred`).

## جمع البيانات الواسع (Catalog + Harvest) ونافذة العاجل
- **فهرس المصادر**: `app/catalog.py` يولّد 1000+ مصدر (`build_catalog()`) موزّعة على المجالات
  كافة، بمفاتيح فريدة وأنواع `feed`/`search`/`dataset`/`api`. تُزامَن إلى جدول `source_catalog`
  عند `init_db()` عبر `_sync_catalog()`؛ وتُكتب نسخة JSON في `app/data/source_catalog.json`
  بأمر `python -m app.cli catalog --write`.
- **جدول `source_catalog`** (ضمن `SCHEMA_VERSION=8`): يحمل حالة كل مصدر (`last_run`/`last_status`/
  `last_error`/`fail_count`/`next_run`/`items_total`/`inserted_total`/`enabled`).
  دوالّه: `db.catalog_due()` (المصادر المستحقّة للدوران)، `db.mark_catalog_run()` (تسجيل النتيجة
  مع تراجع أسّي عند الفشل بسقف 24 ساعة)، `db.catalog_health()` (ملخّص: total/enabled/ok/failed/never_run).
- **محرّك الجمع**: `app/harvest.py::harvest_batch()` يسحب دفعة محدودة (`--sources`) وبحدّ لكل مصدر
  (`--max`)، يدوّر المصادر المستحقّة، يُصنّف (`importers.classify`) ويستخرج الدولة، ثم يُدرج بمنع
  تكرار على مستويين (`external_id` للرابط و`dedup_key` للمحتوى) مع تسجيل المصادر الإضافية في
  `report_sources`. الوضع الجاف: `dry_run=True` أو `--dry-run`.
- **التكامل مع المجدول**: `refresh.refresh()` يستدعي دفعة جمع محدودة كل دورة (كل 60 ثانية)،
  و`recompute_aggregates(limit=400)` يحدّ إعادة الحساب للحفاظ على الأداء.
- **نافذة العاجل (الرئيسية)**: قالب `_urgent.html` (مُضمَّن في `index.html` بعد قسم البطل):
  شريط حالة أخضر «الجمع يعمل الآن» + مقاييس (`added_1h`/`added_24h`/`critical_24h`/مصادر نشطة)،
  وبطاقات البلاغات الحرجة/المرتفعة بنبذة وشرائح (مجال/حالة/دولة/تاريخ) ورقم البلاغ، ورابط «فتح البلاغ».
  تُحدَّث تلقائيًّا كل 60 ثانية عبر `/api/urgent` في `app.js` (وتُعلن «جديد» في `[data-live-region]`).
- **نقاط API**: `/api/urgent?limit=&hours=` (بلاغات عاجلة + حالة الجمع + صحة الفهرس) و
  `/api/collection` (حالة الجمع + صحة الفهرس). دوالّه: `db.urgent_reports()` و`db.collection_stats()`.
- **تواريخ RSS**: `rss_feeds.parse_iso_date()` يطبّع RFC-822 (RSS) وISO-8601 (Atom) إلى `YYYY-MM-DD`؛
  كان الخطأ القديم يقتطع بـ`[:10]` فيُخزّن «Wed, 26 Au». `db.repair_bad_dates()` يُصلح الصفوف
  المشوّهة ويعيد حساب `dedup_key`، ويُشغَّل ضمن `python -m app.cli dedup`.
- **الفهارس الحرجة للأداء** (مع عشرات آلاف الصفوف): `idx_reports_sev_reported` (severity+reported_on)،
  `idx_reports_dedup` (dedup_key)، و`idx_reports_ym` (فهرس تعبيري على شهر الوقوع).
  `db.count_reports()` صار `SELECT COUNT(*)` مباشرًا (لا يجلب الصفوف)، و`db.timeline_milestones()`
  يُحدّد الأشهر أولًا بالفهرس ثم يجلب بلاغًا بارزًا لكل شهر.
- **حالة المصادر في الرئيسية** تُشتقّ الآن من `catalog_health` (ok/failed) لا من جدول `sources` القديم.
- **بنية `reports`**: تواريخ الوقوع/النشر ISO (`YYYY-MM-DD`) دائمًا؛ لا تُخزَّن صيغ RFC-822 الخام.
  عند تغيير مخطّط `reports` أو جداول FTS ارفع `SCHEMA_VERSION`؛ الفهارس تُنشأ ضمن `SCHEMA` تلقائيًّا.
## المنصّة الاجتماعية (قيد التنفيذ — على دفعات)
- **الوثيقة المرجعية**: `docs/social-platform-plan.md` — 2000 خاصية في 20 مجالًا (نشر الحقائق،
  التعاون بين الناشطين، رفع الشكاوى، الملفات الحساسة).
- **الدفعات**: 12 دفعة متتابعة (الأساس الاجتماعي → المنشورات → التفاعل → المجموعات → الرسائل →
  القضايا → الإشراف/السمعة → الإشعارات/البحث → الملفات الحساسة/الأمن → الخصوصية/التحقّق →
  الوسائط/الحملات → التكامل/الإدارة).
- **الدفعة 1 (منجزة) — الأساس الاجتماعي + دليل الأعضاء**:
  - جدول `members` (SCHEMA_VERSION = 7) + `app/social.py` (بيانات أولية `SEED_MEMBERS` ودوال
    `query_members/count_members/member_by_handle/member_counts/member_countries/seed_members`).
  - `taxonomy.MEMBER_ROLES`/`MEMBER_STATUSES` + `member_role_label`/`member_status_label`.
  - مسارات: `/members` (مرشّحات + ترقيم + تصدير)، `/member/{handle}`، `/api/members`، `/api/members.csv`.
  - `_enrich_member()` و`_localized_taxonomy` (member_roles/member_statuses) في `main.py`؛
    `exports.members_to_csv`؛ قالبا `members.html`/`member.html`؛ أنماط `.member-*`/`.role-legend`/`.tag-chip`.
  - **خصوصية**: لا تُخزَّن بيانات شخصية حسّاسة؛ واجهة `/api/members` تُرجع حقولًا عامة فقط
    (اختبار `test_members_public_fields_only` يحرس ذلك).
- أي تغيير في مخطّط `members` يتطلّب رفع `SCHEMA_VERSION`. ارفع `ASSET_VER` عند تغيير CSS/JS.
- **الدفعة 2 (منجزة) — المنشورات والتغذية**:
  - جدول `posts` + `posts_fts` (SCHEMA_VERSION = 8) مع حذف ناعم (`status='hidden'`)؛ مُشغّلات
    FTS على `search_blob` (مبنيّ عبر `textutils.build_search_text`).
  - `taxonomy.POST_KINDS`/`POST_VISIBILITIES`/`POST_STATUSES` + `post_kind_label`/`post_visibility_label`/
    `post_status_label`؛ تُمرَّر للقوالب كـ `post_kinds`/`post_visibilities` عبر `_localized_taxonomy`.
  - `social.py`: `SEED_POSTS` (16 منشورًا) و`seed_posts`، `query_posts` (مرشّحات: كاتب/نوع/ظهور/وسم/
    بلاغ/بحث FTS)، `count_posts`، `post_by_id`، `insert_post`، `hide_post`، `post_counts`، `recent_posts`.
  - مسارات: `/posts` (مرشّحات + ترقيم)، `/post/{id}`، `/api/posts`؛ `_enrich_post()` في `main.py`.
  - قالبا `posts.html`/`post.html`؛ أنماط `.post-*`؛ مفاتيح `posts.*`/`post_kind.*`/`post_vis.*`.
- **الدفعة 3 (منجزة) — التفاعل والتعليقات والإبلاغ**:
  - جداول `reactions`/`comments`/`attachments`/`member_blocks`/`content_reports` (SCHEMA_VERSION = 9).
  - `app/ratelimit.py`: تقييد معدّل في الذاكرة (نافذة متحرّكة، thread-safe، `allow/reset`).
  - `social.py`: `toggle_reaction`/`add_comment`/`comment_tree`/`report_content`/`block_member`/
    عدّادات مجمّعة (`reaction_counts_bulk`/`comment_counts_bulk`) و`seed_interactions`.
  - نقاط الكتابة محمية: `POST /api/posts/{id}/react|comment|report`، `POST /api/members/{handle}/block`؛
    للقراءة: `GET /api/posts/{id}/comments`، `GET /api/content-reports` (طابور الإشراف).
  - **تحذير**: لا يوجد نظام مصادقة بعد؛ المعرّف الفاعل يُمرَّر كوسيط `handle` ويُتحقّق أنه عضو نشط
    منشور (`_acting_handle`). لا تعتمد على هذه النقاط لأي بيانات حسّاسة حتى إضافة مصادقة.
  - صفحة المنشور: أزرار تفاعل + منتقي هوية + نموذج تعليق/ردّ + شجرة تعليقات؛ المنطق في `app.js`
    (`[data-post-actions]`/`[data-react]`/`[data-comment-form]`/`[data-reply-to]`).
- أي تغيير في مخطّط الجداول الاجتماعية يتطلّب رفع `SCHEMA_VERSION`. ارفع `ASSET_VER` عند تغيير CSS/JS.
- **الدفعة 4 (منجزة) — المجموعات والمجتمعات**:
  - جداول `groups`/`group_members`/`group_posts` (SCHEMA_VERSION = 10).
  - `taxonomy.GROUP_KINDS`/`GROUP_VISIBILITIES`/`GROUP_ROLES`/`GROUP_MEMBER_STATUSES` + دوال التسمية؛
    تُمرَّر للقوالب كـ `group_kinds`/`group_visibilities`/`group_roles`/`group_member_statuses`.
  - `social.py`: `SEED_GROUPS` (8 مجموعات) و`seed_groups`، `query_groups`/`count_groups`/`group_by_slug`/
    `group_members`/`group_posts`/`group_role`/`join_group`/`leave_group`/`approve_group_member`/
    `group_counts`/`groups_for_member`.
  - **خصوصية**: المجموعات السرّية تُستثنى دائمًا من `query_groups` ومن صفحة المجموعة ومن الـ API
    (اختبار `test_secret_group_hidden_from_listing`). الانضمام مباشر للعام وبانتظار الموافقة للخاص/السرّي.
    مالك المجموعة لا يستطيع المغادرة (يُمنع في SQL).
  - مسارات: `/groups`، `/group/{slug}`، `/api/groups`، `/api/groups/{slug}`،
    `POST /api/groups/{slug}/join|leave` (محمية بحدّ معدّل)؛ `_enrich_group()` في `main.py`.
  - قالبا `groups.html`/`group.html`؛ أنماط `.group-*`/`.roster-*`؛ مفاتيح `groups.*`/`group_kind.*`/`group_vis.*`؛
    منطق الانضمام/المغادرة في `app.js` (`[data-group-actions]`).
- **الدفعة 5 (منجزة) — الرسائل والمحادثات**:
  - جداول `conversations`/`conversation_members`/`messages` (SCHEMA_VERSION = 11).
  - `social.py`: `SEED_CONVERSATIONS` (5 محادثات) و`seed_conversations`، `conversation_for_member`/
    `conversations_for_member`/`conversation_members`/`conversation_messages`/`send_message`/
    `count_messages`/`find_direct_conversation`/`start_direct_conversation`.
  - **وصول**: `conversation_for_member` يحصر القراءة/الكتابة على المشاركين فقط؛ الإرسال لغير المشارك
    يعيد 404 (اختبار `test_send_message_requires_participant`).
  - مسارات: `/messages`، `/api/conversations`، `/api/conversations/{cid}`،
    `POST /api/conversations/{cid}/messages`، `POST /api/conversations/direct` (محمية بحدّ معدّل).
  - قالب `messages.html`؛ أنماط `.messages-*`/`.convo-*`/`.message-bubble`؛ مفاتيح `messages.*`؛
    منطق الإرسال في `app.js` (`[data-compose]`/`[data-thread]`).
  - **تحذير**: لا مصادقة ولا تشفير؛ رسائل تجريبية للعرض فقط (لافتة `messages.privacy_note`).
- **الدفعة 6 (منجزة) — التحقّق من الحقائق والتوثيق**:
  - جداول `claims`/`claim_sources`/`claim_reviews`/`claim_timeline` (SCHEMA_VERSION = 12).
  - `taxonomy`: `CLAIM_STATUSES`/`CLAIM_SOURCE_KINDS`/`SOURCE_RELIABILITY` (مقياس Admiralty مبسّط)/
    `REVIEW_DECISIONS` + دوال التسمية؛ تُمرَّر للقوالب عبر `_localized_taxonomy`.
  - `social.py`: `SEED_CLAIMS` (6 ادّعاءات) و`seed_claims`، `query_claims`/`claim_by_ref`/
    `claim_sources`/`claim_reviews`/`claim_timeline`/`add_claim_source`/`review_claim`/`assign_claim`/
    `claim_counts`/`claims_leaderboard`، و`_claim_reliability_score`/`_claim_confidence`.
  - **قاعدة التوثيق**: `review_claim(decision='approve')` لا يمنح `verified` إلا بمصدرين مستقلّين على
    الأقلّ؛ وإلا يبقى `pending` (اختبار `test_approve_requires_two_sources`). التكذيب يضبط `debunked`.
  - مسارات: `/verification`، `/verification/{ref}`، `/api/claims`، `/api/claims/{ref}`،
    `POST /api/claims/{ref}/sources|review|assign` (محمية بحدّ معدّل)؛ `_enrich_claim()`/`_enrich_claim_source()`.
  - قالبا `verification.html`/`claim.html`؛ أنماط `.claim-*`/`.conf-chip`/`.source-*`/`.verify-timeline`؛
    مفاتيح `verify.*`/`claim_status.*`/`source_kind.*`/`decision.*`؛ منطق `app.js` (`[data-claim-actions]`).
- **الدفعة 7 (منجزة) — الإشراف والحوكمة**:
  - جداول `moderation_actions`/`appeals`/`audit_log` (SCHEMA_VERSION = 13)؛ تستفيد من `content_reports` القائم.
  - `taxonomy`: `MODERATION_ACTIONS` (تحذير→كتم→حظر بدرجات)، `REPORT_STATES`/`REPORT_REASONS`/
    `APPEAL_STATUSES` + دوال التسمية؛ تُمرَّر للقوالب عبر `_localized_taxonomy`.
  - `social.py`: `seed_moderation`، `apply_moderation`/`active_restriction`/`set_report_state`/
    `file_appeal`/`appeals`/`review_appeal`/`moderation_stats`/`recent_audit`/`expiry_alerts`/`_log`.
  - **قواعد الحوكمة**: سبب إلزامي لكل إجراء (≥5)، الحظر يتطلّب سببًا مطوّلًا (≥20) وسابقة إشرافية
    (`escalation_required`) — مبدأ «educate-first». قبول الاستئناف يرفع إجراء المحتوى إلى «ملاحظة».
  - **الأدوار**: `_acting_moderator()` يحصر الإجراءات في دور `admin`/`moderator` (403 لغيره).
  - مسارات: `/moderation`، `/api/moderation/reports/{id}/state`، `POST /api/moderation/actions`،
    `POST /api/appeals`، `POST /api/appeals/{id}/review`، `/api/moderation/stats` (محمية بحدّ معدّل).
  - قالب `moderation.html`؛ أنماط `.mod-*`/`.tabs`/`.kpi*`/`.appeal-*`/`.audit-*`؛ مفاتيح `mod.*`/
    `mod_status.*`/`mod_action.*`/`appeal_status.*`/`reason.*`؛ منطق `app.js` (`[data-mod-console]`).
- **الدفعة 8 (منجزة) — السمعة والثقة**:
  - جداول `endorsements`/`vouches`/`member_badges`/`trust_snapshots` (SCHEMA_VERSION = 14).
  - `taxonomy`: `REPUTATION_DIMENSIONS` (دقّة/تعاون/موثوقية)، `TRUST_LEVELS` (0–5 بصلاحيات)، `BADGES`،
    `VOUCH_KINDS` + دوال التسمية و`trust_level_for_score`.
  - `social.py`: `seed_reputation`، `add_endorsement`/`_endorser_weight`، `add_vouch`، `award_badge`،
    `trust_score` (مركّب قابل للتفسير 0–100 بتفصيل)، `trust_history`، `trust_leaderboard`، `trust_network`.
  - **منع التلاعب**: لا تقييم ذاتي، لا تكرار لنفس البُعد، لا تقييم انتقامي مباشر (خلال يوم)،
    ووزن المُقيِّم يقلّ لغير الموثّق ولدوائر التبادل المغلقة؛ ضمان الأقران يتطلّب ضامنًا بثقة ≥ 40.
  - مسارات: `/trust`، `/api/members/{h}/trust`، `POST /api/members/{h}/endorse|vouch`،
    `/api/trust/leaderboard`؛ صفحة العضو `/member/{h}` تعرض الثقة والشارات والتأييدات وشبكة الثقة.
  - قالب `trust.html`؛ أنماط `.badge-*`/`.endorse-*`/`.trust-*`؛ مفاتيح `trust.*`/`trust_level.*`/
    `badge.*`/`vouch_kind.*`/`trust.b_*`؛ منطق `app.js` (`[data-trust-panel]`).
- **الدفعة 9 (منجزة) — الإشعارات والتنبيهات**:
  - جداول `notifications`/`notification_prefs`/`subscriptions`/`quiet_hours` (SCHEMA_VERSION = 15).
  - `taxonomy`: `NOTIFICATION_CATEGORIES` (نظام/تفاعل/أمن/مهام)، `NOTIFICATION_PRIORITIES` (عادي/مهم/حرج)،
    `NOTIFICATION_CHANNELS` (inapp/rss فعّالة، والباقي تصدير/محاكاة)، `SUBSCRIPTION_KINDS` + دوال التسمية.
  - `social.py`: `seed_notifications`، `notify`، `_in_quiet_hours`/`set_quiet_hours`، `set_notification_pref`/
    `mute_all`، `notifications_for`/`unread_count`/`mark_read`، `digest`، `subscribe`/`unsubscribe`/
    `subscribers_for`/`notify_subscribers`، `purge_old_notifications`، `notification_stats`.
  - **قواعد الخصوصية**: الإشعارات بلا محتوى حسّاس (content-free)؛ **الإشعارات الأمنية لا تُكتم أبدًا**
    (تتجاوز ساعات الهدوء وكتم-الكل)؛ «لا إزعاج» يطبَّق على بقية التصنيفات.
  - **الكتم المؤقّت**: `notification_prefs.muted_until` (تاريخ `YYYY-MM-DD` أو طابع زمني) يُحترم في
    `notify()` عبر `_muted_until_active()`؛ تفضيل صريح لكل تصنيف مثل `enabled`، وسريانه يمنع الإنشاء
    (القيم غير الصالحة تُهمَل).
  - **المنطقة الزمنية لساعات الهدوء**: `_in_quiet_hours` يحسب الساعة بالمنطقة المخزَّنة
    `quiet_hours.tz` عبر `_hour_in_tz()` (لا بـUTC)، ويرجع إلى UTC عند غيابها أو تعذّر تحميلها؛
    والنافذة شاملة لطرفَيها `[s, e]` فـ`(0, 23)` تغطّي اليوم كاملًا.
  - مسارات: `/notifications`، `/api/notifications`، `/api/notifications/count|digest|stats`،
    `POST /api/notifications/read|test|prefs|mute-all|quiet-hours`، `POST/DELETE/GET /api/subscriptions`،
    و`/notifications.rss` (قناة RSS).
  - قالب `notifications.html`؛ أنماط `.notif-*`/`.digest-*`/`.sub*`/`.quiet-row`؛ مفاتيح `notif.*`/
    `notif.category.*`/`notif.prio.*`/`notif.channel.*`/`sub_kind.*`؛ منطق `app.js` (`[data-notif-center]`).
- **الدفعة 10 (منجزة) — البحث والاكتشاف**:
  - جدول `saved_searches` (SCHEMA_VERSION = 16).
  - `app/search.py`: بحث موحّد عبر 7 أنواع (بلاغ/منشور/ادّعاء/كيان/مصدر/عضو/مجموعة) عبر `_SEARCHERS`؛
    `suggest_correction` (difflib على مفردات)، `complete`، `suggest_queries`، `related_terms`،
    `trending_terms`، `discovery_boards`، `save_search`/`unsave_search`/`saved_searches`/`search_counts_since`.
  - **تطبيع عربي** عبر `textutils` (همزات/تاء مربوطة/تشكيل) فـ«اطفال» تطابق «أطفال»؛
    إبراز `<mark>` ومقتطف سياق `_snippet`؛ **بحث آمن** يُخفي البلاغات الحرجة غير الموثّقة.
  - مسارات: `/discover`، `/api/search/unified`، `/api/search/suggest|trending|saved|export|index`،
    `/api/discover/boards`.
  - قالب `discover.html` (بحث + شرائح أنواع + اقتراحات فورية + لوحات اكتشاف + بحوث محفوظة)؛
    أنماط `.discover-*`/`.boards-grid`/`mark`؛ مفاتيح `discover.*`/`search_kind.*`؛ منطق `app.js`
    (`[data-discover-form]`/`[data-discover]`).
- **الدفعة 11 (منجزة) — الحملات والمناصرة** (بيانات تجريبية بالكامل):
  - جداول `campaigns`/`campaign_team`/`campaign_signatures`/`campaign_targets`/`campaign_pledges`/
    `campaign_events`/`campaign_updates`/`campaign_waves`/`campaign_media` (SCHEMA_VERSION = 17).
  - `taxonomy`: `CAMPAIGN_STATUSES`/`CAMPAIGN_ROLES`/`CAMPAIGN_TARGET_KINDS`/`CAMPAIGN_EVENT_KINDS`/
    `PLEDGE_STATES`/`WAVE_STATES`/`ADVOCACY_CHARTER` (ميثاق الأخلاقيات).
  - `app/campaigns.py`: بذور حملات، `progress`، توقيع آمن (`sign_campaign`: منع مكرّر + مهلة + حماية هوية)،
    `campaign_impact`، `campaign_risk` (خطة أمان الناشطين)، موجات (`schedule_wave`/`send_wave` بسقف إغراق
    محاكاة/`measure_wave`)، وعود (`set_pledge_state`)، `suggested_campaigns`/`opportunities`.
  - **خصوصية/أمان**: التوقيع المجهول يخفي الاسم والمعرّف (يظهر «موقّع مجهول»)؛ الإرسال محاكاة فقط
    ولا يخرج أي بريد؛ التحديثات للمنسّقين فقط.
  - مسارات: `/campaigns`، `/campaign/{slug}`، `/api/campaigns`، `/api/campaigns/stats`،
    `/api/campaigns/{slug}`، `/api/campaigns/{slug}/impact`، `POST /api/campaigns/{slug}/sign`،
    `POST /api/campaigns/{slug}/updates`، `POST /api/campaigns/waves/{id}/send`،
    `POST /api/campaigns/pledges/{id}/state`.
  - قالبا `campaigns.html`/`campaign_detail.html`؛ أنماط `.camp-*`؛ مفاتيح `camp.*`/`camp_status.*`/
    `camp_role.*`/`camp_target.*`/`camp_event.*`/`pledge_state.*`/`wave_state.*`؛ منطق `app.js` (`[data-campaign]`).
- **الدفعة 12 (منجزة) — التكامل والأتمتة** (كل التكاملات محاكاة):
  - جداول `api_keys`/`api_usage`/`webhooks`/`webhook_deliveries`/`connectors`/`automation_rules`/
    `rule_runs`/`jobs`/`workers` (SCHEMA_VERSION = 18).
  - `taxonomy`: `API_SCOPES`/`API_VERSIONS`/`WEBHOOK_EVENTS`/`CONNECTOR_KINDS`/`RULE_TRIGGERS`/
    `RULE_ACTIONS`/`JOB_STATES`/`DELIVERY_STATES`.
  - `app/integrations.py`: مفاتيح محدودة الصلاحيات (`key_has_scope`) والمعدّل (`within_rate_limit`/
    `record_api_usage`)، Webhooks موقّعة HMAC-SHA256 (`sign_payload`/`dispatch_event`/`deliver` بإعادة
    محاولة حتى سقف)، موصلات، قواعد أتمتة (`validate_rule`/`run_rule`/`toggle_rule`)، طابور مهام
    (`enqueue_job`/`dequeue_job`/`finish_job`/`requeue_failed`/`queue_congested`) وعمّال، وتقارير صحّة.
  - **خصوصية/أمان**: لا شبكة ولا بيانات حقيقية؛ التوقيعات محلية؛ v0 مهمل ومُعطَّل.
  - مسارات: `/integrations`، `/api/docs`، `/api/openapi.json`، `/api/integrations/{stats,keys,webhooks,
    connectors,rules,queue,health}`، و`POST /api/integrations/{webhooks/test,webhooks/{id}/retry,
    connectors/{id}/sync,rules/{id}/run,rules/{id}/toggle,rules/validate,queue/enqueue,queue/{id}/finish,
    queue/requeue-failed}`.
  - قالبا `integrations.html`/`api_docs.html`؛ أنماط `.data-table`/`.code-block`/`.sr-only`؛
    مفاتيح `integ.*`/`api_scope.*`/`webhook_event.*`/`connector_kind.*`/`rule_trigger.*`/`rule_action.*`/
    `job_state.*`؛ منطق `app.js` (`[data-integrations]`).
- **الدفعة 13 (منجزة، الختامية) — الإدارة والتشغيل والتحليلات** (بيانات تجريبية):
  - جداول `system_flags`/`announcements`/`service_health`/`incidents`/`audit_log`/
    `retention_policies`/`roadmap`/`governance_decisions`/`volunteers`/`page_views`
    (SCHEMA_VERSION = 19).
  - `taxonomy`: `SERVICE_STATES`/`INCIDENT_STATES`/`RETENTION_CLASSES`/`ALERT_LEVELS`/`ROADMAP_STATES`.
  - `app/ops.py`: أعلام النظام (`set_flag`/`in_maintenance`/`read_only`)، إعلانات، صحّة الخدمات
    (`system_status`)، حوادث وما بعد العطل (`update_incident`)، سجل تدقيق (`audit`)، سياسات احتفاظ
    (`retention_report`/`archive_candidates`)، **تحليلات مجمّعة بلا تتبّع شخصي** (`record_view`
    يحوّل أي مسار إلى حزمة عامّة؛ `analytics_summary`)، مؤشّرات `kpis`، كشف شذوذ (`detect_anomalies`)،
    مقارنة فترات واتجاهات، خارطة طريق، قرارات حوكمة، وإدارة متطوّعين.
  - **بوّابة تشغيلية** في الوسيط: وضع الصيانة → 503 (صفحة `maintenance.html` للـHTML، JSON للـAPI)
    باستثناء `/healthz`/`/status`/`/api/status`/الأصول و**نقاط الإدارة** (`/admin`, `/api/admin/*`)
    كي يرفع المشرف الوضع؛ وضع القراءة فقط → 403 لطرق الكتابة.
  - **خصوصية**: التحليلات مجمّعة فقط (لا معرّفات/IP)؛ كل بيانات التشغيل تجريبية.
  - مسارات: `/admin`، `/status`، `/api/admin/{status,kpis,analytics,incidents,flags,audit,retention,
    roadmap,volunteers,ops-report}`، و`POST /api/admin/{flags,announcements,incidents/{id}/state,
    retention,volunteers/hours}` (تتطلّب هوية مشرف عبر `handle`).
  - قالبا `admin.html`/`status.html` (+ `maintenance.html`)؛ أنماط `.kpi*`؛ مفاتيح
    `admin.*`/`status.*`/`maint.*`/`service_state.*`/`incident_state.*`/`alert_level.*`/`roadmap_state.*`؛
    منطق `app.js` (`[data-admin]`).
- **الدفعة 14 (منجزة، محاكاة فقط) — الملفات الحسّاسة**:
  - **قيد أمني صارم**: لا رفع حقيقي، لا محتوى مخزَّن، لا تشفير فعلي (`crypto_ready()` دائمًا
    `False`)، لا تنزيل (`allow_download="0"` لا يقبل التحويل إلى `1`)، لا شبكة. تُعطَّل الطبقة
    كاملة بـ `MIRSAD_SENSITIVE_MODE=0` (تعيد 404). راجع `docs/sensitive-files-review.md`.
  - جداول `vault_items`/`vault_access`/`vault_receipts`/`vault_policies` (SCHEMA_VERSION = 20).
  - `taxonomy`: `SENSITIVE_KINDS`/`SENSITIVE_STATES`/`CLASSIFICATION_LEVELS`/`ACCESS_STATES`/`RECEIPT_KINDS`.
  - `app/sensitive.py`: إيداع وصفي (`create_item`)، ختم/سحب (`set_item_state`)، طلب وصول يبدأ
    `pending` دائمًا (`request_access`)، قرار المالك فقط (`decide_access`)، تحقّق وصول (`can_access`)،
    إيصالات (`add_receipt`)، سياسات (`set_policy`)، وإحصاءات.
  - مسارات: `/vault`، `/vault/{id}`، `/api/vault/{items,items/{id},items/{id}/state,items/{id}/request,
    access/{id}/decide,access/pending,policies,stats}`.
  - قالبا `vault.html`/`vault_detail.html`؛ أنماط `.notice--ref`؛ مفاتيح `vault.*`/`sensitive_kind.*`/
    `sensitive_state.*`/`classification.*`/`access_state.*`/`receipt_kind.*`؛ منطق `app.js` (`[data-vault]`).
- **تصلّب الإدارة (دفعة 14)**: نقاط `/api/admin/*` تمرّ عبر `_require_admin`؛ عند ضبط
  `MIRSAD_ADMIN_KEY` يُشترط ترويسة `X-Admin-Key` (وإلا 401)، وإلا تُقبل هوية مشرف نشطة (بيئة تطوير).
- **دفعة تحسينات UX/إتاحة/PWA (جلسة ساعة)**: أُصلح مفتاح ترجمة ناقص `search.submit`
  (كان يُعرض حرفيًّا في `/discover`)، وأُضيف اختبار حارس `test_no_literal_i18n_keys_in_templates`
  يفشل عند أي مفتاح `t('...')` حرفي غير موجود في `STRINGS`. أُضيفت أيقونات PWA مربّعة PNG
  `app/static/img/icon-{192,512}.png` (مولَّدة برمجيًّا بلا مكتبات خارجية) مع `apple-touch-icon`
  وmanifest محدَّث؛ ورُفعت `CACHE` في `sw.js` إلى `mirsad-v2` و`ASSET_VER` إلى `20261016n`.
  الخط الزمني `/timeline`: روابط مراسي `id="g-<key>"` + شرائح «محطات سريعة» `.timeline-jump`
  + رؤوس محطات لاصقة (`.timeline--full .timeline__group-head` بـ `--sticky-offset`). شريط
  الزمن في الخريطة صار له `aria-label`/`aria-valuetext` محدَّث في `applyMonth()`.

## الدمج: البيانات + المنصّة الاجتماعية (فرع `integration/all`)
- **الحالة**: الفرعان `data-rss-cross-domain-dedup` (فهرس المصادر/الجمع/نافذة العاجل) و
  `feat/social-platform` (المنصّة الاجتماعية، الدفعات 1–14) مدموجان في فرع واحد `integration/all`.
  نقطة التفرّع المشتركة: `68202cb`.
- **`SCHEMA_VERSION = 20`** (أعلى القيمتين؛ كان فرع البيانات 8 والاجتماعي 20). الترقية **في المكان**
  عبر `_migrate()` تحفظ البلاغات المستوردة: تحقّقت ترقية قاعدة الإنتاج (50,009 بلاغًا) إلى v20 دون فقد.
- **تعارضات الدمج الأربعة** (حُلّت بالجمع لا الاختيار):
  - `AGENTS.md`: قسما «جمع البيانات الواسع» و«المنصّة الاجتماعية» — أُبقيا معًا.
  - `app/db.py`: `SCHEMA_VERSION` → 20.
  - `app/main.py`: `ASSET_VER` → `20261016o` مع الإبقاء على `MAP_POINT_LIMIT` و`TIMELINE_PAGE_SIZE`
    (كانا في فرع البيانات فقط).
  - `app/templates/base.html`: الإبقاء على كتلة `urgent` (نافذة العاجل) ومفاتيح `MIRSAD_I18N` الاجتماعية.
- **الوسائط**: بقيت `security_headers` (اللغة + كاش الأصول + X-Request-ID) و`_ops_gate` (الصيانة/
  القراءة فقط) و`GZipMiddleware` — لا تعارض.
- **إصلاح مرافق**: حُذف مفتاح i18n مكرّر `submit.draft_restored` (كان معرّفًا مرّتين في الفرعين).
- **التحقّق**: 410 اختبارًا تمرّ؛ 129 مسارًا تُرجع دون أخطاء 500؛ ترقية قاعدة الإنتاج + تشغيل دورة
  `refresh()` بنجاح. بيئة العرض: 12000 = الأساسي، 12002 = الدمج، 12001 = الاجتماعي (worktree).

## دمج دفعة الإصلاحات (15 فرع `agent/*`)
- **الحالة**: 15 فرع إصلاح على GitLab (14 MR مفتوحًا) دُمجت كلها في `master` دفعةً واحدة. الفروع
  المتعدّدة التي عالجت **نفس الوظيفة** تعارضت مع بعضها، فدُمجت بالترتيب مع حلّ يدوي يجمع الإصلاحات
  المتكاملة (لا اختيار أحدها):
  - **ساعات الهدوء (4 فروع متعارضة)**: `_in_quiet_hours` في `app/social.py` وُحّد على السلوك الشامل
    لطرفَي النافذة `[s, e]` مع احترام المنطقة الزمنية المخزَّنة (`_hour_in_tz`، وتراجع إلى UTC):
    `return (hour >= s or hour <= e) if s > e else (s <= hour <= e)`. نافذة نقطية `(3,3)` تغطّي
    ساعتها فقط؛ `(0,23)` تغطّي اليوم كاملًا. (فرع واحد توقّع أن النافذة النقطية لا تكتم شيئًا —
    عُدّل اختباره ليطابق السلوك الموحّد.)
  - **البحث الموحّد (4 فروع)**: `app/search.py` جمع تصحيح الروابط (`/report` → `/reports`)،
    إصلاح الأنواع المنكسرة + إخفاء المجموعات السرّية + تسجيل الفشل، خريطة إزاحة الإبراز
    (`_norm_char_index`)، وتهريب HTML (`html.escape`) معًا — الإبراز يُبنى على النصّ الأصلي
    **ومُهرَّب** (يُعرض بـ`| safe` بأمان).
  - **التصدير (فرعان)**: `app/exports.py` جمع تحييد حقن الصيغ (`csv_cell`) وتحسين أسطر الاستشهاد
    (`_plain`)؛ `app/templates/map.html` يحيّد CSV في الواجهة أيضًا.
- **تعارضات أخرى حُلّت بالجمع**: `AGENTS.md` (ملاحظتا الكتم المؤقّت + المنطقة الزمنية)،
  `tests/test_api.py` (اختبارات الإبراز/الإزاحة + XSS، واختبارات ساعات الهدوء).
- **التحقّق**: 520 اختبارًا تمرّ (كانت 490)؛ فحص دخان لنقاط `/healthz` و`/api/reports` و`/api/search`
  و`/discover` و`/api/notifications/count` و`/api/integrations/webhooks` و`/api/campaigns`
  (كلها 200)، و`/api/reports?limit=-1` يُرجع عنصرًا واحدًا (القصّ يعمل).
- **ملاحظة**: دفع `master` أغلق الـ14 MR تلقائيًّا في GitLab (الفرع المصدر صار مدموجًا).

## اصطلاحات الإتاحة (a11y) وطبقة الأدوات
- **الأيقونات**: كل SVG في `_icons.html` (macro `icon`) و`base.html` يحمل
  `aria-hidden="true" focusable="false"` — الأيقونات زخرفية والنصّ المجاور هو الدلالة.
- **الأزرار**: كل زر غير مُرسِل يحمل `type="button"` صراحةً (منع الإرسال غير المقصود).
- **ترتيب العناوين**: لا قفز في المستويات (h1 → h2 → h3). عناوين الأقسام داخل الصفحات `h2`
  وبطاقات البلاغات `h2`؛ لتغيير حجم عنصر عنوان دون كسر التسلسل استخدم نمطًا مضمّنًا صريحًا
  أو صنف `.u-*` بدل تغيير الوسم.
- **إجراءات JS**: لا معالجات مضمّنة (`onclick=`). استخدم `data-action="print|back|reload"`
  (معالج مُفوَّض في نهاية `app.js`) أو سمات `data-*` قائمة.
- **الجداول**: كل `<table>` يحمل `<caption class="sr-only">` أو `visually-hidden`.
- **طبقة الأدوات `.u-*`** (نهاية `style.css`): أُخرجت من أنماط مضمّنة متكرّرة، وتستخدم
  `!important` **عمدًا** لمحاكاة أسبقية النمط المضمّن السابق. لا تُضِف قواعد إليها بلا سبب.
- أي تغيير في CSS/JS يتطلّب رفع `ASSET_VER` في `main.py`.
- سجلّ التدقيق والتحسينات: `docs/ui-ux-backlog.md`.

## نظام أحجام الأيقونات (إلزامي)
- **قاعدة عامة** في `style.css`: `svg { width: var(--icon-md); height: var(--icon-md); flex: none;
  vertical-align: -0.125em; }`. أي `<svg>` بلا قاعدة تحجيم خاصة كان يُعرض بالحجم الافتراضي
  للمتصفّح (ضخم) — كانت ~700 أيقونة منفجرة قبل الإصلاح.
- **سلّم الرموز** في `:root`: `--icon-xs:12 --icon-sm:14 --icon-md:16 --icon-lg:18 --icon-xl:20
  --icon-2xl:22 --icon-3xl:44`. لا تكتب أبعاد svg ثابتة بالبكسل؛ استخدم رمزًا من السلّم.
- **استثناء الخرائط**: `#map svg, #globe svg { width:auto; height:auto; }` — مكتبتا Leaflet وglobe.gl
  تضبطان أبعاد svg بنفسهما، فلا تُحجَّم.
- **سماكة الخطّ**: كل أيقونات الماكرو و`base.html` بسماكة موحّدة `stroke-width="1.6"`.
- **بلا أبعاد مضمّنة**: لا `width`/`height` على وسوم `<svg>` في الماكرو أو `base.html` (يتولّاها CSS).
- **أصناف اختيارية** عند الحاجة لتجاوز الافتراضي: `.ico-xs|sm|md|lg|xl`.
- **صيانة**: أضف قاعدة تحجيم لأي حاوية أيقونات جديدة، وإلا وقعت على الافتراضي `--icon-md`.
  تحرسها اختبارات في `tests/test_ux_batch6.py`.

## اكتشاف المصادر آليًّا (discovery)
- `app/discovery.py` — محرّك الاكتشاف الدوري. يبحث في مرشّحين مصنَّفين ضمن **15 تصنيفًا مرجعيًّا**
  (`DISCOVERY_GROUPS`: تسريبات/شفافية، حقوق الإنسان، بيئة، ذكاء اصطناعي/حقوق رقمية، سكان أصليون،
  LGBTQ+، أقليات/حريات دينية وفكرية، حرية الصحافة، عمال/اقتصاد، إعاقة/عدالة انتقالية، نساء/جندر،
  لاجئون/مهاجرون، أطفال، كبار سن، أرشيف أدلة OSINT)، ثم يتحقّق من معايير القبول (مجاني/مفتوح)
  ومن عدم التكرار قبل الإضافة إلى `source_catalog` (وبالتالي قائمة المصادر).
- الدوال الأساسية: `discover(conn, *, limit, dry_run, log_run)` (دورة كاملة)، `maybe_discover(conn)`
  (تُشغَّل فقط عند استحقاق الفترة)، `is_due(conn)`، `ensure_groups(conn)` (إدراج فوري عند الإقلاع)،
  `build_dedup_index(conn)` + `is_duplicate(conn, name, url, index)` (منع تكرار بالاسم المُطبَّع أو
  المضيف مقابل `sources` و`source_catalog` — يُبنى الفهرس مرّة واحدة لكل دورة للأداء)،
  `license_is_open(license)` (بوّابة الرخصة)، و`CANDIDATES`/`DISCOVERY_GROUPS`/`SOURCE_KINDS`.
- **الفترة** افتراضيًّا 300 ثانية (5 دقائق) عبر `MIRSAD_DISCOVERY_INTERVAL`؛ تُخزَّن حالة آخر دورة
  في `meta` عبر `_set_meta`. المرشّحون ذوو تغذية (`feed_url`) يُفعَّلون في الفهرس ليُجمعوا دوريًّا،
  والمرجعيون يبقون معطّلين.
- التكامل: يُستدعى في `refresh()` (خطوة 5)، وفي `lifespan` بـ`main.py` عبر `ensure_groups()`.
- CLI: `python -m app.cli discover [--limit N] [--dry-run] [--due]`.
- API: `GET /api/discovery` (التصنيفات + العدّ + المصادر + آخر تقرير + السجل)،
  `POST /api/discovery/run` (تشغيل فوري؛ محمي بـ`X-Ingest-Key` عند ضبط `MIRSAD_INGEST_KEY`).
- الواجهة: قسم «المصادر المكتشفة آليًّا» في `sources.html` (مؤشرات، تصفية حسب التصنيف، سجلّ الدورات،
  زر «شغّل دورة اكتشاف الآن» عبر `[data-discovery-run]` + `data-disc-*`).
- جداول قاعدة البيانات: أعمدة الاكتشاف في `source_catalog` (`discovered`, `group_key`, `source_kind`,
  `coverage`, `access`, `categories`…) وجدول `discovery_run`؛ دوال مساعدة: `discovered_count`,
  `discovered_sources`, `add_discovered_source`, `latest_discovery_report`, `discovery_history`.
  `SCHEMA_VERSION = 22`.
- مفاتيح i18n: `discovery.*` (عربي/إنجليزي) في `app/i18n.py`، و`discoveryRunning`/`discoveryRanOk`
  في `MIRSAD_I18N` (`base.html`).
- اختبارات: `tests/test_discovery.py` (تغطية التصنيفات الـ15، بوّابة الرخصة، منع التكرار، الإضافة
  والاستمرارية، التشغيل الجاف، الاستحقاق، صفحة المصادر، واجهات API).

## الأمان والوصول الإداري (تدقيق)
- **بوّابة المناطق الإدارية/التشغيلية**: `_operator_gate()` (وسيط `security_headers`) تحجب
  `/api/admin/*` و`/api/monitoring*` والصفحات `/admin` و`/monitor` و`/audit` **عند ضبط
  `MIRSAD_ADMIN_KEY` فقط**. بلا مفتاح (تطوير) تبقى مفتوحة، مع تحذير في `lifespan`.
  - نقاط API تُرجع `401 {"error":"admin_key_required"}`؛ صفحات HTML تُرجع `403` بصفحة `error.html`
    تتضمّن نموذج إدخال مفتاح (`unlock_action`).
  - القبول بترويسة `X-Admin-Key` **أو** كوكي `mirsad_admin` (HttpOnly، SameSite=Lax) يُعيَّن عبر
    `GET /ops/unlock?key=…&next=…` (يعيد التوجيه دائمًا، ويقبل `next` داخليًّا فقط عبر `_safe_next`).
  - `_require_admin` يقبل المفتاح/الكوكي أيضًا (لكتابة الإدارة)، ويبقى مسار العضو بدور admin/moderator
    صالحًا في بيئة التطوير بلا مفتاح.
- **ترويسات الأمان** (وسيط `security_headers`): `Content-Security-Policy` (أصول محلية،
  `img-src https:` لبلاطات الخريطة، `object-src 'none'`، `frame-ancestors 'self'`)،
  و`Strict-Transport-Security` **فقط عند HTTPS** (أو `X-Forwarded-Proto: https`)،
  إضافة إلى `X-Content-Type-Options`/`Referrer-Policy`/`X-Frame-Options`/`Permissions-Policy`.
- **robots.txt** يمنع فهرسة `/account` و`/messages` و`/notifications` و`/moderation` و`/vault`
  و`/admin` و`/monitor` و`/audit` و`/api/` و`/auth/` و`/submit` و`/offline`.
- **نموذج الهوية (`handle`)**: النقاط الاجتماعية/الإشرافية تعتمد معرّف عضو منشور نشط؛
  هذه بيئة محاكاة. عند ضبط `MIRSAD_ADMIN_KEY` تصبح كتابة الإدارة مقيّدة بالمفتاح،
  ويُوصى بربط جلسة المستخدم المُصادَق بـ`members.handle` قبل الإنتاج العام.
- اختبارات: `tests/test_security_audit.py` (CSP/HSTS، حجب الإدارة، فتح المفتاح، `ops/unlock`).

## الاستجابة (responsive)
- الترويسة تنكسر لسطرين على `max-width:980px`، وتُضغط أدواتها إلى أيقونات على `max-width:720px`
  (`.account-btn__name`/`.account-btn--signin span`/`.lang-switch span` مخفيّة) لتفادي التجاوز الأفقي.
- الجداول العريضة داخل `.table-scroll` (`overflow-x:auto`)؛ و`.chart-grid > * { min-width:0 }`
  لمنع تضخّم شبكة الرسوم. تحقّق منها عبر Playwright عند 320/375/414/768/1024/1440.

