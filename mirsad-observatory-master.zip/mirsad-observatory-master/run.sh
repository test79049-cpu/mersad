#!/usr/bin/env bash
# تشغيل مِرصد مع تهيئة متوازنة لأتمتة التحديث.
#
# الموازنة: معدّل الاستيراد يجب ألا يتجاوز معدّل المعالجة، وإلا تراكم المخزون
# بلا حدّ. القيم الافتراضية في الكود (collect=8, process=25) تجعل الوصول
# (~50–95 مستندًا/دقيقة) أسرع من التفريغ (25/دقيقة)، فينمو `documents.pending`
# بلا توقّف. القيم أدناه تعكس المعادلة: collect=4 يخفض الوصول إلى ~25–50/دقيقة،
# وprocess=100 يرفع التفريغ إلى 100/دقيقة — فينكمش المخزون ويلحق بالمصادر.
set -euo pipefail

cd "$(dirname "$0")"

: "${PORT:=12000}"
: "${HOST:=0.0.0.0}"

# أسرار محلية اختيارية (مُستبعَدة من git): مفاتيح الاستيراد/الإدارة/الجلسة.
# عند غيابها تبقى نقاط الكتابة مفتوحة — لا تُشغّل الموقع عامًّا بدونها.
if [ -f .env.local ]; then
  set -a
  . ./.env.local
  set +a
fi

# ---------------------------------------------------------------------------
# بوّابة أمان قبل الإقلاع (بوّابة تحقّق، لا نصّ توثيقي فقط).
#
# السبب: بدون MIRSAD_INGEST_KEY و MIRSAD_ADMIN_KEY تبقى نقاط الكتابة
# /api/ingest/* و /api/admin/* مفتوحة للعالم بلا مصادقة (الافتراضي للتطوير).
# لا يكفي تحذير في السجلّ؛ في الإنتاج نرفض الإقلاع نهائيًّا. لا تُطبع قيم المفاتيح أبدًا.
#
# الإنتاج = MIRSAD_ENV=production (تضبطه منصّات النشر: compose/systemd/render).
# ---------------------------------------------------------------------------
: "${MIRSAD_ENV:=development}"
if [ "$MIRSAD_ENV" = "production" ]; then
  _missing=""
  [ -n "${MIRSAD_INGEST_KEY:-}" ] || _missing="$_missing MIRSAD_INGEST_KEY"
  [ -n "${MIRSAD_ADMIN_KEY:-}" ] || _missing="$_missing MIRSAD_ADMIN_KEY"
  if [ -z "${MIRSAD_SECRET_KEY:-}" ] \
     || [ "${MIRSAD_SECRET_KEY:-}" = "mirsad-dev-secret-change-me" ]; then
    _missing="$_missing MIRSAD_SECRET_KEY"
  fi
  if [ -n "$_missing" ]; then
    {
      echo "✗ رفض الإقلاع (MIRSAD_ENV=production): مفاتيح ناقصة أو افتراضية:$_missing"
      echo "  بدونها تبقى /api/ingest/* و/api/admin/* مفتوحة للعالم بلا مصادقة."
      echo "  ولّد مفتاحًا: python3 -c \"import secrets;print(secrets.token_urlsafe(32))\""
      echo "  اضبطها في .env.local أو بيئة الخدمة. للتطوير المحلي: MIRSAD_ENV=development."
    } >&2
    exit 1
  fi
  echo "✓ بوّابة الإنتاج: مفاتيح الحماية مضبوطة (INGEST/ADMIN/SECRET)."
elif [ -z "${MIRSAD_INGEST_KEY:-}" ] || [ -z "${MIRSAD_ADMIN_KEY:-}" ]; then
  {
    echo "⚠ وضع التطوير (MIRSAD_ENV=$MIRSAD_ENV): نقاط الكتابة /api/ingest/*"
    echo "  و /api/admin/* مفتوحة للعالم. للإنتاج: اضبط المفاتيح ثم MIRSAD_ENV=production."
  } >&2
fi

export MIRSAD_COLLECT_SOURCES="${MIRSAD_COLLECT_SOURCES:-4}"
export MIRSAD_PROCESS_BATCH="${MIRSAD_PROCESS_BATCH:-100}"
export MIRSAD_VERIFY_BATCH="${MIRSAD_VERIFY_BATCH:-60}"
export MIRSAD_BACKLOG_THRESHOLD="${MIRSAD_BACKLOG_THRESHOLD:-2000}"

exec python3 -m uvicorn app.main:app --host "$HOST" --port "$PORT"
