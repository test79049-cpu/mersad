"""مستوردات من المصادر المفتوحة.

- GDELT DOC API: عناوين أخبار عالمية تُصنَّف آلياً إلى مجالات الانتهاك.
- ويكيداتا: إثراء الكيانات بمعرّفات QID.

كل مُستورَد يُسجَّل في جدول ingest_log، ويُمنع التكرار عبر external_id.
"""

import csv
import re
import io
from datetime import date

from . import db
from .clients import get_text
from .config import GDELT_BASE
from .countries import arabic_name, find as find_country
from .taxonomy import CATEGORIES

# كلمات مفتاحية (عربية + إنجليزية) لتصنيف عناوين الأخبار إلى مجالات.
# الكلمات الإنجليزية تُطابَق بحدود الكلمات (مفردة أو عبارة) لتفادي المطابقات
# الجزئية المضلّلة مثل «strike» داخل «airstrikes».
CATEGORY_KEYWORDS = {
    "human_rights": [
        "اعتقال", "تعذيب", "احتجاز", "تظاهر", "قمع", "سجين", "محاكمة",
        "human rights", "detention", "torture", "protest", "crackdown", "arbitrary",
    ],
    "animal_rights": [
        "حيوان", "رفق", "مسلخ", "صيد", "انقراض", "نفوق",
        "animal cruelty", "poaching", "wildlife", "slaughter", "endangered",
    ],
    "environment": [
        "تلوث", "بيئة", "انبعاث", "تسرب", "نفايات", "غابات", "جفاف",
        "pollution", "emission", "oil spill", "deforestation", "toxic", "climate",
    ],
    "ai_ethics": [
        "ذكاء اصطناعي", "خوارزمية", "مراقبة", "تحيز", "بيانات شخصية",
        "artificial intelligence", "algorithm", "surveillance", "bias", "facial recognition",
    ],
    "labor_rights": [
        "عمال", "أجور", "إضراب", "نقابة", "عمل قسري", "عمالة أطفال",
        "labor", "labour", "wages", "union", "forced labor", "child labor",
        "labor strike", "workers strike",
    ],
    "minorities": [
        "أقلية", "أقليات", "تهجير", "عرقي", "إثني", "لاجئ",
        "minority", "ethnic", "displacement", "refugee", "discrimination",
    ],
    "beliefs": [
        "معتقد", "دين", "إلحاد", "حرية الرأي", "اضطهاد", "كفر",
        "religious freedom", "blasphemy", "atheist", "persecution", "apostasy",
    ],
    "women_children": [
        "المرأة", "النساء", "الطفل", "الأطفال", "عنف أسري", "زواج قسري",
        "women", "children", "child marriage", "domestic violence", "gender-based",
        "forced marriage", "girls",
    ],
    "refugees_migrants": [
        "لاجئ", "لاجئون", "مهاجر", "مهاجرون", "نازح", "إعادة قسرية", "ترحيل",
        "refugee", "migrant", "asylum", "deportation", "displacement", "rescue at sea",
    ],
    "expression": [
        "صحافة", "صحفي", "إعلام", "تعبير", "حجب", "رقيب", "تجمع سلمي",
        "press freedom", "journalist", "censorship", "freedom of expression",
        "free speech", "media freedom",
    ],
    "transitional_justice": [
        "عدالة انتقالية", "إفلات من العقاب", "لجنة الحقيقة", "تعويضات", "جبر الضرر",
        "transitional justice", "impunity", "truth commission", "reparations",
        "redress", "accountability",
    ],
    "economic_social": [
        "اقتصادية", "سكن", "إخلاء", "ضمان اجتماعي", "أجور", "بطالة",
        "housing", "eviction", "social security", "living wage", "unemployment",
        "economic rights",
    ],
    "health": [
        "صحة", "علاج", "دواء", "رعاية صحية", "مستشفى", "وباء",
        "health", "healthcare", "medicine", "hospital", "epidemic", "medical care",
    ],
    "education_culture": [
        "تعليم", "مدرسة", "جامعة", "ثقافة", "تراث", "هوية ثقافية",
        "education", "school", "university", "cultural heritage", "literacy", "curriculum",
    ],
    "poverty_food": [
        "فقر", "غذاء", "مجاعة", "أمن غذائي", "مياه", "جوع",
        "poverty", "food security", "famine", "hunger", "malnutrition", "water access",
    ],
    "criminal_justice": [
        "محاكمة عادلة", "إعدام", "قضاء", "تعذيب", "اختفاء قسري", "إفلات",
        "fair trial", "death penalty", "judicial", "enforced disappearance",
        "due process", "rule of law",
    ],
    "prisoners_rights": [
        "سجين", "محتجز", "سجن", "احتجاز", "إعادة تأهيل", "ظروف الاحتجاز",
        "prisoner", "detainee", "prison conditions", "incarceration", "rehabilitation",
    ],
    "disability_rights": [
        "إعاقة", "ذوي الإعاقة", "إمكانية الوصول", "إدماج", "تمكين",
        "disability", "accessibility", "inclusion", "persons with disabilities",
        "reasonable accommodation",
    ],
    "peace_security": [
        "حرب", "نزاع", "سلام", "نزع السلاح", "مدنيون", "أسلحة",
        "armed conflict", "disarmament", "civilians", "war crimes", "peace",
        "weapons of mass destruction",
    ],
    "elderly_rights": [
        "كبار السن", "المسنون", "معاش", "تقاعد", "تمييز عمري",
        "elderly", "older persons", "pension", "age discrimination", "retirement",
    ],
    "inclusivity": [
        "تنوع", "إدماج اجتماعي", "تمييز متعدد", "فئوية", "كراهية",
        "diversity", "inclusion", "hate speech", "intersectional", "social cohesion",
    ],
}

# استعلامات GDELT الافتراضية لكل مجال (كل شروط OR محاطة بأقواس)
GDELT_QUERIES = {
    "human_rights": '("human rights" OR "arbitrary detention" OR torture)',
    "animal_rights": '("animal cruelty" OR poaching OR "wildlife trafficking")',
    "environment": '("oil spill" OR pollution OR deforestation)',
    "ai_ethics": '("facial recognition" OR "algorithmic bias" OR surveillance)',
    "labor_rights": '("child labor" OR "forced labor" OR "labour strike")',
    "minorities": '("ethnic minority" OR "forced displacement")',
    "beliefs": '("religious persecution" OR blasphemy)',
    "women_children": '("child marriage" OR "domestic violence" OR "gender-based violence")',
    "refugees_migrants": '("refugee" OR "migrant" OR deportation)',
    "expression": '("press freedom" OR censorship OR "freedom of expression")',
    "transitional_justice": '("transitional justice" OR impunity OR "truth commission")',
    "economic_social": '("forced eviction" OR "social security" OR "economic rights")',
    "health": '("right to health" OR healthcare OR "medical care")',
    "education_culture": '("right to education" OR "cultural heritage")',
    "poverty_food": '("food insecurity" OR famine OR "right to food")',
    "criminal_justice": '("fair trial" OR "death penalty" OR "rule of law")',
    "prisoners_rights": '("prison conditions" OR "detention conditions")',
    "disability_rights": '("disability rights" OR accessibility)',
    "peace_security": '("protection of civilians" OR disarmament OR "war crimes")',
    "elderly_rights": '("older persons" OR pension OR "age discrimination")',
    "inclusivity": '(diversity OR "hate speech" OR "social inclusion")',
}

# تقدير مستوى الخطورة من كلمات العنوان
_SEVERITY_HINTS = [
    ("critical", ["قتل", "مذبحة", "إبادة", "جماعي", "death", "killed", "massacre", "genocide"]),
    ("high", ["اعتقال", "تعذيب", "عنف", "تهجير", "تسرب", "torture", "violence", "spill", "abuse"]),
    ("medium", ["احتجاج", "إضراب", "تلوث", "تمييز", "protest", "strike", "pollution", "discrimination"]),
]


def _keyword_hit(text: str, words: list[str]) -> int:
    """يحصي الكلمات المطابقة: العربية كسلسلة، والإنجليزية بحدود الكلمات."""
    low = text.lower()
    hits = 0
    for w in words:
        wl = w.lower()
        if wl.isascii():
            if re.search(r"\b" + re.escape(wl) + r"\b", low):
                hits += 1
        elif wl in text:
            hits += 1
    return hits


def classify(title: str) -> tuple[str, str, int]:
    """يصنّف عنواناً: (المجال، الخطورة، درجة الثقة)."""
    low = title.lower()
    scores = {}
    for cat, words in CATEGORY_KEYWORDS.items():
        score = _keyword_hit(title, words)
        if score:
            scores[cat] = score
    category = max(scores, key=scores.get) if scores else "human_rights"
    confidence = min(scores.get(category, 1), 3)

    severity = "medium"
    for sev, words in _SEVERITY_HINTS:
        if _keyword_hit(low, words):
            severity = sev
            break
    return category, severity, confidence


def _guess_country(title: str) -> tuple[str, str | None, float | None, float | None]:
    """يخمّن الدولة من العنوان بالبحث عن أسماء الدول العربية/الإنجليزية."""
    from .countries import all_countries
    low = title.lower()
    for c in all_countries():
        if c["ar"] and c["ar"] in title:
            return c["ar"], c["iso3"], c["latlng"][0], c["latlng"][1]
        if len(c["en"]) > 3 and c["en"].lower() in low:
            return c["ar"], c["iso3"], c["latlng"][0], c["latlng"][1]
    return "غير محدّد", None, None, None


def _validate_gdelt_csv(raw: str) -> None:
    """يرفض استجابات GDELT غير الصالحة (رسائل خطأ أو صفحة HTML)."""
    head = raw.lstrip()[:80].lower()
    if head.startswith("<") or "must be surrounded" in raw.lower() or \
            "please limit requests" in raw.lower():
        raise RuntimeError(f"استجابة GDELT غير صالحة: {raw.strip()[:160]}")


def fetch_gdelt(query: str, maxrecords: int = 25) -> list[dict]:
    """يجلب عناوين أخبار من GDELT DOC API (تنسيق CSV)."""
    params = {
        "query": query,
        "mode": "artlist",
        "format": "csv",
        "maxrecords": maxrecords,
        "sort": "datedesc",
    }
    raw = get_text(GDELT_BASE, params=params, ttl=1800, min_interval=5.0,
                   validator=_validate_gdelt_csv)
    reader = csv.DictReader(io.StringIO(raw))
    rows = []
    for row in reader:
        title = (row.get("Title") or "").strip()
        url = (row.get("URL") or "").strip()
        if title and url:
            rows.append({"title": title, "url": url, "date": (row.get("Date") or "").strip()})
    return rows


def ingest_gdelt(conn, query: str | None = None, category: str | None = None,
                 maxrecords: int = 25, dry_run: bool = False) -> dict:
    """يستورد عناوين GDELT ويحفظها كبلاغات غير موثّقة."""
    queries = [query] if query else list(GDELT_QUERIES.values())
    src = conn.execute("SELECT id FROM sources WHERE key = 'gdelt'").fetchone()
    source_id = src["id"] if src else None

    fetched = inserted = skipped = 0
    for q in queries:
        try:
            rows = fetch_gdelt(q, maxrecords=maxrecords)
        except RuntimeError as exc:
            db.log_ingest(conn, "gdelt", 0, 0, 0, status="error", note=str(exc)[:200])
            continue

        for row in rows:
            fetched += 1
            ext_id = f"gdelt:{row['url']}"
            if db.report_exists(conn, ext_id):
                skipped += 1
                continue

            auto_cat, severity, confidence = classify(row["title"])
            use_cat = category or auto_cat
            country, code, lat, lng = _guess_country(row["title"])
            reported = (row["date"] or date.today().isoformat())[:10]

            if dry_run:
                inserted += 1
                continue

            db.insert_report(conn, {
                "title": row["title"][:240],
                "category": use_cat,
                "severity": severity,
                "status": "new",
                "country": country,
                "country_code": code,
                "region": None,
                "lat": lat,
                "lng": lng,
                "occurred_on": None,
                "reported_on": reported,
                "summary": f"خبر مرصود آلياً من GDELT: {row['title'][:200]}",
                "details": (f"هذا السجل مستورد آلياً من مشروع GDELT (رخصة CC BY 4.0) "
                            f"ويتطلّب مراجعة بشرية قبل التوثيق. درجة ثقة التصنيف الآلي: {confidence}/3."),
                "source_name": "GDELT Project",
                "source_url": row["url"],
                "source_id": source_id,
                "external_id": ext_id,
                "verified": 0,
            })
            inserted += 1

    db.log_ingest(conn, "gdelt", fetched, inserted, skipped)
    return {"source": "gdelt", "fetched": fetched, "inserted": inserted, "skipped": skipped}


def enrich_report_entities(conn, limit: int = 10) -> dict:
    """يثري بلاغات بدون كيانات بمعرّفات ويكيداتا للدولة."""
    from .wikidata import find_country_qid

    rows = conn.execute(
        """SELECT r.id, r.country, r.country_code FROM reports r
           WHERE NOT EXISTS (SELECT 1 FROM entities e WHERE e.report_id = r.id)
           LIMIT ?""",
        (limit,),
    ).fetchall()

    enriched = 0
    for row in rows:
        hit = find_country_qid(row["country"])
        if hit:
            db.add_entity(conn, row["id"], row["country"], kind="country",
                          wikidata_id=hit["id"])
            enriched += 1
    db.log_ingest(conn, "wikidata", len(rows), enriched, len(rows) - enriched)
    return {"source": "wikidata", "scanned": len(rows), "enriched": enriched}
