"""مستورد تغذيات RSS/Atom من منظّمات حقوق الإنسان والمصادر الموثوقة.

يجلب العناوين والملخّصات والروابط، ويصنّفها آلياً إلى مجالات المنصة، ويستخرج
الدولة، ثم يُدرجها كبلاغات غير موثّقة تتطلّب مراجعة بشرية. يمنع التكرار على
مستويين: تطابق `external_id` (الرابط) وبصمة المحتوى `dedup_key`، مع تسجيل
المصادر الإضافية في `report_sources` عند ورود الحدث نفسه من أكثر من تغذية.
"""

from __future__ import annotations

import html
import re
import xml.etree.ElementTree as ET
from datetime import date, datetime
from email.utils import parsedate_to_datetime

from . import db
from .clients import get_text
from .config import USER_AGENT
from .importers import classify, _guess_country

# تغذيات موثوقة متاحة بلا مفتاح، مرتّبة حسب المجال الأساسي المتوقّع.
RSS_FEEDS = [
    # حقوق الإنسان
    ("hrw", "Human Rights Watch", "https://www.hrw.org/rss/news", "human_rights", "high"),
    ("amnesty", "Amnesty International", "https://www.amnesty.org/en/latest/feed/",
     "human_rights", "high"),
    ("ohchr", "المفوضية السامية لحقوق الإنسان (OHCHR)", "https://www.ohchr.org/en/rss.xml",
     "human_rights", "medium"),
    ("fidh", "الاتحاد الدولي لحقوق الإنسان (FIDH)",
     "https://www.fidh.org/spip.php?page=backend", "human_rights", "high"),
    ("un_news_hr", "أخبار الأمم المتحدة — حقوق الإنسان",
     "https://news.un.org/feed/subscribe/en/news/topic/human-rights/feed/rss.xml",
     "human_rights", "medium"),
    # البيئة
    ("un_news_env", "أخبار الأمم المتحدة — المناخ",
     "https://news.un.org/feed/subscribe/en/news/topic/climate-change/feed/rss.xml",
     "environment", "medium"),
    ("greenpeace", "غرين بيس (Greenpeace)", "https://www.greenpeace.org/international/feed/",
     "environment", "medium"),
    ("unep", "برنامج الأمم المتحدة للبيئة (UNEP)", "https://www.unep.org/rss.xml",
     "environment", "medium"),
    ("insideclimate", "Inside Climate News", "https://insideclimatenews.org/feed/",
     "environment", "medium"),
    # حقوق العمل
    ("solidaritycenter", "مركز التضامن (Solidarity Center)",
     "https://www.solidaritycenter.org/feed/", "labor_rights", "medium"),
    ("un_news_econ", "أخبار الأمم المتحدة — التنمية الاقتصادية",
     "https://news.un.org/feed/subscribe/en/news/topic/economic-development/feed/rss.xml",
     "labor_rights", "medium"),
    # الأقليات والمهاجرون
    ("un_news_women", "أخبار الأمم المتحدة — المرأة",
     "https://news.un.org/feed/subscribe/en/news/topic/women/feed/rss.xml",
     "minorities", "medium"),
    ("irin", "ذا نيو هيومانيتريان (TNH)", "https://www.thenewhumanitarian.org/rss.xml",
     "minorities", "high"),
    ("migrationpolicy", "معهد سياسات الهجرة (MPI)", "https://www.migrationpolicy.org/rss.xml",
     "minorities", "medium"),
    # حرية المعتقد
    ("uscirf", "اللجنة الأمريكية للحرية الدينية الدولية (USCIRF)",
     "https://www.uscirf.gov/rss.xml", "beliefs", "high"),
    ("pew_religion", "مركز بيو — الدين", "https://www.pewresearch.org/topic/religion/feed/",
     "beliefs", "medium"),
    ("religionnews", "Religion News Service", "https://religionnews.com/feed/",
     "beliefs", "medium"),
    # أخلاقيات الذكاء الاصطناعي
    ("aiindex_rss", "مؤشر الذكاء الاصطناعي (Stanford HAI)",
     "https://aiindex.stanford.edu/feed/", "ai_ethics", "medium"),
    ("ainow", "معهد AI Now", "https://ainowinstitute.org/feed", "ai_ethics", "medium"),
    ("accessnow", "Access Now", "https://www.accessnow.org/feed/", "ai_ethics", "medium"),
    ("eff", "مؤسسة الحدود الإلكترونية (EFF)", "https://www.eff.org/rss/updates.xml",
     "ai_ethics", "medium"),
    # حقوق الحيوان
    ("peta", "بيتا (PETA UK)", "https://www.peta.org.uk/feed/", "animal_rights", "medium"),
    ("sea_shepherd", "Sea Shepherd", "https://seashepherd.org/feed/",
     "animal_rights", "high"),
    ("animal_equality", "Animal Equality", "https://www.animalequality.org/feed/",
     "animal_rights", "medium"),
    ("vegnews", "VegNews", "https://vegnews.com/rss", "animal_rights", "medium"),
]

_STRIP_TAGS = re.compile(r"<[^>]+>")
_WS = re.compile(r"\s+")


def _clean(text: str | None) -> str:
    """يزيل وسوم HTML ويفكّ الكيانات ويضغط الفراغات."""
    if not text:
        return ""
    text = _STRIP_TAGS.sub(" ", text)
    text = html.unescape(text)
    return _WS.sub(" ", text).strip()


def _localname(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def parse_iso_date(value: str | None) -> str:
    """يحوّل أي صيغة تاريخ شائعة في التغذيات إلى ISO (YYYY-MM-DD).

    يدعم RFC-822 (RSS 2.0) وISO-8601 (Atom)؛ يعيد "" عند تعذّر التحليل
    حتى لا تُخزَّن تواريخ مشوّهة في القاعدة.
    """
    if not value:
        return ""
    v = value.strip()
    # RFC-822 مثل «Wed, 26 Aug 2026 10:00:00 GMT»
    try:
        dt = parsedate_to_datetime(v)
        if dt is not None:
            return dt.date().isoformat()
    except (TypeError, ValueError, IndexError):
        pass
    # ISO-8601 مثل «2026-08-26T10:00:00Z»
    try:
        return datetime.fromisoformat(v.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        pass
    # آخر محاولة: أول 10 محارف إن كانت تاريخاً صالحاً.
    m = re.match(r"(\d{4}-\d{2}-\d{2})", v)
    if m:
        return m.group(1)
    return ""


def parse_feed(raw: str) -> list[dict]:
    """يحلّل RSS 2.0 أو Atom ويعيد عناصر (title, link, summary, date)."""
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return []
    items: list[dict] = []
    for node in root.iter():
        name = _localname(node.tag)
        if name not in ("item", "entry"):
            continue
        title = link = summary = pubdate = ""
        for child in node:
            cn = _localname(child.tag)
            if cn == "title" and not title:
                title = _clean(child.text or "".join(child.itertext()))
            elif cn == "link" and not link:
                link = (child.get("href") or child.text or "").strip()
            elif cn in ("description", "summary", "content") and not summary:
                summary = _clean(child.text or "".join(child.itertext()))
            elif cn in ("pubdate", "published", "updated", "date") and not pubdate:
                pubdate = (child.text or "").strip()
        if title and link:
            items.append({"title": title, "link": link, "summary": summary,
                          "date": parse_iso_date(pubdate)})
    return items


def _feed_text(url: str) -> str:
    """يجلب محتوى التغذية عبر عميل HTTP مع تخزين مؤقّت."""
    return get_text(url, ttl=1800, min_interval=1.0)


def ingest_rss(conn, *, feeds: list[tuple] | None = None, maxrecords: int = 40,
               dry_run: bool = False) -> dict:
    """يستورد عناصر تغذيات RSS/Atom ويُدرجها كبلاغات مصنّفة ومنزوعة التكرار."""
    feeds = feeds or RSS_FEEDS
    fetched = inserted = skipped = merged = errors = 0

    for key, name, url, ref_cat, ref_sev in feeds:
        src = conn.execute("SELECT id FROM sources WHERE key = ?", (key,)).fetchone()
        source_id = src["id"] if src else None
        try:
            raw = _feed_text(url)
            items = parse_feed(raw)[:maxrecords]
        except Exception:  # noqa: BLE001 — تغذية معطّلة لا تُفشل البقية
            errors += 1
            db.log_ingest(conn, key, 0, 0, 0, status="error", note="فشل جلب التغذية")
            continue

        for it in items:
            fetched += 1
            ext_id = f"rss:{it['link']}"
            if db.report_exists(conn, ext_id):
                skipped += 1
                continue

            text = f"{it['title']} {it['summary']}"
            auto_cat, severity, confidence = classify(text)
            # نُرجّح المجال المرجعي للتغذية عند غياب إشارات واضحة.
            category = auto_cat if confidence > 0 else ref_cat
            if severity == "medium" and ref_sev == "high":
                severity = ref_sev
            country, code, lat, lng = _guess_country(text)
            reported = it["date"] or date.today().isoformat()

            dedup_key = db.compute_dedup_key(it["title"], category, country, None)
            existing = db.find_duplicate(conn, dedup_key)
            if existing:
                # الحدث نفسه من مصدر آخر: نضمّ المصدر بدل إنشاء بلاغ مكرّر.
                if not dry_run:
                    db.attach_source(conn, existing, name, it["link"], ext_id)
                merged += 1
                continue

            if dry_run:
                inserted += 1
                continue

            db.insert_report(conn, {
                "title": it["title"][:240],
                "category": category,
                "severity": severity,
                "status": "new",
                "country": country,
                "country_code": code,
                "region": None,
                "lat": lat,
                "lng": lng,
                "occurred_on": None,
                "reported_on": reported,
                "summary": (it["summary"][:400] or it["title"][:200]),
                "details": (f"بلاغ مرصود آلياً من تغذية «{name}» ويتطلّب مراجعة بشرية "
                            f"قبل التوثيق. درجة ثقة التصنيف الآلي: {confidence}/3."),
                "source_name": name,
                "source_url": it["link"],
                "source_id": source_id,
                "external_id": ext_id,
                "verified": 0,
            })
            inserted += 1

        db.log_ingest(conn, key, len(items), inserted, skipped)

    return {"source": "rss", "fetched": fetched, "inserted": inserted,
            "skipped": skipped, "merged": merged, "errors": errors}
