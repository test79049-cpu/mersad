"""واجهة سطر أوامر لإدارة المنصة: التهيئة، الاستيراد، والإحصاءات.

الاستخدام:
    python -m app.cli init [--force]
    python -m app.cli stats
    python -m app.cli refresh [--news] [--max N]
    python -m app.cli entities [--kind KIND] [--limit N]
    python -m app.cli ingest-gdelt [--query "..."] [--category KEY] [--max N] [--dry-run]
    python -m app.cli enrich-wikidata [--limit N]
"""

import argparse
import json
import sys

from . import db, importers, refresh as refresh_mod, sources_registry


def cmd_init(args) -> int:
    db.init_db(force=args.force)
    conn = db.connect()
    st = db.stats(conn)
    conn.close()
    print(f"تمت التهيئة. عدد البلاغات: {st['total']}، المصادر: {st['country_count']} دولة.")
    return 0


def cmd_stats(_args) -> int:
    conn = db.connect()
    st = db.stats(conn)
    conn.close()
    print(json.dumps(st, ensure_ascii=False, indent=2))
    return 0


def cmd_ingest_gdelt(args) -> int:
    conn = db.connect()
    try:
        result = importers.ingest_gdelt(
            conn, query=args.query, category=args.category,
            maxrecords=args.max, dry_run=args.dry_run)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("inserted", 0) or args.dry_run else 1


def cmd_enrich_wikidata(args) -> int:
    conn = db.connect()
    try:
        result = importers.enrich_report_entities(conn, limit=args.limit)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_ingest_gdelt_raw(args) -> int:
    from . import gdelt_raw
    conn = db.connect()
    try:
        result = gdelt_raw.ingest_gdelt_raw(
            conn, days=args.days, step_windows=args.step, windows=args.windows,
            maxrecords=args.max, dry_run=args.dry_run)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("inserted", 0) or args.dry_run else 1


def cmd_ingest_rss(args) -> int:
    from . import rss_feeds
    conn = db.connect()
    try:
        result = rss_feeds.ingest_rss(conn, maxrecords=args.max, dry_run=args.dry_run)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("inserted", 0) or args.dry_run else 1


def cmd_dedup(args) -> int:
    conn = db.connect()
    try:
        fixed_dates = db.repair_bad_dates(conn)
        backfilled = db.backfill_dedup_keys(conn)
        result = db.deduplicate_reports(conn)
    finally:
        conn.close()
    print(json.dumps({"fixed_dates": fixed_dates, "backfilled": backfilled, **result},
                     ensure_ascii=False, indent=2))
    return 0


def cmd_refresh(args) -> int:
    conn = db.connect()
    try:
        result = refresh_mod.refresh(conn, pull_news=args.news, max_records=args.max)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_entities(args) -> int:
    conn = db.connect()
    try:
        items = db.entities_summary(conn, kind=args.kind, limit=args.limit)
        counts = db.entity_counts(conn)
    finally:
        conn.close()
    print(json.dumps({"counts": counts, "items": items}, ensure_ascii=False, indent=2))
    return 0


def cmd_sources(args) -> int:
    print(json.dumps(sources_registry.stats(), ensure_ascii=False, indent=2))
    return 0


def cmd_discover(args) -> int:
    from . import discovery
    conn = db.connect()
    try:
        if args.due:
            report = discovery.maybe_discover(conn)
            if report is None:
                print(json.dumps({"skipped": "لم يحن وقت الاكتشاف بعد"},
                                 ensure_ascii=False, indent=2))
                return 0
        else:
            report = discovery.discover(conn, limit=args.limit, dry_run=args.dry_run)
        report["health"] = db.catalog_health(conn)
        report["discovered_total"] = db.discovered_count(conn)
    finally:
        conn.close()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def cmd_monitor(args) -> int:
    """يشغّل دورة منظومة الرصد (جمع مستحق → معالجة → تحقق → مصالحة)."""
    from . import monitoring
    conn = db.connect()
    try:
        if args.task:
            result = monitoring.run_now(conn, args.task)
        else:
            result = monitoring.monitor_tick(conn, backfill_sources=args.backfill)
        result["status"] = monitoring.status(conn)["metrics"]
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_verify(args) -> int:
    """يشغّل دورة تحقق فورية على دفعة من السجلات المستحقة."""
    from . import monitoring
    conn = db.connect()
    try:
        result = monitoring.verify_cycle(conn, limit=args.limit)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_process(args) -> int:
    """يفرّغ طابور المعالجة (تطبيع/استخراج/تصنيف/كشف تكرار)."""
    from . import monitoring
    conn = db.connect()
    try:
        result = monitoring.process_cycle(conn, limit=args.limit)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_backfill(args) -> int:
    """استيراد تاريخي/أرشيفي قابل للاستئناف."""
    from . import backfill
    conn = db.connect()
    try:
        if args.source:
            row = conn.execute("SELECT * FROM source_catalog WHERE key = ?",
                               (args.source,)).fetchone()
            if not row:
                print(json.dumps({"error": f"مصدر غير موجود: {args.source}"},
                                 ensure_ascii=False, indent=2))
                return 1
            result = backfill.backfill_source(conn, dict(row), batch_items=args.batch)
        else:
            result = backfill.backfill_batch(conn, sources=args.sources,
                                             batch_items=args.batch)
        result["archive"] = backfill.archive_report(conn)["by_status"]
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_archive(args) -> int:
    """يعرض تقدّم الاستيراد التاريخي/الأرشيفي."""
    from . import backfill
    conn = db.connect()
    try:
        result = backfill.archive_report(conn)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_catalog(args) -> int:
    from . import catalog
    if args.write:
        result = catalog.write_catalog()
    else:
        entries = catalog.build_catalog()
        by_kind: dict[str, int] = {}
        for e in entries:
            by_kind[e["kind"]] = by_kind.get(e["kind"], 0) + 1
        result = {"total": len(entries), "by_kind": by_kind}
    if args.sync:
        conn = db.connect()
        try:
            result["synced"] = db.sync_catalog(conn, catalog.load_catalog())
        finally:
            conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def cmd_harvest(args) -> int:
    from . import harvest
    conn = db.connect()
    try:
        if args.sources:
            result = harvest.harvest_many(conn, sources=args.sources,
                                          per_source=args.max, dry_run=args.dry_run)
        else:
            result = harvest.harvest_batch(conn, batch=args.batch, per_source=args.max,
                                           dry_run=args.dry_run)
        result["health"] = db.catalog_health(conn)
    finally:
        conn.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="mirsad", description="أدوات منصة مِرصد")
    sub = p.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="تهيئة قاعدة البيانات")
    p_init.add_argument("--force", action="store_true", help="حذف القاعدة وإعادة البناء")
    p_init.set_defaults(func=cmd_init)

    p_stats = sub.add_parser("stats", help="طباعة الإحصاءات")
    p_stats.set_defaults(func=cmd_stats)

    p_gdelt = sub.add_parser("ingest-gdelt", help="استيراد عناوين من GDELT")
    p_gdelt.add_argument("--query", help="استعلام مخصّص (بدل الاستعلامات الافتراضية)")
    p_gdelt.add_argument("--category", help="فرض مجال على كل السجلات المستوردة")
    p_gdelt.add_argument("--max", type=int, default=25, help="أقصى عدد لكل استعلام")
    p_gdelt.add_argument("--dry-run", action="store_true", help="عرض دون حفظ")
    p_gdelt.set_defaults(func=cmd_ingest_gdelt)

    p_gdelt_raw = sub.add_parser("ingest-gdelt-raw",
                                 help="استيراد أحداث عنفية من ملفات GDELT الخام")
    p_gdelt_raw.add_argument("--days", type=int, default=30,
                             help="نطاق الأيام للعيّنة الزمنية (افتراضي 30)")
    p_gdelt_raw.add_argument("--step", type=int, default=12,
                             help="خطوة أخذ العيّنات بالنوافذ (كل 15 دقيقة)")
    p_gdelt_raw.add_argument("--windows", type=int,
                             help="بدلاً من ذلك: عدد نوافذ متتالية حديثة")
    p_gdelt_raw.add_argument("--max", type=int, default=2000,
                             help="أقصى عدد أحداث لكل نافذة")
    p_gdelt_raw.add_argument("--dry-run", action="store_true", help="عرض دون حفظ")
    p_gdelt_raw.set_defaults(func=cmd_ingest_gdelt_raw)

    p_wd = sub.add_parser("enrich-wikidata", help="إثراء الكيانات بمعرّفات ويكيداتا")
    p_wd.add_argument("--limit", type=int, default=20)
    p_wd.set_defaults(func=cmd_enrich_wikidata)

    p_rss = sub.add_parser("ingest-rss", help="استيراد بلاغات من تغذيات RSS الموثوقة")
    p_rss.add_argument("--max", type=int, default=40, help="أقصى عدد عناصر لكل تغذية")
    p_rss.add_argument("--dry-run", action="store_true", help="عرض دون حفظ")
    p_rss.set_defaults(func=cmd_ingest_rss)

    p_dedup = sub.add_parser("dedup", help="دمج البلاغات المكرّرة وتعبئة بصمات منع التكرار")
    p_dedup.set_defaults(func=cmd_dedup)

    p_ref = sub.add_parser("refresh", help="تشغيل دورة تحديث دورية واحدة")
    p_ref.add_argument("--news", action="store_true", help="اسحب أيضاً دفعة إخبارية (GDELT)")
    p_ref.add_argument("--max", type=int, default=12, help="أقصى عدد أخبار لكل دورة")
    p_ref.set_defaults(func=cmd_refresh)

    p_ent = sub.add_parser("entities", help="عرض ملخّص الكيانات")
    p_ent.add_argument("--kind", help="نوع الكيان (company/person/organization/country/government)")
    p_ent.add_argument("--limit", type=int, default=50)
    p_ent.set_defaults(func=cmd_entities)

    p_src = sub.add_parser("sources", help="ملخّص سجل المصادر المفتوحة")
    p_src.set_defaults(func=cmd_sources)

    p_cat = sub.add_parser("catalog", help="توليد/مزامنة فهرس المصادر الواسع (≈1000 مصدر)")
    p_cat.add_argument("--write", action="store_true", help="اكتب الفهرس إلى JSON")
    p_cat.add_argument("--sync", action="store_true", help="زامن الفهرس إلى قاعدة البيانات")
    p_cat.set_defaults(func=cmd_catalog)

    p_harv = sub.add_parser("harvest", help="جمع آلي من فهرس المصادر (دفعة أو عدة مصادر)")
    p_harv.add_argument("--batch", type=int, default=12, help="عدد المصادر في الدفعة")
    p_harv.add_argument("--sources", type=int, default=0,
                        help="شغّل حتى استيفاء هذا العدد من المصادر (بدل دفعة واحدة)")
    p_harv.add_argument("--max", type=int, default=12, help="أقصى عناصر لكل مصدر")
    p_harv.add_argument("--dry-run", action="store_true", help="عرض دون حفظ")
    p_harv.set_defaults(func=cmd_harvest)

    p_disc = sub.add_parser("discover",
                            help="اكتشاف مصادر جديدة (مواقع/قواعد بيانات/تسريبات) وإضافتها")
    p_disc.add_argument("--limit", type=int, help="أقصى عدد مرشّحين لفحصهم")
    p_disc.add_argument("--dry-run", action="store_true", help="عرض دون إضافة")
    p_disc.add_argument("--due", action="store_true",
                        help="شغّل فقط إن حان وقت الدورة الدورية")
    p_disc.set_defaults(func=cmd_discover)

    p_mon = sub.add_parser("monitor",
                           help="دورة منظومة الرصد (جمع/معالجة/تحقق/مصالحة)")
    p_mon.add_argument("--task", choices=["collect", "process", "verify", "reconcile"],
                       help="تشغيل مهمّة محدّدة فورًا بدل الدورة الموحّدة")
    p_mon.add_argument("--backfill", type=int, default=0,
                       help="عدد المصادر للاستيراد التاريخي في هذه الدورة")
    p_mon.set_defaults(func=cmd_monitor)

    p_ver = sub.add_parser("verify", help="دورة تحقق فورية على دفعة من السجلات")
    p_ver.add_argument("--limit", type=int, default=30, help="أقصى عدد سجلات")
    p_ver.set_defaults(func=cmd_verify)

    p_proc = sub.add_parser("process", help="تفريغ طابور المعالجة")
    p_proc.add_argument("--limit", type=int, default=25, help="أقصى عدد مستندات")
    p_proc.set_defaults(func=cmd_process)

    p_bf = sub.add_parser("backfill", help="استيراد تاريخي/أرشيفي قابل للاستئناف")
    p_bf.add_argument("--source", help="مفتاح مصدر محدّد")
    p_bf.add_argument("--sources", type=int, default=4, help="عدد المصادر في الدفعة")
    p_bf.add_argument("--batch", type=int, default=40, help="عدد العناصر لكل دفعة")
    p_bf.set_defaults(func=cmd_backfill)

    p_arch = sub.add_parser("archive", help="تقدّم الاستيراد التاريخي/الأرشيفي")
    p_arch.set_defaults(func=cmd_archive)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
