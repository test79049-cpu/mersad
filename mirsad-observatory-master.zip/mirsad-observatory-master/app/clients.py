"""عميل HTTP بسيط: تخزين مؤقّت على القرص، مهلة زمنية، تقييد معدّل، وإعادة محاولة.

مبني على المكتبة القياسية فقط (urllib) لتقليل الاعتماديات. يحترم سياسات
المصادر المفتوحة (User-Agent معرَّف، مهلة، فاصل زمني بين الطلبات، وإعادة
محاولة مع تراجع أسّي عند 429 وأخطاء الخادم).
"""

import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from .config import HTTP_TIMEOUT, USER_AGENT

CACHE_DIR = Path(__file__).resolve().parent.parent / "data" / "cache"
CACHE_TTL = 3600  # ثانية
RETRYABLE_STATUS = {429, 500, 502, 503, 504}

_last_request: dict[str, float] = {}


def _cache_path(url: str) -> Path:
    key = hashlib.sha256(url.encode("utf-8")).hexdigest()[:24]
    return CACHE_DIR / f"{key}.json"


def _read_cache(path: Path, ttl: int):
    if not path.exists():
        return None
    try:
        blob = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if time.time() - blob.get("ts", 0) >= ttl:
        return None
    return blob.get("data")


def _write_cache(path: Path, data) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"ts": time.time(), "data": data}, ensure_ascii=False),
                    encoding="utf-8")


def _fetch(url: str, min_interval: float, retries: int) -> str:
    host = urllib.parse.urlparse(url).netloc
    req = urllib.request.Request(url, headers={
        "User-Agent": USER_AGENT,
        "Accept": "application/json,text/csv,text/plain,*/*",
    })
    last_exc: Exception | None = None
    for attempt in range(retries + 1):
        if min_interval > 0:
            elapsed = time.time() - _last_request.get(host, 0.0)
            if elapsed < min_interval:
                time.sleep(min_interval - elapsed)
        try:
            with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            _last_request[host] = time.time()
            return raw
        except urllib.error.HTTPError as exc:
            last_exc = exc
            _last_request[host] = time.time()
            if exc.code not in RETRYABLE_STATUS or attempt == retries:
                raise RuntimeError(f"تعذّر جلب {url}: {exc}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            last_exc = exc
            _last_request[host] = time.time()
            if attempt == retries:
                raise RuntimeError(f"تعذّر جلب {url}: {exc}") from exc
        # تراجع أسّي: 1، 2، 4… ثوانٍ مع سقف 30 ثانية
        time.sleep(min(2 ** attempt, 30))
    raise RuntimeError(f"تعذّر جلب {url}: {last_exc}")


def get_text(url: str, *, params: dict | None = None, ttl: int = CACHE_TTL,
             min_interval: float = 0.0, use_cache: bool = True,
             validator=None, retries: int = 2) -> str:
    """يجلب نصاً خاماً (CSV مثلاً) مع التخزين والتقييد وإعادة المحاولة.

    `validator` دالة اختيارية ترفع RuntimeError إن كانت الاستجابة غير صالحة،
    فلا تُخزَّن الاستجابات الخاطئة مؤقتاً.
    """
    if params:
        url = url + "?" + urllib.parse.urlencode(params)

    path = _cache_path(url).with_suffix(".txt")
    if use_cache:
        cached = _read_cache(path, ttl)
        if cached is not None:
            return cached

    raw = _fetch(url, min_interval, retries)

    if validator is not None:
        validator(raw)  # يرفع RuntimeError إن كانت الاستجابة غير صالحة

    _write_cache(path, raw)
    return raw


def get_json(url: str, *, params: dict | None = None, ttl: int = CACHE_TTL,
             min_interval: float = 0.0, use_cache: bool = True,
             retries: int = 2) -> dict | list:
    """يجلب JSON مع تخزين مؤقّت وتقييد معدّل وإعادة محاولة. يرفع RuntimeError عند الفشل."""
    if params:
        url = url + "?" + urllib.parse.urlencode(params)

    path = _cache_path(url)
    if use_cache:
        cached = _read_cache(path, ttl)
        if cached is not None:
            return cached

    raw = _fetch(url, min_interval, retries)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"استجابة غير صالحة من {url}: {raw[:120]}") from exc

    _write_cache(path, data)
    return data
