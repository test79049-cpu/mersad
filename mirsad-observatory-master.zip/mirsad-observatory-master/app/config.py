"""إعدادات المنصة، تُقرأ من متغيّرات البيئة مع قيم افتراضية معقولة."""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = os.getenv("MIRSAD_DB", str(BASE_DIR.parent / "data" / "violations.db"))

# حجم الصفحة في السجل
PAGE_SIZE = int(os.getenv("MIRSAD_PAGE_SIZE", "9"))

# مصادر خارجية مفتوحة
USER_AGENT = os.getenv(
    "MIRSAD_UA",
    "Mirsad-Observatory/1.0 (+https://example.org; open-data aggregator)",
)
HTTP_TIMEOUT = float(os.getenv("MIRSAD_HTTP_TIMEOUT", "20"))
GDELT_BASE = "https://api.gdeltproject.org/api/v2/doc/doc"
WIKIDATA_API = "https://www.wikidata.org/w/api.php"

# الحد الأقصى لعدد السجلات في استجابة API واحد
API_MAX_LIMIT = int(os.getenv("MIRSAD_API_MAX_LIMIT", "200"))


def clamp_limit(value: int, default: int = API_MAX_LIMIT,
                maximum: int = API_MAX_LIMIT) -> int:
    """يُقصّ `limit` الوارد من المستخدم إلى نطاق آمن [1, maximum].

    يمنع تجاوز حدّ الاستجابة عبر قيم سالبة (LIMIT -1 في SQLite = بلا حدّ)
    أو صفرية، ويقيّد القيم الضخمة. القيم غير الصحيحة تعود إلى `default`.
    """
    try:
        n = int(value)
    except (TypeError, ValueError):
        return max(1, min(int(default), int(maximum)))
    return max(1, min(n, int(maximum)))


# مفتاح اختياري لحماية نقاط الاستيراد. إن كان فارغاً تبقى مفتوحة (بيئة تطوير).
INGEST_KEY = os.getenv("MIRSAD_INGEST_KEY", "")

# مفتاح اختياري لصلاحية إدارية عبر ترويسة X-Admin-Key. عند ضبطه تتطلّب نقاط
# /api/admin/* هذا المفتاح؛ وإلا تُقبل هوية مشرف نشطة (بيئة تطوير).
ADMIN_KEY = os.getenv("MIRSAD_ADMIN_KEY", "")

# وضع الملفات الحسّاسة: تجريبي/محاكى حصراً. لا رفع حقيقي ولا تشفير فعلي.
# ثبّته على 0 لتعطيل كل مسارات الملفات الحسّاسة نهائياً.
SENSITIVE_MODE = os.getenv("MIRSAD_SENSITIVE_MODE", "1") == "1"

# عنوان الموقع العام للاستشهادات وsitemap/robots. يُفضّل ضبطه في الإنتاج
# لتثبيت الروابط حتى عند الوصول عبر وسيط عكسي (proxy).
PUBLIC_BASE_URL = os.getenv("MIRSAD_PUBLIC_URL", "").rstrip("/")

# ---------------------------------------------------------------------------
# المصادقة (تسجيل الدخول/الإنشاء) عبر Google ومزوّدي التواصل الاجتماعي.
# ---------------------------------------------------------------------------
# مفتاح توقيع كوكي الجلسة. يُضبط في الإنتاج؛ وإلا يُشتقّ مؤقّتًا (غير آمن للإنتاج).
SECRET_KEY = os.getenv("MIRSAD_SECRET_KEY", "mirsad-dev-secret-change-me")
# عمر الجلسة بالأيام.
SESSION_DAYS = int(os.getenv("MIRSAD_SESSION_DAYS", "30"))

# سجل مزوّدي OAuth. كل مزوّد يُفعَّل تلقائيًا عند ضبط معرّف عميله (client id).
# عند غياب الإعداد يعمل المزوّد في «الوضع التجريبي» المحلي لإتاحة التجربة بلا شبكة.
OAUTH_PROVIDERS: dict[str, dict] = {
    "google": {
        "name_ar": "جوجل", "name_en": "Google", "icon": "google", "color": "#4285f4",
        "authorize": "https://accounts.google.com/o/oauth2/v2/auth",
        "token": "https://oauth2.googleapis.com/token",
        "userinfo": "https://openidconnect.googleapis.com/v1/userinfo",
        "scope": "openid email profile",
        "client_id_env": "MIRSAD_GOOGLE_CLIENT_ID",
        "client_secret_env": "MIRSAD_GOOGLE_CLIENT_SECRET",
        "email_key": "email", "name_key": "name", "avatar_key": "picture",
        "id_key": "sub",
    },
    "github": {
        "name_ar": "جيت هَب", "name_en": "GitHub", "icon": "github", "color": "#8b949e",
        "authorize": "https://github.com/login/oauth/authorize",
        "token": "https://github.com/login/oauth/access_token",
        "userinfo": "https://api.github.com/user",
        "scope": "read:user user:email",
        "client_id_env": "MIRSAD_GITHUB_CLIENT_ID",
        "client_secret_env": "MIRSAD_GITHUB_CLIENT_SECRET",
        "email_key": "email", "name_key": "name", "avatar_key": "avatar_url",
        "id_key": "id",
    },
    "facebook": {
        "name_ar": "فيسبوك", "name_en": "Facebook", "icon": "facebook", "color": "#1877f2",
        "authorize": "https://www.facebook.com/v19.0/dialog/oauth",
        "token": "https://graph.facebook.com/v19.0/oauth/access_token",
        "userinfo": "https://graph.facebook.com/me?fields=id,name,email,picture",
        "scope": "email public_profile",
        "client_id_env": "MIRSAD_FACEBOOK_CLIENT_ID",
        "client_secret_env": "MIRSAD_FACEBOOK_CLIENT_SECRET",
        "email_key": "email", "name_key": "name", "avatar_key": "picture",
        "id_key": "id",
    },
    "x": {
        "name_ar": "إكس (تويتر)", "name_en": "X (Twitter)", "icon": "x", "color": "#e7e9ea",
        "authorize": "https://twitter.com/i/oauth2/authorize",
        "token": "https://api.twitter.com/2/oauth2/token",
        "userinfo": "https://api.twitter.com/2/users/me?user.fields=profile_image_url",
        "scope": "users.read tweet.read",
        "client_id_env": "MIRSAD_X_CLIENT_ID",
        "client_secret_env": "MIRSAD_X_CLIENT_SECRET",
        "email_key": "email", "name_key": "name", "avatar_key": "profile_image_url",
        "id_key": "id",
    },
    "linkedin": {
        "name_ar": "لينكدإن", "name_en": "LinkedIn", "icon": "linkedin", "color": "#0a66c2",
        "authorize": "https://www.linkedin.com/oauth/v2/authorization",
        "token": "https://www.linkedin.com/oauth/v2/accessToken",
        "userinfo": "https://api.linkedin.com/v2/userinfo",
        "scope": "openid email profile",
        "client_id_env": "MIRSAD_LINKEDIN_CLIENT_ID",
        "client_secret_env": "MIRSAD_LINKEDIN_CLIENT_SECRET",
        "email_key": "email", "name_key": "name", "avatar_key": "picture",
        "id_key": "sub",
    },
}


def provider_client_id(provider: str) -> str:
    meta = OAUTH_PROVIDERS.get(provider)
    return os.getenv(meta["client_id_env"], "") if meta else ""


def provider_client_secret(provider: str) -> str:
    meta = OAUTH_PROVIDERS.get(provider)
    return os.getenv(meta["client_secret_env"], "") if meta else ""


def provider_configured(provider: str) -> bool:
    """مزوّد مُهيّأ فعليًّا (ضُبط معرّف عميله)."""
    return bool(provider_client_id(provider) and provider_client_secret(provider))


# تبرّعات: بوابة الدفع اختيارية. عند غياب الإعداد يعمل الموقع في الوضع التجريبي.
DONATION_URL = os.getenv("MIRSAD_DONATION_URL", "https://www.buymeacoffee.com/")
DONATION_MODE = os.getenv("MIRSAD_DONATION_MODE", "demo")  # demo | live

