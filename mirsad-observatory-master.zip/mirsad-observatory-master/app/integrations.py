"""التكامل والأتمتة (الدفعة 12).

مفاتيح API محدودة الصلاحيات والمعدّل، Webhooks موقّعة (HMAC) مع سجل تسليم وإعادة محاولة،
موصلات تجريبية، قواعد أتمتة مرئية (مُشغّل/شروط/إجراءات)، طابور مهام وعمّال،
وتقارير صحّة. كل التكاملات الخارجية **محاكاة** بلا شبكة أو بيانات حقيقية.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import sqlite3
from typing import Any

from .taxonomy import (
    CONNECTOR_KIND_BY_KEY,
    JOB_STATE_BY_KEY,
    RULE_ACTION_BY_KEY,
    RULE_TRIGGER_BY_KEY,
    WEBHOOK_EVENT_BY_KEY,
)

MAX_JOB_ATTEMPTS = 3
DANGEROUS_ACTIONS = {"webhook"}


def seed_integrations(conn: sqlite3.Connection) -> None:
    """بيانات تكامل تجريبية (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM api_keys").fetchone()["n"]:
        return
    keys = [
        ("مفتاح قراءة عامّ", "mrsd_pub", "read", 120, "v1"),
        ("مفتاح تحرير", "mrsd_ed", "read,write", 60, "v1"),
        ("مفتاح استيراد", "mrsd_ing", "read,ingest", 30, "v2"),
        ("مفتاح مهمل", "mrsd_old", "read", 10, "v0"),
    ]
    for name, prefix, scopes, rate, ver in keys:
        conn.execute(
            """INSERT INTO api_keys(name, prefix, scopes, rate_limit, version, is_seed)
               VALUES (?,?,?,?,?,1)""", (name, prefix, scopes, rate, ver))
    hooks = [
        ("تنبيه الفريق", "https://hooks.example.org/mirsad", "report.created,security.alert"),
        ("مزامنة CRM", "https://crm.example.net/mirsad-hook", "campaign.signed"),
        ("بوت تلغرام", "https://api.telegram.example/bot", "moderation.action,security.alert"),
    ]
    for name, url, events in hooks:
        conn.execute(
            "INSERT INTO webhooks(name, url, secret, events, is_seed) VALUES (?,?,?,?,1)",
            (name, url, "whsec_demo_secret", events))
    connectors = [
        ("facts", "منصّة تحقّق مفتوحة", "demo"), ("archive", "أرشيف الويب", "demo"),
        ("conflict", "قاعدة بيانات النزاعات", "demo"), ("satellite", "صور الأقمار", "demo"),
        ("weather", "بيانات الطقس", "demo"), ("translation", "خدمة الترجمة", "demo"),
        ("ocr", "خدمة OCR", "demo"), ("mediacheck", "كشف التلاعب", "demo"),
        ("aicheck", "كشف المحتوى المولّد", "demo"),
    ]
    for kind, name, status in connectors:
        conn.execute(
            "INSERT INTO connectors(kind, name, status, mode, is_seed) VALUES (?,?,?, 'simulated', 1)",
            (kind, name, status))
    rules = [
        ("تنبيه الخطورة الحرجة", "severity.critical", "severity == critical", "notify,assign", 1, 0),
        ("وسم الادّعاءات غير الموثّقة", "claim.unverified", "verified == 0", "tag", 1, 0),
        ("تذكير يومي للمنسّقين", "schedule.daily", "", "notify", 1, 0),
        ("ربط webhook بالإشراف", "report.created", "moderation == 1", "webhook", 1, 1),
    ]
    for name, trig, cond, acts, enabled, danger in rules:
        conn.execute(
            """INSERT INTO automation_rules(name, trigger, conditions, actions, enabled, dangerous, is_seed)
               VALUES (?,?,?,?,?,?,1)""", (name, trig, cond, acts, enabled, danger))
    jobs = [
        ("reindex", "{}", "queued", 3), ("gdelt_pull", "{}", "queued", 5),
        ("webhook_retry", "{}", "running", 4), ("digest_email", "{}", "done", 6),
        ("wayback_snapshot", "{}", "failed", 7),
    ]
    for kind, payload, state, prio in jobs:
        conn.execute(
            "INSERT INTO jobs(kind, payload, state, priority, is_seed) VALUES (?,?,?,?,1)",
            (kind, payload, state, prio))
    for name, status, done in [("worker-1", "idle", 42), ("worker-2", "busy", 17)]:
        conn.execute(
            "INSERT INTO workers(name, status, jobs_done, is_seed) VALUES (?,?,?,1)",
            (name, status, done))
    conn.commit()


# ---------------------------------------------------------------------------
# مفاتيح API
# ---------------------------------------------------------------------------

def query_api_keys(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM api_keys ORDER BY id").fetchall()]


def key_has_scope(conn: sqlite3.Connection, prefix: str, scope: str) -> bool:
    r = conn.execute(
        "SELECT scopes, active, version FROM api_keys WHERE prefix=?", (prefix,)).fetchone()
    if not r or not r["active"]:
        return False
    if r["version"] == "v0":
        return False  # إصدار مهمل
    return scope in (r["scopes"] or "").split(",")


def record_api_usage(conn: sqlite3.Connection, prefix: str, n: int = 1) -> int:
    """تسجيل استخدام المفتاح يوميًّا وإرجاع العدد التراكمي."""
    row = conn.execute("SELECT id FROM api_keys WHERE prefix=?", (prefix,)).fetchone()
    if not row:
        return 0
    conn.execute(
        """INSERT INTO api_usage(api_key_id, day, count) VALUES (?, date('now'), ?)
           ON CONFLICT(api_key_id, day) DO UPDATE SET count = count + ?""",
        (row["id"], n, n))
    conn.execute("UPDATE api_keys SET last_used=datetime('now') WHERE id=?", (row["id"],))
    conn.commit()
    return conn.execute(
        "SELECT count FROM api_usage WHERE api_key_id=? AND day=date('now')",
        (row["id"],)).fetchone()["count"]


def within_rate_limit(conn: sqlite3.Connection, prefix: str) -> bool:
    r = conn.execute("SELECT id, rate_limit FROM api_keys WHERE prefix=?", (prefix,)).fetchone()
    if not r:
        return False
    used = conn.execute(
        "SELECT count FROM api_usage WHERE api_key_id=? AND day=date('now')",
        (r["id"],)).fetchone()
    return not used or used["count"] < r["rate_limit"]


def api_usage_report(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT k.name, k.prefix, k.version, k.rate_limit, COALESCE(u.count,0) AS today
           FROM api_keys k LEFT JOIN api_usage u
             ON u.api_key_id = k.id AND u.day = date('now')
           ORDER BY today DESC""").fetchall()]


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

def sign_payload(secret: str, payload: str) -> str:
    """توقيع HMAC-SHA256 للحمولة (سجل التسليم يخزّن التوقيع للتحقّق)."""
    return "sha256=" + hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()


# الحقول التي يجوز كشفها للواجهة/الـ API (لا تتضمّن السرّ التوقيعي).
WEBHOOK_PUBLIC_FIELDS = ("id", "name", "url", "events", "active", "is_seed", "created_at")


def _all_webhooks(conn: sqlite3.Connection) -> list[dict]:
    """الصفوف الكاملة (بما فيها السرّ) للاستخدام الداخلي فقط."""
    return [dict(r) for r in conn.execute("SELECT * FROM webhooks ORDER BY id").fetchall()]


def query_webhooks(conn: sqlite3.Connection) -> list[dict]:
    """قائمة الـ webhooks بحقول عامّة فقط (بلا السرّ التوقيعي)."""
    return [{k: h.get(k) for k in WEBHOOK_PUBLIC_FIELDS} for h in _all_webhooks(conn)]


def webhook_subscribed(conn: sqlite3.Connection, hook: dict, event: str) -> bool:
    return event in (hook.get("events") or "").split(",")


def dispatch_event(conn: sqlite3.Connection, event: str, data: dict | None = None) -> list[dict]:
    """إرسال حدث لكل webhook مشترك (محاكاة: يُسجَّل التسليم موقّعًا بلا شبكة)."""
    payload = json.dumps({"event": event, "data": data or {}}, ensure_ascii=False, sort_keys=True)
    out = []
    for hook in _all_webhooks(conn):
        if not hook["active"] or not webhook_subscribed(conn, hook, event):
            continue
        sig = sign_payload(hook["secret"], payload)
        cur = conn.execute(
            """INSERT INTO webhook_deliveries(webhook_id, event, payload, signature, state)
               VALUES (?,?,?,?,'pending')""", (hook["id"], event, payload, sig))
        out.append({"delivery_id": cur.lastrowid, "webhook": hook["name"],
                    "event": event, "signature": sig})
    conn.commit()
    return out


def deliver(conn: sqlite3.Connection, delivery_id: int, *, ok: bool = True) -> bool:
    """محاكاة محاولة تسليم؛ تنجح أو تُعاد المحاولة حتى سقف المحاولات."""
    d = conn.execute("SELECT * FROM webhook_deliveries WHERE id=?", (delivery_id,)).fetchone()
    if not d:
        return False
    attempts = d["attempts"] + 1
    if ok:
        conn.execute(
            """UPDATE webhook_deliveries SET state='delivered', attempts=?,
               delivered_at=datetime('now') WHERE id=?""", (attempts, delivery_id))
    else:
        state = "failed" if attempts >= MAX_JOB_ATTEMPTS else "pending"
        conn.execute(
            "UPDATE webhook_deliveries SET state=?, attempts=? WHERE id=?",
            (state, attempts, delivery_id))
    conn.commit()
    return True


def webhook_deliveries(conn: sqlite3.Connection, webhook_id: int | None = None,
                       limit: int = 50) -> list[dict]:
    sql = """SELECT d.*, w.name AS webhook_name FROM webhook_deliveries d
             JOIN webhooks w ON w.id = d.webhook_id"""
    params: list[Any] = []
    if webhook_id:
        sql += " WHERE d.webhook_id=?"; params.append(webhook_id)
    sql += " ORDER BY d.created_at DESC, d.id DESC LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def webhook_health(conn: sqlite3.Connection) -> dict[str, Any]:
    rows = conn.execute(
        "SELECT state, COUNT(*) AS n FROM webhook_deliveries GROUP BY state").fetchall()
    by_state = {r["state"]: r["n"] for r in rows}
    total = sum(by_state.values())
    delivered = by_state.get("delivered", 0)
    return {"total": total, "by_state": by_state,
            "success_rate": round(100.0 * delivered / total, 1) if total else 100.0}


# ---------------------------------------------------------------------------
# الموصلات
# ---------------------------------------------------------------------------

def query_connectors(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM connectors ORDER BY kind").fetchall()]


def sync_connector(conn: sqlite3.Connection, connector_id: int) -> bool:
    """محاكاة مزامنة موصل (لا شبكة حقيقية)."""
    cur = conn.execute(
        "UPDATE connectors SET last_sync=datetime('now'), status='ok' WHERE id=?",
        (connector_id,))
    conn.commit()
    return cur.rowcount > 0


# ---------------------------------------------------------------------------
# قواعد الأتمتة
# ---------------------------------------------------------------------------

def query_rules(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM automation_rules ORDER BY id").fetchall()]


def rule_by_id(conn: sqlite3.Connection, rid: int) -> dict | None:
    r = conn.execute("SELECT * FROM automation_rules WHERE id=?", (rid,)).fetchone()
    return dict(r) if r else None


def validate_rule(trigger: str, actions: str) -> dict[str, Any]:
    """تحقّق من القاعدة قبل التفعيل (مُشغّل وإجراءات معروفة)."""
    errors = []
    if trigger not in RULE_TRIGGER_BY_KEY:
        errors.append("unknown_trigger")
    acts = [a for a in (actions or "").split(",") if a]
    if not acts:
        errors.append("no_actions")
    for a in acts:
        if a not in RULE_ACTION_BY_KEY:
            errors.append(f"unknown_action:{a}")
    return {"valid": not errors, "errors": errors}


def run_rule(conn: sqlite3.Connection, rid: int) -> dict[str, Any]:
    """محاكاة تنفيذ قاعدة وتسجيل النتيجة (نجاح/فشل) في سجل التنفيذ."""
    r = rule_by_id(conn, rid)
    if not r:
        return {"ok": False, "error": "not_found"}
    if not r["enabled"]:
        return {"ok": False, "error": "disabled"}
    v = validate_rule(r["trigger"], r["actions"])
    status = "ok" if v["valid"] else "failed"
    conn.execute(
        "INSERT INTO rule_runs(rule_id, status, detail) VALUES (?,?,?)",
        (rid, status, ";".join(v["errors"]) or "ran"))
    if v["valid"]:
        conn.execute(
            "UPDATE automation_rules SET run_count=run_count+1 WHERE id=?", (rid,))
    else:
        conn.execute(
            "UPDATE automation_rules SET fail_count=fail_count+1 WHERE id=?", (rid,))
    conn.commit()
    return {"ok": v["valid"], "errors": v["errors"]}


def toggle_rule(conn: sqlite3.Connection, rid: int, enabled: bool) -> bool:
    cur = conn.execute(
        "UPDATE automation_rules SET enabled=? WHERE id=?", (1 if enabled else 0, rid))
    conn.commit()
    return cur.rowcount > 0


def rule_runs(conn: sqlite3.Connection, rid: int | None = None, limit: int = 50) -> list[dict]:
    sql = "SELECT * FROM rule_runs"
    params: list[Any] = []
    if rid:
        sql += " WHERE rule_id=?"; params.append(rid)
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


# ---------------------------------------------------------------------------
# الطابور والعمّال
# ---------------------------------------------------------------------------

def query_jobs(conn: sqlite3.Connection, state: str | None = None,
               limit: int = 50) -> list[dict]:
    sql = "SELECT * FROM jobs"
    params: list[Any] = []
    if state:
        sql += " WHERE state=?"; params.append(state)
    sql += " ORDER BY priority ASC, id ASC LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def enqueue_job(conn: sqlite3.Connection, kind: str, payload: str = "{}",
                priority: int = 5) -> int:
    cur = conn.execute(
        "INSERT INTO jobs(kind, payload, state, priority) VALUES (?,?,'queued',?)",
        (kind, payload, max(1, min(priority, 9))))
    conn.commit()
    return cur.lastrowid


def queue_depth(conn: sqlite3.Connection) -> int:
    return conn.execute(
        "SELECT COUNT(*) AS n FROM jobs WHERE state IN ('queued','running')").fetchone()["n"]


def queue_congested(conn: sqlite3.Connection, threshold: int = 20) -> bool:
    return queue_depth(conn) >= threshold


def dequeue_job(conn: sqlite3.Connection, worker: str) -> dict | None:
    """سحب مهمّة ذات أولوية (الأصغر رقمًا أولًا) وإسنادها لعمّال."""
    job = conn.execute(
        "SELECT * FROM jobs WHERE state='queued' ORDER BY priority ASC, id ASC LIMIT 1"
    ).fetchone()
    if not job:
        return None
    conn.execute(
        "UPDATE jobs SET state='running', worker=?, started_at=datetime('now') WHERE id=?",
        (worker, job["id"]))
    conn.execute("UPDATE workers SET status='busy', last_seen=datetime('now') WHERE name=?",
                 (worker,))
    conn.commit()
    return dict(conn.execute("SELECT * FROM jobs WHERE id=?", (job["id"],)).fetchone())


def finish_job(conn: sqlite3.Connection, job_id: int, *, ok: bool = True) -> bool:
    j = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if not j:
        return False
    attempts = j["attempts"] + 1
    if ok:
        conn.execute(
            "UPDATE jobs SET state='done', attempts=?, finished_at=datetime('now') WHERE id=?",
            (attempts, job_id))
        if j["worker"]:
            conn.execute(
                "UPDATE workers SET status='idle', jobs_done=jobs_done+1 WHERE name=?",
                (j["worker"],))
    else:
        # إعادة للمحاولة حتى سقف المحاولات ثم فشل
        state = "failed" if attempts >= MAX_JOB_ATTEMPTS else "queued"
        conn.execute("UPDATE jobs SET state=?, attempts=? WHERE id=?", (state, attempts, job_id))
        if j["worker"]:
            conn.execute("UPDATE workers SET status='idle' WHERE name=?", (j["worker"],))
    conn.commit()
    return True


def requeue_failed(conn: sqlite3.Connection) -> int:
    cur = conn.execute(
        "UPDATE jobs SET state='queued', attempts=0 WHERE state='failed'")
    conn.commit()
    return cur.rowcount


def query_workers(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM workers ORDER BY name").fetchall()]


def set_worker(conn: sqlite3.Connection, name: str, status: str) -> bool:
    cur = conn.execute(
        "UPDATE workers SET status=?, last_seen=datetime('now') WHERE name=?", (status, name))
    conn.commit()
    return cur.rowcount > 0


def integration_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    keys = conn.execute("SELECT COUNT(*) AS n FROM api_keys").fetchone()["n"]
    hooks = conn.execute("SELECT COUNT(*) AS n FROM webhooks").fetchone()["n"]
    conns = conn.execute("SELECT COUNT(*) AS n FROM connectors").fetchone()["n"]
    rules = conn.execute(
        "SELECT COUNT(*) AS n FROM automation_rules WHERE enabled=1").fetchone()["n"]
    queued = queue_depth(conn)
    return {"api_keys": keys, "webhooks": hooks, "connectors": conns,
            "active_rules": rules, "queue_depth": queued,
            "congested": queue_congested(conn)}


def integration_health(conn: sqlite3.Connection) -> dict[str, Any]:
    """تقرير صحّة التكاملات (API/Webhooks/الطابور/القواعد)."""
    wh = webhook_health(conn)
    failed_rules = conn.execute(
        "SELECT COUNT(*) AS n FROM rule_runs WHERE status='failed'").fetchone()["n"]
    failed_jobs = conn.execute(
        "SELECT COUNT(*) AS n FROM jobs WHERE state='failed'").fetchone()["n"]
    return {"api": {"keys": conn.execute("SELECT COUNT(*) AS n FROM api_keys").fetchone()["n"]},
            "webhooks": wh,
            "queue": {"depth": queue_depth(conn), "failed_jobs": failed_jobs},
            "rules": {"failed_runs": failed_rules},
            "healthy": wh["success_rate"] >= 50.0 and failed_jobs < 5}
