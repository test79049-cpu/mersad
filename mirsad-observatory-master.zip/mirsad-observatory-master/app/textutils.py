"""تطبيع النص العربي لأغراض البحث والمقارنة.

يوحّد صور الحروف المختلفة (الألف بأشكالها، التاء المربوطة، الياء) ويزيل
التشكيل والتطويل، حتى يجد البحث «اطفال» كلمة «أطفال».
"""

import re
import unicodedata

_DIACRITICS = re.compile(r"[\u0617-\u061A\u064B-\u0652\u0670\u06D6-\u06ED]")
_TATWEEL = "\u0640"
_NON_WORD = re.compile(r"[^\w\u0600-\u06FF]+", re.UNICODE)

# خرائط التوحيد
_ALEF = {"\u0622": "ا", "\u0623": "ا", "\u0625": "ا", "\u0671": "ا", "\u0672": "ا", "\u0673": "ا"}
_YEH = {"\u0649": "ي", "\u064A": "ي", "\u06CC": "ي"}
_TEH = {"\u0629": "ه"}
_WAW = {"\u0624": "و"}
_OTHER = {"\u0626": "ي"}


def normalize_arabic(text: str) -> str:
    """يطبّع النص: إزالة التشكيل والتطويل، وتوحيد الألف/الياء/التاء."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", str(text))
    text = _DIACRITICS.sub("", text)
    text = text.replace(_TATWEEL, "")
    out = []
    for ch in text:
        if ch in _ALEF:
            out.append(_ALEF[ch])
        elif ch in _YEH:
            out.append(_YEH[ch])
        elif ch in _TEH:
            out.append(_TEH[ch])
        elif ch in _WAW:
            out.append(_WAW[ch])
        elif ch in _OTHER:
            out.append(_OTHER[ch])
        else:
            out.append(ch)
    text = "".join(out)
    text = text.lower()
    return re.sub(r"\s+", " ", text).strip()


def tokenize(text: str) -> list[str]:
    """يقسّم النص إلى كلمات بعد التطبيع."""
    return [t for t in _NON_WORD.split(normalize_arabic(text)) if t]


def build_search_text(*parts: str) -> str:
    """يبني حقلاً نصياً موحّداً للفهرسة من عدّة أجزاء."""
    return normalize_arabic(" ".join(p for p in parts if p))
