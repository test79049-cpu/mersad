"""مستورد أحداث GDELT الخام (GDELT 2.0 Event Database).

عندما يكون GDELT DOC API محجوباً أو مقيَّداً، تبقى ملفات الأحداث الخام متاحة
عبر `data.gdeltproject.org` (رخصة CC BY 4.0). كل ملف يغطّي نافذة 15 دقيقة
ويحمل صفوف CAMEO الموسومة جغرافياً (رمز FIPS، إحداثيات، أطراف، رابط الخبر).

نُبقي فقط الجذور العنفية (COERCE/ASSAULT/FIGHT/MASS VIOLENCE) لأنها تمثّل
انتهاكات محتملة لحقوق الإنسان، مع وسمها كبلاغات غير موثّقة تتطلّب مراجعة بشرية.
"""

from __future__ import annotations

import csv
import io
import json
import urllib.request
import zipfile
from datetime import date
from functools import lru_cache
from pathlib import Path

from . import db
from .clients import CACHE_DIR
from .config import USER_AGENT
from .countries import arabic_name, coords, iso3

LASTUPDATE_URL = "http://data.gdeltproject.org/gdeltv2/lastupdate.txt"

# جذور CAMEO العنفية -> (المجال، الخطورة، التسمية العربية، التسمية الإنجليزية)
VIOLENCE_ROOTS = {
    "17": ("human_rights", "high", "إكراه", "Coercion"),
    "18": ("human_rights", "critical", "اعتداء", "Assault"),
    "19": ("human_rights", "high", "اشتباك", "Fight"),
    "20": ("human_rights", "critical", "عنف جماعي", "Mass violence"),
}

_FIPS_PATH = Path(__file__).resolve().parent / "data" / "fips_iso3.json"


@lru_cache(maxsize=1)
def _fips_iso3() -> dict[str, str]:
    """خريطة رمز FIPS (رمز GDELT الجغرافي) إلى ISO3."""
    try:
        return json.loads(_FIPS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def country_from_fips(code: str) -> str:
    """يعيد اسم الدولة العربي من رمز FIPS، أو نصاً فارغاً عند الجهل به."""
    iso3_code = _fips_iso3().get((code or "").strip().upper())
    if not iso3_code:
        return ""
    return arabic_name(iso3_code) or ""


def _download(url: str, timeout: float = 60.0) -> bytes:
    """ينزّل ملفاً ثنائياً (zip) مع تخزين مؤقّت على القرص."""
    import hashlib

    key = hashlib.sha256(url.encode("utf-8")).hexdigest()[:24]
    path = CACHE_DIR / f"{key}.bin"
    if path.exists():
        return path.read_bytes()
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        blob = resp.read()
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    path.write_bytes(blob)
    return blob


def latest_export_url() -> str:
    """يعيد رابط أحدث ملف أحداث (export) من قائمة lastupdate."""
    req = urllib.request.Request(LASTUPDATE_URL, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[2].endswith(".export.CSV.zip"):
            return parts[2]
    raise RuntimeError("لم يُعثر على رابط ملف الأحداث في lastupdate.txt")


def _stamp(url: str) -> str:
    """يستخرج الطابع الزمني (YYYYMMDDHHMMSS) من رابط ملف GDELT."""
    base = url.rsplit("/", 1)[-1]
    return base.split(".", 1)[0]


def export_urls(count: int = 1) -> list[str]:
    """يعيد روابط أحدث `count` ملفات أحداث (نافذة كل منها 15 دقيقة).

    تُشتقّ الروابط السابقة بالتنقيص 15 دقيقة من طابع أحدث ملف، لأن GDELT
    ينشر ملفاً واحداً كل ربع ساعة.
    """
    from datetime import datetime, timedelta

    latest = latest_export_url()
    stamp = _stamp(latest)
    try:
        end = datetime.strptime(stamp, "%Y%m%d%H%M%S")
    except ValueError:
        return [latest]
    urls = []
    for i in range(max(1, count)):
        ts = (end - timedelta(minutes=15 * i)).strftime("%Y%m%d%H%M%S")
        urls.append(latest.replace(stamp, ts))
    return urls


def export_urls_range(days: int = 30, step_windows: int = 12) -> list[str]:
    """يعيد روابط ملفات موزّعة على آخر `days` يوماً بخطوة `step_windows` نافذة.

    أحداث GDELT تُكرَّر كثيراً بين نوافذ 15 دقيقة المتقاربة، لذا فإن أخذ عيّنات
    متباعدة زمنياً يعطي تنوّعاً جغرافياً وموضوعياً أكبر لكل ملف منزَّل.
    """
    from datetime import datetime, timedelta

    latest = latest_export_url()
    stamp = _stamp(latest)
    try:
        end = datetime.strptime(stamp, "%Y%m%d%H%M%S")
    except ValueError:
        return [latest]
    total = max(1, days * 96)  # 96 نافذة في اليوم
    urls = []
    for i in range(0, total, max(1, step_windows)):
        ts = (end - timedelta(minutes=15 * i)).strftime("%Y%m%d%H%M%S")
        urls.append(latest.replace(stamp, ts))
    return urls


def parse_export(blob: bytes, *, maxrecords: int | None = None) -> list[dict]:
    """يحلّل ملف أحداث GDELT ويعيد الأحداث العنفية فقط."""
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        name = zf.namelist()[0]
        text = zf.read(name).decode("utf-8", errors="replace")

    events: list[dict] = []
    for line in text.splitlines():
        fields = line.split("\t")
        if len(fields) < 61:
            continue
        root = fields[28].strip()
        if root not in VIOLENCE_ROOTS:
            continue
        events.append({
            "event_id": fields[0].strip(),
            "date": fields[1].strip(),
            "root": root,
            "goldstein": fields[30].strip(),
            "mentions": fields[31].strip(),
            "actor1": fields[5].strip(),
            "actor2": fields[15].strip(),
            "location": fields[52].strip(),
            "fips": fields[53].strip(),
            "lat": fields[56].strip(),
            "lng": fields[57].strip(),
            "url": fields[60].strip(),
        })
        if maxrecords and len(events) >= maxrecords:
            break
    return events


def _fingerprint(ev: dict) -> str:
    """بصمة محتوى للحدث تمنع تكرار الحدث نفسه عبر نوافذ/ملفات GDELT.

    GDELT يعيد استخراج الحدث ذاته بمعرّفات مختلفة في ملفات متعدّدة، لذا
    نعتمد على (التاريخ، الجذر، الموقع، الرابط) بدل معرّف الحدث وحده.
    """
    import hashlib

    basis = "|".join([ev.get("date", ""), ev.get("root", ""), ev.get("fips", ""),
                      ev.get("location", ""), ev.get("url", "")])
    return hashlib.sha1(basis.encode("utf-8")).hexdigest()[:20]


def _to_float(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def ingest_gdelt_raw(conn, *, days: int = 30, step_windows: int = 12,
                     windows: int | None = None, maxrecords: int = 2000,
                     dry_run: bool = False) -> dict:
    """ينزّل عيّنة من ملفات أحداث GDELT ويدرج الأحداث العنفية الجديدة.

    إن مُرِّر `windows` صراحةً تُسحَب نوافذ متتالية حديثة؛ وإلا تُؤخذ عيّنة
    موزّعة على آخر `days` يوماً (أكثر تنوّعاً جغرافياً وموضوعياً).
    """
    src = conn.execute("SELECT id FROM sources WHERE key = 'gdelt'").fetchone()
    source_id = src["id"] if src else None

    fetched = inserted = skipped = 0
    try:
        urls = export_urls(windows) if windows else export_urls_range(days, step_windows)
    except Exception as exc:  # noqa: BLE001
        db.log_ingest(conn, "gdelt_raw", 0, 0, 0, status="error", note=str(exc)[:200])
        return {"source": "gdelt_raw", "fetched": 0, "inserted": 0, "skipped": 0,
                "error": str(exc)[:200]}

    events: list[dict] = []
    errors = 0
    for url in urls:
        try:
            events.extend(parse_export(_download(url), maxrecords=maxrecords))
        except Exception:  # noqa: BLE001 — نافذة ناقصة لا تُفشل البقية
            errors += 1

    for ev in events:
        fetched += 1
        ext_id = f"gdelt_raw:{_fingerprint(ev)}"
        if not ev["event_id"] or db.report_exists(conn, ext_id):
            skipped += 1
            continue

        category, severity, label_ar, label_en = VIOLENCE_ROOTS[ev["root"]]
        country = country_from_fips(ev["fips"])
        reported = ev["date"][:4] + "-" + ev["date"][4:6] + "-" + ev["date"][6:8] \
            if len(ev["date"]) == 8 else date.today().isoformat()
        location = ev["location"] or country or "موقع غير محدّد"

        if dry_run:
            inserted += 1
            continue

        c = coords(country) if country else None
        db.insert_report(conn, {
            "title": f"{label_ar} مرصود في {location}"[:240],
            "category": category,
            "severity": severity,
            "status": "new",
            "country": country or "غير محدّد",
            "country_code": iso3(country) if country else None,
            "region": None,
            "lat": _to_float(ev["lat"]) or (c[0] if c else None),
            "lng": _to_float(ev["lng"]) or (c[1] if c else None),
            "occurred_on": reported,
            "reported_on": reported,
            # بصمة الحدث نفسه: تمنع تكرار الحدث عبر الملفات دون دمج أحداث متمايزة
            # تشترك في صيغة العنوان المولّدة.
            "dedup_key": f"gdelt_raw:{_fingerprint(ev)}",
            "summary": (f"حدث عنفي من نوع «{label_ar}» ({label_en}) رُصد آلياً من بيانات "
                        f"GDELT الخام (CAMEO {ev['root']}) في {location}."),
            "details": ("هذا السجل مستورد آلياً من قاعدة أحداث GDELT (رخصة CC BY 4.0) "
                        "ويتطلّب مراجعة بشرية قبل التوثيق. "
                        f"الأطراف: {ev['actor1'] or '—'} / {ev['actor2'] or '—'}؛ "
                        f"عدد الإشارات الإخبارية: {ev['mentions'] or '0'}."),
            "source_name": "GDELT Project",
            "source_url": ev["url"] or None,
            "source_id": source_id,
            "external_id": ext_id,
            "verified": 0,
        })
        inserted += 1

    note = f"windows={len(urls)} errors={errors}"
    db.log_ingest(conn, "gdelt_raw", fetched, inserted, skipped, note=note)
    return {"source": "gdelt_raw", "fetched": fetched, "inserted": inserted,
            "skipped": skipped, "windows": len(urls), "errors": errors}
