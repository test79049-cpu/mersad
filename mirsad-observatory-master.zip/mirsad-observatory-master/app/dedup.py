"""كشف التكرار متعدّد المستويات (القسم 5 من المواصفات).

قبل إنشاء أي سجل، يُنفَّذ كشف تكرار على **كامل قاعدة البيانات** وليس النتائج
الحديثة وحدها، عبر أربعة مستويات:

1. **المطابقة الدقيقة**: معرّف المحتوى الأصلي، الرابط المطبَّع، البصمة الرقمية.
2. **المطابقة النصية**: تشابه العنوان/المتن بعد التطبيع (يلتقط النسخ المنقولة
   وإعادة الصياغة والترجمات).
3. **مطابقة الواقعة**: نوع الواقعة + التاريخ + الموقع + الجهات + الأدلة المشتركة.
4. **مطابقة التحديثات**: هل العنصر تقرير مكرّر، أم تحديث لواقعة معروفة، أم تصحيح،
   أم واقعة مستقلة.

قرارات النظام: تطابق مؤكد، تطابق محتمل، تحديث جوهري، واقعة جديدة، علاقة غير
محسومة. **لا يُدمج سجلان نهائيًا** عند الشك، بل يُحالان للمراجعة (تطابق محتمل).
"""

from __future__ import annotations

import hashlib
import re
import sqlite3
from dataclasses import dataclass, field

from . import db
from .textutils import normalize_arabic, tokenize

# قرارات الكشف (القسم 5).
EXACT = "exact"            # تطابق مؤكد
PROBABLE = "probable"      # تطابق محتمل (مراجعة)
UPDATE = "update"          # تحديث جوهري لواقعة معروفة
NEW = "new"                # واقعة جديدة
UNCERTAIN = "uncertain"    # علاقة غير محسومة

# عتبات التشابه (قابلة للضبط).
TITLE_EXACT = 0.92         # تشابه عنوان يُعدّ تطابقًا مؤكدًا
TITLE_PROBABLE = 0.62      # تشابه عنوان يُعدّ تطابقًا محتملًا
BODY_EXACT = 0.90
BODY_PROBABLE = 0.55
INCIDENT_PROBABLE = 0.60   # تطابق واقعة (نوع+تاريخ+موقع+جهات)
# تطابق نصّي قوي مع تطابق واقعة كافٍ لاعتباره تطابقًا مؤكدًا (تأكيد متعدّد الإشارات).
TEXTUAL_CONFIRM_INCIDENT = 0.50

_STOP = {
    "في", "من", "على", "عن", "الى", "إلى", "او", "أو", "the", "a", "an", "of",
    "in", "on", "at", "for", "and", "or", "to", "news", "report", "reports",
    "خبر", "بلاغ", "تقرير", "مرصود", "عاجل", "breaking",
}

_URL_QUERY = re.compile(r"[?#].*$")


def canonical_url(url: str | None) -> str:
    """يطبّع الرابط: يزيل المخطّط و«www» والشرطة الأخيرة ومعاملات الاستعلام."""
    if not url:
        return ""
    u = url.strip().lower()
    u = re.sub(r"^https?://", "", u)
    u = re.sub(r"^www\.", "", u)
    u = _URL_QUERY.sub("", u)
    return u.rstrip("/")


def host_of(url: str | None) -> str:
    u = canonical_url(url)
    return u.split("/", 1)[0] if u else ""


def content_digest(title: str, body: str = "") -> str:
    """بصمة رقمية دقيقة للمحتوى (تطابق حرفي بعد التطبيع)."""
    basis = normalize_arabic(f"{title or ''}\n{body or ''}")
    return hashlib.sha1(basis.encode("utf-8")).hexdigest()


def content_hash(text: str) -> str:
    """بصمة النصّ المطبَّع (تُستخدم لتجميع المرشّحين المتشابهين)."""
    toks = sorted({t for t in tokenize(text or "") if t not in _STOP})
    return hashlib.sha1(" ".join(toks).encode("utf-8")).hexdigest()


def _tokens(text: str) -> set[str]:
    return {t for t in tokenize(text or "") if t not in _STOP}


def similarity(a: str, b: str) -> float:
    """تشابه Jaccard على الكلمات بعد التطبيع (0..1).

    مناسب للعربية (بلا تجذير ثقيل): يلتقط النسخ المنقولة وإعادة الصياغة
    الجزئية، ويعمل عبر اللغات جزئيًا عند وجود أرقام/أسماء مشتركة.
    """
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    inter = len(ta & tb)
    union = len(ta | tb)
    return inter / union if union else 0.0


@dataclass
class DupResult:
    decision: str
    report_id: int | None = None
    document_id: int | None = None
    level: str = ""            # exact|textual|incident|update
    reason: str = ""
    score: float = 0.0
    # علاقة التحديث: هل العنصر تحديث/تصحيح لواقعة قائمة؟
    is_update: bool = False
    is_correction: bool = False
    tags: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {"decision": self.decision, "report_id": self.report_id,
                "document_id": self.document_id, "level": self.level,
                "reason": self.reason, "score": round(self.score, 3),
                "is_update": self.is_update, "is_correction": self.is_correction,
                "tags": self.tags}


# كلمات تدلّ على أن العنصر تحديث/تصحيح لا واقعة مستقلة.
_UPDATE_MARKERS = {"تحديث", "مستجد", "جديد", "update", "updated", "follow", "latest"}
_CORRECTION_MARKERS = {
    "تصحيح", "تصويب", "نفي", "ينفي", "تراجع", "توضيح", "اعتذار", "correction",
    "corrected", "retraction", "retracts", "denies", "denial", "clarification",
    "apology", "withdrawn", "withdraws",
}


def _has_marker(text: str, markers: set[str]) -> bool:
    toks = _tokens(text)
    return bool(toks & markers)


def detect_update(text: str) -> tuple[bool, bool]:
    """يكتشف إن كان النصّ تحديثًا و/أو تصحيحًا (المستوى الرابع)."""
    return (_has_marker(text, _UPDATE_MARKERS), _has_marker(text, _CORRECTION_MARKERS))


def build_index(conn: sqlite3.Connection) -> dict:
    """يبني فهرس مقارنة مرّة واحدة (أداء): روابط، بصمات، ومرشّحون نصّيون.

    يُبنى مرّة لكل دورة/عنصر على كامل القاعدة (لا على النتائج الحديثة فقط)،
    ثم تُقارَن العناصر الجديدة به في الذاكرة بدل مسح القاعدة لكل عنصر.
    """
    idx: dict = {
        "by_external": {}, "by_url": {}, "by_digest": {}, "by_hash": {},
        "reports": [], "hosts": {},
    }
    for r in conn.execute(
            "SELECT id, title, summary, details, external_id, source_url, country, "
            "region, category, occurred_on, reported_on, content_digest FROM reports"):
        rid = r["id"]
        ext = r["external_id"]
        if ext:
            idx["by_external"].setdefault(ext, rid)
        cu = canonical_url(r["source_url"])
        if cu:
            idx["by_url"].setdefault(cu, rid)
            idx["hosts"].setdefault(host_of(r["source_url"]), []).append(rid)
        if r["content_digest"]:
            idx["by_digest"].setdefault(r["content_digest"], rid)
        idx["reports"].append({
            "id": rid, "title": r["title"] or "",
            "text": f"{r['title'] or ''} {r['summary'] or ''} {r['details'] or ''}",
            "country": r["country"], "region": r["region"],
            "category": r["category"], "occurred_on": r["occurred_on"],
            "reported_on": r["reported_on"], "url": r["source_url"],
        })
    for s in conn.execute("SELECT report_id, source_url, external_id FROM report_sources"):
        if s["external_id"]:
            idx["by_external"].setdefault(s["external_id"], s["report_id"])
        cu = canonical_url(s["source_url"])
        if cu:
            idx["by_url"].setdefault(cu, s["report_id"])
    return idx


def _incident_score(doc: dict, rep: dict) -> tuple[float, list[str]]:
    """مطابقة الواقعة: نوع/تاريخ/موقع/جهات/أدلة مشتركة (المستوى الثالث)."""
    reasons: list[str] = []
    score = 0.0
    # نوع الواقعة (المجال)
    if doc.get("category") and rep.get("category") == doc["category"]:
        score += 0.25
        reasons.append("نفس المجال")
    # التاريخ
    d1 = (doc.get("occurred_on") or doc.get("published_on") or "")[:10]
    d2 = (rep.get("occurred_on") or rep.get("reported_on") or "")[:10]
    if d1 and d2:
        if d1 == d2:
            score += 0.25
            reasons.append("نفس تاريخ الوقوع")
        elif d1[:4] == d2[:4]:
            score += 0.08
            reasons.append("نفس السنة")
    # الموقع
    if doc.get("country") and rep.get("country") == doc["country"]:
        score += 0.20
        reasons.append("نفس الدولة")
    if doc.get("region") and rep.get("region") == doc["region"]:
        score += 0.05
    # الجهات المشتركة
    de = {normalize_arabic(e) for e in (doc.get("entities") or []) if e}
    re_ = _tokens(rep.get("title") or "")
    if de and de & re_:
        score += 0.25
        reasons.append("جهات مشتركة")
    return min(score, 1.0), reasons


def find_duplicate(conn: sqlite3.Connection, doc: dict,
                   index: dict | None = None) -> DupResult:
    """ينفّذ كشف التكرار متعدّد المستويات لعنصر واحد ويعيد القرار.

    `doc` يحمل: title, body/summary, url, external_id, content_digest,
    content_hash, category, country, region, occurred_on, published_on, entities.
    """
    idx = index if index is not None else build_index(conn)
    title = doc.get("title") or ""
    body = doc.get("body") or doc.get("summary") or ""
    text = f"{title} {body}"
    ext = doc.get("external_id")
    cu = canonical_url(doc.get("url"))
    digest = doc.get("content_digest") or content_digest(title, body)
    chash = doc.get("content_hash") or content_hash(text)
    is_update, is_correction = detect_update(text)

    # --- المستوى الأول: مطابقة دقيقة ---
    if ext and ext in idx["by_external"]:
        return DupResult(EXACT, report_id=idx["by_external"][ext], level="exact",
                         reason="تطابق معرّف المصدر الأصلي", score=1.0,
                         is_update=is_update, is_correction=is_correction)
    if cu and cu in idx["by_url"]:
        return DupResult(EXACT, report_id=idx["by_url"][cu], level="exact",
                         reason="تطابق الرابط بعد تطبيعه", score=1.0,
                         is_update=is_update, is_correction=is_correction)
    if digest in idx["by_digest"]:
        return DupResult(EXACT, report_id=idx["by_digest"][digest], level="exact",
                         reason="تطابق البصمة الرقمية للمحتوى", score=1.0,
                         is_update=is_update, is_correction=is_correction)

    # --- المستوى الثاني: مطابقة نصية ---
    best_rep = None
    best_title = best_body = 0.0
    best_incident = 0.0
    best_reasons: list[str] = []
    for rep in idx["reports"]:
        t_sim = similarity(title, rep["title"])
        b_sim = similarity(text, rep["text"])
        if t_sim > best_title:
            best_title = t_sim
            best_rep = rep
        if b_sim > best_body:
            best_body = b_sim
        if t_sim >= TITLE_PROBABLE or b_sim >= BODY_PROBABLE:
            inc, reasons = _incident_score(doc, rep)
            if inc > best_incident:
                best_incident = inc
                best_reasons = reasons

    if best_rep and best_title >= TITLE_EXACT:
        # تشابه العنوان وحده لا يكفي للدمج: قد تتشابه عناوين وقائع مختلفة.
        # نشترط تطابق إشارات الواقعة (مجال/تاريخ/موقع/جهات) للتطابق المؤكد،
        # وإلا نُحيله للمراجعة (تطابق محتمل) فلا يُدمج سجلان نهائيًا عند الشك.
        if best_incident >= TEXTUAL_CONFIRM_INCIDENT:
            return DupResult(EXACT, report_id=best_rep["id"], level="textual",
                             reason=f"تشابه عنوان {best_title:.0%} مع تطابق واقعة",
                             score=best_title, is_update=is_update,
                             is_correction=is_correction, tags=best_reasons)
        return DupResult(PROBABLE, report_id=best_rep["id"], level="textual",
                         reason=f"تشابه عنوان {best_title:.0%} دون تطابق واقعة واضح",
                         score=best_title, is_update=is_update,
                         is_correction=is_correction, tags=best_reasons)
    if best_body >= BODY_EXACT and best_rep:
        if best_incident >= TEXTUAL_CONFIRM_INCIDENT:
            return DupResult(EXACT, report_id=best_rep["id"], level="textual",
                             reason=f"تشابه متن {best_body:.0%} مع تطابق واقعة",
                             score=best_body, is_update=is_update,
                             is_correction=is_correction, tags=best_reasons)
        return DupResult(PROBABLE, report_id=best_rep["id"], level="textual",
                         reason=f"تشابه متن {best_body:.0%} دون تطابق واقعة واضح",
                         score=best_body, is_update=is_update,
                         is_correction=is_correction, tags=best_reasons)

    # --- المستوى الثالث: مطابقة الواقعة ---
    if best_incident >= INCIDENT_PROBABLE:
        # نفس الواقعة: تصحيح/تحديث صريح → تحديث جوهري؛ وإلا تطابق محتمل للمراجعة.
        if is_correction:
            return DupResult(UPDATE, report_id=best_rep["id"] if best_rep else None,
                             level="incident", reason="تصحيح لواقعة قائمة",
                             score=best_incident, is_update=True,
                             is_correction=True, tags=best_reasons)
        if is_update:
            return DupResult(UPDATE, report_id=best_rep["id"] if best_rep else None,
                             level="update", reason="تحديث لواقعة قائمة",
                             score=best_incident, is_update=True, tags=best_reasons)
        return DupResult(PROBABLE, report_id=best_rep["id"] if best_rep else None,
                         level="incident",
                         reason="تطابق واقعة محتمل: " + "، ".join(best_reasons),
                         score=best_incident, tags=best_reasons)

    # --- المستوى الثاني (متابعة): تشابه نصّي دون تطابق واقعة واضح ---
    if best_title >= TITLE_PROBABLE or best_body >= BODY_PROBABLE:
        return DupResult(UNCERTAIN, report_id=best_rep["id"] if best_rep else None,
                         level="textual",
                         reason=f"تشابه نصّي محتمل (عنوان {best_title:.0%})",
                         score=max(best_title, best_body), tags=best_reasons)

    # --- واقعة جديدة ---
    return DupResult(NEW, level="", reason="لا تطابق في القاعدة",
                     score=max(best_title, best_body), is_update=is_update,
                     is_correction=is_correction)


def find_duplicate_document(conn: sqlite3.Connection, doc: dict,
                            exclude_id: int | None = None) -> dict | None:
    """كشف تكرار داخل جدول المستندات (عنصر وصل من مصدرين متزامنين).

    يُنفَّذ قبل الإدراج؛ القيد الفريد (source_key, external_id) يمنع التكرار
    لنفس المصدر، وهذه الدالة تمنع التكرار عبر المصادر المختلفة.
    """
    digest = doc.get("content_digest") or content_digest(
        doc.get("title") or "", doc.get("body") or doc.get("summary") or "")
    for other in db.documents_by_digest(conn, digest, exclude_id=exclude_id):
        return other
    cu = canonical_url(doc.get("url"))
    if cu:
        other = db.document_by_url(conn, doc.get("url"))
        if other and other["id"] != exclude_id:
            return other
    return None
