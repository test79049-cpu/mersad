"""الملفات الحسّاسة — **محاكاة وعرض توضيحي فقط** (الدفعة 14).

قيد أمني صارم: لا رفع ملفات حقيقي، ولا تخزين محتوى، ولا تشفير فعلي، ولا شبكة.
كل ما هنا **بيانات وصفية وهمية** (عنوان، نوع، تصنيف، حجم/بصمة مُصطنعة) لشرح التدفّق:
إيداع وصفي ← ختم ← طلب وصول ← موافقة/رفض ← سحب ← سجل إيصالات.

لتفعيل عرض حقيقي لاحقًا يلزم تقييم مخاطر ومراجعة أمنية وقانونية (انظر
docs/sensitive-files-review.md)؛ الدالة `crypto_ready()` تعيد False دائمًا.
"""
from __future__ import annotations

import hashlib
import sqlite3
from typing import Any

from .taxonomy import (
    ACCESS_STATE_BY_KEY,
    CLASSIFICATION_BY_KEY,
    RECEIPT_KIND_BY_KEY,
    SENSITIVE_KIND_BY_KEY,
)

FAKE_DIGEST_PREFIX = "demo:"
MAX_TITLE = 140
MAX_ITEMS_PER_OWNER = 25

DEFAULT_POLICIES = {
    "retention_days": "365",
    "require_two_person": "1",
    "allow_download": "0",          # لا تنزيل إطلاقًا في الوضع التجريبي
    "watermark": "1",
    "legal_review": "required",
}


def crypto_ready() -> bool:
    """هل جاهز التشفير الفعلي؟ دائمًا False في الوضع التجريبي (قيد أمني)."""
    return False


def seed_vault(conn: sqlite3.Connection) -> None:
    """بيانات وصفية تجريبية للملفات الحسّاسة (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM vault_items").fetchone()["n"]:
        return
    for k, v in DEFAULT_POLICIES.items():
        conn.execute("INSERT OR IGNORE INTO vault_policies(key, value) VALUES (?,?)", (k, v))
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    owner = "rana.act" if "rana.act" in handles else next(iter(handles), "mirsad_admin")
    items = [
        ("شهادات شهود — قضية X", "document", "restricted", "sealed", 204800),
        ("صور ميدانية (بيانات وصفية)", "image", "confidential", "sealed", 1048576),
        ("تسجيل صوتي مجهول المصدر", "audio", "restricted", "draft", 524288),
        ("مجموعة بيانات مفتوحة", "dataset", "internal", "shared", 40960),
    ]
    ids = []
    for title, kind, cls, state, size in items:
        cur = conn.execute(
            """INSERT INTO vault_items(owner, title, kind, classification, state,
               fake_size, fake_digest, is_seed)
               VALUES (?,?,?,?,?,?,?,1)""",
            (owner, title, kind, cls, state, size, _fake_digest(title)))
        ids.append(cur.lastrowid)
    # إيصالات إيداع وهمية
    for iid in ids:
        conn.execute(
            "INSERT INTO vault_receipts(item_id, kind, actor, detail) VALUES (?,?,?,?)",
            (iid, "upload", owner, "إيداع تجريبي (بيانات وصفية فقط)"))
    # طلبات وصول تجريبية
    req = "adam.mem" if "adam.mem" in handles else owner
    conn.execute(
        """INSERT OR IGNORE INTO vault_access(item_id, member, state, purpose, is_seed)
           VALUES (?,?,?,?,1)""", (ids[0], req, "pending", "مراجعة قانونية"))
    conn.execute(
        """INSERT OR IGNORE INTO vault_access(item_id, member, state, purpose, is_seed)
           VALUES (?,?,?,?,1)""", (ids[3], req, "approved", "استخدام بحثي"))
    conn.commit()


def _fake_digest(seed: str) -> str:
    """بصمة مُصطنعة (ليست تجزئة لمحتوى حقيقي) لتمييز السجلات التجريبية فقط."""
    h = hashlib.sha256(seed.encode("utf-8")).hexdigest()[:16]
    return FAKE_DIGEST_PREFIX + h


# ---------------------------------------------------------------------------
# العناصر الوصفية
# ---------------------------------------------------------------------------

def query_items(conn: sqlite3.Connection, *, owner: str | None = None,
                state: str | None = None, limit: int = 100) -> list[dict]:
    sql = "SELECT * FROM vault_items"
    params: list[Any] = []
    where = []
    if owner:
        where.append("owner=?"); params.append(owner)
    if state:
        where.append("state=?"); params.append(state)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def item_by_id(conn: sqlite3.Connection, iid: int) -> dict | None:
    r = conn.execute("SELECT * FROM vault_items WHERE id=?", (iid,)).fetchone()
    return dict(r) if r else None


def create_item(conn: sqlite3.Connection, owner: str, title: str, kind: str = "document",
                classification: str = "internal", note: str = "") -> int | None:
    """إيداع وصفي تجريبي (لا محتوى). يعيد None إن فشل التحقّق."""
    title = (title or "").strip()[:MAX_TITLE]
    if not title or kind not in SENSITIVE_KIND_BY_KEY or classification not in CLASSIFICATION_BY_KEY:
        return None
    n = conn.execute("SELECT COUNT(*) AS n FROM vault_items WHERE owner=?",
                     (owner,)).fetchone()["n"]
    if n >= MAX_ITEMS_PER_OWNER:
        return None
    cur = conn.execute(
        """INSERT INTO vault_items(owner, title, kind, classification, state,
           fake_size, fake_digest, note)
           VALUES (?,?,?,?,'draft',0,?,?)""",
        (owner, title, kind, classification, _fake_digest(title + owner), note[:280]))
    iid = cur.lastrowid
    add_receipt(conn, iid, "upload", owner, "إيداع وصفي")
    conn.commit()
    return iid


def set_item_state(conn: sqlite3.Connection, iid: int, state: str,
                   actor: str | None = None) -> bool:
    if state not in ("draft", "sealed", "shared", "revoked"):
        return False
    cur = conn.execute("UPDATE vault_items SET state=? WHERE id=?", (state, iid))
    if cur.rowcount:
        add_receipt(conn, iid, "revoke" if state == "revoked" else "verify", actor,
                    f"تغيير الحالة إلى {state}")
    conn.commit()
    return cur.rowcount > 0


# ---------------------------------------------------------------------------
# طلبات الوصول
# ---------------------------------------------------------------------------

def query_access(conn: sqlite3.Connection, item_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM vault_access WHERE item_id=? ORDER BY created_at DESC, id DESC",
        (item_id,)).fetchall()]


def pending_access(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT a.*, i.title, i.owner FROM vault_access a
           JOIN vault_items i ON i.id = a.item_id
           WHERE a.state='pending' ORDER BY a.created_at DESC""").fetchall()]


def request_access(conn: sqlite3.Connection, item_id: int, member: str,
                   purpose: str = "") -> bool:
    """طلب وصول (يبدأ بحالة pending دائمًا — لا وصول فوري)."""
    item = item_by_id(conn, item_id)
    if not item or item["owner"] == member:
        return False
    try:
        conn.execute(
            """INSERT INTO vault_access(item_id, member, state, purpose)
               VALUES (?,?,'pending',?)""", (item_id, member, purpose[:200]))
    except sqlite3.IntegrityError:
        return False
    conn.commit()
    return True


def decide_access(conn: sqlite3.Connection, access_id: int, state: str,
                  actor: str | None = None) -> bool:
    """قرار المالك على طلب وصول: approved/denied/revoked."""
    if state not in ("approved", "denied", "revoked"):
        return False
    row = conn.execute("SELECT * FROM vault_access WHERE id=?", (access_id,)).fetchone()
    if not row:
        return False
    item = item_by_id(conn, row["item_id"])
    # قرار الوصول لا يصدره صاحب الطلب نفسه
    if actor and row["member"] == actor:
        return False
    conn.execute("UPDATE vault_access SET state=? WHERE id=?", (state, access_id))
    add_receipt(conn, row["item_id"], "access", actor,
                f"{state} → {row['member']}")
    conn.commit()
    return True


def can_access(conn: sqlite3.Connection, item_id: int, member: str) -> bool:
    """هل يملك العضو وصولًا موافَقًا فعّالًا؟ (المالك يملك دائمًا)."""
    item = item_by_id(conn, item_id)
    if not item:
        return False
    if item["owner"] == member:
        return True
    if item["state"] == "revoked":
        return False
    r = conn.execute(
        "SELECT state FROM vault_access WHERE item_id=? AND member=?",
        (item_id, member)).fetchone()
    return bool(r and r["state"] == "approved")


# ---------------------------------------------------------------------------
# الإيصالات والسياسات
# ---------------------------------------------------------------------------

def add_receipt(conn: sqlite3.Connection, item_id: int, kind: str,
                actor: str | None = None, detail: str = "") -> int:
    if kind not in RECEIPT_KIND_BY_KEY:
        kind = "verify"
    cur = conn.execute(
        "INSERT INTO vault_receipts(item_id, kind, actor, detail) VALUES (?,?,?,?)",
        (item_id, kind, actor, detail[:280]))
    conn.commit()
    return cur.lastrowid


def query_receipts(conn: sqlite3.Connection, item_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM vault_receipts WHERE item_id=? ORDER BY created_at DESC, id DESC",
        (item_id,)).fetchall()]


def policies(conn: sqlite3.Connection) -> dict[str, str]:
    return {r["key"]: r["value"] for r in conn.execute("SELECT * FROM vault_policies")}


def set_policy(conn: sqlite3.Connection, key: str, value: str) -> bool:
    if key not in DEFAULT_POLICIES:
        return False
    if key == "allow_download" and value == "1":
        return False  # لا يُسمح بالتنزيل في الوضع التجريبي
    conn.execute(
        """INSERT INTO vault_policies(key, value) VALUES (?,?)
           ON CONFLICT(key) DO UPDATE SET value=?, updated_at=datetime('now')""",
        (key, value, value))
    conn.commit()
    return True


def vault_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    total = conn.execute("SELECT COUNT(*) AS n FROM vault_items").fetchone()["n"]
    sealed = conn.execute(
        "SELECT COUNT(*) AS n FROM vault_items WHERE state='sealed'").fetchone()["n"]
    pending = conn.execute(
        "SELECT COUNT(*) AS n FROM vault_access WHERE state='pending'").fetchone()["n"]
    receipts = conn.execute("SELECT COUNT(*) AS n FROM vault_receipts").fetchone()["n"]
    return {"items": total, "sealed": sealed, "pending_access": pending,
            "receipts": receipts, "crypto_ready": crypto_ready(),
            "download_enabled": policies(conn).get("allow_download") == "1"}
