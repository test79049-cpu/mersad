/* مِرصد — تفاعلات الواجهة */
(function () {
  "use strict";

  // قائمة الجوال
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector(".nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    // إغلاق القائمة بالنقر خارجها أو بمفتاح Esc.
    document.addEventListener("click", function (e) {
      if (!nav.classList.contains("open")) return;
      if (nav.contains(e.target) || toggle.contains(e.target)) return;
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("open")) {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.focus();
      }
    });
  }

  // إغلاق قوائم التنقّل المنسدلة عند النقر خارجها.
  document.querySelectorAll(".nav__group").forEach(function (g) {
    document.addEventListener("click", function (e) {
      if (!g.contains(e.target)) g.removeAttribute("open");
    });
  });

  // شريط تقدّم القراءة
  var bar = document.querySelector("[data-read-progress]");
  if (bar) {
    var onScroll = function () {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + "%";
    };
    document.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  // زر العودة إلى الأعلى
  var toTop = document.querySelector("[data-to-top]");
  if (toTop) {
    document.addEventListener("scroll", function () {
      toTop.classList.toggle("show", window.scrollY > 600);
    }, { passive: true });
    toTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // شريط عدم الاتصال
  var offline = document.getElementById("offline-banner");
  if (offline) {
    var setOffline = function () { offline.classList.toggle("show", !navigator.onLine); };
    window.addEventListener("online", setOffline);
    window.addEventListener("offline", setOffline);
    setOffline();
  }

  // مبدّل الأرقام العربية-الهندية (يُحفظ محليًّا).
  var NUM_KEY = "mirsad.numerals";
  function arabicNumeralsOn() {
    try { return localStorage.getItem(NUM_KEY) === "ar"; } catch (e) { return false; }
  }
  function applyNumerals() {
    var on = arabicNumeralsOn();
    document.documentElement.classList.toggle("numerals-ar", on);
    if (!on) return;
    var map = "٠١٢٣٤٥٦٧٨٩";
    document.querySelectorAll("[data-count], .stat-board__num, .results-bar__count b, .chip, .country-item__n, .tag__n").forEach(function (el) {
      if (el.dataset.numDone === "1") return;
      var t = el.textContent;
      if (/[0-9]/.test(t)) {
        el.textContent = t.replace(/[0-9]/g, function (d) { return map[+d]; });
        el.dataset.numDone = "1";
      }
    });
  }
  document.querySelectorAll("[data-numerals-toggle]").forEach(function (btn) {
    btn.setAttribute("aria-pressed", arabicNumeralsOn() ? "true" : "false");
    btn.addEventListener("click", function () {
      try { localStorage.setItem(NUM_KEY, arabicNumeralsOn() ? "en" : "ar"); } catch (e) {}
      document.querySelectorAll("[data-count]").forEach(function (el) { delete el.dataset.numDone; });
      applyNumerals();
      btn.setAttribute("aria-pressed", arabicNumeralsOn() ? "true" : "false");
    });
  });
  if (arabicNumeralsOn()) setTimeout(applyNumerals, 1000);

  // ترويسة مضغوطة عند التمرير + ظل
  var masthead = document.querySelector(".masthead");
  if (masthead) {
    var onHeadScroll = function () {
      masthead.classList.toggle("is-scrolled", window.scrollY > 12);
    };
    document.addEventListener("scroll", onHeadScroll, { passive: true });
    onHeadScroll();
  }

  // أعمدة التذييل القابلة للطيّ (على الجوال)
  document.querySelectorAll("[data-footer-toggle]").forEach(function (btn) {
    var col = btn.closest(".footer__col");
    if (!col) return;
    btn.addEventListener("click", function () {
      var collapsed = col.classList.toggle("is-collapsed");
      btn.setAttribute("aria-expanded", collapsed ? "false" : "true");
    });
  });

  // قائمة الأوامر (Command Palette) — Ctrl/⌘ + K
  var cmdDlg = document.getElementById("command-palette");
  var cmdInput = document.getElementById("cmd-input");
  var cmdList = document.getElementById("cmd-list");
  var cmdEmpty = document.querySelector("[data-cmd-empty]");
  var I18N = window.MIRSAD_I18N || {};
  if (cmdDlg && cmdInput && cmdList) {
    var navItems = (I18N.navItems || []).map(function (it, i) {
      var icons = ["◆", "▤", "◉", "▦", "◈", "◇", "❖", "ℹ", "✎"];
      return { label: it.label, href: it.href, icon: icons[i] || "•" };
    });
    var actions = [
      { label: I18N.cmdTheme || "Toggle theme", action: "theme", icon: "◐" },
      { label: I18N.cmdLang || "Switch language", action: "lang", icon: "⇄" },
      { label: I18N.cmdShortcuts || "Shortcuts", action: "shortcuts", icon: "⌨" },
      { label: I18N.cmdTop || "Back to top", action: "top", icon: "↑" }
    ];
    var activeIdx = 0;

    function buildRows(query) {
      var q = (query || "").trim().toLowerCase();
      var rows = [];
      navItems.forEach(function (it) {
        if (!q || it.label.toLowerCase().indexOf(q) !== -1) rows.push({ group: "nav", item: it });
      });
      actions.forEach(function (it) {
        if (!q || it.label.toLowerCase().indexOf(q) !== -1) rows.push({ group: "action", item: it });
      });
      return rows;
    }

    function renderRows(rows) {
      cmdList.innerHTML = "";
      cmdEmpty.hidden = rows.length > 0;
      var lastGroup = null;
      rows.forEach(function (r, i) {
        if (r.group !== lastGroup) {
          lastGroup = r.group;
          var gh = document.createElement("li");
          gh.className = "cmd-palette__group";
          gh.setAttribute("role", "presentation");
          gh.textContent = r.group === "nav" ? (I18N.cmdNav || "Navigate") : (I18N.cmdActions || "Actions");
          cmdList.appendChild(gh);
        }
        var li = document.createElement("li");
        li.className = "cmd-palette__item";
        li.setAttribute("role", "option");
        li.dataset.idx = i;
        li.innerHTML = '<span class="cmd-palette__icon" aria-hidden="true">' + r.item.icon + "</span>" +
          '<span class="cmd-palette__label"></span>';
        li.querySelector(".cmd-palette__label").textContent = r.item.label;
        if (i === activeIdx) li.classList.add("is-active");
        li.addEventListener("mousedown", function (e) { e.preventDefault(); run(r); });
        cmdList.appendChild(li);
      });
    }

    function run(r) {
      closeCmd();
      if (r.group === "nav") {
        window.location.href = r.item.href;
      } else if (r.item.action === "theme") {
        var tb = document.querySelector("[data-theme-toggle]"); if (tb) tb.click();
      } else if (r.item.action === "lang") {
        var ls = document.querySelector(".lang-switch"); if (ls) window.location.href = ls.href;
      } else if (r.item.action === "shortcuts") {
        openShortcuts();
      } else if (r.item.action === "top") {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }

    var currentRows = [];
    function refresh() {
      currentRows = buildRows(cmdInput.value);
      if (activeIdx >= currentRows.length) activeIdx = Math.max(0, currentRows.length - 1);
      renderRows(currentRows);
    }
    function openCmd() {
      activeIdx = 0;
      cmdInput.value = "";
      refresh();
      if (!cmdDlg.open) cmdDlg.showModal();
      setTimeout(function () { cmdInput.focus(); }, 20);
    }
    function closeCmd() { if (cmdDlg.open) cmdDlg.close(); }

    document.querySelectorAll("[data-command-open]").forEach(function (b) {
      b.addEventListener("click", openCmd);
    });
    cmdInput.addEventListener("input", function () { activeIdx = 0; refresh(); });
    cmdInput.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") {
        e.preventDefault(); activeIdx = Math.min(activeIdx + 1, currentRows.length - 1); renderRows(currentRows);
      } else if (e.key === "ArrowUp") {
        e.preventDefault(); activeIdx = Math.max(activeIdx - 1, 0); renderRows(currentRows);
      } else if (e.key === "Enter") {
        e.preventDefault(); if (currentRows[activeIdx]) run(currentRows[activeIdx]);
      } else if (e.key === "Escape") {
        closeCmd();
      }
    });
    cmdDlg.addEventListener("click", function (e) { if (e.target === cmdDlg) closeCmd(); });
  }

  // عدّاد «جديد منذ زيارتك» في التنقّل
  var newBadge = document.querySelector("[data-new-badge]");
  if (newBadge && I18N.newCountUrl) {
    var LAST_KEY = "mirsad.lastVisit";
    var nowIso = new Date().toISOString().slice(0, 19).replace("T", " ");
    var prev = null;
    try { prev = localStorage.getItem(LAST_KEY); } catch (e) {}
    if (prev) {
      fetch(I18N.newCountUrl + "?since=" + encodeURIComponent(prev), { headers: { Accept: "application/json" } })
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) {
          if (d && d.new > 0) {
            newBadge.textContent = (I18N.newBadge || "{n}").replace("{n}", d.new);
            newBadge.hidden = false;
          }
        })
        .catch(function () {});
    }
    try { localStorage.setItem(LAST_KEY, nowIso); } catch (e) {}
  }

  // اختصارات لوحة المفاتيح: "/" للبحث، "g m" للخريطة، "g t" للأعلى، "d" للسمة، "?" للمساعدة.
  var lastKey = "";
  var shortcutsDlg = document.getElementById("shortcuts");
  function openShortcuts() { if (shortcutsDlg && !shortcutsDlg.open) shortcutsDlg.showModal(); }
  document.querySelectorAll("[data-shortcuts-open]").forEach(function (b) {
    b.addEventListener("click", openShortcuts);
  });
  document.querySelectorAll("[data-shortcuts-close]").forEach(function (b) {
    b.addEventListener("click", function () { if (shortcutsDlg) shortcutsDlg.close(); });
  });
  if (shortcutsDlg) {
    shortcutsDlg.addEventListener("click", function (e) {
      if (e.target === shortcutsDlg) shortcutsDlg.close();
    });
  }
  document.addEventListener("keydown", function (e) {
    var tag = (e.target.tagName || "").toLowerCase();
    var typing = tag === "input" || tag === "textarea" || tag === "select" || e.target.isContentEditable;
    // قائمة الأوامر تعمل حتى أثناء الكتابة (Ctrl/⌘ + K).
    if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) {
      e.preventDefault();
      var op = document.querySelector("[data-command-open]");
      if (op) op.click();
      return;
    }
    if (typing) return;
    var NAV = { h: "/", r: "/reports", m: "/map", s: "/stats", c: "/countries",
                e: "/entities", u: "/submit", o: "/sources", a: "/about" };
    if (e.key === "/") {
      var q = document.getElementById("global-q");
      if (q) { e.preventDefault(); q.focus(); }
    } else if (e.key === "?") {
      e.preventDefault(); openShortcuts();
    } else if (lastKey === "g" && NAV[e.key]) {
      window.location.href = NAV[e.key];
    } else if (lastKey === "g" && e.key === "f") {
      // الانتقال إلى أول مرشّح في الصفحة (أو مربّع البحث).
      var facet = document.querySelector(".facets input, .facets select, .map-search__input, #global-q");
      if (facet) { e.preventDefault(); facet.focus(); }
    } else if (e.key === "t") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else if (e.key === "j") {
      // تمرير لأسفل بقدر ارتفاع الشاشة تقريبًا.
      e.preventDefault();
      window.scrollBy({ top: window.innerHeight * 0.85, behavior: "smooth" });
    } else if (e.key === "k") {
      e.preventDefault();
      window.scrollBy({ top: -window.innerHeight * 0.85, behavior: "smooth" });
    } else if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      // التنقّل بين صفحات النتائج (روابط الترقيم في الصفحة).
      var prevL = document.querySelector("a[rel='prev']");
      var nextL = document.querySelector("a[rel='next']");
      var target = (e.key === "ArrowLeft") ? prevL : nextL;
      if (target) { e.preventDefault(); window.location.href = target.href; }
    } else if (e.key === "g" && !lastKey) {
      // مفتاح أوّل في تسلسل "g" — يُنتظر المفتاح التالي.
    } else if (e.key === "d") {
      var tbtn = document.querySelector("[data-theme-toggle]");
      if (tbtn) tbtn.click();
    } else if (e.key === "p") {
      // طباعة الصفحة الحالية (تتضمّن ترويسة الطباعة في وضع PDF).
      e.preventDefault();
      window.print();
    } else if (e.key === "y") {
      // نسخ رابط الصفحة الحالية إلى الحافظة.
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(window.location.href).then(function () {
          announce(I18N.copied || "Copied");
        }, function () {});
      }
    }
    lastKey = e.key;
  });

  // شريط الإعلان القابل للإغلاق (يُحفظ اختيار الإغلاق في localStorage).
  var announce = document.querySelector("[data-announce]");
  if (announce) {
    var ANNOUNCE_KEY = "mirsad.announceClosed";
    var closed = false;
    try { closed = localStorage.getItem(ANNOUNCE_KEY) === "1"; } catch (e) {}
    if (!closed) announce.hidden = false;
    var annClose = document.querySelector("[data-announce-close]");
    if (annClose) annClose.addEventListener("click", function () {
      announce.hidden = true;
      try { localStorage.setItem(ANNOUNCE_KEY, "1"); } catch (e) {}
    });
  }

  // البحث الفوري عن دولة في الصفحة الرئيسية.
  var countryInput = document.querySelector("[data-country-search]");
  var countryResults = document.querySelector("[data-country-results]");
  if (countryInput && countryResults && Array.isArray(I18N.countryList)) {
    var allCountries = I18N.countryList;
    function renderCountries(q) {
      q = (q || "").trim().toLowerCase();
      countryResults.innerHTML = "";
      if (!q) { countryResults.hidden = true; return; }
      var matches = allCountries.filter(function (c) {
        return c.name.toLowerCase().indexOf(q) !== -1;
      }).slice(0, 8);
      if (!matches.length) { countryResults.hidden = true; return; }
      matches.forEach(function (c) {
        var li = document.createElement("li");
        var a = document.createElement("a");
        a.href = c.href;
        var flag = document.createElement("span");
        flag.textContent = c.flag || "";
        flag.setAttribute("aria-hidden", "true");
        var name = document.createElement("span");
        name.textContent = c.name;
        var n = document.createElement("span");
        n.className = "country-item__n";
        n.textContent = c.total;
        a.appendChild(flag); a.appendChild(name); a.appendChild(n);
        li.appendChild(a);
        countryResults.appendChild(li);
      });
      countryResults.hidden = false;
    }
    countryInput.addEventListener("input", function () { renderCountries(countryInput.value); });
    countryInput.addEventListener("keydown", function (e) {
      if (e.key === "Escape") { countryResults.hidden = true; countryInput.blur(); }
      if (e.key === "Enter") {
        var first = countryResults.querySelector("a");
        if (first) { e.preventDefault(); window.location.href = first.href; }
      }
    });
    document.addEventListener("click", function (e) {
      if (!countryInput.contains(e.target) && !countryResults.contains(e.target)) countryResults.hidden = true;
    });
  }

  // عدّاد تنازلي للتحديث القادم (دقائق:ثوانٍ) بلا أي طلب شبكة.
  document.querySelectorAll("[data-refresh-countdown]").forEach(function (el) {
    var mins = parseInt(el.dataset.refreshCountdown, 10) || 30;
    var out = el.querySelector("b");
    var remain = mins * 60;
    function tickCd() {
      if (remain < 0) remain = mins * 60;
      var m = Math.floor(remain / 60), s = remain % 60;
      if (out) out.textContent = m + ":" + (s < 10 ? "0" + s : s);
      remain -= 1;
    }
    tickCd();
    setInterval(tickCd, 1000);
  });

  // الظهور التدريجي عند التمرير
  var reveals = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && reveals.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (e, i) {
          if (e.isIntersecting) {
            var el = e.target;
            var delay = parseInt(el.dataset.delay || "0", 10);
            setTimeout(function () { el.classList.add("in"); }, delay);
            io.unobserve(el);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" }
    );
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("in"); });
  }

  // عدّاد تصاعدي للأرقام
  var counters = document.querySelectorAll("[data-count]");
  if ("IntersectionObserver" in window && counters.length) {
    var co = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var el = e.target;
        var target = parseInt(el.dataset.count, 10) || 0;
        var start = performance.now();
        var dur = 900;
        function tick(now) {
          var p = Math.min((now - start) / dur, 1);
          var eased = 1 - Math.pow(1 - p, 3);
          el.textContent = Math.round(target * eased).toLocaleString("ar-EG");
          if (p < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        co.unobserve(el);
      });
    }, { threshold: 0.4 });
    counters.forEach(function (el) { co.observe(el); });
  }

  // تصفير الفلاتر
  var reset = document.querySelector("[data-reset]");
  if (reset) {
    reset.addEventListener("click", function (e) {
      e.preventDefault();
      window.location.href = reset.dataset.reset;
    });
  }

  // إرسال تلقائي عند تغيير القوائم في شريط التصفية
  document.querySelectorAll("[data-autosubmit]").forEach(function (el) {
    el.addEventListener("change", function () { el.form.submit(); });
  });

  // إرسال تلقائي مؤجّل لحقل البحث النصّي (يتجنّب إرسالًا لكل حرف)
  document.querySelectorAll("[data-live-submit]").forEach(function (el) {
    var t;
    el.addEventListener("input", function () {
      clearTimeout(t);
      t = setTimeout(function () { el.form.submit(); }, 550);
    });
    // بعد إعادة التحميل: أعد التركيز للاستمرار في الكتابة دون انقطاع.
    var u = new URL(window.location.href);
    if (el.name && u.searchParams.get(el.name) && el.value) {
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
    }
  });

  // عناصر تنقّل تُحدّث معاملًا في عنوان الصفحة مع الحفاظ على بقية المعاملات
  document.querySelectorAll("[data-nav-param]").forEach(function (el) {
    el.addEventListener("change", function () {
      var url = new URL(window.location.href);
      var val = el.value;
      if (val) url.searchParams.set(el.dataset.navParam, val);
      else url.searchParams.delete(el.dataset.navParam);
      var reset = el.dataset.navReset;
      if (reset) url.searchParams.delete(reset);
      window.location.href = url.toString();
    });
  });

  // إزالة مرشّح نشط واحد (رقاقة ×) مع الحفاظ على بقية المعاملات
  document.querySelectorAll("[data-remove-filter]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var url = new URL(window.location.href);
      url.searchParams.delete(btn.dataset.removeFilter);
      url.searchParams.delete("page");
      window.location.href = url.toString();
    });
  });

  // الاقتراحات الفورية لبحث الترويسة
  var searchForm = document.querySelector(".masthead__search");
  if (searchForm) {
    var input = searchForm.querySelector("input");
    var box = document.createElement("div");
    box.className = "search-suggest";
    box.hidden = true;
    searchForm.appendChild(box);
    var timer = null, lastQ = "";

    function hide() { box.hidden = true; box.innerHTML = ""; }

    function esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    }

    function render(items) {
      if (!items.length) { hide(); return; }
      box.innerHTML = items.map(function (r) {
        return '<a href="/reports/' + encodeURIComponent(r.id) + '">' +
          '<span class="search-suggest__t">' + esc(r.title) + "</span>" +
          '<span class="search-suggest__m">' + esc(r.category_name) + " · " +
          esc(r.country) + "</span></a>";
      }).join("");
      box.hidden = false;
    }

    input.addEventListener("input", function () {
      var q = input.value.trim();
      clearTimeout(timer);
      if (q.length < 2 || q === lastQ) { hide(); return; }
      timer = setTimeout(function () {
        lastQ = q;
        fetch("/api/search?q=" + encodeURIComponent(q) + "&limit=5")
          .then(function (r) { return r.ok ? r.json() : { items: [] }; })
          .then(function (d) { render(d.items || []); })
          .catch(hide);
      }, 220);
    });

    input.addEventListener("blur", function () {
      setTimeout(hide, 180);
    });
    input.addEventListener("keydown", function (e) {
      if (e.key === "Escape") hide();
    });
  }

  // نسخ إلى الحافظة (الاستشهاد والروابط)
  var I18N = window.MIRSAD_I18N || {};
  var liveRegion = document.querySelector("[data-live-region]");
  function announce(msg) {
    if (liveRegion && msg) liveRegion.textContent = msg;
  }
  document.querySelectorAll("[data-copy], [data-copy-target]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var text = btn.dataset.copy;
      if (text == null && btn.dataset.copyTarget) {
        var src = document.querySelector(btn.dataset.copyTarget);
        text = src ? (src.value != null ? src.value : src.textContent) : "";
      }
      text = (text || "").trim();
      if (!text) return;
      var old = btn.innerHTML;
      var done = function (ok) {
        btn.textContent = ok ? (I18N.copied || "Copied ✓") : (I18N.copyFailed || "Copy failed");
        announce(ok ? (I18N.copied || "Copied") : (I18N.copyFailed || "Copy failed"));
        setTimeout(function () { btn.innerHTML = old; }, 1400);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); });
      } else {
        try {
          var ta = document.createElement("textarea");
          ta.value = text; ta.setAttribute("readonly", "");
          ta.style.position = "absolute"; ta.style.opacity = "0";
          document.body.appendChild(ta); ta.select();
          var ok = document.execCommand("copy");
          document.body.removeChild(ta);
          done(ok);
        } catch (e) { done(false); }
      }
    });
  });

  // المشاركة الاجتماعية: زر واحد يفتح نافذة خيارات (واتساب/تلغرام/X/فيسبوك/
  // لينكدإن/ريديت/بريد) مع نسخ الرابط، وزر «مشاركة أصلية» عند دعم المتصفّح.
  // يشمل الأزرار على البطاقات ([data-card-share]) وأزرار الصفحات ([data-share]).
  (function () {
    var dialog = document.getElementById("share-dialog");
    var subjectEl = dialog ? dialog.querySelector("[data-share-subject]") : null;
    var linkEl = dialog ? dialog.querySelector("[data-share-link]") : null;
    var nativeEl = dialog ? dialog.querySelector('[data-share-target="native"]') : null;
    var current = { title: "", url: "" };
    var canShare = !!(navigator.share && navigator.canShare);

    function fillTargets() {
      if (!dialog) return;
      var u = encodeURIComponent(current.url);
      var t = encodeURIComponent(current.title || document.title);
      var map = {
        whatsapp: "https://wa.me/?text=" + t + "%20" + u,
        telegram: "https://t.me/share/url?url=" + u + "&text=" + t,
        x: "https://twitter.com/intent/tweet?url=" + u + "&text=" + t,
        facebook: "https://www.facebook.com/sharer/sharer.php?u=" + u,
        linkedin: "https://www.linkedin.com/sharing/share-offsite/?url=" + u,
        reddit: "https://www.reddit.com/submit?url=" + u + "&title=" + t,
        email: "mailto:?subject=" + t + "&body=" + u
      };
      dialog.querySelectorAll("[data-share-target]").forEach(function (a) {
        var kind = a.dataset.shareTarget;
        if (kind === "native") { a.hidden = !canShare; return; }
        if (map[kind]) a.setAttribute("href", map[kind]);
      });
      if (nativeEl) nativeEl.hidden = !canShare;
      if (linkEl) linkEl.value = current.url;
      if (subjectEl) subjectEl.textContent = current.title || "";
    }

    function openShare(title, url) {
      current.title = title || document.title;
      current.url = url || window.location.href;
      if (!dialog) {
        // بلا نافذة: جرّب المشاركة الأصلية، وإلا انسخ الرابط.
        if (canShare) {
          navigator.share({ title: current.title, url: current.url }).catch(function () {});
        } else {
          copyText(current.url);
        }
        return;
      }
      fillTargets();
      if (typeof dialog.showModal === "function") dialog.showModal();
      else dialog.setAttribute("open", "");
      announce(I18N.shareMenu || "Share options");
    }

    function copyText(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          announce(I18N.copied || "Copied");
        }, function () { announce(I18N.copyFailed || "Copy failed"); });
      }
    }

    document.querySelectorAll("[data-share], [data-card-share]").forEach(function (btn) {
      btn.hidden = false;
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        openShare(btn.dataset.shareTitle, btn.dataset.shareUrl);
      });
    });

    if (dialog) {
      dialog.querySelectorAll("[data-share-close]").forEach(function (b) {
        b.addEventListener("click", function () { dialog.close(); });
      });
      dialog.addEventListener("click", function (e) {
        if (e.target === dialog) dialog.close();
      });
      if (nativeEl) {
        nativeEl.addEventListener("click", function (e) {
          e.preventDefault();
          navigator.share({ title: current.title, url: current.url }).catch(function () {});
          dialog.close();
        });
      }
      var copyBtn = dialog.querySelector("[data-share-copy]");
      if (copyBtn) {
        copyBtn.addEventListener("click", function () {
          copyText(current.url);
          var old = copyBtn.innerHTML;
          copyBtn.textContent = I18N.copied || "Copied ✓";
          setTimeout(function () { copyBtn.innerHTML = old; }, 1400);
        });
      }
    }
  })();

  // حفظ/متابعة بلاغ محليًّا: [data-card-save] مع مزامنة aria-pressed.
  (function () {
    var KEY = "mirsad.savedReports";
    var read = function () {
      try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; }
    };
    var btns = document.querySelectorAll("[data-card-save]");
    if (!btns.length) return;
    var set = {};
    read().forEach(function (id) { set[id] = true; });
    btns.forEach(function (btn) {
      var id = btn.dataset.cardSave;
      btn.setAttribute("aria-pressed", set[id] ? "true" : "false");
      btn.addEventListener("click", function () {
        var list = read();
        var idx = list.indexOf(id);
        if (idx >= 0) { list.splice(idx, 1); btn.setAttribute("aria-pressed", "false"); }
        else { list.push(id); btn.setAttribute("aria-pressed", "true"); }
        try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) {}
      });
    });
  })();

  // العمليات البحثية المحفوظة محليًّا (localStorage)
  var savedHost = document.querySelector("[data-saved-searches]");
  var filterForm = document.querySelector(".filterbar form");
  if (savedHost && filterForm) {
    var STORE = "mirsad.savedSearches";
    function load() {
      try { return JSON.parse(localStorage.getItem(STORE)) || []; }
      catch (err) { return []; }
    }
    function save(list) {
      try { localStorage.setItem(STORE, JSON.stringify(list.slice(0, 12))); }
      catch (err) { /* التخزين معطّل: نتجاهل بصمت */ }
    }
    function currentQuery() {
      var fd = new FormData(filterForm);
      var parts = [];
      fd.forEach(function (v, k) {
        v = String(v).trim();
        if (v) parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(v));
      });
      return parts.join("&");
    }
    function esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    }
    function label(list) {
      var bits = [];
      list.forEach(function (p) {
        var k = decodeURIComponent(p.split("=")[0]);
        var v = decodeURIComponent(p.split("=")[1] || "");
        if (k === "q") bits.push('"' + v + '"');
        else if (k === "category" || k === "severity" || k === "status" || k === "country")
          bits.push(v);
      });
      return bits.join(" · ") || "تصفية";
    }
    function render() {
      var list = load();
      if (!list.length) { savedHost.hidden = true; savedHost.innerHTML = ""; return; }
      savedHost.hidden = false;
      savedHost.innerHTML =
        '<span class="saved-searches__label">محفوظة:</span>' +
        list.map(function (q, i) {
          return '<span class="saved-chip">' +
            '<a href="/reports?' + esc(q) + '">' + esc(label(q.split("&"))) + "</a>" +
            '<button type="button" data-remove="' + i + '" aria-label="إزالة">×</button></span>';
        }).join("");
    }
    var saveBtn = filterForm.querySelector("[data-save-search]");
    saveBtn.addEventListener("click", function () {
      var q = currentQuery();
      if (!q) return;
      var list = load().filter(function (x) { return x !== q; });
      list.unshift(q);
      save(list);
      render();
      saveBtn.textContent = "تم الحفظ ✓";
      setTimeout(function () { saveBtn.textContent = "حفظ البحث"; }, 1400);
    });
    savedHost.addEventListener("click", function (e) {
      var b = e.target.closest("[data-remove]");
      if (!b) return;
      var list = load();
      list.splice(parseInt(b.dataset.remove, 10), 1);
      save(list);
      render();
    });
    render();
  }
  // تبديل السمة (الوضع الليلي/النهاري) مع الحفظ محليًّا
  var THEME_KEY = "mirsad.theme";
  var themeBtn = document.querySelector("[data-theme-toggle]");
  function currentTheme() { return document.documentElement.dataset.theme === "light" ? "light" : "dark"; }
  function themeLabels() {
    return document.documentElement.lang === "en"
      ? { light: "Light mode", dark: "Dark mode", toLight: "Switch to light mode", toDark: "Switch to dark mode" }
      : { light: "الوضع النهاري", dark: "الوضع الليلي", toLight: "التبديل إلى الوضع النهاري", toDark: "التبديل إلى الوضع الليلي" };
  }
  function syncThemeBtn() {
    if (!themeBtn) return;
    var L = themeLabels();
    var light = currentTheme() === "light";
    themeBtn.setAttribute("aria-pressed", light ? "true" : "false");
    var label = themeBtn.querySelector("[data-theme-label]");
    if (label) label.textContent = light ? L.dark : L.light;
    themeBtn.title = light ? L.toDark : L.toLight;
    themeBtn.setAttribute("aria-label", themeBtn.title);
  }
  function applyTheme(t, persist) {
    document.documentElement.dataset.theme = t;
    if (persist) { try { localStorage.setItem(THEME_KEY, t); } catch (err) { /* التخزين معطّل */ } }
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", t === "light" ? "#f4efe4" : "#100f0d");
    syncThemeBtn();
    document.dispatchEvent(new CustomEvent("mirsad:theme", { detail: { theme: t } }));
  }
  if (themeBtn) {
    syncThemeBtn();
    themeBtn.addEventListener("click", function () {
      applyTheme(currentTheme() === "light" ? "dark" : "light", true);
    });
    // متابعة تفضيل النظام ما لم يختر المستخدم وضعًا صريحًا
    if (window.matchMedia) {
      var mq = window.matchMedia("(prefers-color-scheme: light)");
      var onSys = function (e) {
        var saved = null;
        try { saved = localStorage.getItem(THEME_KEY); } catch (err) {}
        if (!saved) applyTheme(e.matches ? "light" : "dark", false);
      };
      if (mq.addEventListener) mq.addEventListener("change", onSys);
      else if (mq.addListener) mq.addListener(onSys);
    }
  }

  // ------------------------------------------------------------------
  // تحسينات: تحديد متعدّد، جدول قابل للفرز، تبديل العرض، معاينة سريعة
  // ------------------------------------------------------------------
  var LANG = (document.documentElement.lang || "ar").slice(0, 2);

  // تحديد متعدّد + شريط إجراءات جماعية
  var bulkBar = document.querySelector("[data-bulk-bar]");
  var selectAll = document.querySelector("[data-select-all]");
  function selectedIds() {
    return Array.prototype.map.call(
      document.querySelectorAll("[data-select]:checked"),
      function (c) { return c.value; }
    );
  }
  function syncBulk() {
    if (!bulkBar) return;
    var ids = selectedIds();
    var n = bulkBar.querySelector("[data-bulk-n]");
    if (n) n.textContent = (bulkBar.dataset.tpl || "").replace("{n}", ids.length);
    bulkBar.hidden = ids.length === 0;
    document.querySelectorAll(".report-card").forEach(function (card) {
      var c = card.querySelector("[data-select]");
      card.classList.toggle("is-selected", !!(c && c.checked));
    });
  }
  document.querySelectorAll("[data-select]").forEach(function (c) {
    c.addEventListener("change", syncBulk);
  });
  if (selectAll) {
    selectAll.addEventListener("change", function () {
      document.querySelectorAll("[data-select]").forEach(function (c) { c.checked = selectAll.checked; });
      syncBulk();
    });
  }
  if (bulkBar) {
    var bulkExport = bulkBar.querySelector("[data-bulk-export]");
    if (bulkExport) bulkExport.addEventListener("click", function () {
      var ids = selectedIds();
      if (!ids.length) return;
      window.location.href = "/api/export.csv?ids=" + ids.join(",");
    });
    var bulkClear = bulkBar.querySelector("[data-bulk-clear]");
    if (bulkClear) bulkClear.addEventListener("click", function () {
      document.querySelectorAll("[data-select]").forEach(function (c) { c.checked = false; });
      var all = document.querySelector("[data-select-all]");
      if (all) all.checked = false;
      syncBulk();
    });
    syncBulk();
  }

  // جدول قابل للفرز
  document.querySelectorAll("table[data-sortable]").forEach(function (table) {
    var ths = table.querySelectorAll("th.sortable");
    ths.forEach(function (th, idx) {
      // إتاحة الفرز بلوحة المفاتيح: رأس الجدول قابل للتركيز ويستجيب لمفتاحي Enter/المسافة.
      if (!th.hasAttribute("tabindex")) th.setAttribute("tabindex", "0");
      if (!th.hasAttribute("role")) th.setAttribute("role", "button");
      function doSort() {
        var dir = th.dataset.dir === "asc" ? "desc" : "asc";
        ths.forEach(function (o) { o.removeAttribute("data-dir"); o.removeAttribute("aria-sort"); });
        th.dataset.dir = dir;
        th.setAttribute("aria-sort", dir === "asc" ? "ascending" : "descending");
        var tbody = table.querySelector("tbody");
        var rows = Array.prototype.slice.call(
          tbody.querySelectorAll("tr:not(.table-empty-note)"));
        var numeric = th.dataset.type === "num";
        rows.sort(function (a, b) {
          var x = a.children[idx].dataset.v || a.children[idx].textContent.trim();
          var y = b.children[idx].dataset.v || b.children[idx].textContent.trim();
          if (numeric) { x = parseFloat(x) || 0; y = parseFloat(y) || 0; return dir === "asc" ? x - y : y - x; }
          return dir === "asc" ? String(x).localeCompare(String(y), LANG) : String(y).localeCompare(String(x), LANG);
        });
        rows.forEach(function (r) { tbody.appendChild(r); });
        var live = document.querySelector("[data-live-region]");
        if (live) live.textContent = (th.textContent || "").trim() + " — " + (dir === "asc" ? "▲" : "▼");
      }
      th.addEventListener("click", doSort);
      th.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); doSort(); }
      });
    });
  });

  // تبديل عرض البطاقات/الجدول (يُحفظ محليًّا)
  var VIEW_KEY = "mirsad.reportsView";
  var grid = document.querySelector("[data-report-grid]");
  var tableWrap = document.querySelector("[data-report-table]");
  if (grid && tableWrap) {
    var applyView = function (v) {
      grid.hidden = v === "table";
      tableWrap.hidden = v !== "table";
      document.querySelectorAll("[data-view-btn]").forEach(function (b) {
        b.classList.toggle("is-active", b.dataset.viewBtn === v);
        b.setAttribute("aria-pressed", b.dataset.viewBtn === v ? "true" : "false");
      });
    };
    document.querySelectorAll("[data-view-btn]").forEach(function (b) {
      b.addEventListener("click", function () {
        var v = b.dataset.viewBtn;
        try { localStorage.setItem(VIEW_KEY, v); } catch (e) {}
        applyView(v);
      });
    });
    var saved = "cards";
    try { saved = localStorage.getItem(VIEW_KEY) || "cards"; } catch (e) {}
    applyView(saved);
  }

  // معاينة سريعة للبلاغ من البطاقة (زر مستقل داخل البطاقة)
  var qv = document.querySelector("[data-qv]");
  if (qv) {
    var qvTitle = qv.querySelector("[data-qv-title]");
    var qvBody = qv.querySelector("[data-qv-body]");
    var qvLink = qv.querySelector("[data-qv-link]");
    var openQv = function (data) {
      if (qvTitle) qvTitle.textContent = data.title || "";
      if (qvBody) {
        qvBody.textContent = "";
        if (data.body) {
          var p = document.createElement("p");
          p.textContent = data.body;
          qvBody.appendChild(p);
        }
      }
      if (qvLink) qvLink.href = data.href || "#";
      qv.classList.add("show");
      var close = qv.querySelector(".qv__close");
      if (close) close.focus();
    };
    document.querySelectorAll("[data-qv-open]").forEach(function (btn) {
      btn.addEventListener("click", function (e) {
        e.preventDefault();
        var card = btn.closest(".report-card");
        if (!card) return;
        openQv({
          title: card.dataset.qvTitle || "",
          body: card.dataset.qvBody || "",
          href: card.dataset.qvHref || "#"
        });
      });
    });
    var closeQv = function () { qv.classList.remove("show"); };
    qv.addEventListener("click", function (e) {
      if (e.target === qv) closeQv();
      if (e.target.closest(".qv__close")) closeQv();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeQv(); });
  }

  // تمييز كلمات البحث داخل النتائج
  (function () {
    var params = new URLSearchParams(window.location.search);
    var q = (params.get("q") || "").trim();
    if (q.length < 2) return;
    var terms = q.split(/\s+/).filter(function (t) { return t.length > 1; });
    if (!terms.length) return;
    var rx = new RegExp("(" + terms.map(function (t) {
      return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }).join("|") + ")", "gi");
    document.querySelectorAll(".report-card h3, .report-card__summary").forEach(function (el) {
      el.innerHTML = el.innerHTML.replace(rx, "<mark>$1</mark>");
    });
  })();

  // سجل «تابعت مؤخرًا»: يُخزَّن محليًّا عند زيارة بلاغ، ويُعرض في صفحة السجل
  (function () {
    var KEY = "mirsad.recent";
    function read() {
      try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch (e) { return []; }
    }
    var detail = document.querySelector("[data-report-id]");
    if (detail) {
      var item = { id: detail.dataset.reportId, title: detail.dataset.reportTitle, href: window.location.pathname };
      var list = read().filter(function (r) { return r.href !== item.href; });
      list.unshift(item);
      try { localStorage.setItem(KEY, JSON.stringify(list.slice(0, 6))); } catch (e) {}
      return;
    }
    // تتبّع بطاقة بارزة على أي صفحة عبر [data-recent-track] (JSON).
    var tracked = document.querySelector("[data-recent-track]");
    if (tracked) {
      try {
        var t = JSON.parse(tracked.dataset.recentTrack);
        if (t && t.href) {
          var ls = read().filter(function (r) { return r.href !== t.href; });
          ls.unshift({ id: t.id || "", title: t.title || "", href: t.href });
          try { localStorage.setItem(KEY, JSON.stringify(ls.slice(0, 6))); } catch (e) {}
        }
      } catch (e) {}
    }
    var box = document.querySelector("[data-recent]");
    var items = document.querySelector("[data-recent-items]");
    if (!box || !items) return;
    var recent = read();
    if (!recent.length) return;
    function esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    }
    items.innerHTML = recent.map(function (r) {
      return '<a class="saved-chip" href="' + esc(r.href) + '">' + esc(r.title) + "</a>";
    }).join("");
    box.hidden = false;
    var clear = document.querySelector("[data-recent-clear]");
    if (clear) clear.addEventListener("click", function () {
      try { localStorage.removeItem(KEY); } catch (e) {}
      box.hidden = true;
    });
  })();

  // تحديث حالة الزرّ عند رجوع الصفحة من كاش المتصفّح
  window.addEventListener("pageshow", function () { syncBulk(); });

  // بحث فوري داخل الجداول: [data-table-search="<table-id>"] يرشّح صفوف الجدول نصيًّا.
  (function () {
    var inputs = document.querySelectorAll("[data-table-search]");
    Array.prototype.forEach.call(inputs, function (input) {
      var table = document.getElementById(input.getAttribute("data-table-search"));
      if (!table || !table.tBodies.length) return;
      var body = table.tBodies[0];
      var rows = Array.prototype.slice.call(body.rows);
      var note = document.createElement("tr");
      note.className = "table-empty-note";
      note.hidden = true;
      var cell = document.createElement("td");
      cell.colSpan = table.tHead ? table.tHead.rows[0].cells.length : 1;
      cell.className = "faint";
      cell.style.textAlign = "center";
      cell.textContent = I18N.noMatch || "—";
      note.appendChild(cell);
      body.appendChild(note);
      input.addEventListener("input", function () {
        var q = (input.value || "").trim().toLowerCase();
        var visible = 0;
        rows.forEach(function (row) {
          var match = !q || row.textContent.toLowerCase().indexOf(q) !== -1;
          row.hidden = !match;
          if (match) visible += 1;
        });
        note.hidden = visible !== 0;
      });
    });
  })();

  // ------------------------------------------------------------------
  // القشرة العامة: حالة الشبكة، تقليل الحركة، التمرير الأفقي، إتاحة
  // ------------------------------------------------------------------
  // إعلان حالة الاتصال عبر منطقة live (إتاحة).
  window.addEventListener("offline", function () {
    announce(I18N.offline || "Offline");
    document.documentElement.classList.add("is-offline");
  });
  window.addEventListener("online", function () {
    announce(I18N.online || "Online");
    document.documentElement.classList.remove("is-offline");
  });

  // احترام تفضيل تقليل الحركة على مستوى النظام (إتاحة).
  try {
    var rmq = window.matchMedia("(prefers-reduced-motion: reduce)");
    var applyRM = function () { document.documentElement.classList.toggle("reduce-motion", rmq.matches); };
    applyRM();
    if (rmq.addEventListener) rmq.addEventListener("change", applyRM);
  } catch (e) {}

  // مؤشّر تقدّم القراءة أعلى الصفحة (يُحدّث عند التمرير).
  var rpBar = document.querySelector("[data-read-progress]");
  if (rpBar) {
    var updProgress = function () {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      var pct = h > 0 ? Math.min(100, (window.scrollY / h) * 100) : 0;
      rpBar.style.width = pct + "%";
    };
    window.addEventListener("scroll", updProgress, { passive: true });
    window.addEventListener("resize", updProgress);
    updProgress();
  }

  // طبقة تلميح مفاتيح الاختصار: فتح/إغلاق بـ Esc موحّد لكل الحوارات.
  document.querySelectorAll("dialog").forEach(function (dlg) {
    dlg.addEventListener("cancel", function () { dlg.close(); });
  });

  // نافذة العاجل: تحديث تلقائي دوري لحالة الجمع والبلاغات الحرجة.
  (function () {
    var root = document.querySelector("[data-urgent]");
    if (!root) return;
    var I18N = (window.MIRSAD_I18N && window.MIRSAD_I18N.urgent) || {};
    var list = root.querySelector("[data-urgent-list]");
    var statusBox = root.querySelector("[data-urgent-status]");
    var liveRegion = document.querySelector("[data-live-region]");
    var lastTopId = null;
    function esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
      });
    }
    function setMetric(sel, val) {
      var el = root.querySelector(sel);
      if (el && val != null) el.textContent = val;
    }
    function sevLabel(k) { return (I18N.severityLabels || {})[k] || k; }
    function statLabel(k) { return (I18N.statusLabels || {})[k] || k; }
    function card(r) {
      var sevColor = r.severity_color || "var(--muted)";
      var catColor = r.category_color || "var(--muted)";
      var statColor = r.status_color || "var(--muted)";
      var summary = r.summary || "";
      var snippet = summary ? esc(summary.slice(0, 180)) + (summary.length > 180 ? "…" : "") : "";
      var chips = '<span class="chip" style="color:' + esc(catColor) + '">' + esc(r.category_name || "") + "</span>" +
        '<span class="chip" style="color:' + esc(statColor) + '">' + esc(r.status_label || statLabel(r.status)) + "</span>" +
        (r.country_display ? '<span class="chip">' + esc(r.country_display) + "</span>" : "") +
        '<span class="chip">' + esc(r.occurred_display || r.reported_display || "") + "</span>";
      var src = r.source_name
        ? (r.source_url
            ? '<a href="' + esc(r.source_url) + '" target="_blank" rel="noopener nofollow">' + esc(r.source_name) + "</a>"
            : esc(r.source_name))
        : "—";
      return '<article class="urgent-card" data-severity="' + esc(r.severity) + '">' +
        '<div class="urgent-card__top">' +
          '<span class="chip chip--sev" style="color:' + esc(sevColor) + '">' + esc(r.severity_label || sevLabel(r.severity)) + "</span>" +
          '<span class="urgent-card__no mono">#' + esc(r.id) + "</span>" +
        "</div>" +
        '<h3 class="urgent-card__title"><a href="/reports/' + esc(r.id) + '">' + esc(r.title) + "</a></h3>" +
        '<p class="urgent-card__snippet">' + (snippet || '<span class="faint">—</span>') + "</p>" +
        '<div class="urgent-card__chips">' + chips + "</div>" +
        '<div class="urgent-card__foot"><span class="urgent-card__src">' + src + "</span>" +
          '<a class="urgent-card__open" href="/reports/' + esc(r.id) + '">→</a></div>' +
      "</article>";
    }
    function render(data) {
      var c = data.collection || {};
      setMetric("[data-urgent-added-1h]", c.added_1h);
      setMetric("[data-urgent-added-24h]", c.added_24h);
      setMetric("[data-urgent-critical-24h]", c.critical_24h);
      if (data.catalog && data.catalog.enabled != null) setMetric("[data-urgent-sources]", data.catalog.enabled);
      var items = data.items || [];
      if (list && items.length) {
        var topId = items[0].id;
        if (topId !== lastTopId) {
          list.innerHTML = items.map(card).join("");
          if (lastTopId !== null && liveRegion && topId > lastTopId) {
            liveRegion.textContent = (I18N.addedOk || "New report") + ": " + items[0].title;
          }
          lastTopId = topId;
        }
      }
      if (statusBox) statusBox.classList.remove("is-degraded");
    }
    function fail() {
      if (statusBox) {
        statusBox.classList.add("is-degraded");
        var txt = statusBox.querySelector(".urgent__status-text");
        if (txt && I18N.degraded) txt.textContent = I18N.degraded;
      }
    }
    function poll() {
      fetch(I18N.endpoint || "/api/urgent?limit=6", { headers: { Accept: "application/json" } })
        .then(function (r) { if (!r.ok) throw new Error("bad"); return r.json(); })
        .then(render)
        .catch(fail);
    }
    // أول عنصر معروض يُعتبر الأساس (بلا إعلان «جديد» عند التحميل الأول).
    var firstCard = list && list.querySelector(".urgent-card__no");
    if (firstCard) lastTopId = parseInt(firstCard.textContent.replace(/[^0-9]/g, ""), 10) || null;
    setInterval(poll, 60000);
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) poll();
    });
  })();

  // فهرس المحتويات العام (صفحة «عن المنصة» وغيرها): تمييز القسم الحالي + نسخ الرابط.
  var genericToc = document.querySelectorAll(".toc a[href^='#']");
  if (genericToc.length) {
    genericToc.forEach(function (a) {
      a.addEventListener("click", function () {
        var link = window.location.origin + window.location.pathname + a.getAttribute("href");
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(link);
      });
    });
    if ("IntersectionObserver" in window) {
      var gSections = [];
      genericToc.forEach(function (a) {
        var sec = document.getElementById(a.getAttribute("href").slice(1));
        if (sec) gSections.push(sec);
      });
      var gSpy = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          genericToc.forEach(function (a) {
            a.classList.toggle("is-active", a.getAttribute("href") === "#" + en.target.id);
          });
        });
      }, { rootMargin: "-84px 0px -70% 0px", threshold: 0 });
      gSections.forEach(function (s) { gSpy.observe(s); });
    }
  }

  // ---------------------------------------------------------------------
  // المجتمع: التفاعل على المنشور (إعجاب/تعليق/إبلاغ/حجب) — دفعة 3
  // ---------------------------------------------------------------------
  var postActions = document.querySelector("[data-post-actions]");
  if (postActions) {
    var postId = postActions.getAttribute("data-post-id");
    var identitySel = postActions.querySelector("[data-identity]");
    var note = postActions.querySelector("[data-action-note]");
    var i18n = window.MIRSAD_I18N || {};
    var t = function (k, fb) { return (i18n[k] || fb || k); };

    function showNote(msg, ok) {
      if (!note) return;
      note.textContent = msg;
      note.hidden = false;
      note.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { note.hidden = true; }, 4000);
    }
    function identity() { return identitySel ? identitySel.value : ""; }
    function post(url, params, done) {
      var qs = Object.keys(params).map(function (k) {
        return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]);
      }).join("&");
      fetch(url + (qs ? "?" + qs : ""), { method: "POST" })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok) { showNote(t("action.error", "تعذّر التنفيذ"), false); return; }
          done(res.body);
        })
        .catch(function () { showNote(t("action.error", "تعذّر التنفيذ"), false); });
    }

    postActions.querySelectorAll("[data-react]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        if (!identity()) { showNote(t("comments.no_identity", "اختر عضوًا"), false); return; }
        post("/api/posts/" + postId + "/react", { handle: identity(), kind: btn.getAttribute("data-react") }, function (body) {
          if (typeof body.count === "number") {
            var c = btn.querySelector(".react-btn__count");
            if (c) c.textContent = body.count;
          }
          btn.classList.toggle("is-active", !!body.active);
          btn.setAttribute("aria-pressed", body.active ? "true" : "false");
        });
      });
    });

    var reportBtn = postActions.querySelector("[data-report-post]");
    if (reportBtn) {
      reportBtn.addEventListener("click", function () {
        var reason = window.prompt(t("post.report_reason", "سبب الإبلاغ"));
        if (!reason) return;
        post("/api/posts/" + postId + "/report", { handle: identity(), reason: reason }, function () {
          showNote(t("post.reported", "تم استلام الإبلاغ، شكرًا."), true);
        });
      });
    }
  }

  // التعليقات: إرسال جديد أو ردّ على تعليق.
  var commentsRoot = document.querySelector("[data-comments]");
  if (commentsRoot) {
    var cPostId = commentsRoot.getAttribute("data-post-id");
    var form = commentsRoot.querySelector("[data-comment-form]");
    var bodyField = commentsRoot.querySelector("[data-comment-body]");
    var replyNote = commentsRoot.querySelector("[data-reply-note]");
    var replyTo = null;
    var actions = document.querySelector("[data-post-actions]");
    var identitySel2 = actions ? actions.querySelector("[data-identity]") : null;

    commentsRoot.querySelectorAll("[data-reply-to]").forEach(function (b) {
      b.addEventListener("click", function () {
        replyTo = b.getAttribute("data-reply-to");
        if (replyNote) {
          replyNote.textContent = "↳ " + (i18n["comments.reply"] || "ردّ");
          replyNote.hidden = false;
        }
        if (bodyField) bodyField.focus();
      });
    });

    if (form) {
      form.addEventListener("submit", function (ev) {
        ev.preventDefault();
        var text = bodyField ? bodyField.value.trim() : "";
        if (text.length < 2) return;
        var who = identitySel2 ? identitySel2.value : "";
        if (!who) { window.alert(i18n["comments.no_identity"] || "اختر عضوًا"); return; }
        var params = { handle: who, body: text };
        if (replyTo) params.parent_id = replyTo;
        var qs = Object.keys(params).map(function (k) {
          return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]);
        }).join("&");
        fetch("/api/posts/" + cPostId + "/comment?" + qs, { method: "POST" })
          .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
          .then(function () { window.location.reload(); })
          .catch(function () { window.alert(i18n["action.error"] || "تعذّر التنفيذ"); });
      });
    }
  }

  // المجموعات: انضمام/مغادرة (الدفعة 4)
  var groupActions = document.querySelector("[data-group-actions]");
  if (groupActions) {
    var gSlug = groupActions.getAttribute("data-slug");
    var gSel = groupActions.querySelector("[data-identity]");
    var gNote = groupActions.querySelector("[data-action-note]");
    var gi18n = window.MIRSAD_I18N || {};
    function gShow(msg, ok) {
      if (!gNote) return;
      gNote.textContent = msg; gNote.hidden = false;
      gNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { gNote.hidden = true; }, 4000);
    }
    function gWho() { return gSel ? gSel.value : ""; }
    function gPost(path, done) {
      if (!gWho()) { gShow(gi18n["comments.no_identity"] || "اختر عضوًا", false); return; }
      fetch(path + "?handle=" + encodeURIComponent(gWho()), { method: "POST" })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok) { gShow(gi18n["action.error"] || "تعذّر التنفيذ", false); return; }
          done(res.body);
        })
        .catch(function () { gShow(gi18n["action.error"] || "تعذّر التنفيذ", false); });
    }
    var joinBtn = groupActions.querySelector("[data-join]");
    if (joinBtn) joinBtn.addEventListener("click", function () {
      gPost("/api/groups/" + gSlug + "/join", function (b) {
        gShow(b.status === "pending" ? (gi18n["groups.pending"] || "بانتظار الموافقة")
                                     : (gi18n["groups.joined"] || "عضو"), true);
      });
    });
    var leaveBtn = groupActions.querySelector("[data-leave]");
    if (leaveBtn) leaveBtn.addEventListener("click", function () {
      gPost("/api/groups/" + gSlug + "/leave", function () {
        gShow(gi18n["action.done"] || "تم", true);
      });
    });
  }

  // الرسائل: إرسال رسالة (الدفعة 5)
  var compose = document.querySelector("[data-compose]");
  if (compose) {
    var thread = document.querySelector("[data-thread]");
    compose.addEventListener("submit", function (e) {
      e.preventDefault();
      var ta = compose.querySelector("textarea");
      var body = (ta.value || "").trim();
      if (!body || !thread) return;
      var cid = thread.getAttribute("data-cid");
      var who = thread.getAttribute("data-handle");
      var qs = "handle=" + encodeURIComponent(who) + "&body=" + encodeURIComponent(body);
      fetch("/api/conversations/" + cid + "/messages?" + qs, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
        .then(function () { window.location.reload(); })
        .catch(function () { window.alert((window.MIRSAD_I18N || {})["action.error"] || "تعذّر التنفيذ"); });
    });
  }

  // التحقّق: إسناد/مراجعة/إضافة مصدر (الدفعة 6)
  var claimActions = document.querySelector("[data-claim-actions]");
  if (claimActions) {
    var cRef = claimActions.getAttribute("data-ref");
    var cSel = claimActions.querySelector("[data-identity]");
    var aSel = claimActions.querySelector("[data-assignee]");
    var noteEl = claimActions.querySelector("[data-review-note]");
    var cNote = claimActions.querySelector("[data-action-note]");
    function cShow(msg, ok) {
      if (!cNote) return;
      cNote.textContent = msg; cNote.hidden = false;
      cNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { cNote.hidden = true; }, 4000);
    }
    function cWho() { return cSel ? cSel.value : ""; }
    function cPost(path, done) {
      if (!cWho()) { cShow((window.MIRSAD_I18N || {})["comments.no_identity"] || "اختر هوية", false); return; }
      fetch(path, { method: "POST" })
        .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok) { cShow((window.MIRSAD_I18N || {})["action.error"] || "تعذّر التنفيذ", false); return; }
          if (done) done(res.body); else window.location.reload();
        })
        .catch(function () { cShow((window.MIRSAD_I18N || {})["action.error"] || "تعذّر التنفيذ", false); });
    }
    claimActions.querySelectorAll("[data-review]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var decision = btn.getAttribute("data-review");
        var note = noteEl ? noteEl.value : "";
        var qs = "handle=" + encodeURIComponent(cWho()) + "&decision=" + encodeURIComponent(decision)
               + "&note=" + encodeURIComponent(note);
        cPost("/api/claims/" + cRef + "/review?" + qs);
      });
    });
    var assignBtn = claimActions.querySelector("[data-assign]");
    if (assignBtn) assignBtn.addEventListener("click", function () {
      var target = aSel ? aSel.value : "";
      if (!target) { cShow((window.MIRSAD_I18N || {})["verify.unassigned"] || "اختر محقّقًا", false); return; }
      var qs = "handle=" + encodeURIComponent(cWho()) + "&assignee=" + encodeURIComponent(target);
      cPost("/api/claims/" + cRef + "/assign?" + qs);
    });
    var addSrc = claimActions.querySelector("[data-add-source]");
    if (addSrc) addSrc.addEventListener("click", function () {
      var labelEl = claimActions.querySelector("[data-source-label]");
      var urlEl = claimActions.querySelector("[data-source-url]");
      var label = labelEl ? labelEl.value : "";
      if (!label.trim()) { cShow((window.MIRSAD_I18N || {})["verify.source_label"] || "وصف المصدر", false); return; }
      var qs = "handle=" + encodeURIComponent(cWho()) + "&label=" + encodeURIComponent(label)
             + "&url=" + encodeURIComponent(urlEl ? urlEl.value : "");
      cPost("/api/claims/" + cRef + "/sources?" + qs);
    });
  }

  // الإشراف: حالات الإبلاغ + مراجعة الاستئناف + تطبيق إجراء (الدفعة 7)
  var modConsole = document.querySelector("[data-mod-console]");
  var modIdentity = modConsole ? modConsole.querySelector("[data-mod-identity]") : null;
  function modWho() { return modIdentity ? modIdentity.value : ""; }
  function modShow(msg, ok) {
    if (!modConsole) return;
    var n = modConsole.querySelector("[data-mod-note]");
    if (!n) return;
    n.textContent = msg; n.hidden = false;
    n.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
    window.setTimeout(function () { n.hidden = true; }, 4000);
  }
  function modPost(path, okMsg) {
    if (!modWho()) { modShow((window.MIRSAD_I18N || {})["comments.no_identity"] || "اختر هوية", false); return; }
    fetch(path, { method: "POST" })
      .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
      .then(function () { window.location.reload(); })
      .catch(function () { modShow((window.MIRSAD_I18N || {})["action.error"] || "تعذّر التنفيذ", false); });
  }
  document.querySelectorAll("[data-report-state]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var st = btn.getAttribute("data-report-state");
      var rid = btn.getAttribute("data-report-id");
      var qs = "handle=" + encodeURIComponent(modWho()) + "&state=" + encodeURIComponent(st);
      modPost("/api/moderation/reports/" + rid + "/state?" + qs);
    });
  });
  document.querySelectorAll("[data-appeal-review]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var dec = btn.getAttribute("data-appeal-review");
      var aid = btn.getAttribute("data-appeal-id");
      var qs = "handle=" + encodeURIComponent(modWho()) + "&decision=" + encodeURIComponent(dec);
      modPost("/api/appeals/" + aid + "/review?" + qs);
    });
  });
  var modApply = modConsole ? modConsole.querySelector("[data-mod-apply]") : null;
  if (modApply) modApply.addEventListener("click", function () {
    var kind = (modConsole.querySelector("[data-mod-kind]") || {}).value || "member";
    var tid = (modConsole.querySelector("[data-mod-target-id]") || {}).value || "0";
    var th = (modConsole.querySelector("[data-mod-target-handle]") || {}).value || "";
    var act = (modConsole.querySelector("[data-mod-action]") || {}).value || "";
    var days = (modConsole.querySelector("[data-mod-days]") || {}).value || "";
    var reason = (modConsole.querySelector("[data-mod-reason]") || {}).value || "";
    if (reason.trim().length < 5) { modShow((window.MIRSAD_I18N || {})["mod.reason"] || "السبب إلزامي", false); return; }
    var qs = "handle=" + encodeURIComponent(modWho()) + "&target_kind=" + encodeURIComponent(kind)
           + "&target_id=" + encodeURIComponent(tid) + "&target_handle=" + encodeURIComponent(th)
           + "&action=" + encodeURIComponent(act) + "&reason=" + encodeURIComponent(reason);
    if (days) qs += "&days=" + encodeURIComponent(days);
    modPost("/api/moderation/actions?" + qs);
  });

  // الثقة: تأييد وضمان (الدفعة 8)
  var trustPanel = document.querySelector("[data-trust-panel]");
  if (trustPanel) {
    var tIdentity = trustPanel.querySelector("[data-trust-identity]");
    var tNote = trustPanel.querySelector("[data-trust-note]");
    var tHandle = trustPanel.getAttribute("data-handle");
    function tShow(msg, ok) {
      if (!tNote) return;
      tNote.textContent = msg; tNote.hidden = false;
      tNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { tNote.hidden = true; }, 4000);
    }
    function tWho() { return tIdentity ? tIdentity.value : ""; }
    var endorseBtn = trustPanel.querySelector("[data-endorse]");
    if (endorseBtn) endorseBtn.addEventListener("click", function () {
      if (!tWho()) { tShow((window.MIRSAD_I18N || {})["comments.no_identity"] || "اختر هوية", false); return; }
      var dim = (trustPanel.querySelector("[data-endorse-dim]") || {}).value || "accuracy";
      var qs = "handle_by=" + encodeURIComponent(tWho()) + "&dimension=" + encodeURIComponent(dim);
      fetch("/api/members/" + encodeURIComponent(tHandle) + "/endorse?" + qs, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { window.location.reload(); })
        .catch(function (e) { tShow((e && e.error) || "تعذّر التأييد", false); });
    });
    var vouchBtn = trustPanel.querySelector("[data-vouch]");
    if (vouchBtn) vouchBtn.addEventListener("click", function () {
      if (!tWho()) { tShow((window.MIRSAD_I18N || {})["comments.no_identity"] || "اختر هوية", false); return; }
      var qs = "handle_by=" + encodeURIComponent(tWho()) + "&kind=peer";
      fetch("/api/members/" + encodeURIComponent(tHandle) + "/vouch?" + qs, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { window.location.reload(); })
        .catch(function (e) { tShow((e && e.error) || "تعذّر الضمان", false); });
    });
  }

  // الإشعارات: قراءة، اشتراكات، ساعات هدوء، كتم شامل (الدفعة 9)
  var notifCenter = document.querySelector("[data-notif-center]");
  if (notifCenter) {
    var nHandle = notifCenter.getAttribute("data-handle") || "";
    var nIdentity = notifCenter.querySelector("[data-notif-identity]");
    var nNote = notifCenter.querySelector("[data-notif-note]");
    if (nIdentity) nIdentity.addEventListener("change", function () {
      window.location.href = "/notifications?handle=" + encodeURIComponent(nIdentity.value);
    });
    function nWho() { return nHandle; }
    function nShow(msg, ok) {
      if (!nNote) return;
      nNote.textContent = msg; nNote.hidden = false;
      nNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { nNote.hidden = true; }, 4000);
    }
    function nPost(path, reload) {
      fetch(path, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
        .then(function (d) {
          if (reload) window.location.reload();
          else if (d && d.error === "suppressed") nShow((window.MIRSAD_I18N || {})["notif.test_suppressed"] || "مكتوم", false);
          else nShow((window.MIRSAD_I18N || {})["notif.test_sent"] || "أُرسل", true);
        })
        .catch(function () { nShow("تعذّر التنفيذ", false); });
    }
    if (!nWho()) { /* لا هوية محدّدة */ }
    var readAll = notifCenter.querySelector("[data-notif-read-all]");
    if (readAll) readAll.addEventListener("click", function () {
      if (!nWho()) { nShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      nPost("/api/notifications/read?handle=" + encodeURIComponent(nWho()), true);
    });
    notifCenter.querySelectorAll("[data-notif-read]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        nPost("/api/notifications/read?handle=" + encodeURIComponent(nWho()) + "&id=" + btn.getAttribute("data-notif-read"), true);
      });
    });
    var testBtn = notifCenter.querySelector("[data-notif-test]");
    if (testBtn) testBtn.addEventListener("click", function () {
      if (!nWho()) { nShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      nPost("/api/notifications/test?handle=" + encodeURIComponent(nWho()), false);
    });
    var addSub = notifCenter.querySelector("[data-sub-add]");
    if (addSub) addSub.addEventListener("click", function () {
      if (!nWho()) { nShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      var k = (notifCenter.querySelector("[data-sub-kind]") || {}).value || "category";
      var v = (notifCenter.querySelector("[data-sub-value]") || {}).value || "";
      if (!v.trim()) return;
      nPost("/api/subscriptions?handle=" + encodeURIComponent(nWho()) + "&kind=" + encodeURIComponent(k) + "&value=" + encodeURIComponent(v.trim()), true);
    });
    notifCenter.querySelectorAll("[data-sub-remove]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var k = btn.getAttribute("data-sub-kind"), v = btn.getAttribute("data-sub-value");
        fetch("/api/subscriptions?handle=" + encodeURIComponent(nWho()) + "&kind=" + encodeURIComponent(k) + "&value=" + encodeURIComponent(v), { method: "DELETE" })
          .then(function () { window.location.reload(); })
          .catch(function () { nShow("تعذّر الحذف", false); });
      });
    });
    var quietSave = notifCenter.querySelector("[data-quiet-save]");
    if (quietSave) quietSave.addEventListener("click", function () {
      if (!nWho()) { nShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      var s = (notifCenter.querySelector("[data-quiet-start]") || {}).value || "22";
      var e = (notifCenter.querySelector("[data-quiet-end]") || {}).value || "7";
      var tz = (notifCenter.querySelector("[data-quiet-tz]") || {}).value || "UTC";
      nPost("/api/notifications/quiet-hours?handle=" + encodeURIComponent(nWho()) + "&start_hour=" + encodeURIComponent(s) + "&end_hour=" + encodeURIComponent(e) + "&tz=" + encodeURIComponent(tz), true);
    });
    var muteAll = notifCenter.querySelector("[data-notif-mute-all]");
    if (muteAll) muteAll.addEventListener("click", function () {
      if (!nWho()) { nShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      nPost("/api/notifications/mute-all?handle=" + encodeURIComponent(nWho()), true);
    });
  }

  // الاستكشاف: اقتراحات فورية + تبديل الأنواع + بحث محفوظ (الدفعة 10)
  var discover = document.querySelector("[data-discover]");
  var dForm = document.querySelector("[data-discover-form]");
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  if (dForm) {
    var dInput = dForm.querySelector("[data-discover-input]");
    var dKind = dForm.querySelector("[data-discover-kind]");
    var dSuggest = document.querySelector("[data-discover-suggest]");
    var dTimer = null;
    function dFetchSuggest() {
      var q = (dInput.value || "").trim();
      if (!q || !dSuggest) { if (dSuggest) dSuggest.hidden = true; return; }
      fetch("/api/search/suggest?q=" + encodeURIComponent(q) + "&limit=6")
        .then(function (r) { return r.json(); })
        .then(function (d) {
          var parts = [];
          if (d.correction) parts.push('<a href="/discover?q=' + encodeURIComponent(d.correction) + '">' + esc(d.correction) + '</a>');
          (d.queries || []).forEach(function (sug) {
            parts.push('<button type="button" data-sug="' + esc(sug.value) + '">' + esc(sug.value) + (sug.count ? ' · ' + sug.count : '') + '</button>');
          });
          (d.completions || []).forEach(function (w) {
            if (!parts.some(function (p) { return p.indexOf(esc(w)) >= 0; })) {
              parts.push('<button type="button" data-sug="' + esc(w) + '">' + esc(w) + '</button>');
            }
          });
          if (parts.length) { dSuggest.innerHTML = parts.join(""); dSuggest.hidden = false; }
          else dSuggest.hidden = true;
        })
        .catch(function () { if (dSuggest) dSuggest.hidden = true; });
    }
    if (dInput) {
      dInput.addEventListener("input", function () {
        window.clearTimeout(dTimer);
        dTimer = window.setTimeout(dFetchSuggest, 260);
      });
    }
    if (dSuggest) dSuggest.addEventListener("click", function (e) {
      var b = e.target.closest("[data-sug]");
      if (!b) return;
      dInput.value = b.getAttribute("data-sug");
      dSuggest.hidden = true;
      dForm.submit();
    });
    document.querySelectorAll("[data-kind-toggle]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var v = btn.getAttribute("data-kind-toggle");
        if (dKind) dKind.value = v;
        dForm.submit();
      });
    });
  }
  if (discover) {
    var dHandle = discover.getAttribute("data-handle") || "";
    var saveBtn = discover.querySelector("[data-save-search]");
    if (saveBtn) saveBtn.addEventListener("click", function () {
      if (!dHandle) { window.alert((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية أولًا"); return; }
      var q = saveBtn.getAttribute("data-q") || "";
      var kinds = saveBtn.getAttribute("data-kinds") || "";
      fetch("/api/search/saved?handle=" + encodeURIComponent(dHandle) + "&q=" + encodeURIComponent(q) + "&kinds=" + encodeURIComponent(kinds), { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
        .then(function () { window.location.reload(); })
        .catch(function () { window.alert("تعذّر الحفظ"); });
    });
    discover.querySelectorAll("[data-unsave]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        fetch("/api/search/saved?handle=" + encodeURIComponent(dHandle) + "&id=" + btn.getAttribute("data-unsave"), { method: "DELETE" })
          .then(function () { window.location.reload(); })
          .catch(function () { window.alert("تعذّر الحذف"); });
      });
    });
  }

  // الحملات: توقيع آمن مع حماية هوية (الدفعة 11)
  var campEl = document.querySelector("[data-campaign]");
  if (campEl) {
    var campSlug = campEl.getAttribute("data-slug") || "";
    var campIdentity = campEl.querySelector("[data-camp-identity]");
    var campAnon = campEl.querySelector("[data-camp-anon]");
    var campSign = campEl.querySelector("[data-camp-sign]");
    var campNote = campEl.querySelector("[data-camp-note]");
    function cShow(msg, ok) {
      if (!campNote) return;
      campNote.textContent = msg; campNote.hidden = false;
      campNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { campNote.hidden = true; }, 4000);
    }
    if (campSign) campSign.addEventListener("click", function () {
      var who = campIdentity ? campIdentity.value : "";
      if (!who) { cShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      var qs = "handle=" + encodeURIComponent(who) + "&anonymous=" + (campAnon && campAnon.checked ? "1" : "0");
      fetch("/api/campaigns/" + encodeURIComponent(campSlug) + "/sign?" + qs, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { window.location.reload(); })
        .catch(function (e) { cShow((e && e.error) || "تعذّر التوقيع", false); });
    });
  }

  // التكامل والأتمتة: اختبار Webhooks، مزامنة موصلات، قواعد، وطابور (الدفعة 12)
  var integEl = document.querySelector("[data-integrations]");
  if (integEl) {
    function iPost(url, note, okMsg) {
      fetch(url, { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { if (note) { note.textContent = okMsg || "تمّ"; note.hidden = false; } window.setTimeout(function () { window.location.reload(); }, 500); })
        .catch(function (e) { if (note) { note.textContent = (e && e.error) || "تعذّر"; note.hidden = false; note.style.color = "var(--danger, #a12b2b)"; } });
    }
    var whNote = integEl.querySelector("[data-wh-note]");
    integEl.querySelectorAll("[data-wh-test]").forEach(function (b) {
      b.addEventListener("click", function () {
        iPost("/api/integrations/webhooks/test?event=" + encodeURIComponent(b.getAttribute("data-wh-test")), whNote, "أُرسل الحدث التجريبي");
      });
    });
    integEl.querySelectorAll("[data-conn-sync]").forEach(function (b) {
      b.addEventListener("click", function () { iPost("/api/integrations/connectors/" + b.getAttribute("data-conn-sync") + "/sync", null); });
    });
    integEl.querySelectorAll("[data-rule-run]").forEach(function (b) {
      b.addEventListener("click", function () { iPost("/api/integrations/rules/" + b.getAttribute("data-rule-run") + "/run", null); });
    });
    integEl.querySelectorAll("[data-rule-toggle]").forEach(function (b) {
      b.addEventListener("click", function () {
        iPost("/api/integrations/rules/" + b.getAttribute("data-rule-toggle") + "/toggle?enabled=" + b.getAttribute("data-enabled"), null);
      });
    });
    integEl.querySelectorAll("[data-job-finish]").forEach(function (b) {
      b.addEventListener("click", function () { iPost("/api/integrations/queue/" + b.getAttribute("data-job-finish") + "/finish?ok=1", null); });
    });
    var requeue = integEl.querySelector("[data-queue-requeue]");
    if (requeue) requeue.addEventListener("click", function () { iPost("/api/integrations/queue/requeue-failed", null); });
  }

  // الإدارة: أعلام النظام + حلّ الحوادث (الدفعة 13)
  var adminEl = document.querySelector("[data-admin]");
  if (adminEl) {
    var adminIdentity = adminEl.querySelector("[data-admin-identity]");
    var adminNote = adminEl.querySelector("[data-admin-note]");
    function aWho() { return adminIdentity ? adminIdentity.value : ""; }
    function aNote(msg, ok) {
      if (!adminNote) return;
      adminNote.textContent = msg; adminNote.hidden = false;
      adminNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { adminNote.hidden = true; }, 4000);
    }
    function aPost(url, okMsg) {
      if (!aWho()) { aNote((window.MIRSAD_I18N || {})["admin.forbidden"] || "تحتاج صلاحية إشراف", false); return; }
      fetch(url + "&handle=" + encodeURIComponent(aWho()), { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { aNote(okMsg || ((window.MIRSAD_I18N || {})["admin.saved"] || "تمّ الحفظ"), true); window.setTimeout(function () { window.location.reload(); }, 500); })
        .catch(function (e) { aNote((e && e.error) || "تعذّر", false); });
    }
    adminEl.querySelectorAll("[data-flag-set]").forEach(function (b) {
      b.addEventListener("click", function () {
        var cur = b.getAttribute("data-flag-set");
        var next = cur === "1" ? "0" : "1";
        aPost("/api/admin/flags?key=" + b.getAttribute("data-flag-key") + "&value=" + next);
      });
    });
    adminEl.querySelectorAll("[data-incident-resolve]").forEach(function (b) {
      b.addEventListener("click", function () {
        aPost("/api/admin/incidents/" + b.getAttribute("data-incident-resolve") + "/state?state=resolved");
      });
    });
  }

  // الملفات الحسّاسة: إيداع وصفي/ختم/سحب/طلب وصول/قرار (الدفعة 14) — محاكاة فقط
  var vaultEl = document.querySelector("[data-vault], [data-vault-item]");
  if (vaultEl) {
    var vIdentity = vaultEl.querySelector("[data-vault-identity]");
    var vNote = vaultEl.querySelector("[data-vault-note]");
    function vWho() { return vIdentity ? vIdentity.value : ""; }
    function vShow(msg, ok) {
      if (!vNote) return;
      vNote.textContent = msg; vNote.hidden = false;
      vNote.style.color = ok === false ? "var(--danger, #a12b2b)" : "var(--ok, #3f8f6b)";
      window.setTimeout(function () { vNote.hidden = true; }, 4000);
    }
    function vPost(url, okMsg) {
      if (!vWho()) { vShow((window.MIRSAD_I18N || {})["notif.choose_identity"] || "اختر هوية", false); return; }
      fetch(url + "&handle=" + encodeURIComponent(vWho()), { method: "POST" })
        .then(function (r) { return r.ok ? r.json() : r.json().then(function (j) { throw j; }); })
        .then(function () { vShow(okMsg || ((window.MIRSAD_I18N || {})["admin.saved"] || "تمّ"), true); window.setTimeout(function () { window.location.reload(); }, 500); })
        .catch(function (e) { vShow((window.MIRSAD_I18N || {})["vault.error"] || "تعذّر", false); });
    }
    var createBtn = vaultEl.querySelector("[data-vault-create]");
    if (createBtn) createBtn.addEventListener("click", function () {
      var title = vaultEl.querySelector("[data-vault-title]");
      var kind = vaultEl.querySelector("[data-vault-kind]");
      var cls = vaultEl.querySelector("[data-vault-class]");
      if (!title || !title.value.trim()) { vShow("اكتب عنوانًا وصفيًّا", false); return; }
      vPost("/api/vault/items?title=" + encodeURIComponent(title.value.trim())
        + "&kind=" + encodeURIComponent(kind ? kind.value : "document")
        + "&classification=" + encodeURIComponent(cls ? cls.value : "internal"));
    });
    var sealBtn = vaultEl.querySelector("[data-vault-seal]");
    if (sealBtn) sealBtn.addEventListener("click", function () {
      vPost("/api/vault/items/" + vaultEl.getAttribute("data-item-id") + "/state?state=sealed");
    });
    var revokeBtn = vaultEl.querySelector("[data-vault-revoke]");
    if (revokeBtn) revokeBtn.addEventListener("click", function () {
      vPost("/api/vault/items/" + vaultEl.getAttribute("data-item-id") + "/state?state=revoked");
    });
    var reqBtn = vaultEl.querySelector("[data-vault-request]");
    if (reqBtn) reqBtn.addEventListener("click", function () {
      var purpose = vaultEl.querySelector("[data-vault-purpose]");
      vPost("/api/vault/items/" + vaultEl.getAttribute("data-item-id") + "/request?purpose="
        + encodeURIComponent(purpose ? purpose.value : ""));
    });
    vaultEl.querySelectorAll("[data-access-decide]").forEach(function (b) {
      b.addEventListener("click", function () {
        vPost("/api/vault/access/" + b.getAttribute("data-access-decide") + "/decide?state="
          + b.getAttribute("data-decision"));
      });
    });
  }

  // إجراءات عامة مُفوَّضة (بدل onclick المضمّن) — تحترم سياسة أمان المحتوى.
  document.addEventListener("click", function (e) {
    var el = e.target && e.target.closest ? e.target.closest("[data-action]") : null;
    if (!el) return;
    var action = el.getAttribute("data-action");
    if (action === "print") { e.preventDefault(); window.print(); }
    else if (action === "back") { e.preventDefault(); history.back(); }
    else if (action === "reload") { e.preventDefault(); location.reload(); }
  });

  // شرح شارة التوثيق: يجلب أسباب التحقق والمصادر المستقلة ويعرضها في نافذة.
  (function () {
    var trigger = document.querySelector("[data-verify-explain]");
    var dlg = document.getElementById("verify-dialog");
    var body = dlg ? dlg.querySelector("[data-verify-body]") : null;
    if (!trigger || !dlg || !body || typeof dlg.showModal !== "function") return;
    var i18n = window.MIRSAD_I18N || {};
    function esc(s) {
      return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
        return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c];
      });
    }
    trigger.addEventListener("click", function () {
      var id = trigger.getAttribute("data-verify-explain");
      fetch("/api/reports/" + encodeURIComponent(id) + "/verification")
        .then(function (r) { return r.json(); })
        .then(function (data) {
          var ex = (data && data.explanation) || {};
          var rows = (ex.sources || []).map(function (s) {
            return "<li>" + esc(s.source_name) + " — " + esc(s.independence)
              + (s.source_url ? ' <a href="' + esc(s.source_url) + '" rel="noopener nofollow" target="_blank">↗</a>' : "")
              + "</li>";
          }).join("");
          var reasons = (ex.reasons || []).map(function (r) { return "<li>" + esc(r) + "</li>"; }).join("");
          body.innerHTML =
            "<h2>" + esc(i18n.badgeTitle || "شرح التوثيق") + "</h2>" +
            "<p>" + esc(i18n.badgeIndependent || "مصادر مستقلة") + ": <strong>" + esc(ex.independent_sources || 0) + "</strong></p>" +
            (reasons ? "<ul>" + reasons + "</ul>" : "") +
            (rows ? "<h3>" + esc(i18n.badgeSources || "المصادر") + "</h3><ul>" + rows + "</ul>" : "") +
            '<p><button type="button" class="btn btn--sm" data-dialog-close>' + esc(i18n.close || "إغلاق") + "</button></p>";
          var closeBtn = body.querySelector("[data-dialog-close]");
          if (closeBtn) closeBtn.addEventListener("click", function () { dlg.close(); });
          dlg.showModal();
        });
    });
  })();
})();
