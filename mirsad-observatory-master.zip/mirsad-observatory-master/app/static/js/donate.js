/* تفاعلات صفحة التبرّع: المبلغ المخصّص، بطاقات المنظّمات، وحالة الفراغ. */
(function () {
  "use strict";

  // المبلغ المخصّص: عند إدخال قيمة نُلغي اختيار الرقاقات والعكس.
  document.querySelectorAll("[data-custom-input]").forEach(function (input) {
    var fieldset = input.closest("fieldset");
    if (!fieldset) return;
    input.addEventListener("input", function () {
      fieldset.querySelectorAll('input[type="radio"]').forEach(function (r) { r.checked = false; });
    });
    fieldset.querySelectorAll('input[type="radio"]').forEach(function (r) {
      r.addEventListener("change", function () { input.value = ""; });
    });
  });

  // إظهار نموذج التبرّع الخيري عند اختيار منظّمة.
  var form = document.querySelector("[data-charity-form]");
  var target = document.querySelector("[data-charity-target]");
  var nameEl = document.querySelector("[data-charity-name]");
  document.querySelectorAll("[data-give]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (!form) return;
      form.hidden = false;
      if (target) target.value = btn.dataset.key || "";
      if (nameEl) nameEl.textContent = btn.dataset.name || "";
      form.scrollIntoView({ behavior: "smooth", block: "center" });
      var first = form.querySelector('input[type="radio"]');
      if (first) first.focus();
    });
  });

  // بحث/ترشيح فوري في شبكة المنظّمات (بلا إعادة تحميل).
  var search = document.querySelector('[data-table-search="charity-table"]');
  var grid = document.getElementById("charity-grid");
  var empty = document.querySelector("[data-charity-empty]");
  var count = document.querySelector("[data-charity-count]");
  function applyFilter() {
    if (!grid) return;
    var q = (search && search.value || "").trim().toLowerCase();
    var visible = 0;
    grid.querySelectorAll("[data-charity-item]").forEach(function (card) {
      var hay = (card.dataset.search || "") + " " + card.textContent.toLowerCase();
      var ok = !q || hay.indexOf(q) !== -1;
      card.hidden = !ok;
      if (ok) visible++;
    });
    if (empty) empty.hidden = visible !== 0;
    if (count) count.textContent = String(visible);
  }
  if (search && grid) {
    var t = null;
    search.addEventListener("input", function () {
      if (t) clearTimeout(t);
      t = setTimeout(applyFilter, 120);
    });
  }
})();
