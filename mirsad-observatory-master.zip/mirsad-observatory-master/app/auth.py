"""طبقة المصادقة: تسجيل الدخول/الإنشاء عبر Google ومزوّدي التواصل الاجتماعي.

تصميم بلا اعتماديات خارجية (لا مكتبة OAuth):
- تدفّق OAuth 2.0 Authorization Code مع حماية `state` عبر كوكي موقّع.
- عند غياب إعداد المزوّد يعمل «وضع تجريبي» محلي يُنشئ حسابًا محليًّا ليتيح
  تجربة الواجهة كاملةً دون شبكة أو مفاتيح (لا يُستخدم في الإنتاج).

الجلسات تُخزَّن في قاعدة البيانات ببصمة SHA-256 للرمز فقط؛ لا يُحفظ الرمز
الخام، والكوكي `HttpOnly` + `SameSite=Lax`.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import sqlite3
import time
import urllib.parse
from typing import Any

from .config import (
    OAUTH_PROVIDERS,
    SESSION_DAYS,
    SECRET_KEY,
    provider_client_id,
    provider_client_secret,
    provider_configured,
)

SESSION_COOKIE = "mirsad_session"
_STATE_COOKIE = "mirsad_oauth_state"


def const_eq(a: Any, b: Any) -> bool:
    """مقارنة ثابتة الزمن لا تنكسر عند محارف غير ASCII.

    `hmac.compare_digest` يرفض النصوص التي تحوي محارف خارج نطاق ASCII
    (`TypeError`)، ومدخلات المستخدم قد تحويها فتسبّب خطأ 500. نقارن هنا
    التمثيل البايتي (UTF-8) كي نبقى ثابتي الزمن دون انفجار.
    """
    if a is None or b is None:
        return a is b
    if isinstance(a, str):
        a = a.encode("utf-8")
    if isinstance(b, str):
        b = b.encode("utf-8")
    return hmac.compare_digest(a, b)


# ---------------------------------------------------------------------------
# أدوات التوقيع والرموز
# ---------------------------------------------------------------------------

def _b64(data: bytes) -> str:
    return urllib.parse.quote(data.decode("latin-1"), safe="")


def _sign(payload: str) -> str:
    return hmac.new(SECRET_KEY.encode(), payload.encode(), hashlib.sha256).hexdigest()[:32]


def make_state(next_url: str, provider: str) -> str:
    """يبني قيمة `state` موقّعة تحمل الوجهة والمزوّد وطابعًا زمنيًّا."""
    nonce = secrets.token_urlsafe(16)
    body = json.dumps({"n": nonce, "p": provider, "x": next_url, "t": int(time.time())},
                      ensure_ascii=False, separators=(",", ":"))
    return _b64(body.encode()) + "." + _sign(body)


def verify_state(value: str) -> dict[str, Any] | None:
    """يتحقّق من توقيع `state` وصلاحيته الزمنية (10 دقائق) ويعيد حمولته."""
    if not value or "." not in value:
        return None
    b64, sig = value.rsplit(".", 1)
    try:
        body = urllib.parse.unquote_to_bytes(b64).decode()
    except Exception:  # noqa: BLE001
        return None
    if not const_eq(sig, _sign(body)):
        return None
    try:
        data = json.loads(body)
    except ValueError:
        return None
    if int(time.time()) - int(data.get("t", 0)) > 600:
        return None
    return data


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def new_token() -> str:
    return secrets.token_urlsafe(32)


# ---------------------------------------------------------------------------
# المستخدمون والجلسات
# ---------------------------------------------------------------------------

def _now_plus_days(days: int) -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.time() + days * 86400))


def get_or_create_user(conn: sqlite3.Connection, provider: str, profile: dict) -> dict:
    """يُنشئ/يعيد مستخدمًا مرتبطًا بهويّة المزوّد.

    الربط بمفتاح (المزوّد + المعرّف الخارجي) أولًا، ثم بالبريد إن وُجد، وإلا
    يُنشأ مستخدم جديد.
    """
    uid = str(profile.get("id") or "").strip()
    email = (profile.get("email") or "").strip().lower() or None
    name = (profile.get("name") or "").strip() or (email.split("@")[0] if email else "مستخدم مِرصد")
    avatar = profile.get("avatar") or None

    row = None
    if uid:
        row = conn.execute(
            "SELECT u.* FROM users u JOIN user_identities i ON i.user_id = u.id "
            "WHERE i.provider = ? AND i.provider_uid = ?", (provider, uid)).fetchone()
    if row is None and email:
        row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

    if row is None:
        cur = conn.execute(
            "INSERT INTO users (email, display_name, avatar_url, role, status) "
            "VALUES (?,?,?, 'member', 'active')", (email, name, avatar))
        user_id = cur.lastrowid
    else:
        user_id = row["id"]
        # حدّث الاسم/الصورة عند توفّرها، واربط البريد إن كان ناقصًا.
        conn.execute(
            "UPDATE users SET display_name = COALESCE(NULLIF(?, ''), display_name), "
            "avatar_url = COALESCE(?, avatar_url), email = COALESCE(email, ?) WHERE id = ?",
            (name, avatar, email, user_id))

    if uid:
        conn.execute(
            "INSERT OR IGNORE INTO user_identities (user_id, provider, provider_uid, email) "
            "VALUES (?,?,?,?)", (user_id, provider, uid, email))
    conn.execute("UPDATE users SET last_login_at = datetime('now') WHERE id = ?", (user_id,))
    conn.commit()
    return dict(conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone())


def create_session(conn: sqlite3.Connection, user_id: int, user_agent: str = "") -> str:
    token = new_token()
    conn.execute(
        "INSERT INTO sessions (token_hash, user_id, expires_at, user_agent) VALUES (?,?,?,?)",
        (token_hash(token), user_id, _now_plus_days(SESSION_DAYS), (user_agent or "")[:300]))
    conn.commit()
    return token


def user_for_session(conn: sqlite3.Connection, token: str | None) -> dict | None:
    """يعيد المستخدم النشط للرمز، ويحذف الجلسة إن انتهت صلاحيتها."""
    if not token:
        return None
    row = conn.execute(
        "SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id "
        "WHERE s.token_hash = ?", (token_hash(token),)).fetchone()
    if not row:
        return None
    if str(row["expires_at"]) < time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()):
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(token),))
        conn.commit()
        return None
    if row["status"] != "active":
        return None
    return dict(row)


def delete_session(conn: sqlite3.Connection, token: str | None) -> None:
    if token:
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash(token),))
        conn.commit()


def purge_expired(conn: sqlite3.Connection) -> None:
    conn.execute("DELETE FROM sessions WHERE expires_at < datetime('now')")
    conn.commit()


def user_count(conn: sqlite3.Connection) -> int:
    return int(conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"])


# ---------------------------------------------------------------------------
# مزوّدو OAuth
# ---------------------------------------------------------------------------

def providers_for_ui(lang: str = "ar") -> list[dict]:
    """قائمة المزوّدين لعرضها في صفحة الدخول (مع حالة التهيئة)."""
    out = []
    for key, meta in OAUTH_PROVIDERS.items():
        out.append({
            "key": key,
            "name": meta["name_ar"] if lang == "ar" else meta["name_en"],
            "icon": meta["icon"],
            "color": meta["color"],
            "configured": provider_configured(key),
        })
    return out


def authorize_url(provider: str, redirect_uri: str, state: str) -> str | None:
    meta = OAUTH_PROVIDERS.get(provider)
    if not meta:
        return None
    params = {
        "client_id": provider_client_id(provider) or f"demo-{provider}",
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": meta["scope"],
        "state": state,
    }
    return meta["authorize"] + "?" + urllib.parse.urlencode(params)


def exchange_code(provider: str, code: str, redirect_uri: str) -> dict | None:
    """يستبدل رمز التفويض برمز وصول ثم يجلب الملف الشخصي. يعيد None عند الفشل."""
    meta = OAUTH_PROVIDERS.get(provider)
    if not meta:
        return None
    import httpx
    try:
        data = {
            "client_id": provider_client_id(provider),
            "client_secret": provider_client_secret(provider),
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri,
        }
        headers = {"Accept": "application/json"}
        with httpx.Client(timeout=20) as client:
            tok = client.post(meta["token"], data=data, headers=headers)
            tok.raise_for_status()
            access = tok.json().get("access_token")
            if not access:
                return None
            ui = client.get(meta["userinfo"], headers={
                "Authorization": f"Bearer {access}", "Accept": "application/json"})
            ui.raise_for_status()
            raw = ui.json()
    except Exception:  # noqa: BLE001 — أي فشل شبكي/صيغة يُعدّ فشل مصادقة
        return None
    # بعض المزوّدين يلفّون النتيجة في data/response، وبعضها يعيد الصورة ككائن.
    payload = raw.get("data") if isinstance(raw.get("data"), dict) else raw
    avatar = payload.get(meta["avatar_key"])
    if isinstance(avatar, dict):
        avatar = (avatar.get("data") or {}).get("url") or avatar.get("url")
    return {
        "id": payload.get(meta["id_key"]),
        "email": payload.get(meta["email_key"]),
        "name": payload.get(meta["name_key"]),
        "avatar": avatar,
    }


def demo_profile(provider: str) -> dict:
    """ملف شخصي تجريبي لمزوّد غير مُهيّأ (لتجربة الواجهة دون شبكة)."""
    meta = OAUTH_PROVIDERS.get(provider, {})
    name = (meta.get("name_ar") or provider)
    handle = f"{provider}_{secrets.token_hex(3)}"
    return {
        "id": f"demo-{provider}-{secrets.token_hex(4)}",
        "email": f"{handle}@example.invalid",
        "name": f"مستخدم {name} (تجريبي)",
        "avatar": None,
    }
