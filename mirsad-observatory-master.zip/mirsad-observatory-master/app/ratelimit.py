"""تقييد معدّل الطلبات في الذاكرة (بلا اعتماد خارجي).

يُستخدم لحماية نقاط الكتابة الاجتماعية (تفاعل/تعليق/إبلاغ) من الإساءة.
حدود بسيطة لكل (مفتاح، إجراء) داخل نافذة زمنية متحرّكة. الذاكرة مؤقّتة
وتُصفَّر عند إعادة التشغيل، وهو مقبول لطبقة اجتماعية بلا حسابات مصادَقة.
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque

_lock = threading.Lock()
_hits: dict[tuple[str, str], deque[float]] = defaultdict(deque)


def allow(key: str, action: str, limit: int, window: float = 60.0) -> bool:
    """هل يُسمح بطلب جديد؟ يسجّل الطلب عند السماح."""
    now = time.monotonic()
    k = (key or "anon", action)
    with _lock:
        q = _hits[k]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            return False
        q.append(now)
        return True


def retry_after(key: str, action: str, window: float = 60.0) -> int:
    """عدد الثواني المتبقّية حتى إتاحة طلب جديد (تقريبي)."""
    now = time.monotonic()
    with _lock:
        q = _hits.get((key or "anon", action))
        if not q:
            return 0
        return max(0, int(window - (now - q[0])) + 1)


def reset() -> None:
    """يفرّغ كل السجلّات (للاختبارات)."""
    with _lock:
        _hits.clear()
