"""تطبيق «مِرصد» — منصة توثيق الانتهاكات.

واجهات صفحات (HTML/Jinja2) وواجهة برمجة REST، مع تصدير بصيغ مفتوحة
(CSV/JSON/JSON Feed/RSS) واستيراد من مصادر مفتوحة.
"""

from datetime import date, timedelta
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional
import logging
import uuid

from urllib.parse import urlencode, quote

from fastapi import FastAPI, Form, Header, HTTPException, Query, Request
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    PlainTextResponse,
    RedirectResponse,
    Response,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from . import db, exports, importers, sources_registry, wikidata
from . import auth
from . import charities
from . import donations
from . import campaigns
from . import integrations
from . import ops
from . import ratelimit
from . import sensitive
from . import refresh
from . import search
from . import social
from .countries import arabic_name, english_name, find as find_country
from .config import (ADMIN_KEY, API_MAX_LIMIT, INGEST_KEY, PAGE_SIZE,
                     PUBLIC_BASE_URL, SENSITIVE_MODE, DONATION_URL, DONATION_MODE,
                     clamp_limit)
from .i18n import (
    LANGS,
    LANG_META,
    MONTHS,
    format_date,
    format_datetime,
    format_relative,
    is_valid_lang,
    normalize_lang,
    t,
    translator,
)
from .scheduler import scheduler
from . import discovery
from . import monitoring
from . import backfill
from . import verification
from .taxonomy import (
    CATEGORIES,
    CATEGORY_BY_KEY,
    ENTITY_KINDS,
    ENTITY_KIND_BY_KEY,
    MEMBER_ROLES,
    MEMBER_ROLE_BY_KEY,
    MEMBER_STATUSES,
    MEMBER_STATUS_BY_KEY,
    POST_KINDS,
    POST_KIND_BY_KEY,
    POST_VISIBILITIES,
    GROUP_KINDS,
    GROUP_KIND_BY_KEY,
    GROUP_VISIBILITIES,
    GROUP_ROLES,
    GROUP_MEMBER_STATUSES,
    CLAIM_STATUSES,
    CLAIM_STATUS_BY_KEY,
    CLAIM_SOURCE_KINDS,
    SOURCE_RELIABILITY,
    REVIEW_DECISIONS,
    REVIEW_DECISION_BY_KEY,
    MODERATION_ACTION_BY_KEY,
    MODERATION_ACTIONS,
    REPORT_STATES,
    REPORT_STATE_BY_KEY,
    REPORT_REASONS,
    APPEAL_STATUSES,
    REPUTATION_DIMENSIONS,
    TRUST_LEVELS,
    TRUST_LEVEL_BY_KEY,
    BADGES,
    VOUCH_KINDS,
    NOTIFICATION_CATEGORIES,
    NOTIFICATION_CATEGORY_BY_KEY,
    NOTIFICATION_PRIORITIES,
    NOTIFICATION_CHANNELS,
    SUBSCRIPTION_KINDS,
    SEVERITIES,
    SEVERITY_BY_KEY,
    STATUSES,
    STATUS_BY_KEY,
    category_name,
    claim_source_kind_label,
    claim_status_label,
    entity_kind_label,
    entity_kind_singular,
    group_kind_label,
    group_member_status_label,
    group_role_label,
    group_visibility_label,
    member_role_label,
    member_status_label,
    post_kind_label,
    post_status_label,
    post_visibility_label,
    reliability_label,
    review_decision_label,
    moderation_action_label,
    report_state_label,
    report_reason_label,
    appeal_status_label,
    reputation_dimension_label,
    trust_level_label,
    badge_label,
    vouch_kind_label,
    notification_category_label,
    notification_priority_label,
    notification_channel_label,
    subscription_kind_label,
    campaign_status_label,
    campaign_role_label,
    campaign_target_kind_label,
    campaign_event_kind_label,
    pledge_state_label,
    wave_state_label,
    CAMPAIGN_STATUS_BY_KEY,
    CAMPAIGN_STATUSES,
    CAMPAIGN_ROLES,
    CAMPAIGN_TARGET_KINDS,
    CAMPAIGN_EVENT_KINDS,
    PLEDGE_STATES,
    ADVOCACY_CHARTER,
    api_scope_label,
    webhook_event_label,
    connector_kind_label,
    rule_trigger_label,
    rule_action_label,
    job_state_label,
    delivery_state_label,
    API_SCOPES,
    API_VERSIONS,
    WEBHOOK_EVENTS,
    CONNECTOR_KINDS,
    RULE_TRIGGERS,
    RULE_ACTIONS,
    JOB_STATES,
    service_state_label,
    incident_state_label,
    alert_level_label,
    roadmap_state_label,
    SERVICE_STATES,
    INCIDENT_STATES,
    ALERT_LEVELS,
    ROADMAP_STATES,
    RETENTION_CLASSES,
    sensitive_kind_label,
    sensitive_state_label,
    classification_label,
    access_state_label,
    receipt_kind_label,
    SENSITIVE_KINDS,
    SENSITIVE_STATES,
    CLASSIFICATION_LEVELS,
    ACCESS_STATES,
    RECEIPT_KINDS,
    severity_label,
    status_label,
    VERIFICATION_STATES,
    VERIFICATION_STATE_BY_KEY,
    DOCUMENT_TYPES,
    DOCUMENT_TYPE_BY_KEY,
    TRUST_CRITERIA,
    ALERT_KINDS,
    ARCHIVE_STATUSES,
    PIPELINE_STAGES,
    verification_state_label,
    document_type_label,
    alert_kind_label,
)

# نسخة أصول ثابتة لطرد كاش المتصفّح عند تغيير CSS/JS.
ASSET_VER = "20261015d"

# حدّ أعلى لنقاط الخريطة في الصفحة الواحدة؛ الآلاف تُثقل المتصفّح والحمولة.
MAP_POINT_LIMIT = 6000
# أقصى عدد نقاط لكل شهر في خريطة العرض (تمثيل عادل للشهور بدل احتكار الأحدث).
MAP_POINTS_PER_MONTH = 140
# حجم صفحة الخط الزمني (كل البلاغات قد تبلغ عشرات الآلاف).
TIMELINE_PAGE_SIZE = 400

BASE_DIR = Path(__file__).resolve().parent
_log = logging.getLogger("mirsad")


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    # تنبيه صريح عند غياب حماية لوحة الإدارة (تُفتح للزوّار في الإنتاج).
    if not ADMIN_KEY:
        _log.warning(
            "MIRSAD_ADMIN_KEY غير مضبوط: نقاط /api/admin و/api/monitoring "
            "واللوحات الإدارية مفتوحة. اضبط المفتاح في الإنتاج."
        )
    # اكتب المصادر الأساسية المرجعية للتصنيفات الـ15 فورًا عند الإقلاع (بلا تكرار)،
    # ثم تتولّى دورة المجدول اكتشاف الباقي دوريًّا.
    try:
        conn = db.connect()
        try:
            discovery.ensure_groups(conn)
            # آلية الاسترداد: أعد المهام العالقة (running) من انقطاع سابق إلى الطابور.
            from . import monitoring
            monitoring_recovered = db.reset_stale_tasks(conn, older_than_minutes=15)
            del monitoring_recovered
        finally:
            conn.close()
    except Exception:  # noqa: BLE001 — لا نُفشل الإقلاع بسبب الاكتشاف/الاسترداد
        pass
    scheduler.start()
    try:
        yield
    finally:
        await scheduler.stop()


app = FastAPI(
    title="مِرصد | Mirsad",
    description="منصة توثيق الانتهاكات",
    version="2.0.0",
    lifespan=lifespan,
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# ضغط الاستجابات الكبيرة (HTML/JSON) لتقليل زمن التحميل.
app.add_middleware(GZipMiddleware, minimum_size=1024)

# مسارات مستثناة من بوّابة الصيانة/القراءة فقط (تبقى متاحة دائمًا).
_GATE_EXEMPT = ("/healthz", "/status", "/static/", "/favicon", "/sw.js",
                "/manifest", "/api/status")
_WRITE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

# مقارنة ثابتة الزمن آمنة مع المحارف غير ASCII (انظر auth.const_eq).
_const_eq = auth.const_eq


def _ops_gate(request: Request):
    """يعيد استجابة عند فرض وضع الصيانة/القراءة فقط، وإلا None.

    الصيانة تُرجع 503 لطلبات HTML (صفحة ودّية) و JSON لطلبات /api.
    القراءة فقط تمنع طرق الكتابة بـ 403.
    """
    path = request.url.path
    if path.startswith(_GATE_EXEMPT):
        return None
    try:
        conn = db.connect()
        try:
            maintenance = ops.in_maintenance(conn)
            read_only = ops.read_only(conn)
        finally:
            conn.close()
    except Exception:
        return None
    if maintenance:
        # تبقى نقاط الإدارة متاحة كي يستطيع المشرف رفع وضع الصيانة.
        if path.startswith("/api/admin/") or path == "/admin":
            return None
        if path.startswith("/api/"):
            return JSONResponse({"error": "maintenance", "retry_after": 3600},
                                status_code=503, headers={"Retry-After": "3600"})
        lang = normalize_lang(request.query_params.get("lang")
                              or request.cookies.get("mirsad_lang"))
        meta = LANG_META[lang]
        ctx = {"request": request, "t": translator(lang), "asset_ver": ASSET_VER,
               "lang": lang, "html_lang": meta["html_lang"], "lang_dir": meta["dir"],
               "page": "status"}
        return templates.TemplateResponse(
            request, "maintenance.html", ctx, status_code=503,
            headers={"Retry-After": "3600"})
    if read_only and request.method in _WRITE_METHODS:
        return JSONResponse({"error": "read_only"}, status_code=403)
    return None


# لوحات وواجهات إدارية/تشغيلية لا يجوز كشفها للزوّار في الإنتاج.
_OPERATOR_PREFIXES = ("/api/admin/", "/api/monitoring", "/admin", "/monitor", "/audit")
# مسار إدخال مفتاح الإدارة للواجهات (يعيّن كوكي HttpOnly كي يعمل التصفّح بلا ترويسات).
ADMIN_UNLOCK_PATH = "/ops/unlock"
ADMIN_COOKIE = "mirsad_admin"


def _operator_gate(request: Request):
    """يحجب الواجهات الإدارية/التشغيلية عند ضبط MIRSAD_ADMIN_KEY.

    تُشترط ترويسة `X-Admin-Key` مطابقة (مقارنة ثابتة الزمن). عند غياب المفتاح
    (بيئة تطوير محلية) تبقى النقاط مفتوحة لتسهيل التجربة، مع تحذير في السجلات.
    """
    if not ADMIN_KEY:
        return None
    path = request.url.path
    if not any(path == p or path.startswith(p) for p in _OPERATOR_PREFIXES):
        return None
    sent = request.headers.get("X-Admin-Key", "")
    if sent and _const_eq(sent, ADMIN_KEY):
        return None
    cookie = request.cookies.get(ADMIN_COOKIE, "")
    if cookie and _const_eq(cookie, ADMIN_KEY):
        return None
    if path.startswith("/api/"):
        return JSONResponse({"error": "admin_key_required"}, status_code=401)
    lang = getattr(request.state, "lang", "ar")
    next_url = str(request.url)
    if ADMIN_UNLOCK_PATH in next_url:
        next_url = "/"
    ctx = _base_context(request)
    ctx.update({"page": "error", "error_code": 403,
                "error_title": t("error.operator_gate", lang),
                "error_lede": t("error.operator_gate_lede", lang),
                "unlock_action": f"{ADMIN_UNLOCK_PATH}?next={quote(next_url, safe='/')}",
                "unlock_label": t("error.admin_key_label", lang),
                "unlock_submit": t("error.admin_key_submit", lang)})
    return templates.TemplateResponse(request, "error.html", ctx, status_code=403)


@app.get(ADMIN_UNLOCK_PATH)
def ops_unlock(request: Request, key: str = "", next: str = "/"):
    """يعيّن كوكي إدارة HttpOnly عند تطابق المفتاح، لعرض اللوحات في المتصفّح.

    يعيد التوجيه دائمًا (لا يكشف صحّة المفتاح في الجسم)؛ يظهر الحاجز مجددًا عند الخطأ.
    """
    target = _safe_next(next)
    if not ADMIN_KEY:
        return RedirectResponse(target, status_code=303)
    response = RedirectResponse(target, status_code=303)
    if key and _const_eq(key, ADMIN_KEY):
        response.set_cookie(ADMIN_COOKIE, ADMIN_KEY, max_age=86400 * 7,
                            httponly=True, samesite="lax", path="/")
    else:
        response.delete_cookie(ADMIN_COOKIE, path="/")
    return response


# سياسة أمان المحتوى: تسمح بالأصول المحلية فقط، مع بيانات: وblob: والصور عبر
# HTTPS (بلاطات الخريطة). النصوص/الأنماط المضمّنة مسموحة لأن الواجهة تستخدمها.
_CSP = (
    "default-src 'self'; "
    "base-uri 'self'; "
    "object-src 'none'; "
    "frame-ancestors 'self'; "
    "form-action 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob: https:; "
    "font-src 'self' data:; "
    "connect-src 'self'; "
    "media-src 'self'; "
    "worker-src 'self' blob:; "
    "manifest-src 'self'"
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    """ترويسات أمان أساسية لكل الاستجابات + كشف اللغة + بوّابة وضع الصيانة/القراءة فقط."""
    request.state.lang = normalize_lang(request.query_params.get("lang")
                                        or request.cookies.get("mirsad_lang"))
    # حلّ المستخدم الحالي مرة واحدة لكل طلب (تُستخدم في القوالب ونقاط POST).
    request.state.user = None
    if not request.url.path.startswith("/static/"):
        try:
            conn = db.connect()
            try:
                request.state.user = auth.user_for_session(
                    conn, request.cookies.get(auth.SESSION_COOKIE))
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            request.state.user = None
    gate = _operator_gate(request)
    if gate is not None:
        return gate
    gate = _ops_gate(request)
    if gate is not None:
        return gate
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault(
        "Permissions-Policy", "geolocation=(), microphone=(), camera=()"
    )
    response.headers.setdefault("Content-Security-Policy", _CSP)
    # HSTS فقط عند الوصول عبر HTTPS كي لا يكسر التطوير المحلي على HTTP.
    if (request.url.scheme == "https"
            or request.headers.get("x-forwarded-proto", "").split(",")[0].strip() == "https"):
        response.headers.setdefault(
            "Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    response.headers.setdefault("Content-Language", request.state.lang)
    # معرّف طلب مختصر يساعد في تتبّع المشكلات لدى الدعم الفني.
    response.headers.setdefault("X-Request-ID", uuid.uuid4().hex[:12])
    if request.query_params.get("lang"):
        response.set_cookie("mirsad_lang", request.state.lang, max_age=31536000,
                            samesite="lax")
    if request.url.path.startswith("/static/"):
        # الأصول المثبّتة بإصدار (?v=) تُخزَّن طويلًا؛ وإلا فمدة يوم واحد.
        if request.query_params.get("v"):
            response.headers.setdefault("Cache-Control", "public, max-age=31536000, immutable")
        else:
            response.headers.setdefault("Cache-Control", "public, max-age=86400")
    return response


def _enrich(report: dict, lang: str = "ar") -> dict:
    """يضيف الحقول المشتقّة المستخدمة في العرض، مترجمة حسب اللغة."""
    report = dict(report)
    cat = CATEGORY_BY_KEY.get(report["category"], {})
    sev = SEVERITY_BY_KEY.get(report["severity"], {})
    st = STATUS_BY_KEY.get(report["status"], {})
    report["category_name"] = category_name(report["category"], lang)
    report["category_color"] = cat.get("color", "#666")
    report["category_icon"] = cat.get("icon", "dot")
    report["severity_label"] = severity_label(report["severity"], lang)
    report["severity_color"] = sev.get("color", "#666")
    report["status_label"] = status_label(report["status"], lang)
    report["status_color"] = st.get("color", "#666")
    # تواريخ مقروءة حسب اللغة (تُعرض في البطاقات والتفاصيل).
    report["occurred_display"] = format_date(report.get("occurred_on"), lang)
    report["reported_display"] = format_date(report.get("reported_on"), lang)
    # المحتوى الإنجليزي عند توفّره: العنوان والملخّص والتفاصيل.
    if lang == "en":
        report["title"] = report.get("title_en") or report["title"]
        report["summary"] = report.get("summary_en") or report["summary"]
        if report.get("summary_en") and report.get("details"):
            report["details"] = report["details"].replace(report.get("summary", ""), report["summary_en"], 1)
    # اسم الدولة بلغة الواجهة مع علمها.
    cname = english_name(report.get("country", "")) if lang == "en" else arabic_name(report.get("country", ""))
    flag = _flag_emoji(report.get("country", ""))
    report["country_display"] = f"{flag} {cname}".strip() if cname else report.get("country", "")
    # شارة «جديد»: بلاغ وقع خلال آخر 30 يومًا (دلالة على الحداثة المحتوائية).
    report["is_new"] = _within_days(report.get("reported_on"), 30)
    # تقدير مبدئي لعدد المصادر (يُعزّز لاحقًا عند توفّر بيانات إضافية).
    report["sources_count"] = 2 if report.get("verified") else 1
    return report


def _within_days(value, days: int) -> bool:
    """هل يقع تاريخ ISO ضمن آخر `days` يومًا من اليوم؟"""
    if not value:
        return False
    try:
        d = date.fromisoformat(str(value)[:10])
    except ValueError:
        return False
    return (date.today() - d).days <= days


def _iso2(name_or_code: str) -> str | None:
    """رمز ISO2 (حرفان) لدولة، لاستخدامه في أسماء ملفات المحافظات."""
    c = find_country(name_or_code)
    return c["iso2"] if c else None


def _flag_emoji(name_or_code: str) -> str:
    """علم الدولة كرمز إيموجي من رمز ISO2 (مثل EG -> 🇪🇬)."""
    iso2 = _iso2(name_or_code)
    if not iso2 or len(iso2) != 2 or not iso2.isalpha():
        return ""
    return "".join(chr(0x1F1E6 + ord(ch) - ord("A")) for ch in iso2.upper())


def _localized_taxonomy(lang: str) -> dict:
    """نسخ من التصنيف بتسميات مترجمة للاستخدام في القوالب."""
    roles = [{**r, "label": r.get("label_en") or r["label"]} for r in MEMBER_ROLES] \
        if lang == "en" else MEMBER_ROLES
    mstatuses = [{**s, "label": s.get("label_en") or s["label"]} for s in MEMBER_STATUSES] \
        if lang == "en" else MEMBER_STATUSES
    p_kinds = [{**k, "label": k.get("label_en") or k["label"]} for k in POST_KINDS] \
        if lang == "en" else POST_KINDS
    p_vis = [{**v, "label": v.get("label_en") or v["label"]} for v in POST_VISIBILITIES] \
        if lang == "en" else POST_VISIBILITIES
    g_kinds = [{**k, "label": k.get("label_en") or k["label"]} for k in GROUP_KINDS] \
        if lang == "en" else GROUP_KINDS
    g_vis = [{**v, "label": v.get("label_en") or v["label"]} for v in GROUP_VISIBILITIES] \
        if lang == "en" else GROUP_VISIBILITIES
    g_roles = [{**r, "label": r.get("label_en") or r["label"]} for r in GROUP_ROLES] \
        if lang == "en" else GROUP_ROLES
    g_statuses = [{**s, "label": s.get("label_en") or s["label"]} for s in GROUP_MEMBER_STATUSES] \
        if lang == "en" else GROUP_MEMBER_STATUSES
    c_statuses = [{**s, "label": s.get("label_en") or s["label"]} for s in CLAIM_STATUSES] \
        if lang == "en" else CLAIM_STATUSES
    c_source_kinds = [{**k, "label": k.get("label_en") or k["label"]} for k in CLAIM_SOURCE_KINDS] \
        if lang == "en" else CLAIM_SOURCE_KINDS
    c_rel = [{**r, "label": r.get("label_en") or r["label"]} for r in SOURCE_RELIABILITY] \
        if lang == "en" else SOURCE_RELIABILITY
    c_decisions = [{**d, "label": d.get("label_en") or d["label"]} for d in REVIEW_DECISIONS] \
        if lang == "en" else REVIEW_DECISIONS
    mod_actions = [{**a, "label": a.get("label_en") or a["label"]} for a in MODERATION_ACTIONS] \
        if lang == "en" else MODERATION_ACTIONS
    r_states = [{**s, "label": s.get("label_en") or s["label"]} for s in REPORT_STATES] \
        if lang == "en" else REPORT_STATES
    r_reasons = [{**r, "label": r.get("label_en") or r["label"]} for r in REPORT_REASONS] \
        if lang == "en" else REPORT_REASONS
    a_statuses = [{**s, "label": s.get("label_en") or s["label"]} for s in APPEAL_STATUSES] \
        if lang == "en" else APPEAL_STATUSES
    r_dims = [{**d, "label": d.get("label_en") or d["label"]} for d in REPUTATION_DIMENSIONS] \
        if lang == "en" else REPUTATION_DIMENSIONS
    t_levels = [{**lv, "label": lv.get("label_en") or lv["label"]} for lv in TRUST_LEVELS] \
        if lang == "en" else TRUST_LEVELS
    badges = [{**b, "label": b.get("label_en") or b["label"]} for b in BADGES] \
        if lang == "en" else BADGES
    v_kinds = [{**k, "label": k.get("label_en") or k["label"]} for k in VOUCH_KINDS] \
        if lang == "en" else VOUCH_KINDS
    n_cats = [{**c, "label": c.get("label_en") or c["label"]} for c in NOTIFICATION_CATEGORIES] \
        if lang == "en" else NOTIFICATION_CATEGORIES
    n_prios = [{**p, "label": p.get("label_en") or p["label"]} for p in NOTIFICATION_PRIORITIES] \
        if lang == "en" else NOTIFICATION_PRIORITIES
    n_chans = [{**c, "label": c.get("label_en") or c["label"]} for c in NOTIFICATION_CHANNELS] \
        if lang == "en" else NOTIFICATION_CHANNELS
    s_kinds = [{**k, "label": k.get("label_en") or k["label"]} for k in SUBSCRIPTION_KINDS] \
        if lang == "en" else SUBSCRIPTION_KINDS
    # تصنيفات منظومة الرصد (حالات التحقق/أنواع المستندات/معايير الثقة/التنبيهات/الأرشيف).
    def _loc(items):
        return [{**i, "label": i.get("label_en") or i["label"]} for i in items] \
            if lang == "en" else items
    v_states = _loc(VERIFICATION_STATES)
    d_types = _loc(DOCUMENT_TYPES)
    t_criteria = _loc(TRUST_CRITERIA)
    a_kinds = _loc(ALERT_KINDS)
    arch_statuses = _loc(ARCHIVE_STATUSES)
    p_stages = _loc(PIPELINE_STAGES)
    extra = {"member_roles": roles, "member_statuses": mstatuses,
             "post_kinds": p_kinds, "post_visibilities": p_vis,
             "group_kinds": g_kinds, "group_visibilities": g_vis,
             "group_roles": g_roles, "group_member_statuses": g_statuses,
             "claim_statuses": c_statuses, "claim_source_kinds": c_source_kinds,
             "source_reliability": c_rel, "review_decisions": c_decisions,
             "moderation_actions": mod_actions, "report_states": r_states,
             "report_reasons": r_reasons, "appeal_statuses": a_statuses,
             "reputation_dimensions": r_dims, "trust_levels": t_levels,
             "badges": badges, "vouch_kinds": v_kinds,
             "notification_categories": n_cats, "notification_priorities": n_prios,
             "notification_channels": n_chans, "subscription_kinds": s_kinds,
             "verification_states": v_states, "document_types": d_types,
             "trust_criteria": t_criteria, "alert_kinds": a_kinds,
             "archive_statuses": arch_statuses, "pipeline_stages": p_stages}
    if lang != "en":
        by_parent: dict[str, list[dict]] = {}
        for c in CATEGORIES:
            if c.get("parent"):
                by_parent.setdefault(c["parent"], []).append(c)
        return {
            "categories": CATEGORIES,
            "severities": SEVERITIES,
            "statuses": STATUSES,
            "entity_kinds": ENTITY_KINDS,
            "cat_groups": [{**c, "children": by_parent.get(c["key"], [])}
                           for c in CATEGORIES if not c.get("parent")],
            **extra,
        }
    cats = [{**c, "name": c.get("name_en") or c["name"],
             "short": c.get("short_en") or c["short"],
             "description": c.get("description_en") or c["description"]} for c in CATEGORIES]
    sevs = [{**s, "label": s.get("label_en") or s["label"]} for s in SEVERITIES]
    stats = [{**s, "label": s.get("label_en") or s["label"]} for s in STATUSES]
    kinds = [{**k, "label": k.get("label_en") or k["label"],
              "singular": k.get("singular_en") or k["singular"]} for k in ENTITY_KINDS]
    # تسلسل هرمي: كل مجال حاوٍ يحمل أبناءه الفرعيين لتُعرض مجمّعة.
    by_parent: dict[str, list[dict]] = {}
    for c in cats:
        if c.get("parent"):
            by_parent.setdefault(c["parent"], []).append(c)
    cat_groups = [{**c, "children": by_parent.get(c["key"], [])}
                  for c in cats if not c.get("parent")]
    return {"categories": cats, "severities": sevs, "statuses": stats,
            "entity_kinds": kinds, "cat_groups": cat_groups, **extra}


def _enrich_member(member: dict, lang: str = "ar") -> dict:
    """يضيف حقول العرض المشتقّة لعضو (تسمية الدور/الحالة، الحروف الأولى)."""
    member = dict(member)
    member["role_label"] = member_role_label(member.get("role", "member"), lang)
    role_meta = MEMBER_ROLE_BY_KEY.get(member.get("role", ""), {})
    member["role_color"] = role_meta.get("color", "#6b7280")
    member["role_icon"] = role_meta.get("icon", "user")
    member["status_label"] = member_status_label(member.get("status", "active"), lang)
    status_meta = MEMBER_STATUS_BY_KEY.get(member.get("status", ""), {})
    member["status_color"] = status_meta.get("color", "#6b7280")
    member["initial"] = (member.get("display_name") or "?").strip()[:1]
    if lang == "en":
        member["bio"] = member.get("bio_en") or member.get("bio")
    member["country_display"] = (
        f"{_flag_emoji(member.get('country'))} "
        f"{(english_name(member['country']) if lang == 'en' else arabic_name(member['country']))}"
    ).strip() if member.get("country") else ""
    member["interest_list"] = [s.strip() for s in (member.get("interests") or "").split(",") if s.strip()]
    member["lang_list"] = [s.strip() for s in (member.get("langs") or "").split(",") if s.strip()]
    member["since_display"] = format_date((member.get("created_at") or "")[:10], lang)
    return member


TRUST_BREAKDOWN_LABELS = {
    "verified": "trust.b_verified",
    "posts": "trust.b_posts",
    "comments": "trust.b_comments",
    "verified_claims": "trust.b_claims",
    "reviews": "trust.b_reviews",
    "endorsements": "trust.b_endorsements",
    "vouches": "trust.b_vouches",
    "tenure": "trust.b_tenure",
    "penalty": "trust.b_penalty",
}


def _enrich_trust(member: dict, trust: dict, lang: str = "ar") -> dict:
    """يضيف حقول عرض مركّب الثقة (المستوى، اللون، والتفصيل المترجم)."""
    member = dict(member)
    member["trust"] = trust
    level = str(trust.get("level", "0"))
    member["trust_level_label"] = trust_level_label(level, lang)
    member["trust_color"] = TRUST_LEVEL_BY_KEY.get(level, {}).get("color", "#9ca3af")
    member["trust_breakdown"] = [
        {"key": k, "value": v, "label": t(TRUST_BREAKDOWN_LABELS.get(k, k), lang=lang)}
        for k, v in (trust.get("breakdown") or {}).items()
    ]
    return member


def _enrich_post(post: dict, lang: str = "ar") -> dict:
    """يضيف حقول العرض المشتقّة لمنشور (تسمية النوع، وقت نسبي، وسوم)."""
    post = dict(post)
    kind_meta = POST_KIND_BY_KEY.get(post.get("kind", ""), {})
    post["kind_label"] = post_kind_label(post.get("kind", "update"), lang)
    post["kind_color"] = kind_meta.get("color", "#6b7280")
    post["kind_icon"] = kind_meta.get("icon", "edit")
    post["visibility_label"] = post_visibility_label(post.get("visibility", "public"), lang)
    post["status_label"] = post_status_label(post.get("status", "published"), lang)
    post["author_role_label"] = member_role_label(post.get("author_role", "member"), lang)
    if lang == "en":
        post["title"] = post.get("title_en") or post.get("title")
        post["body"] = post.get("body_en") or post.get("body")
    post["created_display"] = format_datetime(post.get("created_at"), lang)
    post["created_relative"] = format_relative(post.get("created_at"), lang)
    post["tag_list"] = [s.strip() for s in (post.get("tags") or "").split(",") if s.strip()]
    return post


def _enrich_group(group: dict, lang: str = "ar") -> dict:
    """يضيف حقول العرض المشتقّة لمجموعة (تسميات النوع/الظهور/الدور)."""
    group = dict(group)
    kind_meta = GROUP_KIND_BY_KEY.get(group.get("kind", ""), {})
    group["kind_label"] = group_kind_label(group.get("kind", "working"), lang)
    group["kind_color"] = kind_meta.get("color", "#6b7280")
    group["kind_icon"] = kind_meta.get("icon", "people")
    group["visibility_label"] = group_visibility_label(group.get("visibility", "public"), lang)
    if group.get("viewer_role"):
        group["viewer_role_label"] = group_role_label(group["viewer_role"], lang)
    if lang == "en":
        group["name"] = group.get("name_en") or group.get("name")
        group["purpose"] = group.get("purpose_en") or group.get("purpose")
    group["created_display"] = format_date((group.get("created_at") or "")[:10], lang)
    return group


def _enrich_claim(claim: dict, lang: str = "ar") -> dict:
    """يضيف حقول العرض المشتقّة لادّعاء تحقّق (تسميات الحالة ودرجة الثقة)."""
    claim = dict(claim)
    meta = CLAIM_STATUS_BY_KEY.get(claim.get("status", ""), {})
    claim["status_label"] = claim_status_label(claim.get("status", ""), lang)
    claim["status_color"] = meta.get("color", "#9ca3af")
    claim["category_label"] = category_name(claim.get("category"), lang) \
        if claim.get("category") else ""
    conf = claim.get("confidence")
    if not conf:
        sources = claim.get("sources") or []
        conf = social._claim_confidence(claim.get("status", ""), sources)
        claim["confidence"] = conf
    claim["confidence_level"] = conf.get("level", "low")
    claim["updated_display"] = format_date((claim.get("updated_at") or "")[:10], lang)
    claim["created_display"] = format_date((claim.get("created_at") or "")[:10], lang)
    if lang == "en":
        claim["title"] = claim.get("title_en") or claim.get("title")
        claim["summary"] = claim.get("summary_en") or claim.get("summary")
    return claim


def _enrich_claim_source(src: dict, lang: str = "ar") -> dict:
    src = dict(src)
    src["kind_label"] = claim_source_kind_label(src.get("kind", ""), lang)
    src["reliability_label"] = reliability_label(src.get("reliability", "3"), lang)
    if lang == "en":
        src["label"] = src.get("label_en") or src.get("label")
    return src


def _enrich_mod_action(a: dict, lang: str = "ar") -> dict:
    """يضيف حقول عرض لقرار إشراف (تسمية الإجراء ودرجته ولونه)."""
    a = dict(a)
    meta = MODERATION_ACTION_BY_KEY.get(a.get("action", ""), {})
    a["action_label"] = moderation_action_label(a.get("action", ""), lang)
    a["action_severity"] = meta.get("severity", 1)
    a["action_color"] = meta.get("color", "#6b7280")
    a["created_display"] = format_datetime(a.get("created_at"), lang)
    if a.get("expires_at"):
        a["expires_display"] = format_datetime(a["expires_at"], lang)
    return a


def _site_url(request: Request) -> str:
    """عنوان الموقع العام: من الإعداد إن وُجد، وإلا من الطلب الحالي."""
    if PUBLIC_BASE_URL:
        return PUBLIC_BASE_URL
    return str(request.base_url).rstrip("/")


def _lang(request: Request) -> str:
    """لغة الطلب الحالي (من الوسيط)."""
    return getattr(request.state, "lang", None) or normalize_lang(
        request.query_params.get("lang") or request.cookies.get("mirsad_lang"))


def _group_timeline(items: list[dict], key_len: int) -> list[dict]:
    """يجمّع بلاغات الخط الزمني في محطات حسب طول مفتاح التاريخ (4=سنة، 7=شهر، 10=يوم).

    التجميع على تاريخ الوقوع (`occurred_on`) مع الرجوع إلى تاريخ النشر عند غيابه،
    للحفاظ على الترتيب الزمني نفسه المستخدم في `sort="occurred_asc"`.
    """
    groups: list[dict] = []
    index: dict[str, dict] = {}
    for r in items:
        key = (r.get("occurred_on") or r.get("reported_on") or "")[:key_len]
        g = index.get(key)
        if g is None:
            g = {"key": key, "reports": []}
            index[key] = g
            groups.append(g)
        g["reports"].append(r)
    return groups


def _base_context(request: Request) -> dict:
    lang = _lang(request)
    meta = LANG_META[lang]
    tax = _localized_taxonomy(lang)
    other = "en" if lang == "ar" else "ar"
    # روابط بديلة للغتين مع الحفاظ على الصفحة والمرشّحات الحالية
    base_params = dict(request.query_params)
    alt_urls = {}
    for code in LANGS:
        p = {**base_params, "lang": code}
        alt_urls[code] = str(request.url.replace_query_params(**p))
    switch_url = alt_urls[other]
    # المستخدم الحالي (من الجلسة) متاح لكل القوالب لعرض حالة الدخول.
    user = getattr(request.state, "user", None)
    if user is None:
        try:
            conn = db.connect()
            try:
                user = auth.user_for_session(conn, request.cookies.get(auth.SESSION_COOKIE))
            finally:
                conn.close()
        except Exception:  # noqa: BLE001
            user = None
    return {
        **tax,
        "current_user": user,
        "kind_by_key": ENTITY_KIND_BY_KEY,
        "sev_color": {s["key"]: s["color"] for s in SEVERITIES},
        "cat_by_key": CATEGORY_BY_KEY,
        # عدد المجالات يُمرَّر للترجمات التي تذكر العدد صراحةً (‏{n}).
        "domain_count": len(CATEGORIES),
        "category_name": lambda k: category_name(k, lang),
        "severity_label": lambda k: severity_label(k, lang),
        "status_label": lambda k: status_label(k, lang),
        "severity_label_map": {s["key"]: severity_label(s["key"], lang) for s in SEVERITIES},
        "status_label_map": {s["key"]: status_label(s["key"], lang) for s in STATUSES},
        "category_label_map": {c["key"]: category_name(c["key"], lang) for c in CATEGORIES},
        "severity_color_map": {s["key"]: s["color"] for s in SEVERITIES},
        "status_color_map": {s["key"]: s["color"] for s in STATUSES},
        "category_color_map": {c["key"]: c["color"] for c in CATEGORIES},
        "entity_kind_label": lambda k: entity_kind_label(k, lang),
        "entity_kind_singular": lambda k: entity_kind_singular(k, lang),
        "fmt_date": lambda v: format_date(v, lang),
        "fmt_datetime": lambda v: format_datetime(v, lang),
        "fmt_relative": lambda v: format_relative(v, lang),
        "months": MONTHS[lang],
        "f": {},
        "asset_ver": ASSET_VER,
        "site_url": _site_url(request),
        "today": date.today().isoformat(),
        "is_lite": request.query_params.get("lite") == "1",
        "lang": lang,
        "lang_dir": meta["dir"],
        "html_lang": meta["html_lang"],
        "og_locale": meta["og_locale"],
        "other_lang": other,
        "lang_switch_url": switch_url,
        "alt_urls": alt_urls,
        "langs": LANGS,
        "t": translator(lang),
    }


# ---------------------------------------------------------------------------
# اللغة
# ---------------------------------------------------------------------------

@app.get("/lang/{code}")
def switch_lang(code: str, next: str = "/"):
    """يثبّت اللغة في كوكي ويعيد المستخدم إلى الصفحة المطلوبة."""
    if not is_valid_lang(code):
        code = "ar"
    response = RedirectResponse(url=_safe_next(next), status_code=303)
    response.set_cookie("mirsad_lang", code, max_age=31536000, samesite="lax")
    return response


# ---------------------------------------------------------------------------
# المصادقة (تسجيل الدخول/الإنشاء)
# ---------------------------------------------------------------------------

# محارف تُطبَّع في المتصفّح إلى `/` أو تُهمَل في عنوان Location، فتُستغلّ لتجاوز
# فحص «المسار الداخلي» (مثل `/\evil.com` → `//evil.com`).
_REDIRECT_STRIP = {ord(c): None for c in "\\\t\r\n\x0b\x0c"}


def _safe_next(value: str | None) -> str:
    """يضمن أن وجهة إعادة التوجيه مسار داخلي آمن.

    المتصفّحات تعامل الشرطة المائلة العكسية (`\\`) والمحارف الضابطة (TAB/CR/LF)
    في عنوان `Location` كما تعامل `/`، فـ`/\\evil.com` و`/<TAB>/evil.com` تُفسَّران
    كـ`//evil.com` (توجيه خارجي). نزيل هذه المحارف قبل التحقّق لمنع Open Redirect.
    """
    v = (value or "").strip().translate(_REDIRECT_STRIP)
    if v.startswith("/") and not v.startswith("//"):
        return v
    return "/"


def _set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(auth.SESSION_COOKIE, token, max_age=86400 * 30,
                        httponly=True, samesite="lax", path="/")


@app.get("/auth/login", response_class=HTMLResponse)
def auth_login(request: Request, next: str = "/", error: str = ""):
    """صفحة تسجيل الدخول/الإنشاء (واجهة موحّدة)."""
    ctx = _base_context(request)
    ctx.update({
        "page": "signin",
        "mode": "signin",
        "next_url": _safe_next(next),
        "providers": auth.providers_for_ui(ctx["lang"]),
        "error": error,
        "any_configured": any(p["configured"] for p in auth.providers_for_ui(ctx["lang"])),
    })
    return templates.TemplateResponse(request, "signin.html", ctx)


@app.get("/auth/signup", response_class=HTMLResponse)
def auth_signup(request: Request, next: str = "/", error: str = ""):
    """صفحة إنشاء الحساب (نفس الواجهة، بترويسة مختلفة)."""
    ctx = _base_context(request)
    ctx.update({
        "page": "signup",
        "mode": "signup",
        "next_url": _safe_next(next),
        "providers": auth.providers_for_ui(ctx["lang"]),
        "error": error,
        "any_configured": any(p["configured"] for p in auth.providers_for_ui(ctx["lang"])),
    })
    return templates.TemplateResponse(request, "signin.html", ctx)


@app.get("/auth/{provider}/start")
def auth_start(provider: str, request: Request, next: str = "/"):
    """يبدأ تدفّق OAuth للمزوّد المطلوب."""
    if provider not in config_oauth_providers():
        return RedirectResponse(f"/auth/login?error=provider", status_code=303)
    redirect_uri = str(request.url_for("auth_callback", provider=provider))
    state = auth.make_state(_safe_next(next), provider)
    response = RedirectResponse(auth.authorize_url(provider, redirect_uri, state), status_code=303)
    response.set_cookie(auth._STATE_COOKIE, state, max_age=600, httponly=True,
                        samesite="lax", path="/")
    return response


def config_oauth_providers() -> set[str]:
    from .config import OAUTH_PROVIDERS
    return set(OAUTH_PROVIDERS.keys())


@app.get("/auth/{provider}/callback", name="auth_callback")
def auth_callback(provider: str, request: Request, code: str = "", state: str = "", error: str = ""):
    """يكمل تدفّق OAuth: يتحقّق من الحالة، يجلب الملف الشخصي، وينشئ جلسة."""
    if error or not code:
        return RedirectResponse("/auth/login?error=denied", status_code=303)
    if provider not in config_oauth_providers():
        return RedirectResponse("/auth/login?error=provider", status_code=303)
    cookie_state = request.cookies.get(auth._STATE_COOKIE, "")
    verified = auth.verify_state(state or cookie_state)
    if not verified or verified.get("p") != provider or not _const_eq(state, cookie_state):
        return RedirectResponse("/auth/login?error=state", status_code=303)
    next_url = _safe_next(verified.get("x"))

    from .config import provider_configured
    if provider_configured(provider):
        profile = auth.exchange_code(provider, code, str(request.url_for("auth_callback", provider=provider)))
        if not profile:
            return RedirectResponse("/auth/login?error=failed", status_code=303)
    else:
        # وضع تجريبي: لا مفاتيح مضبوطة، نُنشئ حسابًا محليًّا لتجربة الواجهة.
        profile = auth.demo_profile(provider)

    conn = db.connect()
    try:
        user = auth.get_or_create_user(conn, provider, profile)
        token = auth.create_session(conn, user["id"], request.headers.get("user-agent", ""))
    finally:
        conn.close()
    response = RedirectResponse(next_url, status_code=303)
    _set_session_cookie(response, token)
    response.delete_cookie(auth._STATE_COOKIE, path="/")
    return response


@app.post("/auth/email")
def auth_email(request: Request, email: str = Form(...), name: str = Form(""), next: str = Form("/")):
    """دخول/إنشاء مبسّط بالبريد (بيئة تجريبية بلا كلمة مرور)."""
    email = (email or "").strip().lower()
    if "@" not in email or "." not in email.split("@")[-1]:
        return RedirectResponse("/auth/login?error=email", status_code=303)
    conn = db.connect()
    try:
        user = auth.get_or_create_user(conn, "email", {
            "id": email, "email": email, "name": (name or "").strip() or email.split("@")[0],
            "avatar": None})
        token = auth.create_session(conn, user["id"], request.headers.get("user-agent", ""))
    finally:
        conn.close()
    response = RedirectResponse(_safe_next(next), status_code=303)
    _set_session_cookie(response, token)
    return response


@app.get("/auth/logout")
def auth_logout(request: Request, next: str = "/"):
    conn = db.connect()
    try:
        auth.delete_session(conn, request.cookies.get(auth.SESSION_COOKIE))
    finally:
        conn.close()
    response = RedirectResponse(_safe_next(next), status_code=303)
    response.delete_cookie(auth.SESSION_COOKIE, path="/")
    return response


@app.get("/account", response_class=HTMLResponse)
def account_page(request: Request):
    """صفحة حساب المستخدم (تتطلّب تسجيل الدخول)."""
    ctx = _base_context(request)
    user = ctx.get("current_user")
    if not user:
        return RedirectResponse("/auth/login?next=/account", status_code=303)
    conn = db.connect()
    try:
        identities = [dict(r) for r in conn.execute(
            "SELECT provider, email, created_at FROM user_identities WHERE user_id = ? "
            "ORDER BY created_at", (user["id"],))]
        # عمليات البحث المحفوظة ومنشورات المجتمع المرتبطة باسم المستخدم.
        saved = [dict(r) for r in conn.execute(
            "SELECT * FROM saved_searches WHERE member = ? ORDER BY id DESC LIMIT 20",
            (user["display_name"],))]
        following = [dict(r) for r in conn.execute(
            "SELECT * FROM posts WHERE author_handle = ? ORDER BY id DESC LIMIT 10",
            (user["display_name"],))]
    finally:
        conn.close()
    ctx.update({"page": "account", "identities": identities,
                "saved_searches": saved, "following": following,
                "provider_meta": {k: v for k, v in _oauth_meta().items()}})
    return templates.TemplateResponse(request, "account.html", ctx)


def _oauth_meta() -> dict:
    from .config import OAUTH_PROVIDERS
    return OAUTH_PROVIDERS


# ---------------------------------------------------------------------------
# التبرّعات
# ---------------------------------------------------------------------------

@app.get("/donate", response_class=HTMLResponse)
def donate_page(request: Request, tab: str = "coffee", ok: int = 0, cat: str = "", q: str = ""):
    lang = _lang(request)
    conn = db.connect()
    try:
        dstat = donations.stats(conn)
        recent = donations.recent(conn, limit=10)
    finally:
        conn.close()
    orgs = charities.filter_charities(cat=cat, q=q, lang=lang)
    for o in orgs:
        o["display_name"] = o["name_ar"] if lang == "ar" else o["name_en"]
        o["display_focus"] = o["focus_ar"] if lang == "ar" else o["focus_en"]
        o["display_country"] = o["country_ar"] if lang == "ar" else o["country_en"]
        o["category_name"] = category_name(o["category"], lang)
    ctx = _base_context(request)
    ctx.update({
        "page": "donate", "tab": tab if tab in ("coffee", "charity") else "coffee",
        "ok": ok, "dstat": dstat, "recent": recent,
        "coffee_presets": donations.COFFEE_PRESETS,
        "charity_presets": donations.CHARITY_PRESETS,
        "charities": orgs, "charity_count": charities.count(),
        "charity_categories": [c for c in CATEGORIES
                               if any(x["category"] == c["key"] for x in charities.all_charities())],
        "f": {"cat": cat, "q": q},
        "donation_url": DONATION_URL, "donation_mode": DONATION_MODE,
    })
    return templates.TemplateResponse(request, "donate.html", ctx)


@app.post("/donate")
def donate_submit(request: Request,
                  kind: str = Form("coffee"),
                  amount: str = Form(""),
                  frequency: str = Form("once"),
                  target_key: str = Form(""),
                  donor_name: str = Form(""),
                  message: str = Form(""),
                  anonymous: str = Form("")):
    """يسجّل نيّة تبرّع (قهوة أو خيرية) ويعيد إلى صفحة الشكر."""
    try:
        amt = float((amount or "0").replace(",", "").strip() or 0)
    except ValueError:
        amt = 0.0
    kind = "charity" if kind == "charity" else "coffee"
    target = charities.by_key(target_key) if kind == "charity" else None
    user = getattr(request.state, "user", None)
    conn = db.connect()
    try:
        donations.record_donation(conn, {
            "kind": kind, "amount": amt if amt > 0 else None, "frequency": frequency,
            "target_key": target["key"] if target else None,
            "target_name": (target["name_ar"] if target else None),
            "user_id": user["id"] if user else None,
            "donor_name": (donor_name or "").strip() or None,
            "message": (message or "").strip() or None,
            "anonymous": bool(anonymous),
        })
    finally:
        conn.close()
    q = f"/donate?tab={kind}&ok=1"
    if kind == "charity" and target:
        q += f"&thanks={quote(target['name_ar'])}"
    return RedirectResponse(q, status_code=303)


# ---------------------------------------------------------------------------
# الصفحات
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    lang = _lang(request)
    conn = db.connect()
    try:
        st = db.stats(conn)
        latest = [_enrich(r, _lang(request)) for r in db.query_reports(conn, sort="recent", limit=6)]
        critical = [_enrich(r, _lang(request)) for r in db.query_reports(conn, severity="critical", sort="recent", limit=3)]
        # نافذة «عاجل»: أحدث البلاغات الحرجة/المرتفعة مع حالة الجمع الحيّة.
        urgent = [_enrich(r, _lang(request)) for r in db.urgent_reports(conn, limit=6)]
        collection = db.collection_stats(conn)
        catalog_health = db.catalog_health(conn)
        # بيانات لوحة الرئيسية: خط زمني (محطات موزّعة زمنيًا)، وسوم رائجة، ملخّص أسبوعي، معاينة جغرافية.
        timeline = [_enrich(r, _lang(request)) for r in db.timeline_milestones(conn, limit=6)]
        all_countries = db.countries_summary(conn)
        top_countries = all_countries[:8]
        points = db.geo_points(conn, limit=200)
        # بلاغات موثّقة حديثًا، وأخرى تحتاج توثيقًا (بلا تحقّق).
        verified_recent = [_enrich(r, _lang(request)) for r in db.query_reports(
            conn, verified=True, sort="recent", limit=3)]
        needs_verification = [_enrich(r, _lang(request)) for r in db.query_reports(
            conn, verified=False, sort="recent", limit=3)]
        # بطاقات المجالات: اتجاه مقارنة بالشهر الماضي (تقريب من الإجمالي الشهري).
        sources = db.list_sources(conn)
        last_refresh_ts = refresh.last_refresh(conn)
        regions = {r.get("region") for r in db.query_reports(conn, limit=5000)}
    finally:
        conn.close()

    for c in top_countries:
        c["name"] = english_name(c["country"]) if lang == "en" else arabic_name(c["country"])
        c["flag"] = _flag_emoji(c["country"])

    for c in all_countries:
        c["name"] = english_name(c["country"]) if lang == "en" else arabic_name(c["country"])
        c["flag"] = _flag_emoji(c["country"])
        c["href"] = f"/country/{c['country']}"
    country_search = sorted(all_countries, key=lambda x: x["name"])

    # وسوم رائجة: أعلى المجالات والدول وروداً في البلاغات.
    trending = []
    for c in CATEGORIES:
        n = st["by_category"].get(c["key"], 0)
        if n:
            trending.append({"kind": "cat", "key": c["key"], "label": category_name(c["key"], lang),
                             "count": n, "color": c["color"], "href": f"/reports?category={c['key']}"})
    trending.sort(key=lambda x: x["count"], reverse=True)
    country_tags = [{"kind": "country", "label": t2["name"], "count": t2["total"],
                     "flag": t2["flag"], "href": f"/country/{t2['country']}"} for t2 in top_countries[:6]]
    tags = trending[:6] + country_tags

    # ملخّص الأسبوع: عدد البلاغات الجديدة والدول خلال آخر 7 أيام.
    monthly = {m["month"]: m["count"] for m in st["by_month"]}
    today = date.today()
    def _month_key(d: date) -> str:
        return f"{d.year:04d}-{d.month:02d}"
    this_month = monthly.get(_month_key(today), 0)
    prev = today.replace(day=1) - timedelta(days=1)
    prev_month = monthly.get(_month_key(prev), 0)
    if prev_month:
        delta = round((this_month - prev_month) / prev_month * 100)
    else:
        delta = 100 if this_month else 0
    week_cut = (today - timedelta(days=7)).isoformat()
    week_items = [r for r in timeline if (r.get("reported_on") or "") >= week_cut]
    week_count = len(week_items)
    week_countries = len({r.get("country") for r in week_items})

    # مسار مخطط مصغّر (sparkline) لآخر 12 شهراً.
    spark_months = st["by_month"][-12:]
    spark = spark_area = ""
    if len(spark_months) >= 2:
        vals = [m["count"] for m in spark_months]
        mx = max(vals) or 1
        n = len(vals)
        pts = [f"{i / (n - 1) * 100:.1f},{30 - (v / mx * 27) - 1.5:.1f}"
               for i, v in enumerate(vals)]
        spark = "M" + " L".join(pts)
        spark_area = spark + " L100,30 L0,30 Z"

    # شريط «عاجل»: الحالات الحرجة ثم أحدث البلاغات، دون تكرار ما ظهر في قائمة الحالات الحرجة.
    critical_ids = {r["id"] for r in critical}
    ticker_items = critical + [r for r in latest if r["id"] not in critical_ids]

    # اتجاه كل مجال: حصّة الشهر الحالي مقابل السابق (تقريب من الإجمالي الشهري).
    cat_trend = {}
    for c in CATEGORIES:
        base = st["by_category"].get(c["key"], 0)
        share = (this_month / st["total"]) if st["total"] else 0
        this_c = base * share
        prev_share = (prev_month / st["total"]) if st["total"] else 0
        prev_c = base * prev_share
        if prev_c <= 0:
            cat_trend[c["key"]] = "flat"
        elif this_c > prev_c * 1.05:
            cat_trend[c["key"]] = "up"
        elif this_c < prev_c * 0.95:
            cat_trend[c["key"]] = "down"
        else:
            cat_trend[c["key"]] = "flat"

    # حالة المصادر: نعتمد فهرس الجمع الواسع (source_catalog) لأنه محرّك السحب
    # الفعلي الآن؛ «يعمل» = نجح آخر سحب، «متأخّر» = فشل أو لم يُسحب بعد.
    healthy = catalog_health.get("ok", 0)
    stale = catalog_health.get("failed", 0)

    # عدّاد التحديث التالي (بالدقائق) — المجدول يعمل كل 30 دقيقة افتراضياً.
    refresh_minutes = 30

    # أسئلة شائعة مصغّرة في الصفحة الرئيسية (تُترجَم من مفاتيح i18n).
    faq_items = [
        {"q": t("home.faq_q1", lang), "a": t("home.faq_a1", lang)},
        {"q": t("home.faq_q2", lang), "a": t("home.faq_a2", lang)},
        {"q": t("home.faq_q3", lang), "a": t("home.faq_a3", lang)},
    ]
    ctx = _base_context(request)
    ctx.update({"stats": st, "latest": latest, "critical": critical,
                "urgent": urgent, "collection": collection,
                "catalog_health": catalog_health,
                "ticker_items": ticker_items, "page": "home",
                "timeline": timeline, "tags": tags, "top_countries": top_countries,
                "week_count": week_count, "week_countries": week_countries,
                "month_delta": delta, "spark": spark, "spark_area": spark_area,
                "cat_trend": cat_trend, "verified_recent": verified_recent,
                "needs_verification": needs_verification,
                "sources_healthy": healthy, "sources_stale": stale,
                "last_refresh": last_refresh_ts, "refresh_minutes": refresh_minutes,
                "region_count": len([r for r in regions if r]),
                "all_countries": all_countries,
                "country_search": country_search,
                "faq_items": faq_items,
                "sources": sources,
                "data_health": round(st["verified"] / st["total"] * 100) if st["total"] else 0,
                "map_points": points[:60]})
    return templates.TemplateResponse(request, "index.html", ctx)


@app.get("/reports", response_class=HTMLResponse)
def reports_page(
    request: Request,
    category: str | None = None,
    severity: str | None = None,
    status: str | None = None,
    country: str | None = None,
    q: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    verified: str | None = None,
    sort: str = "recent",
    page: int = 1,
    per_page: int = PAGE_SIZE,
):
    conn = db.connect()
    try:
        page = max(1, page)
        per_page = per_page if per_page in (20, 50, 100) else PAGE_SIZE
        verified_bool = None if verified in (None, "") else verified == "1"
        filters = dict(category=category, severity=severity, status=status,
                       country=country, search=q, date_from=date_from, date_to=date_to,
                       verified=verified_bool)
        total = db.count_reports(conn, **filters)
        items = [_enrich(r, _lang(request)) for r in db.query_reports(
            conn, **filters, sort=sort, limit=per_page, offset=(page - 1) * per_page)]
        countries = db.distinct_countries(conn)
        counts = db.filter_counts(conn)
    finally:
        conn.close()
    pages = max(1, (total + per_page - 1) // per_page)
    # مرشّحات نشطة قابلة للإزالة (chips) + قيمة ثابتة لتثبيت الفلاتر في العمود الجانبي.
    active = []
    for key, val, label in (
        ("category", category, next((c["name"] for c in CATEGORIES if c["key"] == category), category)),
        ("severity", severity, severity_label(severity, _lang(request)) if severity else None),
        ("status", status, status_label(status, _lang(request)) if status else None),
        ("country", country, country),
        ("q", q, q),
        ("date_from", date_from,
         t("reports.filter_from", _lang(request)) + ": " + date_from if date_from else None),
        ("date_to", date_to,
         t("reports.filter_to", _lang(request)) + ": " + date_to if date_to else None),
        ("verified", verified,
         (t("reports.verified_only", _lang(request)) if verified == "1"
          else t("reports.unverified_only", _lang(request))) if verified else None),
    ):
        if val:
            active.append({"key": key, "value": val, "label": label})
    ctx = _base_context(request)
    ctx.update({
        "page": "reports", "items": items, "total": total, "pages": pages,
        "current_page": page, "countries": countries, "counts": counts,
        "active_filters": active, "per_page": per_page,
        "f": {"category": category, "severity": severity, "status": status,
              "country": country, "q": q, "date_from": date_from, "date_to": date_to,
              "verified": verified, "sort": sort},
    })
    return templates.TemplateResponse(request, "reports.html", ctx)


@app.get("/timeline", response_class=HTMLResponse)
def timeline_page(
    request: Request,
    granularity: str = "month",
    category: str | None = None,
    severity: str | None = None,
    country: str | None = None,
    page: int = 1,
):
    """الخط الزمني الكامل: البلاغات مرتّبة بتاريخ الوقوع ومجمَّعة في محطات.

    مرقّم (TIMELINE_PAGE_SIZE لكل صفحة) لأن العدد قد يبلغ عشرات الآلاف.
    """
    granularity = granularity if granularity in ("day", "month", "year") else "month"
    unit = {"day": 10, "month": 7, "year": 4}[granularity]
    page = max(1, page)
    conn = db.connect()
    try:
        total = db.count_reports(conn, category=category or None,
                                 severity=severity or None, country=country or None)
        rows = db.query_reports(conn, category=category or None,
                                severity=severity or None, country=country or None,
                                sort="occurred_asc", limit=TIMELINE_PAGE_SIZE,
                                offset=(page - 1) * TIMELINE_PAGE_SIZE)
        items = [_enrich(r, _lang(request)) for r in rows]
        countries = db.distinct_countries(conn)
        counts = db.filter_counts(conn)
    finally:
        conn.close()
    groups = _group_timeline(items, unit)
    pages = max(1, (total + TIMELINE_PAGE_SIZE - 1) // TIMELINE_PAGE_SIZE)
    base_filters = {k: v for k, v in
                    (("category", category), ("severity", severity), ("country", country)) if v}
    links = {u: "/timeline?" + urlencode({**base_filters, "granularity": u})
             for u in ("day", "month", "year")}
    ctx = _base_context(request)
    ctx.update({"page": "timeline", "items": items, "groups": groups,
                "granularity": granularity, "total": total,
                "current_page": page, "pages": pages,
                "countries": countries, "counts": counts, "links": links,
                "f": {"granularity": granularity, "category": category,
                      "severity": severity, "country": country}})
    return templates.TemplateResponse(request, "timeline.html", ctx)


@app.get("/reports/{report_id}", response_class=HTMLResponse)
def report_detail(request: Request, report_id: int):
    conn = db.connect()
    try:
        raw = db.get_report(conn, report_id)
        if not raw:
            raise HTTPException(status_code=404, detail="البلاغ غير موجود")
        report = _enrich(raw, _lang(request))
        related = [_enrich(r, _lang(request)) for r in db.related_reports(conn, raw)]
        entities = db.entities_for(conn, report_id)
        adjacent = db.adjacent_reports(conn, report_id)
    finally:
        conn.close()
    ctx = _base_context(request)
    lang = _lang(request)
    # خريطة مصغّرة لموقع الواقعة إن توفّرت الإحداثيات.
    point = None
    if raw.get("lat") is not None and raw.get("lng") is not None:
        point = {"lat": raw["lat"], "lng": raw["lng"],
                 "title": report["title"], "category": raw["category"]}
    # أنماط استشهاد متعدّدة (APA / MLA / Chicago).
    cite = {
        "apa": exports.to_apa([raw], _site_url(request)).strip(),
        "mla": exports.to_mla([raw], _site_url(request)).strip(),
        "chicago": exports.to_chicago([raw], _site_url(request)).strip(),
    }
    ctx.update({"page": "reports", "report": report, "related": related,
                "entities": entities, "point": point, "cite": cite,
                "adjacent": adjacent,
                "status_flow": [s["key"] for s in STATUSES],
                "citation_apa": cite["apa"]})
    # زمن قراءة تقديري من نصّ الواقعة والتفاصيل (≈200 كلمة/دقيقة).
    words = len(((report.get("details") or "") + " " + (report.get("summary") or "")).split())
    ctx["reading_minutes"] = max(1, round(words / 200))
    return templates.TemplateResponse(request, "report_detail.html", ctx)


@app.get("/stats", response_class=HTMLResponse)
def stats_page(request: Request):
    conn = db.connect()
    try:
        st = db.stats(conn)
        last_refresh = refresh.last_refresh(conn)
        daily = db.daily_activity(conn, days=365)
        matrix = db.category_severity_matrix(conn)
    finally:
        conn.close()
    ctx = _base_context(request)
    # مقارنة الشهر الحالي بالسابق لخلاصة نصّية.
    monthly = {m["month"]: m["count"] for m in st["by_month"]}
    today = date.today()
    cur_key = f"{today.year:04d}-{today.month:02d}"
    prev_day = today.replace(day=1) - timedelta(days=1)
    prev_key = f"{prev_day.year:04d}-{prev_day.month:02d}"
    cur = monthly.get(cur_key, 0)
    prev = monthly.get(prev_key, 0)
    delta = round((cur - prev) / prev * 100) if prev else (100 if cur else 0)
    # مؤشرات مشتقّة للوحة البيانات.
    by_month = st["by_month"]
    counts_m = [m["count"] for m in by_month]
    peak = max(by_month, key=lambda m: m["count"]) if by_month else None
    avg_month = round(sum(counts_m) / len(counts_m), 1) if counts_m else 0
    recent = counts_m[-6:] if len(counts_m) >= 6 else counts_m
    older = counts_m[-12:-6] if len(counts_m) >= 12 else counts_m[:max(0, len(counts_m) - 6)]
    trend = (sum(recent) - sum(older)) if older else 0
    by_cat = st.get("by_category", {})
    top_cat_key = max(by_cat, key=by_cat.get) if by_cat else None
    top_cat = CATEGORY_BY_KEY.get(top_cat_key, {}) if top_cat_key else None
    verified_rate = round(st["verified"] / st["total"] * 100) if st["total"] else 0
    ctx.update({"page": "stats", "stats": st,
                "last_refresh": last_refresh, "daily": daily, "matrix": matrix,
                "month_delta": delta, "cur_month": cur, "prev_month": prev,
                "peak_month": peak, "avg_month": avg_month, "trend": trend,
                "top_cat": top_cat, "top_cat_count": by_cat.get(top_cat_key, 0) if top_cat_key else 0,
                "verified_rate": verified_rate,
                "critical_count": st["by_severity"].get("critical", 0),
                "refresh_interval": scheduler.status()["interval_seconds"]})
    return templates.TemplateResponse(request, "stats.html", ctx)


@app.get("/map", response_class=HTMLResponse)
def map_page(request: Request, country: str = ""):
    lang = _lang(request)
    conn = db.connect()
    try:
        st = db.stats(conn)
        total_points = db.geo_point_count(conn)
        # عيّنة موزّعة شهريًّا: تضمن بقاء كل الشهور في الشريط الزمني للخريطة
        # بدل أن تحتكر أحدث دفعة استيراد كل النقاط (إصلاح خلل الخريطة).
        points = db.geo_points_sampled(conn, per_month=MAP_POINTS_PER_MONTH,
                                       max_total=MAP_POINT_LIMIT)
        summary = db.countries_summary(conn)
    finally:
        conn.close()
    # ترميز البلدان التي لها بلاغات إلى رموز ISO2 لإتاحة الاختيار والمحافظات.
    report_countries = []
    seen_iso = set()
    for row in summary:
        iso = _iso2(row["country"])
        if iso and iso not in seen_iso:
            seen_iso.add(iso)
            latlng = find_country(row["country"])
            report_countries.append({
                "iso2": iso,
                "name": english_name(row["country"]) if lang == "en" else row["country"],
                "lat": latlng["latlng"][0] if latlng else 0,
                "lng": latlng["latlng"][1] if latlng else 0,
            })
    report_countries.sort(key=lambda c: c["name"])
    ctx = _base_context(request)
    for p in points:
        p["reported_display"] = format_date(p.get("reported_on"), lang)
        p["flag"] = _flag_emoji(p.get("country", ""))
        if lang == "en":
            p["title"] = p.get("title_en") or p["title"]
            p["country"] = english_name(p.get("country", "")) or p["country"]
    ctx.update({"page": "map", "stats": st, "points": points,
                "map_countries": report_countries,
                "total_points": total_points,
                "points_capped": total_points > len(points)})
    if country:
        # تمرير رمز دولة ISO2 عبر الرابط للتكبير التلقائي وعرض المحافظات.
        ctx["initial_country"] = country.strip().upper()
    return templates.TemplateResponse(request, "map.html", ctx)


@app.get("/sources", response_class=HTMLResponse)
def sources_page(request: Request):
    conn = db.connect()
    try:
        sources = db.list_sources(conn)
        history = db.ingest_history(conn, limit=15)
        src_counts = db.source_report_counts(conn)
        discovered = db.discovered_sources(conn)
        discovered_total = db.discovered_count(conn)
        discovery_report = db.latest_discovery_report(conn)
        discovery_runs = db.discovery_history(conn, limit=10)
    finally:
        conn.close()
    # تصنيف موثوقية مبني على طبيعة المصدر (رسمي/بيانات مفتوحة/إعلامي).
    for s in sources:
        kind = s.get("kind") or ""
        if kind in ("dataset", "official"):
            s["reliability"] = "official"
        elif kind == "manual":
            s["reliability"] = "media"
        else:
            s["reliability"] = "open"
        info = src_counts.get(s.get("name"))
        s["report_count"] = info["count"] if info else 0
        s["last_used"] = info["last"] if info else None
    # عدّ المصادر المكتشفة لكل تصنيف مرجعي (لعرض الشرائح).
    disc_by_group: dict[str, int] = {}
    for d in discovered:
        disc_by_group[d.get("group_key") or "other"] = disc_by_group.get(d.get("group_key") or "other", 0) + 1
    ctx = _base_context(request)
    ctx.update({"page": "sources", "sources": sources, "datasets": sources_registry.OPEN_DATASETS,
                "software": sources_registry.OPEN_SOFTWARE,
                "doc_resources": sources_registry.DOC_RESOURCES,
                "doc_kinds": sources_registry.DOC_RESOURCE_KINDS,
                "doc_categories": sources_registry.DOC_RESOURCE_CATEGORIES,
                "registry_stats": sources_registry.stats(),
                "history": history,
                "discovered": discovered,
                "discovered_total": discovered_total,
                "discovered_by_group": disc_by_group,
                "discovery_report": discovery_report,
                "discovery_runs": discovery_runs,
                "discovery_groups": discovery.DISCOVERY_GROUPS,
                "discovery_interval": discovery.DISCOVERY_INTERVAL,
                "refresh_interval": scheduler.status()["interval_seconds"]})
    return templates.TemplateResponse(request, "sources.html", ctx)


@app.get("/submit", response_class=HTMLResponse)
def submit_form(request: Request, ok: int = 0, ref: int | None = None, intent: str | None = None):
    ctx = _base_context(request)
    # سياق بلاغ مرجعي (توثيق/مصدر/تصحيح) لعرض تلميح في النموذج.
    ref_report = None
    if ref:
        conn = db.connect()
        try:
            raw = db.get_report(conn, ref)
            if raw:
                ref_report = _enrich(raw, _lang(request))
        finally:
            conn.close()
    ctx.update({"page": "submit", "ok": bool(ok), "error": None, "form": {},
                "ref_report": ref_report, "intent": intent})
    return templates.TemplateResponse(request, "submit.html", ctx)


@app.post("/submit", response_class=HTMLResponse)
def submit_report(
    request: Request,
    title: str = Form(...),
    category: str = Form(...),
    severity: str = Form(...),
    country: str = Form(...),
    region: str = Form(""),
    occurred_on: str = Form(""),
    summary: str = Form(...),
    details: str = Form(""),
    source_name: str = Form(""),
    source_url: str = Form(""),
):
    ctx = _base_context(request)
    lang = _lang(request)
    form = {
        "title": title, "category": category, "severity": severity, "country": country,
        "region": region, "occurred_on": occurred_on, "summary": summary,
        "details": details, "source_name": source_name, "source_url": source_url,
    }
    errors = []
    if len(title.strip()) < 6:
        errors.append(t("submit.err_title_short", lang))
    if category not in CATEGORY_BY_KEY:
        errors.append(t("submit.err_category", lang))
    if severity not in SEVERITY_BY_KEY:
        errors.append(t("submit.err_severity", lang))
    if not country.strip():
        errors.append(t("submit.err_country_required", lang))
    elif not find_country(country.strip()):
        errors.append(t("submit.err_country_unknown", lang))
    if len(summary.strip()) < 20:
        errors.append(t("submit.err_summary_short", lang))

    occurred = occurred_on.strip()
    if occurred:
        try:
            d = date.fromisoformat(occurred)
            if d > date.today():
                errors.append(t("submit.err_occurred_future", lang))
        except ValueError:
            errors.append(t("submit.err_occurred_format", lang))

    url = source_url.strip()
    if url and not url.lower().startswith(("http://", "https://")):
        errors.append(t("submit.err_url", lang))

    if errors:
        ctx.update({"page": "submit", "ok": False, "error": " ".join(errors), "form": form})
        return templates.TemplateResponse(request, "submit.html", ctx, status_code=400)

    conn = db.connect()
    try:
        src = conn.execute("SELECT id FROM sources WHERE key = 'manual'").fetchone()
        db.insert_report(conn, {
            "title": title.strip(), "category": category, "severity": severity,
            "status": "new", "country": country.strip(), "region": region.strip(),
            "occurred_on": occurred_on or None, "reported_on": date.today().isoformat(),
            "summary": summary.strip(), "details": details.strip(),
            "source_name": source_name.strip(), "source_url": source_url.strip(),
            "source_id": src["id"] if src else None, "verified": 0,
        })
    finally:
        conn.close()
    return RedirectResponse(url="/submit?ok=1", status_code=303)


@app.get("/about", response_class=HTMLResponse)
def about_page(request: Request):
    conn = db.connect()
    try:
        st = db.stats(conn)
        registry = db.source_report_counts(conn)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "about", "stats": st, "source_count": len(registry)})
    return templates.TemplateResponse(request, "about.html", ctx)


# ---------------------------------------------------------------------------
# المجتمع: الأعضاء (الدفعة 1 من المنصّة الاجتماعية)
# ---------------------------------------------------------------------------

MEMBERS_PAGE_SIZE = 24


@app.get("/members", response_class=HTMLResponse)
def members_page(
    request: Request,
    role: str = "",
    status: str = "",
    country: str = "",
    q: str = "",
    sort: str = "role",
    page: int = 1,
):
    lang = _lang(request)
    page = max(1, page)
    filters = dict(role=role or None, status=status or None,
                   country=country or None, q=q or None, sort=sort)
    conn = db.connect()
    try:
        total = social.count_members(conn, **filters)
        rows = social.query_members(
            conn, **filters,
            limit=MEMBERS_PAGE_SIZE, offset=(page - 1) * MEMBERS_PAGE_SIZE,
        )
        counts = social.member_counts(conn)
        member_countries = social.member_countries(conn)
    finally:
        conn.close()
    members = [_enrich_member(m, lang) for m in rows]
    pages = max(1, (total + MEMBERS_PAGE_SIZE - 1) // MEMBERS_PAGE_SIZE)

    # روابط المرشّحات تحفظ بقية المعاملات (بلا الاعتماد على request.url المطلق).
    # القيمة الفارغة في overrides تعني «احذف هذا المعامل».
    def _link(**overrides) -> str:
        params = {}
        if role:
            params["role"] = role
        if status:
            params["status"] = status
        if country:
            params["country"] = country
        if q:
            params["q"] = q
        if sort and sort != "role":
            params["sort"] = sort
        for key, val in overrides.items():
            if val in (None, ""):
                params.pop(key, None)
            else:
                params[key] = val
        return "/members" + ("?" + urlencode(params) if params else "")

    ctx = _base_context(request)
    ctx.update({
        "page": "members",
        "members": members,
        "total": total,
        "counts": counts,
        "member_countries": member_countries,
        "f": {"role": role, "status": status, "country": country, "q": q, "sort": sort},
        "current_page": page,
        "pages": pages,
        "link": _link,
    })
    return templates.TemplateResponse(request, "members.html", ctx)


@app.get("/member/{handle}", response_class=HTMLResponse)
def member_detail(request: Request, handle: str):
    lang = _lang(request)
    conn = db.connect()
    try:
        row = social.member_by_handle(conn, handle)
        groups = social.groups_for_member(conn, handle) if row else []
        trust = social.trust_score(conn, handle) if row else None
        badges = social.badges_for(conn, handle) if row else []
        endorsements = social.endorsements_for(conn, handle) if row else []
        vouches = social.vouches_for(conn, handle) if row else []
        network = social.trust_network(conn, handle) if row else {"inbound": [], "outbound": []}
        endorsers = [m["handle"] for m in social.query_members(conn, limit=None)]
    finally:
        conn.close()
    ctx = _base_context(request)
    if not row or not row.get("published"):
        ctx.update({"page": "members", "handle": handle})
        return templates.TemplateResponse(
            request, "member.html", ctx, status_code=404
        )
    member = _enrich_member(row, lang)
    member = _enrich_trust(member, trust, lang)
    for b in badges:
        b["label"] = badge_label(b.get("badge", ""), lang)
    for e in endorsements:
        e["dimension_label"] = reputation_dimension_label(e.get("dimension", ""), lang)
        e["created_display"] = format_date((e.get("created_at") or "")[:10], lang)
    for v in vouches:
        v["kind_label"] = vouch_kind_label(v.get("kind", ""), lang)
        v["created_display"] = format_date((v.get("created_at") or "")[:10], lang)
    ctx.update({"page": "members", "member": member,
                "member_groups": groups, "member_badges": badges,
                "endorsements": endorsements, "vouches": vouches,
                "network": network, "endorsers": endorsers})
    return templates.TemplateResponse(request, "member.html", ctx)


@app.get("/api/members")
def api_members(
    role: str | None = None,
    status: str | None = None,
    country: str | None = None,
    q: str | None = None,
    limit: int = 50,
):
    """واجهة برمجة للأعضاء (بيانات عامة فقط، بلا حقول خاصّة)."""
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = social.query_members(
            conn, role=role, status=status, country=country, q=q, limit=limit
        )
    finally:
        conn.close()
    out = []
    for m in rows:
        out.append({
            "handle": m["handle"],
            "display_name": m["display_name"],
            "role": m["role"],
            "status": m["status"],
            "country": m["country"],
            "langs": m["langs"],
            "interests": m["interests"],
            "org": m["org"],
            "verified": bool(m["verified"]),
        })
    return {"count": len(out), "members": out}


@app.get("/api/members.csv")
def export_members_csv(role: str | None = None, status: str | None = None,
                       country: str | None = None):
    conn = db.connect()
    try:
        rows = social.query_members(conn, role=role, status=status, country=country)
    finally:
        conn.close()
    body = exports.members_to_csv(rows)
    return Response(
        content=body, media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mirsad-members.csv"'},
    )


# ---------------------------------------------------------------------------
# المجتمع: المنشورات والتغذية (الدفعة 2)
# ---------------------------------------------------------------------------

POSTS_PAGE_SIZE = 20


@app.get("/posts", response_class=HTMLResponse)
def posts_page(request: Request, kind: str = "", author: str = "", tag: str = "",
               q: str = "", page: int = 1):
    """تغذية المجتمع: منشورات الناشطين مرتّبة زمنيًّا مع مرشّحات."""
    lang = _lang(request)
    page = max(1, page)
    filters = dict(kind=kind or None, author=author or None, tag=tag or None,
                   search=q or None)
    conn = db.connect()
    try:
        total = social.count_posts(conn, **filters)
        rows = social.query_posts(conn, **filters, limit=POSTS_PAGE_SIZE,
                                  offset=(page - 1) * POSTS_PAGE_SIZE)
        counts = social.post_counts(conn)
    finally:
        conn.close()
    posts = [_enrich_post(p, lang) for p in rows]
    pages = max(1, (total + POSTS_PAGE_SIZE - 1) // POSTS_PAGE_SIZE)

    def _link(**overrides) -> str:
        params = {}
        if kind:
            params["kind"] = kind
        if author:
            params["author"] = author
        if tag:
            params["tag"] = tag
        if q:
            params["q"] = q
        for key, val in overrides.items():
            if val in (None, ""):
                params.pop(key, None)
            else:
                params[key] = val
        return "/posts" + ("?" + urlencode(params) if params else "")

    ctx = _base_context(request)
    ctx.update({
        "page": "posts",
        "posts": posts,
        "total": total,
        "counts": counts,
        "f": {"kind": kind, "author": author, "tag": tag, "q": q},
        "current_page": page,
        "pages": pages,
        "link": _link,
    })
    return templates.TemplateResponse(request, "posts.html", ctx)


@app.get("/post/{post_id}", response_class=HTMLResponse)
def post_detail(request: Request, post_id: int):
    lang = _lang(request)
    conn = db.connect()
    try:
        row = social.post_by_id(conn, post_id)
        linked_report = None
        if row and row.get("report_id"):
            rep = db.get_report(conn, row["report_id"])
            if rep:
                linked_report = _enrich(rep, lang)
    finally:
        conn.close()
    ctx = _base_context(request)
    if not row or row.get("status") == "hidden":
        ctx.update({"page": "posts", "post_id": post_id})
        return templates.TemplateResponse(request, "post.html", ctx, status_code=404)
    conn = db.connect()
    try:
        reactions = social.reaction_summary(conn, post_id)
        comments = social.comment_tree(conn, post_id)
        comment_total = social.count_comments(conn, post_id)
        attachments = social.attachments_for_post(conn, post_id)
        member_handles = [m["handle"] for m in social.query_members(conn, limit=None)]
    finally:
        conn.close()
    ctx.update({"page": "posts", "post": _enrich_post(row, lang),
                "linked_report": linked_report, "reactions": reactions,
                "comments": comments, "comment_total": comment_total,
                "attachments": attachments, "member_handles": member_handles})
    return templates.TemplateResponse(request, "post.html", ctx)


@app.get("/api/posts")
def api_posts(kind: str | None = None, author: str | None = None,
              tag: str | None = None, q: str | None = None, limit: int = 30):
    """واجهة برمجة لمنشورات المجتمع (المنشورات العامّة فقط)."""
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = social.query_posts(conn, kind=kind, author=author, tag=tag,
                                  search=q, limit=limit)
        ids = [p["id"] for p in rows]
        rc = social.reaction_counts_bulk(conn, ids)
        cc = social.comment_counts_bulk(conn, ids)
    finally:
        conn.close()
    out = [{
        "id": p["id"],
        "author": p["author_handle"],
        "author_name": p["author_name"],
        "kind": p["kind"],
        "visibility": p["visibility"],
        "title": p["title"],
        "body": p["body"],
        "tags": p["tags"],
        "report_id": p["report_id"],
        "created_at": p["created_at"],
        "reactions": rc.get(p["id"], 0),
        "comments": cc.get(p["id"], 0),
    } for p in rows]
    return {"count": len(out), "posts": out}


# ---------------------------------------------------------------------------
# المجتمع: التفاعل (الدفعة 3) — نقاط كتابة محمية بحدّ معدّل
# ---------------------------------------------------------------------------

def _client_key(request: Request) -> str:
    return (request.client.host if request.client else "") or "anon"


def _acting_handle(conn, handle: str | None) -> str | None:
    """يتحقّق أن المعرّف الفاعل عضو نشط منشور (لا نظام مصادقة بعد)."""
    if not handle:
        return None
    m = social.member_by_handle(conn, handle)
    if not m or not m.get("published") or m.get("status") != "active":
        return None
    return handle


def _acting_moderator(conn, handle: str | None) -> str | None:
    """يتحقّق أن الفاعل عضو نشط بدور إشرافي (admin/moderator)."""
    who = _acting_handle(conn, handle)
    if not who:
        return None
    m = social.member_by_handle(conn, who)
    return who if m and m.get("role") in ("admin", "moderator") else None


def _admin_forbidden() -> JSONResponse:
    return JSONResponse({"error": "forbidden"}, status_code=403)


def _require_admin(conn, request: Request, handle: str | None) -> tuple[str | None, JSONResponse | None]:
    """بوّابة موحّدة لنقاط الإدارة.

    عند ضبط MIRSAD_ADMIN_KEY يُشترط تطابق ترويسة X-Admin-Key؛ وإلا (بيئة تطوير)
    تُقبل هوية عضو نشط بدور admin/moderator عبر `handle`.
    """
    if ADMIN_KEY:
        sent = request.headers.get("X-Admin-Key", "")
        cookie = request.cookies.get(ADMIN_COOKIE, "")
        ok = ((sent and _const_eq(sent, ADMIN_KEY))
              or (cookie and _const_eq(cookie, ADMIN_KEY)))
        if not ok:
            return None, JSONResponse({"error": "admin_key_required"}, status_code=401)
        who = _acting_handle(conn, handle) or "admin-key"
        return who, None
    who = _acting_moderator(conn, handle)
    if not who:
        return None, _admin_forbidden()
    return who, None


def _too_many(request: Request, action: str, key: str, limit: int) -> JSONResponse | None:
    if ratelimit.allow(f"{_client_key(request)}:{key}", action, limit):
        return None
    return JSONResponse(
        {"error": "rate_limited",
         "retry_after": ratelimit.retry_after(f"{_client_key(request)}:{key}", action)},
        status_code=429,
    )


@app.post("/api/posts/{post_id}/react")
def api_react(post_id: int, request: Request, handle: str = "", kind: str = "like"):
    """يبدّل تفاعلًا (like/support/important) على منشور."""
    conn = db.connect()
    try:
        if not social.post_by_id(conn, post_id):
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "react", who, 40)
        if limited:
            return limited
        result = social.toggle_reaction(conn, post_id, who, kind)
        summary = social.reaction_summary(conn, post_id)
    finally:
        conn.close()
    return {"ok": True, **result, "summary": summary}


@app.get("/api/posts/{post_id}/comments")
def api_comments(post_id: int):
    conn = db.connect()
    try:
        if not social.post_by_id(conn, post_id):
            return JSONResponse({"error": "not_found"}, status_code=404)
        tree = social.comment_tree(conn, post_id)
        total = social.count_comments(conn, post_id)
    finally:
        conn.close()
    return {"count": total, "comments": tree}


@app.post("/api/posts/{post_id}/comment")
def api_add_comment(post_id: int, request: Request, handle: str = "",
                    body: str = "", parent_id: int | None = None):
    """يضيف تعليقًا أو ردًّا على منشور."""
    body = (body or "").strip()
    if len(body) < 2:
        return JSONResponse({"error": "empty"}, status_code=400)
    if len(body) > 2000:
        return JSONResponse({"error": "too_long"}, status_code=400)
    conn = db.connect()
    try:
        if not social.post_by_id(conn, post_id):
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "comment", who, 20)
        if limited:
            return limited
        cid = social.add_comment(conn, post_id, who, body, parent_id or None)
    finally:
        conn.close()
    return {"ok": True, "id": cid}


@app.post("/api/posts/{post_id}/report")
def api_report_post(post_id: int, request: Request, handle: str = "",
                    reason: str = "", note: str = ""):
    """يسجّل إبلاغًا عن منشور في طابور الإشراف."""
    reason = (reason or "").strip()
    if not reason:
        return JSONResponse({"error": "reason_required"}, status_code=400)
    conn = db.connect()
    try:
        if not social.post_by_id(conn, post_id):
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        limited = _too_many(request, "report", who or _client_key(request), 10)
        if limited:
            return limited
        rid = social.report_content(conn, "post", post_id, reason, who, note or None)
    finally:
        conn.close()
    return {"ok": True, "id": rid}


@app.post("/api/members/{handle}/block")
def api_block_member(handle: str, request: Request, owner: str = "",
                     action: str = "block"):
    """يحجب عضوًا (أو يرفع الحجب) على مستوى العرض."""
    conn = db.connect()
    try:
        if not _acting_handle(conn, owner):
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        if not _acting_handle(conn, handle):
            return JSONResponse({"error": "target_not_found"}, status_code=404)
        limited = _too_many(request, "block", owner, 30)
        if limited:
            return limited
        changed = (social.unblock_member(conn, owner, handle) if action == "unblock"
                   else social.block_member(conn, owner, handle))
    finally:
        conn.close()
    return {"ok": True, "changed": changed}


@app.get("/api/content-reports")
def api_content_reports(state: str = "open"):
    """طابور الإشراف: الإبلاغات عن محتوى المجتمع."""
    conn = db.connect()
    try:
        rows = social.content_reports(conn, state=state)
    finally:
        conn.close()
    return {"count": len(rows), "reports": rows}


# ---------------------------------------------------------------------------
# المجتمع: المجموعات والمجتمعات (الدفعة 4)
# ---------------------------------------------------------------------------

@app.get("/groups", response_class=HTMLResponse)
def groups_page(request: Request, kind: str = "", visibility: str = "",
                q: str = "", sort: str = "recent", page: int = 1):
    """دليل المجموعات: مجتمعات ولجان وفِرق تعاون الناشطين."""
    lang = _lang(request)
    page = max(1, page)
    conn = db.connect()
    try:
        filters = dict(kind=kind or None, visibility=visibility or None, search=q or None)
        total = social.count_groups(conn, **filters)
        rows = social.query_groups(conn, **filters, sort=sort,
                                   limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
        counts = social.group_counts(conn)
    finally:
        conn.close()
    groups = [_enrich_group(g, lang) for g in rows]
    pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)

    def _link(**overrides) -> str:
        params = {}
        for key, val in (("kind", kind), ("visibility", visibility), ("q", q), ("sort", sort)):
            if val:
                params[key] = val
        for key, val in overrides.items():
            if val in (None, ""):
                params.pop(key, None)
            else:
                params[key] = val
        return "/groups" + ("?" + urlencode(params) if params else "")

    ctx = _base_context(request)
    ctx.update({"page": "groups", "groups": groups, "total": total, "counts": counts,
                "f": {"kind": kind, "visibility": visibility, "q": q, "sort": sort},
                "current_page": page, "pages": pages, "link": _link})
    return templates.TemplateResponse(request, "groups.html", ctx)


@app.get("/group/{slug}", response_class=HTMLResponse)
def group_detail(request: Request, slug: str):
    lang = _lang(request)
    conn = db.connect()
    try:
        row = social.group_by_slug(conn, slug)
        members = social.group_members(conn, row["id"]) if row else []
        posts = social.group_posts(conn, row["id"]) if row else []
        pending = social.group_members(conn, row["id"], status="pending") if row else []
        member_handles = [m["handle"] for m in social.query_members(conn, limit=None)]
    finally:
        conn.close()
    ctx = _base_context(request)
    if not row or row.get("status") != "active" or row.get("visibility") == "secret":
        ctx.update({"page": "groups", "slug": slug})
        return templates.TemplateResponse(request, "group.html", ctx, status_code=404)
    ctx.update({"page": "groups", "group": _enrich_group(row, lang),
                "members": members, "posts": [_enrich_post(p, lang) for p in posts],
                "pending": pending, "member_handles": member_handles})
    return templates.TemplateResponse(request, "group.html", ctx)


@app.get("/api/groups")
def api_groups(kind: str | None = None, visibility: str | None = None,
               q: str | None = None, limit: int = 50):
    """واجهة برمجة للمجموعات (بلا المجموعات السرّية)."""
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = social.query_groups(conn, kind=kind, visibility=visibility,
                                   search=q, limit=limit)
    finally:
        conn.close()
    out = [{"id": g["id"], "slug": g["slug"], "name": g["name"], "name_en": g["name_en"],
            "kind": g["kind"], "visibility": g["visibility"], "country": g["country"],
            "category": g["category"], "members": g["member_count"], "posts": g["post_count"]}
           for g in rows]
    return {"count": len(out), "groups": out}


@app.get("/api/groups/{slug}")
def api_group_detail(slug: str):
    conn = db.connect()
    try:
        row = social.group_by_slug(conn, slug)
        if not row or row.get("visibility") == "secret":
            return JSONResponse({"error": "not_found"}, status_code=404)
        members = social.group_members(conn, row["id"])
    finally:
        conn.close()
    return {"group": {"slug": row["slug"], "name": row["name"], "kind": row["kind"],
                      "visibility": row["visibility"], "purpose": row["purpose"],
                      "members": row["member_count"]},
            "roster": [{"handle": m["handle"], "name": m["display_name"], "role": m["role"]}
                       for m in members]}


@app.post("/api/groups/{slug}/join")
def api_group_join(slug: str, request: Request, handle: str = ""):
    """انضمام لمجموعة (مباشر للعام، وبانتظار الموافقة للخاص/السرّي)."""
    conn = db.connect()
    try:
        row = social.group_by_slug(conn, slug)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "group_join", who, 20)
        if limited:
            return limited
        result = social.join_group(conn, row["id"], who)
    finally:
        conn.close()
    return result


@app.post("/api/groups/{slug}/leave")
def api_group_leave(slug: str, request: Request, handle: str = ""):
    conn = db.connect()
    try:
        row = social.group_by_slug(conn, slug)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "group_leave", who, 20)
        if limited:
            return limited
        left = social.leave_group(conn, row["id"], who)
    finally:
        conn.close()
    return {"ok": True, "left": left}


# ---------------------------------------------------------------------------
# المجتمع: الرسائل والمحادثات (الدفعة 5)
# ---------------------------------------------------------------------------

@app.get("/messages", response_class=HTMLResponse)
def messages_page(request: Request, handle: str = "", cid: int | None = None):
    """صندوق محادثات العضو. الهوية عبر `?handle=` (لا مصادقة بعد)."""
    lang = _lang(request)
    conn = db.connect()
    try:
        members = social.query_members(conn, limit=None)
        handles = {m["handle"] for m in members}
        who = handle if handle in handles else (members[0]["handle"] if members else "")
        convos = social.conversations_for_member(conn, who) if who else []
        active = None
        messages = []
        if cid is not None and who:
            active = social.conversation_for_member(conn, cid, who)
            if active:
                messages = social.conversation_messages(conn, cid)
        elif convos and who:
            active = social.conversation_for_member(conn, convos[0]["id"], who)
            if active:
                messages = social.conversation_messages(conn, convos[0]["id"])
    finally:
        conn.close()
    for c in convos:
        c["title_display"] = c.get("title") if lang == "ar" else (c.get("title_en") or c.get("title"))
        c["last_display"] = format_relative(c.get("last_at"), lang) if c.get("last_at") else ""
    for m in messages:
        m["created_display"] = format_relative(m.get("created_at"), lang)
    ctx = _base_context(request)
    ctx.update({"page": "messages", "who": who, "members": members,
                "convos": convos, "active": active, "messages": messages})
    return templates.TemplateResponse(request, "messages.html", ctx)


@app.get("/api/conversations")
def api_conversations(handle: str = ""):
    """محادثات عضو (يتطلّب عضوية صالحة)."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        rows = social.conversations_for_member(conn, who)
    finally:
        conn.close()
    return {"count": len(rows), "conversations": rows}


@app.get("/api/conversations/{cid}")
def api_conversation(cid: int, handle: str = ""):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        conv = social.conversation_for_member(conn, cid, who)
        if not conv:
            return JSONResponse({"error": "not_found"}, status_code=404)
        msgs = social.conversation_messages(conn, cid)
        members = social.conversation_members(conn, cid)
    finally:
        conn.close()
    return {"conversation": {"id": conv["id"], "kind": conv["kind"], "title": conv["title"]},
            "members": [{"handle": m["handle"], "name": m["display_name"], "role": m["role"]} for m in members],
            "messages": [{"id": m["id"], "sender": m["sender_handle"], "body": m["body"],
                          "created_at": m["created_at"]} for m in msgs]}


@app.post("/api/conversations/{cid}/messages")
def api_send_message(cid: int, request: Request, handle: str = "", body: str = ""):
    """إرسال رسالة إلى محادثة (المشاركون فقط)."""
    body = (body or "").strip()
    if len(body) < 1:
        return JSONResponse({"error": "empty"}, status_code=400)
    if len(body) > 4000:
        return JSONResponse({"error": "too_long"}, status_code=400)
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "message", who, 60)
        if limited:
            return limited
        mid = social.send_message(conn, cid, who, body)
        if mid is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
    finally:
        conn.close()
    return {"ok": True, "id": mid}


@app.post("/api/conversations/direct")
def api_start_direct(request: Request, handle: str = "", target: str = ""):
    """يفتح (أو ينشئ) محادثة مباشرة بين عضوين."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        other = _acting_handle(conn, target)
        if not who or not other or who == other:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "direct", who, 20)
        if limited:
            return limited
        cid = social.start_direct_conversation(conn, who, other)
    finally:
        conn.close()
    return {"ok": True, "id": cid}


# ---------------------------------------------------------------------------
# التحقّق من الحقائق والتوثيق (الدفعة 6)
# ---------------------------------------------------------------------------

@app.get("/verification", response_class=HTMLResponse)
def verification_page(request: Request, status: str = "", category: str = "",
                      assignee: str = "", q: str = "", sort: str = "recent",
                      page: int = 1):
    """طابور التحقّق: ادّعاءات قيد المراجعة ومصادرها ودرجة الثقة."""
    lang = _lang(request)
    page = max(1, page)
    conn = db.connect()
    try:
        filters = dict(status=status or None, category=category or None,
                       assignee=assignee or None, q=q or None)
        total = social.count_claims(conn, **filters)
        rows = social.query_claims(conn, **filters, sort=sort,
                                   limit=PAGE_SIZE, offset=(page - 1) * PAGE_SIZE)
        counts = social.claim_counts(conn)
        leaderboard = social.claims_leaderboard(conn)
        for r in rows:
            r["sources"] = social.claim_sources(conn, r["id"])
    finally:
        conn.close()
    claims = [_enrich_claim(c, lang) for c in rows]
    pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    ctx = _base_context(request)
    ctx.update({"page": "verification", "claims": claims, "total": total, "counts": counts,
                "leaderboard": leaderboard,
                "f": {"status": status, "category": category, "assignee": assignee,
                      "q": q, "sort": sort},
                "current_page": page, "pages": pages})
    return templates.TemplateResponse(request, "verification.html", ctx)


@app.get("/verification/{ref}", response_class=HTMLResponse)
def claim_detail(request: Request, ref: str):
    lang = _lang(request)
    conn = db.connect()
    try:
        row = social.claim_by_ref(conn, ref)
        if not row:
            sources = reviews = timeline = []
        else:
            sources = social.claim_sources(conn, row["id"])
            reviews = social.claim_reviews(conn, row["id"])
            timeline = social.claim_timeline(conn, row["id"])
        handles = [m["handle"] for m in social.query_members(conn, role="verifier", limit=None)]
        reports = db.reports_by_ids(conn, [row["report_id"]]) if row and row.get("report_id") else []
    finally:
        conn.close()
    ctx = _base_context(request)
    if not row:
        ctx.update({"page": "verification", "ref": ref})
        return templates.TemplateResponse(request, "claim.html", ctx, status_code=404)
    claim = _enrich_claim(row, lang)
    claim["sources"] = [_enrich_claim_source(s, lang) for s in sources]
    claim["confidence"] = social._claim_confidence(claim["status"], sources)
    claim["confidence_level"] = claim["confidence"]["level"]
    claim["linked_report"] = _enrich(reports[0], lang) if reports else None
    for rv in reviews:
        rv["decision_label"] = review_decision_label(rv.get("decision", ""), lang)
        rv["created_display"] = format_datetime(rv.get("created_at"), lang)
    for t in timeline:
        t["action_label"] = review_decision_label(t.get("action", ""), lang) \
            if t.get("action") in REVIEW_DECISION_BY_KEY else t.get("action", "")
        t["created_display"] = format_datetime(t.get("created_at"), lang)
    ctx.update({"page": "verification", "claim": claim, "reviews": reviews,
                "timeline": timeline, "verifier_handles": handles})
    return templates.TemplateResponse(request, "claim.html", ctx)


@app.get("/api/claims")
def api_claims(status: str | None = None, category: str | None = None,
               q: str | None = None, limit: int = 50):
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = social.query_claims(conn, status=status, category=category, q=q, limit=limit)
        for r in rows:
            r["sources"] = social.claim_sources(conn, r["id"])
    finally:
        conn.close()
    out = []
    for c in rows:
        conf = social._claim_confidence(c["status"], c["sources"])
        out.append({"ref": c["ref"], "title": c["title"], "status": c["status"],
                    "category": c["category"], "sources": len(c["sources"]),
                    "confidence": conf["score"], "level": conf["level"]})
    return {"count": len(out), "claims": out}


@app.get("/api/claims/{ref}")
def api_claim(ref: str):
    conn = db.connect()
    try:
        row = social.claim_by_ref(conn, ref)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        sources = social.claim_sources(conn, row["id"])
        reviews = social.claim_reviews(conn, row["id"])
    finally:
        conn.close()
    conf = social._claim_confidence(row["status"], sources)
    return {"claim": {"ref": row["ref"], "title": row["title"], "summary": row["summary"],
                      "status": row["status"], "category": row["category"],
                      "assignee": row["assignee_handle"], "report_id": row["report_id"]},
            "confidence": conf,
            "sources": [{"kind": s["kind"], "reliability": s["reliability"],
                         "label": s["label"], "url": s["url"]} for s in sources],
            "reviews": [{"reviewer": r["reviewer_handle"], "decision": r["decision"],
                         "note": r["note"], "at": r["created_at"]} for r in reviews]}


@app.post("/api/claims/{ref}/sources")
def api_add_claim_source(ref: str, request: Request, handle: str = "",
                         kind: str = "secondary", reliability: str = "3",
                         label: str = "", url: str = ""):
    """إضافة مصدر لادّعاء (للمحقّقين فقط)."""
    conn = db.connect()
    try:
        row = social.claim_by_ref(conn, ref)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "claim_source", who, 40)
        if limited:
            return limited
        sid = social.add_claim_source(conn, row["id"], kind=kind, reliability=reliability,
                                      label=(label or "").strip()[:200], url=url or None)
    finally:
        conn.close()
    return {"ok": True, "id": sid}


@app.post("/api/claims/{ref}/review")
def api_review_claim(ref: str, request: Request, handle: str = "",
                     decision: str = "", note: str = ""):
    """مراجعة ادّعاء: تأكيد/اعتراض/تكذيب/طلب أدلّة (للمحقّقين فقط)."""
    if decision not in REVIEW_DECISION_BY_KEY:
        return JSONResponse({"error": "invalid_decision"}, status_code=400)
    conn = db.connect()
    try:
        row = social.claim_by_ref(conn, ref)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "claim_review", who, 40)
        if limited:
            return limited
        result = social.review_claim(conn, row["id"], who, decision, (note or "").strip()[:500])
    finally:
        conn.close()
    return result


@app.post("/api/claims/{ref}/assign")
def api_assign_claim(ref: str, request: Request, handle: str = "", assignee: str = ""):
    """إسناد ادّعاء لمحقّق."""
    conn = db.connect()
    try:
        row = social.claim_by_ref(conn, ref)
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        target = _acting_handle(conn, assignee)
        if not who or not target:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "claim_assign", who, 40)
        if limited:
            return limited
        ok = social.assign_claim(conn, row["id"], target, who)
    finally:
        conn.close()
    return {"ok": ok}


# ---------------------------------------------------------------------------
# الإشراف والحوكمة (الدفعة 7)
# ---------------------------------------------------------------------------

@app.get("/moderation", response_class=HTMLResponse)
def moderation_page(request: Request, state: str = "open"):
    """لوحة الإشراف: طابور الإبلاغات، الاستئنافات، سجلّ القرارات، والمؤشّرات."""
    lang = _lang(request)
    state = state if state in REPORT_STATE_BY_KEY else "open"
    conn = db.connect()
    try:
        reports = social.content_reports(conn, state=state, limit=100)
        counts = {s["key"]: social.count_content_reports(conn, s["key"]) for s in REPORT_STATES}
        pending = social.appeals(conn, status="pending")
        stats = social.moderation_stats(conn)
        audit = social.recent_audit(conn, limit=30)
        alerts = social.expiry_alerts(conn)
        moderators = [m for m in social.query_members(conn, limit=None)
                      if m.get("role") in ("admin", "moderator") and m.get("published")]
        for r in reports:
            r["reason_label"] = report_reason_label(r.get("reason", ""), lang)
            r["created_display"] = format_datetime(r.get("created_at"), lang)
            r["target_label"] = _target_label(conn, r["target_kind"], r["target_id"], lang)
        for a in pending:
            a["action_label"] = moderation_action_label(a.get("action", ""), lang)
            a["created_display"] = format_datetime(a.get("created_at"), lang)
    finally:
        conn.close()
    for e in alerts:
        e["action_label"] = moderation_action_label(e.get("action", ""), lang)
        e["expires_display"] = format_datetime(e.get("expires_at"), lang)
    ctx = _base_context(request)
    ctx.update({"page": "moderation", "reports": reports, "state": state, "counts": counts,
                "appeals": pending, "stats": stats, "audit": audit, "alerts": alerts,
                "moderators": moderators})
    return templates.TemplateResponse(request, "moderation.html", ctx)


def _target_label(conn, kind: str, target_id: int, lang: str) -> str:
    """وصف مقروء لهدف إبلاغ (منشور/تعليق)."""
    if kind == "post":
        p = social.post_by_id(conn, target_id)
        return (p or {}).get("title") or f"#{target_id}"
    if kind == "comment":
        c = conn.execute("SELECT body FROM comments WHERE id=?", (target_id,)).fetchone()
        return c["body"][:60] if c else f"#{target_id}"
    return f"{kind} #{target_id}"


@app.post("/api/moderation/reports/{report_id}/state")
def api_report_state(report_id: int, request: Request, handle: str = "", state: str = ""):
    conn = db.connect()
    try:
        who = _acting_moderator(conn, handle)
        if not who:
            return JSONResponse({"error": "forbidden"}, status_code=403)
        limited = _too_many(request, "mod_state", who, 60)
        if limited:
            return limited
        ok = social.set_report_state(conn, report_id, state, who)
    finally:
        conn.close()
    return {"ok": ok}


@app.post("/api/moderation/actions")
def api_moderate(request: Request, handle: str = "", target_kind: str = "member",
                 target_id: int = 0, target_handle: str = "", action: str = "",
                 reason: str = "", report_id: int | None = None, days: int | None = None):
    """يطبّق إجراء إشراف متدرّجًا (يتطلّب مشرفًا وسببًا)."""
    conn = db.connect()
    try:
        who = _acting_moderator(conn, handle)
        if not who:
            return JSONResponse({"error": "forbidden"}, status_code=403)
        limited = _too_many(request, "moderate", who, 40)
        if limited:
            return limited
        result = social.apply_moderation(
            conn, target_kind=target_kind, target_id=target_id,
            target_handle=target_handle or None, action=action, reason=reason,
            moderator=who, report_id=report_id, days=days)
    finally:
        conn.close()
    if not result.get("ok"):
        return JSONResponse(result, status_code=400)
    return result


@app.post("/api/appeals")
def api_file_appeal(request: Request, handle: str = "", action_id: int = 0, statement: str = ""):
    """يقدّم العضو استئنافًا على إجراء إشراف يخصّه."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "appeal", who, 10)
        if limited:
            return limited
        result = social.file_appeal(conn, action_id, who, statement)
    finally:
        conn.close()
    if not result.get("ok"):
        return JSONResponse(result, status_code=400)
    return result


@app.post("/api/appeals/{appeal_id}/review")
def api_review_appeal(appeal_id: int, request: Request, handle: str = "",
                      decision: str = "", note: str = ""):
    """يراجع مشرف استئنافًا (قبول يرفع الإجراء)."""
    conn = db.connect()
    try:
        who = _acting_moderator(conn, handle)
        if not who:
            return JSONResponse({"error": "forbidden"}, status_code=403)
        limited = _too_many(request, "appeal_review", who, 40)
        if limited:
            return limited
        result = social.review_appeal(conn, appeal_id, who, decision, (note or "").strip()[:500])
    finally:
        conn.close()
    if not result.get("ok"):
        return JSONResponse(result, status_code=400)
    return result


@app.get("/api/moderation/stats")
def api_moderation_stats():
    conn = db.connect()
    try:
        stats = social.moderation_stats(conn)
        audit = social.recent_audit(conn, limit=20)
    finally:
        conn.close()
    return {"stats": stats, "audit": audit}


# ---------------------------------------------------------------------------
# السمعة والثقة (الدفعة 8)
# ---------------------------------------------------------------------------

@app.get("/trust", response_class=HTMLResponse)
def trust_page(request: Request):
    """صفحة الثقة: مركّب الثقة، المستويات، اللوحة، والشارات (شفافية)."""
    lang = _lang(request)
    conn = db.connect()
    try:
        leaderboard = social.trust_leaderboard(conn, limit=25)
        top_endorsed = [dict(r) for r in conn.execute(
            """SELECT member, COUNT(*) AS n, COALESCE(SUM(weight),0) AS w
               FROM endorsements GROUP BY member ORDER BY w DESC LIMIT 10"""
        ).fetchall()]
        total_vouches = conn.execute("SELECT COUNT(*) AS n FROM vouches").fetchone()["n"]
        total_badges = conn.execute("SELECT COUNT(*) AS n FROM member_badges").fetchone()["n"]
        for r in leaderboard:
            r["level_label"] = trust_level_label(r["level"], lang)
            r["level_color"] = TRUST_LEVEL_BY_KEY.get(str(r["level"]), {}).get("color", "#9ca3af")
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "trust", "leaderboard": leaderboard, "top_endorsed": top_endorsed,
                "total_vouches": total_vouches, "total_badges": total_badges})
    return templates.TemplateResponse(request, "trust.html", ctx)


@app.get("/api/members/{handle}/trust")
def api_member_trust(handle: str):
    conn = db.connect()
    try:
        if not social.member_by_handle(conn, handle):
            return JSONResponse({"error": "not_found"}, status_code=404)
        trust = social.trust_score(conn, handle)
        badges = [b["badge"] for b in social.badges_for(conn, handle)]
        vouches = social.vouches_for(conn, handle)
        endorsements = social.endorsements_for(conn, handle)
        network = social.trust_network(conn, handle)
    finally:
        conn.close()
    return {"handle": handle, "score": trust["score"], "level": trust["level"],
            "breakdown": trust["breakdown"], "badges": badges,
            "endorsements": len(endorsements), "vouches": len(vouches),
            "network_degree": network["degree"]}


@app.post("/api/members/{handle}/endorse")
def api_endorse(handle: str, request: Request, handle_by: str = "",
                dimension: str = "accuracy", note: str = ""):
    """يضيف تأييدًا لعضو (بوزن يعتمد على موثوقية المُقيِّم)."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle_by)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "endorse", who, 20)
        if limited:
            return limited
        result = social.add_endorsement(conn, handle, who, dimension, (note or "").strip()[:300])
    finally:
        conn.close()
    if not result.get("ok"):
        return JSONResponse(result, status_code=400)
    return result


@app.post("/api/members/{handle}/vouch")
def api_vouch(handle: str, request: Request, handle_by: str = "",
              kind: str = "peer", statement: str = ""):
    """يضمن عضوًا موثوقًا عضوًا آخر (web of trust)."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle_by)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "vouch", who, 10)
        if limited:
            return limited
        result = social.add_vouch(conn, handle, who, kind, (statement or "").strip()[:300])
    finally:
        conn.close()
    if not result.get("ok"):
        return JSONResponse(result, status_code=400)
    return result


@app.get("/api/trust/leaderboard")
def api_trust_leaderboard(limit: int = 20):
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = social.trust_leaderboard(conn, limit=limit)
    finally:
        conn.close()
    return {"count": len(rows),
            "leaderboard": [{"handle": r["handle"], "display_name": r["display_name"],
                             "score": r["score"], "level": r["level"]} for r in rows]}


# ---------------------------------------------------------------------------
# الإشعارات والتنبيهات (الدفعة 9)
# ---------------------------------------------------------------------------

def _enrich_notification(n: dict, lang: str = "ar") -> dict:
    n = dict(n)
    n["category_label"] = notification_category_label(n.get("category", ""), lang)
    n["priority_label"] = notification_priority_label(n.get("priority", ""), lang)
    n["channel_label"] = notification_channel_label(n.get("channel", ""), lang)
    cat = NOTIFICATION_CATEGORY_BY_KEY.get(n.get("category", ""), {})
    n["category_color"] = cat.get("color", "#6b7280")
    n["category_icon"] = cat.get("icon", "alert")
    n["created_display"] = format_datetime(n.get("created_at"), lang)
    n["is_critical"] = n.get("priority") == "critical"
    return n


@app.get("/notifications", response_class=HTMLResponse)
def notifications_page(request: Request, handle: str = "", category: str = "",
                       unread: int = 0):
    """مركز الإشعارات الموحّد: القائمة، الملخّص، الاشتراكات، والتفضيلات."""
    lang = _lang(request)
    conn = db.connect()
    try:
        member = social.member_by_handle(conn, handle) if handle else None
        member = member if (member and member.get("published")) else None
        items, digest_data, subs, prefs, quiet, stats = [], None, [], [], None, None
        if member:
            h = member["handle"]
            items = [_enrich_notification(n, lang) for n in social.notifications_for(
                conn, h, unread_only=bool(unread),
                category=(category if category in NOTIFICATION_CATEGORY_BY_KEY else None))]
            digest_data = social.digest(conn, h)
            subs = social.subscriptions_for(conn, h)
            prefs = social.notification_prefs_for(conn, h)
            quiet = social.quiet_hours_for(conn, h)
            stats = {"unread": social.unread_count(conn, h)}
            for s in subs:
                s["kind_label"] = subscription_kind_label(s.get("kind", ""), lang)
                s["created_display"] = format_date((s.get("created_at") or "")[:10], lang)
            for p in prefs:
                p["category_label"] = notification_category_label(p.get("category", ""), lang)
                p["channel_label"] = notification_channel_label(p.get("channel", ""), lang)
        for d in (digest_data["items"] if digest_data else []):
            d["category_label"] = notification_category_label(d.get("category", ""), lang)
            d["priority_label"] = notification_priority_label(d.get("priority", ""), lang)
        nav_members = [m for m in social.query_members(conn, limit=None) if m.get("published")]
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "notifications", "handle": handle, "member": member,
                "items": items, "digest": digest_data, "subs": subs, "prefs": prefs,
                "quiet": quiet, "stats": stats, "category": category,
                "nav_members": nav_members, "unread_only": bool(unread)})
    return templates.TemplateResponse(request, "notifications.html", ctx)


@app.get("/api/notifications")
def api_notifications(handle: str = "", unread: int = 0, category: str | None = None,
                      limit: int = 50):
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        if not social.member_by_handle(conn, handle):
            return JSONResponse({"error": "not_found"}, status_code=404)
        items = social.notifications_for(conn, handle, unread_only=bool(unread),
                                         category=category, limit=limit)
        unread_n = social.unread_count(conn, handle)
    finally:
        conn.close()
    return {"count": len(items), "unread": unread_n,
            "notifications": [{k: n[k] for k in
                               ("id", "category", "priority", "kind", "title", "body",
                                "link", "actor", "read", "created_at")} for n in items]}


@app.get("/api/notifications/count")
def api_notifications_count(handle: str = ""):
    conn = db.connect()
    try:
        n = social.unread_count(conn, handle) if handle else 0
    finally:
        conn.close()
    return {"unread": n}


@app.get("/api/notifications/digest")
def api_notifications_digest(handle: str = ""):
    conn = db.connect()
    try:
        if not social.member_by_handle(conn, handle):
            return JSONResponse({"error": "not_found"}, status_code=404)
        d = social.digest(conn, handle)
    finally:
        conn.close()
    return d


@app.post("/api/notifications/read")
def api_notifications_read(request: Request, handle: str = "", id: int | None = None):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "notif_read", who, 120)
        if limited:
            return limited
        n = social.mark_read(conn, who, id)
    finally:
        conn.close()
    return {"ok": True, "updated": n}


@app.post("/api/notifications/test")
def api_notifications_test(request: Request, handle: str = "", category: str = "system",
                           title: str = "إشعار تجريبي"):
    """ينشئ إشعارًا تجريبيًّا (لاختبار احترام التفضيلات وساعات الهدوء)."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "notif_test", who, 20)
        if limited:
            return limited
        nid = social.notify(conn, who, "test", title, category=category,
                            body="هذا إشعار تجريبي من مِرصد.", link="/notifications")
    finally:
        conn.close()
    if nid is None:
        return JSONResponse({"ok": False, "error": "suppressed"}, status_code=200)
    return {"ok": True, "id": nid}


@app.post("/api/notifications/prefs")
def api_notifications_prefs(request: Request, handle: str = "", category: str = "",
                            channel: str = "inapp", enabled: int = 1,
                            muted_until: str | None = None):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        if category not in NOTIFICATION_CATEGORY_BY_KEY:
            return JSONResponse({"error": "bad_category"}, status_code=400)
        social.set_notification_pref(conn, who, category, channel, bool(enabled), muted_until)
    finally:
        conn.close()
    return {"ok": True}


@app.post("/api/notifications/mute-all")
def api_notifications_mute_all(request: Request, handle: str = "", until: str | None = None):
    """إيقاف كل الإشعارات بزر واحد (عدا الأمنية)."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        social.mute_all(conn, who, until)
    finally:
        conn.close()
    return {"ok": True}


@app.post("/api/notifications/quiet-hours")
def api_quiet_hours(request: Request, handle: str = "", start_hour: int = 22,
                    end_hour: int = 7, tz: str = "UTC"):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        social.set_quiet_hours(conn, who, start_hour, end_hour, tz)
    finally:
        conn.close()
    return {"ok": True}


@app.post("/api/subscriptions")
def api_subscribe(request: Request, handle: str = "", kind: str = "category", value: str = ""):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "subscribe", who, 40)
        if limited:
            return limited
        ok = social.subscribe(conn, who, kind, value.strip())
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "bad_subscription"}, status_code=400)
    return {"ok": True}


@app.delete("/api/subscriptions")
def api_unsubscribe(request: Request, handle: str = "", kind: str = "category", value: str = ""):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        ok = social.unsubscribe(conn, who, kind, value.strip())
    finally:
        conn.close()
    return {"ok": ok}


@app.get("/api/subscriptions")
def api_subscriptions(handle: str = ""):
    conn = db.connect()
    try:
        rows = social.subscriptions_for(conn, handle) if handle else []
    finally:
        conn.close()
    return {"count": len(rows), "subscriptions": rows}


@app.get("/notifications.rss")
def notifications_rss(request: Request, handle: str = ""):
    """قناة RSS لآخر الإشعارات (تصدير)."""
    lang = _lang(request)
    conn = db.connect()
    try:
        items = social.notifications_for(conn, handle, limit=40) if handle else []
    finally:
        conn.close()
    base = _site_url(request)
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<rss version="2.0"><channel>',
             f"<title>{t('notif.title', lang=lang)}</title>",
             f"<link>{base}/notifications</link>",
             f"<description>{t('notif.lede', lang=lang)}</description>"]
    for n in items:
        parts.append("<item>")
        parts.append(f"<title>{exports._xml_escape(n['title'])}</title>")
        parts.append(f"<link>{base}{n.get('link') or '/notifications'}</link>")
        parts.append(f"<pubDate>{n['created_at']}</pubDate>")
        parts.append(f"<category>{exports._xml_escape(n['category'])}</category>")
        if n.get("body"):
            parts.append(f"<description>{exports._xml_escape(n['body'])}</description>")
        parts.append("</item>")
    parts.append("</channel></rss>")
    return Response("".join(parts), media_type="application/rss+xml; charset=utf-8")


@app.get("/api/notifications/stats")
def api_notification_stats():
    conn = db.connect()
    try:
        stats = social.notification_stats(conn)
    finally:
        conn.close()
    return stats


# ---------------------------------------------------------------------------
# البحث والاكتشاف (الدفعة 10)
# ---------------------------------------------------------------------------

def _localized_search_kinds(lang: str = "ar") -> list[dict]:
    return [{**k, "label": (k.get("label_en") or k["label"]) if lang == "en" else k["label"]}
            for k in search.SEARCH_KINDS]


@app.get("/discover", response_class=HTMLResponse)
def discover_page(request: Request, q: str = "", kind: str = "", safe: int = 1,
                  handle: str = ""):
    """صفحة البحث والاكتشاف: بحث موحّد + لوحات اكتشاف + بحوث محفوظة."""
    lang = _lang(request)
    q = (q or "").strip()
    kinds = [k for k in kind.split(",") if k in search.SEARCH_KIND_BY_KEY] if kind else None
    conn = db.connect()
    try:
        data = search.unified_search(conn, q, kinds=kinds, safe=bool(safe)) if q else None
        if data:
            for grp in data["groups"].values():
                for it in grp:
                    it["kind_label"] = search.search_kind_label(it["kind"], lang)
                    it["safe_hidden"] = bool(safe)
        boards = search.discovery_boards(conn)
        for c in boards["top_categories"]:
            c["label"] = category_name(c["category"], lang)
        trending = search.trending_terms(conn)
        saved = search.saved_searches(conn, handle) if handle else []
        member = social.member_by_handle(conn, handle) if handle else None
        member = member if (member and member.get("published")) else None
        nav_members = [m for m in social.query_members(conn, limit=None) if m.get("published")]
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "discover", "q": q, "kind": kind, "safe": bool(safe),
                "data": data, "boards": boards, "trending": trending,
                "saved": saved, "handle": handle, "member": member,
                "nav_members": nav_members,
                "search_kinds": _localized_search_kinds(lang),
                "search_kind_label": lambda k: search.search_kind_label(k, lang)})
    return templates.TemplateResponse(request, "discover.html", ctx)


@app.get("/api/search/unified")
def api_search_unified(q: str = Query(..., min_length=1), kind: str = "",
                       per_kind: int = 12, safe: int = 1):
    kinds = [k for k in kind.split(",") if k in search.SEARCH_KIND_BY_KEY] if kind else None
    per_kind = max(1, min(per_kind, API_MAX_LIMIT))
    conn = db.connect()
    try:
        data = search.unified_search(conn, q, kinds=kinds, per_kind=per_kind, safe=bool(safe))
    finally:
        conn.close()
    return data


@app.get("/api/search/suggest")
def api_search_suggest(q: str = "", limit: int = 8):
    limit = max(1, min(limit, 20))
    conn = db.connect()
    try:
        completions = search.complete(conn, q, limit) if q else []
        corrections = search.suggest_correction(conn, q) if q else None
        queries = search.suggest_queries(conn, q, limit) if q else []
        related = search.related_terms(conn, q, limit) if q else []
    finally:
        conn.close()
    return {"query": q, "completions": completions, "correction": corrections,
            "queries": queries, "related": related}


@app.get("/api/search/trending")
def api_search_trending(limit: int = 12):
    limit = max(1, min(limit, 30))
    conn = db.connect()
    try:
        terms = search.trending_terms(conn, limit)
    finally:
        conn.close()
    return {"count": len(terms), "terms": terms}


@app.get("/api/discover/boards")
def api_discovery_boards():
    conn = db.connect()
    try:
        boards = search.discovery_boards(conn)
    finally:
        conn.close()
    return boards


@app.get("/api/search/saved")
def api_saved_searches(handle: str = ""):
    conn = db.connect()
    try:
        rows = search.saved_searches(conn, handle) if handle else []
    finally:
        conn.close()
    return {"count": len(rows), "saved": rows}


@app.post("/api/search/saved")
def api_save_search(request: Request, handle: str = "", q: str = "",
                    kinds: str = "", notify: int = 1):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "save_search", who, 60)
        if limited:
            return limited
        res = search.save_search(conn, who, q, kinds, bool(notify))
    finally:
        conn.close()
    if not res.get("ok"):
        return JSONResponse(res, status_code=400)
    return res


@app.delete("/api/search/saved")
def api_unsave_search(request: Request, handle: str = "", id: int = 0):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        ok = search.unsave_search(conn, who, id)
    finally:
        conn.close()
    return {"ok": ok}


@app.get("/api/search/export")
def api_search_export(q: str = Query(..., min_length=1), kind: str = "", fmt: str = "json"):
    """تصدير نتائج البحث (JSON أو CSV)."""
    kinds = [k for k in kind.split(",") if k in search.SEARCH_KIND_BY_KEY] if kind else None
    conn = db.connect()
    try:
        rows = search.results_to_rows(conn, q, kinds=kinds, per_kind=50)
    finally:
        conn.close()
    if fmt == "csv":
        import csv
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["kind", "title", "url", "snippet"])
        for r in rows:
            w.writerow([exports.csv_cell(r.get("kind", "")),
                        exports.csv_cell(r.get("title", "")),
                        exports.csv_cell(r.get("url", "")),
                        exports.csv_cell((r.get("snippet") or "").replace("\n", " "))])
        return Response(buf.getvalue(), media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": "attachment; filename=mirsad-search.csv"})
    return {"query": q, "count": len(rows), "results": rows}


@app.get("/api/search/index")
def api_search_index():
    """حالة فهرس البحث (قابل لإعادة البناء) + إحصاءات."""
    conn = db.connect()
    try:
        reports = conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()["n"]
        fts = conn.execute("SELECT COUNT(*) AS n FROM reports_fts").fetchone()["n"]
        posts = conn.execute("SELECT COUNT(*) AS n FROM posts").fetchone()["n"]
        vocab = len(search._all_vocabulary(conn))
    finally:
        conn.close()
    return {"reports": reports, "reports_indexed": fts, "posts": posts,
            "vocabulary": vocab, "rebuildable": True}


# ---------------------------------------------------------------------------
# الحملات والمناصرة (الدفعة 11)
# ---------------------------------------------------------------------------

def _localized_campaign_taxonomies(lang: str = "ar") -> dict:
    def loc(items, *label_fields):
        if lang != "en":
            return items
        return [{**i, "label": i.get("label_en") or i["label"]} for i in items]
    return {
        "campaign_statuses": loc(CAMPAIGN_STATUSES),
        "campaign_roles": loc(CAMPAIGN_ROLES),
        "campaign_target_kinds": loc(CAMPAIGN_TARGET_KINDS),
        "campaign_event_kinds": loc(CAMPAIGN_EVENT_KINDS),
        "pledge_states": loc(PLEDGE_STATES),
        "advocacy_charter": loc(ADVOCACY_CHARTER),
    }


@app.get("/campaigns", response_class=HTMLResponse)
def campaigns_page(request: Request, status: str = "", category: str = "", country: str = ""):
    lang = _lang(request)
    conn = db.connect()
    try:
        rows = campaigns.query_campaigns(
            conn,
            status=(status if status in CAMPAIGN_STATUS_BY_KEY else None),
            category=(category or None), country=(country or None))
        items = []
        for c in rows:
            c["status_label"] = campaign_status_label(c["status"], lang)
            c["progress"] = campaigns.progress(conn, c)
            items.append(c)
        stats = campaigns.campaign_stats(conn)
        suggestions = campaigns.suggested_campaigns(conn)
        opps = campaigns.opportunities(conn)
        for s in suggestions:
            s["label"] = category_name(s["category"], lang)
        for o in opps:
            o["label"] = category_name(o["category"], lang)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "campaigns", "items": items, "stats": stats,
                "status": status, "category": category, "country": country,
                "suggestions": suggestions, "opportunities": opps,
                **_localized_campaign_taxonomies(lang)})
    return templates.TemplateResponse(request, "campaigns.html", ctx)


@app.get("/campaign/{slug}", response_class=HTMLResponse)
def campaign_detail(request: Request, slug: str):
    lang = _lang(request)
    conn = db.connect()
    try:
        c = campaigns.campaign_by_slug(conn, slug)
        if not c:
            raise HTTPException(status_code=404, detail="campaign_not_found")
        c["status_label"] = campaign_status_label(c["status"], lang)
        c["progress"] = campaigns.progress(conn, c)
        team = campaigns.campaign_team(conn, c["id"])
        for t in team:
            t["role_label"] = campaign_role_label(t["role"], lang)
        sigs = campaigns.campaign_signatures(conn, c["id"])
        targets = campaigns.campaign_targets(conn, c["id"])
        for t in targets:
            t["kind_label"] = campaign_target_kind_label(t["kind"], lang)
        pledges = campaigns.campaign_pledges(conn, c["id"])
        for p in pledges:
            p["state_label"] = pledge_state_label(p["state"], lang)
            p["due_display"] = format_date(p["due_on"], lang) if p.get("due_on") else ""
        events = campaigns.campaign_events(conn, c["id"])
        for e in events:
            e["kind_label"] = campaign_event_kind_label(e["kind"], lang)
        updates = campaigns.campaign_updates(conn, c["id"])
        for u in updates:
            u["created_display"] = format_datetime(u.get("created_at"), lang)
        waves = campaigns.campaign_waves(conn, c["id"])
        for w in waves:
            w["state_label"] = wave_state_label(w["state"], lang)
        media = campaigns.campaign_media(conn, c["id"])
        impact = campaigns.campaign_impact(conn, c["id"])
        risk = campaigns.campaign_risk(conn, c["id"])
        nav_members = [m for m in social.query_members(conn, limit=None) if m.get("published")]
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "campaigns", "campaign": c, "team": team, "signatures": sigs,
                "targets": targets, "pledges": pledges, "events": events,
                "updates": updates, "waves": waves, "media": media,
                "impact": impact, "risk": risk, "nav_members": nav_members,
                **_localized_campaign_taxonomies(lang)})
    return templates.TemplateResponse(request, "campaign_detail.html", ctx)


@app.get("/api/campaigns")
def api_campaigns(status: str = "", limit: int = 50):
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        rows = campaigns.query_campaigns(conn, status=(status or None), limit=limit)
        for c in rows:
            c["progress"] = campaigns.progress(conn, c)
    finally:
        conn.close()
    return {"count": len(rows), "campaigns": rows}


@app.get("/api/campaigns/stats")
def api_campaign_stats():
    conn = db.connect()
    try:
        stats = campaigns.campaign_stats(conn)
    finally:
        conn.close()
    return stats


@app.get("/api/campaigns/{slug}")
def api_campaign(slug: str):
    conn = db.connect()
    try:
        c = campaigns.campaign_by_slug(conn, slug)
        if not c:
            return JSONResponse({"error": "not_found"}, status_code=404)
        c["progress"] = campaigns.progress(conn, c)
        c["impact"] = campaigns.campaign_impact(conn, c["id"])
    finally:
        conn.close()
    return c


@app.get("/api/campaigns/{slug}/impact")
def api_campaign_impact(slug: str):
    conn = db.connect()
    try:
        c = campaigns.campaign_by_slug(conn, slug)
        if not c:
            return JSONResponse({"error": "not_found"}, status_code=404)
        impact = campaigns.campaign_impact(conn, c["id"])
        risk = campaigns.campaign_risk(conn, c["id"])
    finally:
        conn.close()
    return {"impact": impact, "risk": risk}


@app.post("/api/campaigns/{slug}/sign")
def api_campaign_sign(request: Request, slug: str, handle: str = "", anonymous: int = 0):
    conn = db.connect()
    try:
        c = campaigns.campaign_by_slug(conn, slug)
        if not c:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "sign", who, 20)
        if limited:
            return limited
        res = campaigns.sign_campaign(conn, c["id"], who, anonymous=bool(anonymous))
    finally:
        conn.close()
    if not res.get("ok"):
        return JSONResponse(res, status_code=400)
    return res


@app.post("/api/campaigns/{slug}/updates")
def api_campaign_update(request: Request, slug: str, handle: str = "",
                        title: str = "", body: str = ""):
    conn = db.connect()
    try:
        c = campaigns.campaign_by_slug(conn, slug)
        if not c:
            return JSONResponse({"error": "not_found"}, status_code=404)
        who = _acting_handle(conn, handle)
        if not who or not title.strip():
            return JSONResponse({"error": "invalid"}, status_code=400)
        # التحديثات للمنسّقين فقط
        is_coord = conn.execute(
            "SELECT 1 FROM campaign_team WHERE campaign_id=? AND member=? AND role='coordinator'",
            (c["id"], who)).fetchone()
        if not is_coord:
            return JSONResponse({"error": "forbidden"}, status_code=403)
        uid = campaigns.add_campaign_update(conn, c["id"], title.strip(), body.strip())
    finally:
        conn.close()
    return {"ok": True, "id": uid}


@app.post("/api/campaigns/waves/{wave_id}/send")
def api_campaign_send_wave(request: Request, wave_id: int, handle: str = ""):
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        limited = _too_many(request, "wave_send", who, 30)
        if limited:
            return limited
        res = campaigns.send_wave(conn, wave_id)
    finally:
        conn.close()
    if not res.get("ok"):
        return JSONResponse(res, status_code=400)
    return res


@app.post("/api/campaigns/pledges/{pledge_id}/state")
def api_campaign_pledge_state(request: Request, pledge_id: int, state: str = "pending",
                              handle: str = ""):
    """تعديل حالة وعد: للمنسّقين فقط (مثل تحديثات الحملة) لمنع التلاعب بالالتزامات."""
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return JSONResponse({"error": "invalid_member"}, status_code=400)
        cid = campaigns.pledge_campaign_id(conn, pledge_id)
        if cid is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        if not campaigns.is_campaign_coordinator(conn, cid, who):
            return JSONResponse({"error": "forbidden"}, status_code=403)
        ok = campaigns.set_pledge_state(conn, pledge_id, state)
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "invalid"}, status_code=400)
    return {"ok": True}


# ---------------------------------------------------------------------------
# التكامل والأتمتة (الدفعة 12)
# ---------------------------------------------------------------------------

def _localized_integration_taxonomies(lang: str = "ar") -> dict:
    def loc(items):
        if lang != "en":
            return items
        return [{**i, "label": i.get("label_en") or i["label"]} for i in items]
    return {
        "api_scopes": loc(API_SCOPES),
        "api_versions": loc(API_VERSIONS),
        "webhook_events": loc(WEBHOOK_EVENTS),
        "connector_kinds": loc(CONNECTOR_KINDS),
        "rule_triggers": loc(RULE_TRIGGERS),
        "rule_actions": loc(RULE_ACTIONS),
        "job_states": loc(JOB_STATES),
    }


@app.get("/integrations", response_class=HTMLResponse)
def integrations_page(request: Request):
    lang = _lang(request)
    conn = db.connect()
    try:
        keys = integrations.query_api_keys(conn)
        usage_map = {u["prefix"]: u["today"] for u in integrations.api_usage_report(conn)}
        for k in keys:
            k["scopes_display"] = ", ".join(
                api_scope_label(s, lang) for s in (k["scopes"] or "").split(",") if s)
            k["used_today"] = usage_map.get(k["prefix"], 0)
        usage = integrations.api_usage_report(conn)
        hooks = integrations.query_webhooks(conn)
        for h in hooks:
            h["events_display"] = ", ".join(
                webhook_event_label(e, lang) for e in (h["events"] or "").split(",") if e)
        deliveries = integrations.webhook_deliveries(conn, limit=20)
        for d in deliveries:
            d["state_label"] = delivery_state_label(d["state"], lang)
        wh_health = integrations.webhook_health(conn)
        connectors = integrations.query_connectors(conn)
        for c in connectors:
            c["kind_label"] = connector_kind_label(c["kind"], lang)
        rules = integrations.query_rules(conn)
        for r in rules:
            r["trigger_label"] = rule_trigger_label(r["trigger"], lang)
            r["actions_display"] = ", ".join(
                rule_action_label(a, lang) for a in (r["actions"] or "").split(",") if a)
        runs = integrations.rule_runs(conn, limit=15)
        jobs = integrations.query_jobs(conn, limit=20)
        for j in jobs:
            j["state_label"] = job_state_label(j["state"], lang)
        workers = integrations.query_workers(conn)
        stats = integrations.integration_stats(conn)
        health = integrations.integration_health(conn)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "integrations", "keys": keys, "usage": usage, "hooks": hooks,
                "deliveries": deliveries, "wh_health": wh_health, "connectors": connectors,
                "rules": rules, "runs": runs, "jobs": jobs, "workers": workers,
                "stats": stats, "health": health,
                **_localized_integration_taxonomies(lang)})
    return templates.TemplateResponse(request, "integrations.html", ctx)


@app.get("/api/integrations/stats")
def api_integration_stats():
    conn = db.connect()
    try:
        return {"stats": integrations.integration_stats(conn),
                "health": integrations.integration_health(conn)}
    finally:
        conn.close()


@app.get("/api/integrations/keys")
def api_integration_keys():
    conn = db.connect()
    try:
        return {"count": len(integrations.query_api_keys(conn)),
                "keys": integrations.query_api_keys(conn),
                "usage": integrations.api_usage_report(conn)}
    finally:
        conn.close()


@app.get("/api/integrations/webhooks")
def api_integration_webhooks():
    conn = db.connect()
    try:
        return {"webhooks": integrations.query_webhooks(conn),
                "deliveries": integrations.webhook_deliveries(conn, limit=50),
                "health": integrations.webhook_health(conn)}
    finally:
        conn.close()


@app.post("/api/integrations/webhooks/test")
def api_webhook_test(request: Request, event: str = "report.created"):
    """إرسال حدث تجريبي إلى Webhooks المشتركة (محاكاة موقّعة بلا شبكة)."""
    if event not in {e["key"] for e in WEBHOOK_EVENTS}:
        return JSONResponse({"error": "unknown_event"}, status_code=400)
    conn = db.connect()
    try:
        limited = _too_many(request, "webhook_test", "api", 60)
        if limited:
            return limited
        sent = integrations.dispatch_event(conn, event, {"demo": True})
        # محاكاة تسليم ناجح فورًا
        for s in sent:
            integrations.deliver(conn, s["delivery_id"], ok=True)
    finally:
        conn.close()
    return {"ok": True, "delivered": len(sent), "targets": [s["webhook"] for s in sent]}


@app.post("/api/integrations/webhooks/{delivery_id}/retry")
def api_webhook_retry(request: Request, delivery_id: int, ok: int = 1):
    conn = db.connect()
    try:
        limited = _too_many(request, "webhook_retry", "api", 60)
        if limited:
            return limited
        done = integrations.deliver(conn, delivery_id, ok=bool(ok))
        row = conn.execute("SELECT * FROM webhook_deliveries WHERE id=?", (delivery_id,)).fetchone()
    finally:
        conn.close()
    if not done:
        return JSONResponse({"error": "not_found"}, status_code=404)
    return {"ok": True, "state": row["state"], "attempts": row["attempts"]}


@app.get("/api/integrations/connectors")
def api_integration_connectors():
    conn = db.connect()
    try:
        return {"connectors": integrations.query_connectors(conn)}
    finally:
        conn.close()


@app.post("/api/integrations/connectors/{connector_id}/sync")
def api_connector_sync(request: Request, connector_id: int):
    conn = db.connect()
    try:
        limited = _too_many(request, "connector_sync", "api", 60)
        if limited:
            return limited
        ok = integrations.sync_connector(conn, connector_id)
    finally:
        conn.close()
    return {"ok": ok}


@app.get("/api/integrations/rules")
def api_integration_rules():
    conn = db.connect()
    try:
        return {"rules": integrations.query_rules(conn),
                "runs": integrations.rule_runs(conn, limit=30)}
    finally:
        conn.close()


@app.post("/api/integrations/rules/{rule_id}/run")
def api_rule_run(request: Request, rule_id: int):
    conn = db.connect()
    try:
        limited = _too_many(request, "rule_run", "api", 60)
        if limited:
            return limited
        res = integrations.run_rule(conn, rule_id)
    finally:
        conn.close()
    if not res.get("ok") and res.get("error"):
        return JSONResponse(res, status_code=400)
    return res


@app.post("/api/integrations/rules/{rule_id}/toggle")
def api_rule_toggle(rule_id: int, enabled: int = 1):
    conn = db.connect()
    try:
        ok = integrations.toggle_rule(conn, rule_id, bool(enabled))
    finally:
        conn.close()
    return {"ok": ok}


@app.post("/api/integrations/rules/validate")
def api_rule_validate(trigger: str = "", actions: str = ""):
    return integrations.validate_rule(trigger, actions)


@app.get("/api/integrations/queue")
def api_integration_queue():
    conn = db.connect()
    try:
        return {"depth": integrations.queue_depth(conn),
                "congested": integrations.queue_congested(conn),
                "jobs": integrations.query_jobs(conn, limit=50),
                "workers": integrations.query_workers(conn)}
    finally:
        conn.close()


@app.post("/api/integrations/queue/enqueue")
def api_queue_enqueue(request: Request, kind: str = "", priority: int = 5):
    if not kind.strip():
        return JSONResponse({"error": "kind_required"}, status_code=400)
    conn = db.connect()
    try:
        limited = _too_many(request, "job_enqueue", "api", 120)
        if limited:
            return limited
        jid = integrations.enqueue_job(conn, kind.strip(), "{}", priority)
    finally:
        conn.close()
    return {"ok": True, "id": jid}


@app.post("/api/integrations/queue/{job_id}/finish")
def api_queue_finish(job_id: int, ok: int = 1):
    conn = db.connect()
    try:
        done = integrations.finish_job(conn, job_id, ok=bool(ok))
    finally:
        conn.close()
    return {"ok": done}


@app.post("/api/integrations/queue/requeue-failed")
def api_queue_requeue():
    conn = db.connect()
    try:
        n = integrations.requeue_failed(conn)
    finally:
        conn.close()
    return {"ok": True, "requeued": n}


@app.get("/api/integrations/health")
def api_integration_health():
    conn = db.connect()
    try:
        return integrations.integration_health(conn)
    finally:
        conn.close()


@app.get("/api/openapi.json")
def api_openapi_alias():
    """توثيق API تفاعلي (OpenAPI) — اسم بديل مختصر."""
    return app.openapi()


@app.get("/api/docs")
def api_docs_page(request: Request):
    ctx = _base_context(request)
    ctx.update({"page": "integrations"})
    return templates.TemplateResponse(request, "api_docs.html", ctx)


# ---------------------------------------------------------------------------
# الإدارة والتشغيل والتحليلات (الدفعة 13)
# ---------------------------------------------------------------------------

def _localized_ops_taxonomies(lang: str = "ar") -> dict:
    def loc(items):
        if lang != "en":
            return items
        return [{**i, "label": i.get("label_en") or i["label"]} for i in items]
    return {
        "service_states": loc(SERVICE_STATES),
        "incident_states": loc(INCIDENT_STATES),
        "alert_levels": loc(ALERT_LEVELS),
        "roadmap_states": loc(ROADMAP_STATES),
        "retention_classes": loc(RETENTION_CLASSES),
    }


@app.get("/admin", response_class=HTMLResponse)
def admin_page(request: Request):
    lang = _lang(request)
    conn = db.connect()
    try:
        status = ops.system_status(conn)
        for s in status["services"]:
            s["state_label"] = service_state_label(s["state"], lang)
        for a in status["alerts"]:
            a["level_label"] = alert_level_label(a["level"], lang)
        incidents = ops.query_incidents(conn)
        for i in incidents:
            i["state_label"] = incident_state_label(i["state"], lang)
            i["severity_label"] = alert_level_label(i["severity"], lang)
            i["created_display"] = format_datetime(i.get("created_at"), lang)
        announcements = ops.query_announcements(conn)
        for a in announcements:
            a["level_label"] = alert_level_label(a["level"], lang)
            a["created_display"] = format_datetime(a.get("created_at"), lang)
        flags = ops.all_flags(conn)
        audit = ops.query_audit(conn, limit=25)
        for e in audit:
            e["created_display"] = format_datetime(e.get("created_at"), lang)
        retention = ops.retention_report(conn)
        kpis = ops.kpis(conn)
        anomalies = ops.detect_anomalies(conn)
        trends_data = ops.trends(conn)
        comparison = ops.compare_periods(conn)
        analytics = ops.analytics_summary(conn)
        roadmap = ops.query_roadmap(conn)
        for r in roadmap:
            r["state_label"] = roadmap_state_label(r["state"], lang)
        governance = ops.query_governance(conn)
        volunteers = ops.query_volunteers(conn)
        vol_stats = ops.volunteer_stats(conn)
        status_ok = status["state"] == "ok" and not status["maintenance"]
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "admin", "status": status, "status_ok": status_ok,
                "incidents": incidents, "announcements": announcements, "flags": flags,
                "audit": audit, "retention": retention, "kpis": kpis,
                "anomalies": anomalies, "trends": trends_data, "comparison": comparison,
                "analytics": analytics, "roadmap": roadmap, "governance": governance,
                "volunteers": volunteers, "vol_stats": vol_stats,
                **_localized_ops_taxonomies(lang)})
    return templates.TemplateResponse(request, "admin.html", ctx)


@app.get("/monitor", response_class=HTMLResponse)
def monitor_page(request: Request):
    """لوحة منظومة الرصد والتحقق الآلي (القسم 12)."""
    lang = _lang(request)
    conn = db.connect()
    try:
        st = monitoring.status(conn)
        alerts = db.query_alerts(conn, acked=False, limit=20)
        for a in alerts:
            a["kind_label"] = alert_kind_label(a.get("kind", ""), lang)
            a["created_display"] = format_datetime(a.get("created_at"), lang)
        tasks = db.query_tasks(conn, limit=20)
        for t in tasks:
            t["created_display"] = format_datetime(t.get("created_at"), lang)
        changes = db.change_history(conn, limit=15)
        for ch in changes:
            ch["created_display"] = format_datetime(ch.get("created_at"), lang)
        runs = st["runs"]
        for r in runs:
            r["started_display"] = format_datetime(r.get("started_at"), lang)
            r["finished_display"] = format_datetime(r.get("finished_at"), lang)
        last = {k: (format_datetime(v, lang) if v else None)
                for k, v in st["last"].items()}
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "monitor", "st": st, "alerts": alerts, "tasks": tasks,
                "changes": changes, "runs": runs, "last": last,
                "metrics": st["metrics"], "archive": st["archive"],
                **_localized_taxonomy(lang)})
    return templates.TemplateResponse(request, "monitor.html", ctx)


@app.get("/audit", response_class=HTMLResponse)
def audit_page(request: Request, entity: str = "", q: str = "", page: int = 1):
    """سجل التدقيق القابل للبحث (القسم 12)."""
    lang = _lang(request)
    page = max(1, page)
    conn = db.connect()
    try:
        total = len(db.change_history(conn, entity=entity or None, search=q or None,
                                      limit=100000))
        rows = db.change_history(conn, entity=entity or None, search=q or None,
                                 limit=PAGE_SIZE)
        # للترقيم: نطلب من الإزاحة بسياسة مبسّطة (الأحدث أولًا).
        if page > 1:
            allrows = db.change_history(conn, entity=entity or None,
                                        search=q or None, limit=page * PAGE_SIZE)
            rows = allrows[(page - 1) * PAGE_SIZE:]
        for r in rows:
            r["created_display"] = format_datetime(r.get("created_at"), lang)
        entities = sorted({r["entity"] for r in db.change_history(conn, limit=100000)})
    finally:
        conn.close()
    pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    ctx = _base_context(request)
    ctx.update({"page": "audit", "rows": rows, "total": total, "entities": entities,
                "f": {"entity": entity, "q": q}, "current_page": page, "pages": pages})
    return templates.TemplateResponse(request, "audit.html", ctx)


@app.get("/status", response_class=HTMLResponse)
def public_status_page(request: Request):
    """لوحة حالة عامّة (بلا بيانات إدارية حسّاسة)."""
    lang = _lang(request)
    conn = db.connect()
    try:
        status = ops.system_status(conn)
        for s in status["services"]:
            s["state_label"] = service_state_label(s["state"], lang)
        incidents = [i for i in ops.query_incidents(conn) if i["state"] != "resolved"][:5]
        for i in incidents:
            i["state_label"] = incident_state_label(i["state"], lang)
            i["severity_label"] = alert_level_label(i["severity"], lang)
        announcements = [a for a in ops.query_announcements(conn, active_only=True)
                         if a["level"] in ("info", "warning")]
        for a in announcements:
            a["level_label"] = alert_level_label(a["level"], lang)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "status", "status": status, "incidents": incidents,
                "announcements": announcements, **_localized_ops_taxonomies(lang)})
    return templates.TemplateResponse(request, "status.html", ctx)


@app.get("/api/admin/status")
def api_admin_status():
    conn = db.connect()
    try:
        return ops.system_status(conn)
    finally:
        conn.close()


@app.get("/api/admin/kpis")
def api_admin_kpis():
    conn = db.connect()
    try:
        return {"kpis": ops.kpis(conn), "comparison": ops.compare_periods(conn),
                "anomalies": ops.detect_anomalies(conn), "trends": ops.trends(conn)}
    finally:
        conn.close()


@app.get("/api/admin/analytics")
def api_admin_analytics(days: int = 14):
    days = max(1, min(days, 90))
    conn = db.connect()
    try:
        return ops.analytics_summary(conn, days)
    finally:
        conn.close()


@app.get("/api/admin/incidents")
def api_admin_incidents(state: str = ""):
    conn = db.connect()
    try:
        return {"incidents": ops.query_incidents(conn, state=(state or None))}
    finally:
        conn.close()


@app.post("/api/admin/incidents/{iid}/state")
def api_admin_incident_state(request: Request, iid: int, handle: str = "",
                             state: str = "mitigated", postmortem: str = ""):
    conn = db.connect()
    try:
        who, denied = _require_admin(conn, request, handle)
        if denied:
            return denied
        ok = ops.update_incident(conn, iid, state, postmortem or None)
        if ok:
            ops.audit(conn, who, "incident.update", str(iid), state)
    finally:
        conn.close()
    return {"ok": ok}


@app.get("/api/admin/flags")
def api_admin_flags():
    conn = db.connect()
    try:
        return ops.all_flags(conn)
    finally:
        conn.close()


@app.post("/api/admin/flags")
def api_admin_set_flag(request: Request, handle: str = "", key: str = "", value: str = ""):
    conn = db.connect()
    try:
        who, denied = _require_admin(conn, request, handle)
        if denied:
            return denied
        if key not in ops.DEFAULT_FLAGS:
            return JSONResponse({"error": "unknown_flag"}, status_code=400)
        if key in (ops.FLAG_MAINTENANCE, ops.FLAG_READONLY) and value not in ("0", "1"):
            return JSONResponse({"error": "invalid_value"}, status_code=400)
        ops.set_flag(conn, key, value)
        ops.audit(conn, who, "flag.set", key, value)
        flags = ops.all_flags(conn)
    finally:
        conn.close()
    return {"ok": True, "flags": flags}


@app.post("/api/admin/announcements")
def api_admin_announce(request: Request, handle: str = "", level: str = "info",
                       title: str = "", body: str = ""):
    conn = db.connect()
    try:
        who, denied = _require_admin(conn, request, handle)
        if denied:
            return denied
        if not title.strip():
            return JSONResponse({"error": "title_required"}, status_code=400)
        aid = ops.post_announcement(conn, level, title.strip(), body.strip())
        ops.audit(conn, who, "announcement.post", str(aid), level)
    finally:
        conn.close()
    return {"ok": True, "id": aid}


@app.get("/api/admin/audit")
def api_admin_audit(action: str = "", limit: int = 50):
    limit = max(1, min(limit, API_MAX_LIMIT))
    conn = db.connect()
    try:
        return {"entries": ops.query_audit(conn, action=(action or None), limit=limit)}
    finally:
        conn.close()


@app.get("/api/admin/retention")
def api_admin_retention():
    conn = db.connect()
    try:
        return {"policies": ops.retention_policies(conn),
                "report": ops.retention_report(conn),
                "archive_candidates": ops.archive_candidates(conn)}
    finally:
        conn.close()


@app.post("/api/admin/retention")
def api_admin_set_retention(request: Request, handle: str = "", cls: str = "",
                            days: int = 0):
    conn = db.connect()
    try:
        who, denied = _require_admin(conn, request, handle)
        if denied:
            return denied
        if days < 1:
            return JSONResponse({"error": "invalid_days"}, status_code=400)
        ok = ops.set_retention(conn, cls, days)
        if ok:
            ops.audit(conn, who, "retention.set", cls, str(days))
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "unknown_class"}, status_code=400)
    return {"ok": True}


@app.get("/api/admin/roadmap")
def api_admin_roadmap():
    conn = db.connect()
    try:
        return {"roadmap": ops.query_roadmap(conn), "governance": ops.query_governance(conn)}
    finally:
        conn.close()


@app.get("/api/admin/volunteers")
def api_admin_volunteers():
    conn = db.connect()
    try:
        return {"volunteers": ops.query_volunteers(conn), "stats": ops.volunteer_stats(conn)}
    finally:
        conn.close()


@app.post("/api/admin/volunteers/hours")
def api_admin_volunteer_hours(request: Request, handle: str = "", member: str = "",
                              hours: float = 0.0):
    conn = db.connect()
    try:
        who, denied = _require_admin(conn, request, handle)
        if denied:
            return denied
        if hours <= 0:
            return JSONResponse({"error": "invalid_hours"}, status_code=400)
        ops.log_volunteer_hours(conn, member, hours)
        ops.audit(conn, who, "volunteer.hours", member, str(hours))
    finally:
        conn.close()
    return {"ok": True}


@app.get("/api/admin/ops-report")
def api_admin_ops_report():
    conn = db.connect()
    try:
        return ops.ops_summary(conn)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# الملفات الحسّاسة (الدفعة 14) — محاكاة وعرض توضيحي فقط
# ---------------------------------------------------------------------------

def _localized_vault_taxonomies(lang: str = "ar") -> dict:
    def loc(items):
        if lang != "en":
            return items
        return [{**i, "label": i.get("label_en") or i["label"]} for i in items]
    return {
        "sensitive_kinds": loc(SENSITIVE_KINDS),
        "sensitive_states": loc(SENSITIVE_STATES),
        "classification_levels": loc(CLASSIFICATION_LEVELS),
        "access_states": loc(ACCESS_STATES),
        "receipt_kinds": loc(RECEIPT_KINDS),
    }


def _vault_disabled() -> JSONResponse:
    return JSONResponse({"error": "sensitive_disabled"}, status_code=404)


@app.get("/vault", response_class=HTMLResponse)
def vault_page(request: Request):
    if not SENSITIVE_MODE:
        raise HTTPException(status_code=404, detail="معطّل")
    lang = _lang(request)
    conn = db.connect()
    try:
        items = sensitive.query_items(conn)
        for it in items:
            it["kind_label"] = sensitive_kind_label(it["kind"], lang)
            it["state_label"] = sensitive_state_label(it["state"], lang)
            it["classification_label"] = classification_label(it["classification"], lang)
            it["created_display"] = format_datetime(it.get("created_at"), lang)
        stats = sensitive.vault_stats(conn)
        policies = sensitive.policies(conn)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "vault", "items": items, "stats": stats, "policies": policies,
                "sensitive_mode": SENSITIVE_MODE,
                **_localized_vault_taxonomies(lang)})
    return templates.TemplateResponse(request, "vault.html", ctx)


@app.get("/vault/{item_id}", response_class=HTMLResponse)
def vault_item_page(request: Request, item_id: int):
    if not SENSITIVE_MODE:
        raise HTTPException(status_code=404, detail="معطّل")
    lang = _lang(request)
    conn = db.connect()
    try:
        item = sensitive.item_by_id(conn, item_id)
        if not item:
            raise HTTPException(status_code=404, detail="غير موجود")
        item["kind_label"] = sensitive_kind_label(item["kind"], lang)
        item["state_label"] = sensitive_state_label(item["state"], lang)
        item["classification_label"] = classification_label(item["classification"], lang)
        item["created_display"] = format_datetime(item.get("created_at"), lang)
        access = sensitive.query_access(conn, item_id)
        for a in access:
            a["state_label"] = access_state_label(a["state"], lang)
        receipts = sensitive.query_receipts(conn, item_id)
        for r in receipts:
            r["kind_label"] = receipt_kind_label(r["kind"], lang)
            r["created_display"] = format_datetime(r.get("created_at"), lang)
        policies = sensitive.policies(conn)
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "vault", "item": item, "access": access, "receipts": receipts,
                "policies": policies, "sensitive_mode": SENSITIVE_MODE,
                **_localized_vault_taxonomies(lang)})
    return templates.TemplateResponse(request, "vault_detail.html", ctx)


@app.get("/api/vault/items")
def api_vault_items(owner: str = "", state: str = ""):
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        return {"items": sensitive.query_items(conn, owner=(owner or None),
                                               state=(state or None)),
                "stats": sensitive.vault_stats(conn)}
    finally:
        conn.close()


@app.get("/api/vault/items/{item_id}")
def api_vault_item(item_id: int):
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        item = sensitive.item_by_id(conn, item_id)
        if not item:
            return JSONResponse({"error": "not_found"}, status_code=404)
        return {"item": item, "access": sensitive.query_access(conn, item_id),
                "receipts": sensitive.query_receipts(conn, item_id)}
    finally:
        conn.close()


@app.post("/api/vault/items")
def api_vault_create(request: Request, handle: str = "", title: str = "",
                     kind: str = "document", classification: str = "internal",
                     note: str = ""):
    """إيداع وصفي تجريبي — لا محتوى ولا ملف حقيقي."""
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        limited = _too_many(request, "vault_create", "vault", 20)
        if limited:
            return limited
        who = _acting_handle(conn, handle)
        if not who:
            return _admin_forbidden()
        iid = sensitive.create_item(conn, who, title, kind, classification, note)
    finally:
        conn.close()
    if not iid:
        return JSONResponse({"error": "invalid"}, status_code=400)
    return {"ok": True, "id": iid}


@app.post("/api/vault/items/{item_id}/state")
def api_vault_state(request: Request, item_id: int, handle: str = "", state: str = "sealed"):
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return _admin_forbidden()
        item = sensitive.item_by_id(conn, item_id)
        if not item:
            return JSONResponse({"error": "not_found"}, status_code=404)
        if item["owner"] != who:
            return _admin_forbidden()
        ok = sensitive.set_item_state(conn, item_id, state, who)
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "invalid_state"}, status_code=400)
    return {"ok": True}


@app.post("/api/vault/items/{item_id}/request")
def api_vault_request(request: Request, item_id: int, handle: str = "", purpose: str = ""):
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        limited = _too_many(request, "vault_request", "vault", 30)
        if limited:
            return limited
        who = _acting_handle(conn, handle)
        if not who:
            return _admin_forbidden()
        ok = sensitive.request_access(conn, item_id, who, purpose)
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "invalid"}, status_code=400)
    return {"ok": True, "state": "pending"}


@app.post("/api/vault/access/{access_id}/decide")
def api_vault_decide(request: Request, access_id: int, handle: str = "",
                     state: str = "approved"):
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        who = _acting_handle(conn, handle)
        if not who:
            return _admin_forbidden()
        row = conn.execute("SELECT * FROM vault_access WHERE id=?", (access_id,)).fetchone()
        if not row:
            return JSONResponse({"error": "not_found"}, status_code=404)
        item = sensitive.item_by_id(conn, row["item_id"])
        if not item or item["owner"] != who:
            return _admin_forbidden()
        ok = sensitive.decide_access(conn, access_id, state, who)
    finally:
        conn.close()
    if not ok:
        return JSONResponse({"error": "invalid"}, status_code=400)
    return {"ok": True}


@app.get("/api/vault/access/pending")
def api_vault_pending():
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        return {"pending": sensitive.pending_access(conn)}
    finally:
        conn.close()


@app.get("/api/vault/policies")
def api_vault_policies():
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        return {"policies": sensitive.policies(conn),
                "crypto_ready": sensitive.crypto_ready()}
    finally:
        conn.close()


@app.get("/api/vault/stats")
def api_vault_stats():
    if not SENSITIVE_MODE:
        return _vault_disabled()
    conn = db.connect()
    try:
        return sensitive.vault_stats(conn)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# واجهة برمجة REST
# ---------------------------------------------------------------------------

def _api_filters(category, severity, status, country, q, date_from, date_to, verified=None) -> dict:
    return dict(category=category, severity=severity, status=status, country=country,
                search=q, date_from=date_from, date_to=date_to,
                verified=None if verified in (None, "") else verified == "1")


@app.get("/api/reports")
def api_reports(
    request: Request,
    category: str | None = None,
    severity: str | None = None,
    status: str | None = None,
    country: str | None = None,
    q: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    verified: str | None = None,
    sort: str = "recent",
    limit: int = 50,
    offset: int = 0,
):
    conn = db.connect()
    try:
        filters = _api_filters(category, severity, status, country, q, date_from, date_to, verified)
        total = db.count_reports(conn, **filters)
        items = db.query_reports(conn, **filters, sort=sort,
                                 limit=clamp_limit(limit), offset=max(0, offset))
        return {"count": len(items), "total": total, "offset": max(0, offset),
                "items": [_enrich(r, _lang(request)) for r in items]}
    finally:
        conn.close()


@app.get("/api/reports/{report_id}")
def api_report(request: Request, report_id: int):
    conn = db.connect()
    try:
        raw = db.get_report(conn, report_id)
        if not raw:
            return JSONResponse({"detail": "البلاغ غير موجود"}, status_code=404)
        out = _enrich(raw, _lang(request))
        out["entities"] = db.entities_for(conn, report_id)
        return out
    finally:
        conn.close()


@app.get("/api/stats")
def api_stats():
    conn = db.connect()
    try:
        return db.stats(conn)
    finally:
        conn.close()


@app.get("/api/taxonomy")
def api_taxonomy():
    return {"categories": CATEGORIES, "severities": SEVERITIES, "statuses": STATUSES}


@app.get("/api/geo")
def api_geo(limit: int = 5000):
    conn = db.connect()
    try:
        return {"type": "FeatureCollection", "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [p["lng"], p["lat"]]},
                "properties": {
                    "id": p["id"], "title": p["title"], "category": p["category"],
                    "severity": p["severity"], "country": p["country"],
                    "reported_on": p["reported_on"], "year": p["year"],
                },
            } for p in db.geo_points(conn, limit=min(max(1, limit), 20000))
        ]}
    finally:
        conn.close()


@app.get("/api/sources")
def api_sources():
    conn = db.connect()
    try:
        return {"registry": sources_registry.OPEN_DATASETS,
                "sources": db.list_sources(conn),
                "history": db.ingest_history(conn)}
    finally:
        conn.close()


@app.get("/api/discovery")
def api_discovery(limit: int = 20):
    """تقرير آخر دورة اكتشاف مصادر + سجل الدورات + المصادر المكتشفة."""
    conn = db.connect()
    try:
        return {
            "groups": discovery.DISCOVERY_GROUPS,
            "kinds": discovery.SOURCE_KINDS,
            "interval_seconds": discovery.DISCOVERY_INTERVAL,
            "discovered_count": db.discovered_count(conn),
            "sources": db.discovered_sources(conn, limit=clamp_limit(limit, default=20)),
            "latest_report": db.latest_discovery_report(conn),
            "history": db.discovery_history(conn, limit=10),
        }
    finally:
        conn.close()


@app.post("/api/discovery/run")
def api_discovery_run(request: Request, dry_run: int = 0, limit: int | None = None,
                      key: str | None = None):
    """يشغّل دورة اكتشاف فورًا. محمية بـ`X-Ingest-Key` عند ضبط `MIRSAD_INGEST_KEY`."""
    if INGEST_KEY:
        sent = request.headers.get("X-Ingest-Key", "")
        if sent != INGEST_KEY:
            raise HTTPException(status_code=403, detail="مفتاح استيراد غير صالح")
    conn = db.connect()
    try:
        report = discovery.discover(
            conn, limit=clamp_limit(limit) if limit is not None else None,
            dry_run=bool(dry_run))
    finally:
        conn.close()
    return report


# ---------------------------------------------------------------------------
# منظومة الرصد والتحقق الآلي (API)
# ---------------------------------------------------------------------------

@app.get("/api/monitoring")
def api_monitoring(limit: int = 20):
    """حالة المنظومة: الفترات، آخر تشغيل، المؤشرات، الدورات، الأرشيف."""
    conn = db.connect()
    try:
        st = monitoring.status(conn)
        limit = clamp_limit(limit, default=20)
        st["alerts"] = db.query_alerts(conn, acked=False, limit=limit)
        st["tasks"] = db.query_tasks(conn, limit=limit)
        return st
    finally:
        conn.close()


@app.get("/api/monitoring/metrics")
def api_monitoring_metrics():
    """مؤشرات لوحة التحكم المركزية (تشغيل/محتوى/جودة) (القسم 12)."""
    conn = db.connect()
    try:
        return {"metrics": db.monitoring_metrics(conn),
                "alerts": db.alert_stats(conn),
                "queue": db.task_queue_stats(conn)}
    finally:
        conn.close()


@app.post("/api/monitoring/run")
def api_monitoring_run(request: Request, task: str | None = None,
                       backfill: int = 0):
    """يشغّل دورة رصد فورًا (أو مهمّة محدّدة). محمي بـX-Ingest-Key عند الضبط."""
    if INGEST_KEY:
        sent = request.headers.get("X-Ingest-Key", "")
        if sent != INGEST_KEY:
            raise HTTPException(status_code=403, detail="مفتاح استيراد غير صالح")
    conn = db.connect()
    try:
        if task:
            return monitoring.run_now(conn, task)
        return monitoring.monitor_tick(conn, backfill_sources=backfill)
    finally:
        conn.close()


@app.get("/api/monitoring/tasks")
def api_monitoring_tasks(state: str | None = None, kind: str | None = None,
                         limit: int = 50):
    conn = db.connect()
    try:
        return {"items": db.query_tasks(conn, state=state, kind=kind, limit=limit),
                "stats": db.task_queue_stats(conn)}
    finally:
        conn.close()


@app.get("/api/monitoring/alerts")
def api_monitoring_alerts(acked: int | None = None, limit: int = 50):
    conn = db.connect()
    try:
        acked_flag = None if acked is None else bool(acked)
        return {"items": db.query_alerts(conn, acked=acked_flag, limit=limit),
                "stats": db.alert_stats(conn)}
    finally:
        conn.close()


@app.post("/api/monitoring/alerts/{alert_id}/ack")
def api_monitoring_ack(request: Request, alert_id: int):
    if INGEST_KEY:
        sent = request.headers.get("X-Ingest-Key", "")
        if sent != INGEST_KEY:
            raise HTTPException(status_code=403, detail="مفتاح استيراد غير صالح")
    conn = db.connect()
    try:
        return {"ok": db.ack_alert(conn, alert_id)}
    finally:
        conn.close()


@app.get("/api/monitoring/changes")
def api_monitoring_changes(entity: str | None = None, entity_id: int | None = None,
                           q: str | None = None, limit: int = 50):
    """سجل التدقيق القابل للبحث (القسم 12)."""
    conn = db.connect()
    try:
        return {"items": db.change_history(conn, entity=entity, entity_id=entity_id,
                                           search=q, limit=limit)}
    finally:
        conn.close()


@app.get("/api/monitoring/archive")
def api_monitoring_archive():
    conn = db.connect()
    try:
        return backfill.archive_report(conn)
    finally:
        conn.close()


@app.post("/api/monitoring/backfill")
def api_monitoring_backfill(request: Request, source: str | None = None,
                            sources: int = 4):
    if INGEST_KEY:
        sent = request.headers.get("X-Ingest-Key", "")
        if sent != INGEST_KEY:
            raise HTTPException(status_code=403, detail="مفتاح استيراد غير صالح")
    conn = db.connect()
    try:
        if source:
            row = conn.execute("SELECT * FROM source_catalog WHERE key = ?",
                               (source,)).fetchone()
            if not row:
                raise HTTPException(status_code=404, detail="مصدر غير موجود")
            return backfill.backfill_source(conn, dict(row))
        return backfill.backfill_batch(conn, sources=sources)
    finally:
        conn.close()


@app.get("/api/reports/{report_id}/verification")
def api_report_verification(report_id: int):
    """شرح حالة التحقق والشارة لواقعة (القسم 9)."""
    conn = db.connect()
    try:
        return {"explanation": verification.badge_explanation(conn, report_id),
                "history": db.verification_history(conn, report_id),
                "evidence": db.evidence_for_report(conn, report_id)}
    finally:
        conn.close()


@app.get("/api/search")
def api_search(request: Request, q: str = Query(..., min_length=1), limit: int = 20):
    conn = db.connect()
    try:
        items = db.query_reports(conn, search=q, sort="relevance",
                                 limit=clamp_limit(limit, default=20))
        return {"query": q, "count": len(items), "items": [_enrich(r, _lang(request)) for r in items]}
    finally:
        conn.close()


@app.get("/api/countries")
def api_countries(q: str | None = None, limit: int = 20):
    from . import countries as country_data
    limit = clamp_limit(limit, default=20)
    if q:
        return {"items": country_data.search(q, limit=limit)}
    return {"items": country_data.all_countries()[:limit]}


@app.get("/api/wikidata/search")
def api_wikidata_search(q: str = Query(..., min_length=1), lang: str = "ar"):
    return {"query": q, "results": wikidata.search_entity(q, language=lang)}


# ---------------------------------------------------------------------------
# التصدير
# ---------------------------------------------------------------------------

def _export_rows(category, severity, status, country, q, date_from, date_to, limit, verified=None):
    conn = db.connect()
    try:
        filters = _api_filters(category, severity, status, country, q, date_from, date_to, verified)
        return db.query_reports(conn, **filters, sort="recent",
                                limit=clamp_limit(limit))
    finally:
        conn.close()


def _cite_rows(category, severity, status, country, q, limit, report_id):
    """صفوف الاستشهاد: بلاغ واحد عند تمرير id، وإلّا وفق المرشّحات."""
    if report_id is not None:
        conn = db.connect()
        try:
            row = db.get_report(conn, report_id)
            return [row] if row else []
        finally:
            conn.close()
    return _export_rows(category, severity, status, country, q, None, None, limit)


@app.get("/api/export.csv")
def export_csv(category: str | None = None, severity: str | None = None,
               status: str | None = None, country: str | None = None,
               q: str | None = None, date_from: str | None = None,
               date_to: str | None = None, verified: str | None = None,
               ids: str | None = None, limit: int = 200):
    if ids:
        rows = _rows_by_ids(ids)
    else:
        rows = _export_rows(category, severity, status, country, q, date_from, date_to, limit, verified)
    body = exports.to_csv(rows)
    return Response(
        content=body, media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mirsad-reports.csv"'},
    )


def _rows_by_ids(ids: str) -> list[dict]:
    """صفوف بلاغات محدّدة بأرقام معرّفاتها (للتصدير الجماعي من الواجهة)."""
    wanted = []
    for part in ids.split(","):
        part = part.strip()
        # isdecimal() (لا isdigit) يضمن أن int() لن يرفع ValueError:
        # بعض المحارف مثل '²'/'⁰' تُعدّ digit لكن int() يرفضها.
        if part.isdecimal():
            wanted.append(int(part))
    if not wanted:
        return []
    conn = db.connect()
    try:
        out = []
        for rid in wanted[:API_MAX_LIMIT]:
            row = db.get_report(conn, rid)
            if row:
                out.append(row)
        return out
    finally:
        conn.close()


@app.get("/api/export.json")
def export_json(category: str | None = None, severity: str | None = None,
                status: str | None = None, country: str | None = None,
                q: str | None = None, date_from: str | None = None,
                date_to: str | None = None, verified: str | None = None,
                limit: int = 200):
    rows = _export_rows(category, severity, status, country, q, date_from, date_to, limit, verified)
    return Response(content=exports.to_json(rows),
                    media_type="application/json; charset=utf-8")


def _entity_rows(kind: str | None, limit: int) -> list[dict]:
    conn = db.connect()
    try:
        return db.entities_summary(conn, kind=kind, limit=clamp_limit(limit))
    finally:
        conn.close()


@app.get("/api/entities.csv")
def export_entities_csv(kind: str | None = None, limit: int = 500):
    rows = _entity_rows(kind, limit)
    return Response(
        content=exports.to_entities_csv(rows), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mirsad-entities.csv"'},
    )


@app.get("/api/entities.json")
def export_entities_json(kind: str | None = None, limit: int = 500):
    rows = _entity_rows(kind, limit)
    meta = {"kind": kind} if kind else None
    return Response(content=exports.to_entities_json(rows, meta=meta),
                    media_type="application/json; charset=utf-8")


@app.get("/api/cite.bib")
def export_bibtex(request: Request, id: int | None = None, category: str | None = None,
                  severity: str | None = None, status: str | None = None,
                  country: str | None = None, q: str | None = None,
                  limit: int = 200):
    rows = _cite_rows(category, severity, status, country, q, limit, id)
    body = exports.to_bibtex(rows, site_url=_site_url(request))
    return Response(
        content=body, media_type="application/x-bibtex; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mirsad-reports.bib"'},
    )


@app.get("/api/cite.ris")
def export_ris(request: Request, id: int | None = None, category: str | None = None,
               severity: str | None = None, status: str | None = None,
               country: str | None = None, q: str | None = None,
               limit: int = 200):
    rows = _cite_rows(category, severity, status, country, q, limit, id)
    body = exports.to_ris(rows, site_url=_site_url(request))
    return Response(
        content=body, media_type="application/x-research-info-systems; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mirsad-reports.ris"'},
    )


@app.get("/api/cite.txt")
def export_apa(request: Request, id: int | None = None, category: str | None = None,
               severity: str | None = None, status: str | None = None,
               country: str | None = None, q: str | None = None,
               limit: int = 200):
    rows = _cite_rows(category, severity, status, country, q, limit, id)
    body = exports.to_apa(rows, site_url=_site_url(request))
    return PlainTextResponse(content=body)


@app.get("/feed.json")
def feed_json(request: Request, category: str | None = None,
              severity: str | None = None, status: str | None = None,
              country: str | None = None, q: str | None = None,
              limit: int = 50):
    rows = _export_rows(category, severity, status, country, q, None, None, limit)
    return Response(content=exports.to_json_feed(rows, str(request.url)),
                    media_type="application/feed+json; charset=utf-8")


@app.get("/feed.xml")
def feed_rss(request: Request, category: str | None = None,
             severity: str | None = None, status: str | None = None,
             country: str | None = None, q: str | None = None,
             limit: int = 50):
    rows = _export_rows(category, severity, status, country, q, None, None, limit)
    return Response(content=exports.to_rss(rows, str(request.url)),
                    media_type="application/rss+xml; charset=utf-8")


# ---------------------------------------------------------------------------
# الاستيراد (تشغيل يدوي؛ محمي بترويسة X-Ingest-Key عند ضبط MIRSAD_INGEST_KEY)
# ---------------------------------------------------------------------------

def _require_ingest_key(x_ingest_key: str | None) -> None:
    if INGEST_KEY and x_ingest_key != INGEST_KEY:
        raise HTTPException(status_code=401, detail="مفتاح الاستيراد غير صالح")


@app.post("/api/ingest/gdelt")
def ingest_gdelt(x_ingest_key: str | None = Header(default=None),
                 query: str | None = None, category: str | None = None,
                 maxrecords: int = 25, dry_run: bool = False):
    _require_ingest_key(x_ingest_key)
    conn = db.connect()
    try:
        return importers.ingest_gdelt(conn, query=query, category=category,
                                      maxrecords=maxrecords, dry_run=dry_run)
    finally:
        conn.close()


@app.post("/api/ingest/wikidata")
def ingest_wikidata(x_ingest_key: str | None = Header(default=None),
                    limit: int = 10):
    _require_ingest_key(x_ingest_key)
    conn = db.connect()
    try:
        return importers.enrich_report_entities(conn, limit=limit)
    finally:
        conn.close()


@app.get("/category/{key}", response_class=HTMLResponse)
def category_page(request: Request, key: str, page: int = 1, sort: str = "recent"):
    cat = CATEGORY_BY_KEY.get(key)
    if not cat:
        raise HTTPException(status_code=404, detail="المجال غير موجود")
    if sort not in ("recent", "severity", "verified"):
        sort = "recent"
    lang = _lang(request)
    cat = {**cat, "name": category_name(key, lang),
           "description": cat.get("description_en") if lang == "en" else cat.get("description")}
    conn = db.connect()
    try:
        st = db.stats(conn)
        page = max(1, page)
        items = [_enrich(r, _lang(request)) for r in db.query_reports(
            conn, category=key, sort=sort, limit=PAGE_SIZE,
            offset=(page - 1) * PAGE_SIZE)]
        countries = db.distinct_countries(conn)
        total = st["by_category"].get(key, 0)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        counts = {s["key"]: 0 for s in SEVERITIES}
        for r in db.query_reports(conn, category=key):
            counts[r["severity"]] = counts.get(r["severity"], 0) + 1
        severities = [{**s, "count": counts.get(s["key"], 0)} for s in SEVERITIES]
        top_countries = [c for c in st["by_country"] if c["country"] in
                         {r["country"] for r in items}][:6]
        all_items = db.query_reports(conn, category=key)
        daily = {}
        for r in all_items:
            d = r.get("reported_on")
            if d:
                daily[d] = daily.get(d, 0) + 1
        daily = [{"day": k, "count": v} for k, v in sorted(daily.items())]
        # مجالات ذات صلة: الأعلى عددًا بعد المجال الحالي.
        related = sorted((c for c in st["by_category"].items() if c[0] != key),
                         key=lambda kv: kv[1], reverse=True)[:5]
        related = [{**CATEGORY_BY_KEY[k], "name": category_name(k, lang), "count": v}
                   for k, v in related if k in CATEGORY_BY_KEY]
    finally:
        conn.close()
    ctx = _base_context(request)
    ctx.update({"page": "reports", "cat": cat, "items": items, "total": total,
                "countries": countries, "severities": severities,
                "top_countries": top_countries, "daily": daily, "related": related,
                "doc_resources": sources_registry.doc_resources_for_category(key),
                "current_page": page, "pages": pages, "key": key, "sort": sort})
    return templates.TemplateResponse(request, "category.html", ctx)


@app.get("/countries", response_class=HTMLResponse)
def countries_index(request: Request):
    lang = _lang(request)
    conn = db.connect()
    try:
        summary = db.countries_summary(conn)
    finally:
        conn.close()
    for c in summary:
        c["flag"] = _flag_emoji(c["country"])
        c["name"] = english_name(c["country"]) if lang == "en" else arabic_name(c["country"])
    max_count = max((c["total"] for c in summary), default=1) or 1
    # شارات: الأكثر تضرّرًا، والدول ذات البلاغات الجديدة (آخر 30 يومًا).
    top_country = summary[0]["country"] if summary else None
    recent_cut = (date.today() - timedelta(days=30)).isoformat()
    for c in summary:
        c["is_top"] = c["country"] == top_country
        c["is_recent"] = bool(c.get("last_on")) and c["last_on"] >= recent_cut
        c["verified_pct"] = round((c.get("verified") or 0) / c["total"] * 100) if c["total"] else 0
    regions = sorted({(c.get("region") or "").strip() for c in summary if c.get("region")})
    ctx = _base_context(request)
    ctx.update({"page": "countries", "countries": summary, "max_count": max_count,
                "regions": regions})
    return templates.TemplateResponse(request, "countries.html", ctx)


@app.get("/country/{name}", response_class=HTMLResponse)
def country_page(request: Request, name: str):
    lang = _lang(request)
    conn = db.connect()
    try:
        summary = next((c for c in db.countries_summary(conn) if c["country"] == name), None)
        if not summary:
            raise HTTPException(status_code=404, detail="الدولة غير موجودة في السجل")
        items = [_enrich(r, _lang(request)) for r in db.country_reports(conn, name)]
        ents = [e for r in items for e in db.entities_for(conn, r["id"])]
        counts = {s["key"]: 0 for s in SEVERITIES}
        for r in items:
            counts[r["severity"]] = counts.get(r["severity"], 0) + 1
        severities = [{**s, "count": counts.get(s["key"], 0)} for s in SEVERITIES]
        cat_keys = summary["categories"]
        cats = [{**c, "name": category_name(c["key"], lang),
                 "count": sum(1 for r in items if r["category"] == c["key"])}
                for c in CATEGORIES if c["key"] in cat_keys]
        by_source = {}
        for r in items:
            by_source[r["source_name"] or "—"] = by_source.get(r["source_name"] or "—", 0) + 1
        sources = sorted(by_source.items(), key=lambda kv: kv[1], reverse=True)[:8]
        # نشاط يومي لهذه الدولة (للخريطة الحرارائية المصغّرة).
        daily = {}
        for r in items:
            d = r.get("reported_on")
            if d:
                daily[d] = daily.get(d, 0) + 1
        daily = [{"day": k, "count": v} for k, v in sorted(daily.items())]
        # دول ذات صلة: تشترك في أكثر مجال ممثّل هنا.
        top_cat = max(cat_keys, key=lambda k: sum(1 for r in items if r["category"] == k), default=None)
        related_countries = []
        if top_cat:
            related_countries = [c for c in db.countries_summary(conn)
                                 if c["country"] != name and top_cat in c["categories"]][:6]
            for c in related_countries:
                c["flag"] = _flag_emoji(c["country"])
                c["name"] = english_name(c["country"]) if lang == "en" else arabic_name(c["country"])
    finally:
        conn.close()
    summary["flag"] = _flag_emoji(name)
    summary["name"] = english_name(name) if lang == "en" else arabic_name(name)
    ctx = _base_context(request)
    ctx.update({"page": "countries", "country": summary, "items": items,
                "severities": severities, "cats": cats, "sources": sources,
                "entities": ents, "iso2": _iso2(name) or "",
                "daily": daily, "related_countries": related_countries,
                "top_cat": top_cat})
    return templates.TemplateResponse(request, "country.html", ctx)


@app.get("/entities", response_class=HTMLResponse)
def entities_index(request: Request, kind: str | None = None):
    conn = db.connect()
    try:
        all_ents = db.entities_summary(conn, kind=kind)
        counts = db.entity_counts(conn)
        total_entities = sum(counts.values())
    finally:
        conn.close()
    lang = _lang(request)
    kind_counts = [{**k, "label": k.get("label_en") if lang == "en" else k["label"],
                    "count": counts.get(k["key"], 0)} for k in ENTITY_KINDS]
    kind_counts = [k for k in kind_counts if k["count"] or k["key"] != "other"]
    top_entities = all_ents[:5]
    max_entity_count = max((e["count"] for e in all_ents), default=1) or 1
    ctx = _base_context(request)
    ctx.update({"page": "entities", "entities": all_ents, "kinds": kind_counts,
                "total_entities": total_entities, "active_kind": kind,
                "top_entities": top_entities, "max_entity_count": max_entity_count})
    return templates.TemplateResponse(request, "entities.html", ctx)


@app.get("/entity/{name}", response_class=HTMLResponse)
def entity_page(request: Request, name: str):
    conn = db.connect()
    try:
        raw = db.entity_reports(conn, name)
        if not raw:
            raise HTTPException(status_code=404, detail="الكيان غير موجود في السجل")
        items = [_enrich(r, _lang(request)) for r in raw]
        kind = db.entity_kind(conn, name)
        cooccurring = db.cooccurring_entities(conn, name)
        cat_keys: set[str] = set()
        for r in items:
            cat_keys.add(r["category"])
    finally:
        conn.close()
    from . import actors as actors_mod
    profile = actors_mod.by_name(name)
    related = []
    if profile:
        related = [a["name"] for a in actors_mod.ACTORS
                   if a["kind"] == profile["kind"] and a["name"] != name][:8]
    cats = [{**c, "name": category_name(c["key"], _lang(request))}
            for c in CATEGORIES if c["key"] in cat_keys]
    ctx = _base_context(request)
    ctx.update({"page": "entities", "name": name, "items": items, "kind": kind,
                "profile": profile, "related": related, "cats": cats,
                "cooccurring": cooccurring,
                "kind_meta": ENTITY_KIND_BY_KEY.get(kind, {})})
    return templates.TemplateResponse(request, "entity.html", ctx)


@app.get("/sitemap.xml")
def sitemap(request: Request):
    conn = db.connect()
    try:
        ids = [r["id"] for r in conn.execute("SELECT id FROM reports ORDER BY id")]
    finally:
        conn.close()
    base = _site_url(request)
    paths = ["/", "/reports", "/timeline", "/map", "/stats",
             "/sources", "/about", "/submit", "/countries",
             "/entities", "/members", "/posts", "/groups",
             "/messages", "/verification", "/moderation", "/trust", "/notifications",
             "/discover", "/campaigns", "/integrations", "/status", "/vault",
             "/monitor", "/audit"]
    paths += [f"/category/{c['key']}" for c in CATEGORIES]
    conn2 = db.connect()
    try:
        paths += [f"/country/{c['country']}" for c in db.countries_summary(conn2)]
        paths += [f"/entity/{e['name']}" for e in db.entities_summary(conn2, limit=None)]
        paths += [f"/member/{m['handle']}" for m in social.query_members(conn2, limit=None)]
        paths += [f"/post/{p['id']}" for p in social.query_posts(conn2, limit=None)]
        paths += [f"/group/{g['slug']}" for g in social.query_groups(conn2, limit=None)]
        paths += [f"/verification/{c['ref']}" for c in social.query_claims(conn2, limit=None)]
    finally:
        conn2.close()
    paths += [f"/reports/{i}" for i in ids]
    # مسارات الموقع يجب أن تكون مُرمَّزة (الفراغات والعربية في أسماء الدول/الكيانات).
    urls = [f"{base}{quote(p, safe='/')}" for p in paths]
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls:
        parts.append(f"<url><loc>{u}</loc></url>")
    parts.append("</urlset>")
    return Response(content="\n".join(parts), media_type="application/xml; charset=utf-8")


@app.get("/robots.txt", response_class=PlainTextResponse)
def robots(request: Request):
    base = _site_url(request)
    # امنع فهرسة المسارات الخاصّة/التشغيلية والواجهات البرمجية للكتابة.
    disallow = ["/account", "/messages", "/notifications", "/moderation", "/vault",
                "/admin", "/monitor", "/audit", "/api/", "/auth/", "/submit",
                "/offline"]
    lines = ["User-agent: *", "Allow: /"]
    lines += [f"Disallow: {p}" for p in disallow]
    lines.append(f"Sitemap: {base}/sitemap.xml")
    return "\n".join(lines) + "\n"


@app.get("/healthz")
def healthz():
    return {"status": "ok", "version": app.version}


@app.get("/api/status")
def api_status():
    """حالة المنصة: الإحصاءات، آخر تحديث دوري، وحالة المجدول."""
    conn = db.connect()
    try:
        st = db.stats(conn)
        last = refresh.last_refresh(conn)
        ingests = db.ingest_history(conn, limit=8)
    finally:
        conn.close()
    return {
        "stats": st,
        "last_refresh": last,
        "scheduler": scheduler.status(),
        "recent_ingests": ingests,
    }


@app.get("/api/urgent")
def api_urgent(request: Request, limit: int = 8, hours: int = 72):
    """بلاغات «عاجل» (حرجة/مرتفعة حديثة) مع حالة الجمع الحيّة — لنافذة العاجل."""
    lang = _lang(request)
    conn = db.connect()
    try:
        # نحدّ `hours` لتفادي OverflowError في timedelta مع القيم الضخمة (500).
        items = [_enrich(r, lang) for r in
                 db.urgent_reports(conn, limit=min(max(1, limit), 30),
                                   hours=max(1, min(hours, 24 * 365)))]
        collection = db.collection_stats(conn)
        health = db.catalog_health(conn)
    finally:
        conn.close()
    return {"collection": collection, "catalog": health,
            "count": len(items), "items": items}


@app.get("/api/collection")
def api_collection():
    """مؤشرات الجمع الآلي: المُضاف حديثاً، صحّة فهرس المصادر، وحالة المجدول."""
    conn = db.connect()
    try:
        return {"collection": db.collection_stats(conn),
                "catalog": db.catalog_health(conn),
                "scheduler": scheduler.status()}
    finally:
        conn.close()


@app.get("/api/new-count")
def api_new_count(since: str | None = None):
    """عدد البلاغات المُضافة بعد `since` (طابع زمني ISO)، وطابع آخر بلاغ.

    يستخدمه عدّاد «جديد» في التنقّل لمقارنة آخر زيارة للمستخدم.
    """
    conn = db.connect()
    try:
        latest = db.latest_created_at(conn)
        n = db.count_since(conn, since) if since else 0
    finally:
        conn.close()
    return {"since": since, "new": n, "latest": latest}


@app.get("/api/entities")
def api_entities(kind: str | None = None, limit: int = 100):
    conn = db.connect()
    try:
        items = db.entities_summary(conn, kind=kind, limit=clamp_limit(limit, default=100))
        counts = db.entity_counts(conn)
    finally:
        conn.close()
    return {"counts": counts, "items": items}


@app.get("/api/entities/{name}/related")
def api_entity_related(name: str, limit: int = 12):
    """الكيانات المشتركة في البلاغات مع الكيان المحدّد."""
    conn = db.connect()
    try:
        if not db.entity_reports(conn, name):
            raise HTTPException(status_code=404, detail="الكيان غير موجود في السجل")
        related = db.cooccurring_entities(conn, name, limit=clamp_limit(limit, default=12, maximum=50))
    finally:
        conn.close()
    return {"name": name, "count": len(related), "items": related}


@app.get("/api/refresh")
def api_refresh():
    """تنفيذ دورة تحديث واحدة فوراً (للاستخدام التشغيلي/المراقبة)."""
    conn = db.connect()
    try:
        return refresh.refresh(conn, pull_news=False)
    finally:
        conn.close()


@app.get("/api/daily")
def api_daily(days: int = 365):
    """نشاط يومي (عدد البلاغات لكل يوم) — للخريطة الحرارائية التقويمية."""
    conn = db.connect()
    try:
        rows = db.daily_activity(conn, days=min(days, 730))
    finally:
        conn.close()
    return {"days": days, "items": rows}


@app.get("/sw.js")
def service_worker():
    """يُقدَّم عامل الخدمة من الجذر ليعمل على كامل نطاق الموقع."""
    path = BASE_DIR / "static" / "sw.js"
    return Response(content=path.read_text(encoding="utf-8"),
                    media_type="application/javascript; charset=utf-8",
                    headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})


@app.get("/offline", response_class=HTMLResponse)
def offline_page(request: Request):
    """صفحة بديلة عند انقطاع الاتصال (تُخزّن بواسطة عامل الخدمة)."""
    ctx = _base_context(request)
    ctx.update({"page": "offline"})
    return templates.TemplateResponse(request, "offline.html", ctx)


# ---------------------------------------------------------------------------
# معالجة الأخطاء الودّية
# ---------------------------------------------------------------------------

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """صفحة خطأ مخصّصة لطلبات HTML، وJSON لبقية الطلبات."""
    accepts_html = "text/html" in (request.headers.get("accept") or "")
    friendly = {400: "error.bad_request", 403: "error.forbidden",
                404: "error.not_found", 405: "error.method",
                429: "error.rate_limited"}
    if accepts_html and exc.status_code in friendly:
        ctx = _base_context(request)
        ctx.update({"page": "error", "error_code": exc.status_code,
                    "error_title": t(friendly[exc.status_code], ctx["lang"]),
                    "error_lede": t(friendly[exc.status_code] + "_lede", ctx["lang"])})
        return templates.TemplateResponse(request, "error.html", ctx, status_code=exc.status_code)
    return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)


@app.exception_handler(OverflowError)
async def overflow_exception_handler(request: Request, exc: OverflowError):
    """قيمة عددية خارج نطاق SQLite (مُعامل/مسار ضخم) → 400 بدل 500.

    `int` في مسارات FastAPI بلا حدّ أعلى، فتمرير قيمة أكبر من 2^63-1 إلى SQLite
    يرفع OverflowError. نحوّلها إلى طلب غير صالح مع الحفاظ على شكل الخطأ نفسه.
    نُمرّر أي OverflowError آخر إلى المعالج العام كي لا نخفي أخطاء برمجية حقيقية.
    """
    if "SQLite" not in str(exc):
        return await unhandled_exception_handler(request, exc)
    accepts_html = "text/html" in (request.headers.get("accept") or "")
    if accepts_html:
        ctx = _base_context(request)
        ctx.update({"page": "error", "error_code": 400,
                    "error_title": t("error.bad_request", ctx["lang"]),
                    "error_lede": t("error.bad_request_lede", ctx["lang"])})
        return templates.TemplateResponse(request, "error.html", ctx, status_code=400)
    return JSONResponse({"detail": "Bad Request"}, status_code=400)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """صفحة خطأ 500 ودّية لطلبات HTML بدل التتبّع الخام."""
    accepts_html = "text/html" in (request.headers.get("accept") or "")
    if accepts_html:
        ctx = _base_context(request)
        ctx.update({"page": "error", "error_code": 500,
                    "error_title": t("error.server", ctx["lang"]),
                    "error_lede": t("error.server_lede", ctx["lang"])})
        return templates.TemplateResponse(request, "error.html", ctx, status_code=500)
    return JSONResponse({"detail": "Internal Server Error"}, status_code=500)
