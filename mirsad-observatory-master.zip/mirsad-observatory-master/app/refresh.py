"""تحديث دوري لقاعدة البيانات.

يشغّل هذا الوحدة مهمّة خفيفة كل دقيقة (عبر `scheduler.py`) تُبقي السجل حيّاً:

1. تجديد التجميعات (العناقيد الزمنية للبلاغات المستوردة).
2. إثراء الكيانات الناقصة بمعرّفات ويكيداتا.
3. إعادة ربط الجهات الفاعلة من `actors.ACTORS` بالنصوص المستوردة حديثاً.
4. سحب دفعة صغيرة (دوريّة) من GDELT لإضافة بلاغات جديدة، مع استخدام
   التخزين المؤقّت لتقليل الضغط على المصدر واحترام سياسة تقييد المعدّل.

كل تشغيل يُسجَّل في `ingest_log`، ويُحفظ دور الاستعلامات في `schema_meta`
حتى لا يُبدأ من الصفر في كل مرة.
"""

from __future__ import annotations

import sqlite3
from datetime import date, datetime, timezone

from . import actors, db, importers
from .taxonomy import CATEGORY_BY_KEY, SEVERITY_BY_KEY, STATUS_BY_KEY

# ترتيب دوريّ لاستعلامات GDELT (واحد لكل تشغيل لتقليل الضغط)
_ROTATION = list(importers.GDELT_QUERIES.keys())

_REFRESH_META_KEY = "last_refresh"
_ROTATION_META_KEY = "gdelt_rotation"


def _get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM schema_meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def _set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO schema_meta(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def _next_rotation(conn: sqlite3.Connection) -> str:
    idx = int(_get_meta(conn, _ROTATION_META_KEY) or "0") % len(_ROTATION)
    _set_meta(conn, _ROTATION_META_KEY, str(idx + 1))
    return _ROTATION[idx]


def relink_entities(conn: sqlite3.Connection, limit: int = 200) -> int:
    """يعيد ربط الجهات الفاعلة بالبلاغات التي ينقصها كيان من نوع غير الدولة.

    مفيد للبلاغات المستوردة آلياً (مثل GDELT) التي لا تحمل كيانات أصلاً،
    وللبلاغات المضافة يدوياً بعد توسيع سجل الجهات.
    """
    rows = conn.execute(
        """SELECT r.id, r.title, r.summary, r.details FROM reports r
           WHERE NOT EXISTS (
               SELECT 1 FROM entities e
               WHERE e.report_id = r.id AND e.kind IN ('person', 'company', 'government')
           )
           LIMIT ?""",
        (limit,),
    ).fetchall()
    added = 0
    for r in rows:
        existing = {e["name"] for e in db.entities_for(conn, r["id"])}
        haystack = " ".join(filter(None, [r["title"], r["summary"], r["details"]]))
        for actor in actors.match_actors(haystack):
            if actor["name"] not in existing:
                db.add_entity(conn, r["id"], actor["name"], kind=actor["kind"])
                existing.add(actor["name"])
                added += 1
    if added:
        conn.commit()
    return added


def recompute_aggregates(conn: sqlite3.Connection, limit: int = 400) -> dict:
    """يتحقق من سلامة الفهرس النصّي ويعيد بناء `search_blob` للصفوف الناقصة فقط.

    مُقيَّد بـ`limit` لأن مسح عشرات آلاف الصفوف في كل دورة مكلف؛ الصفوف الجديدة
    تحصل على `search_blob` عبر المُشغّلات عند الإدراج، فهذا فحص تدريجي للسلامة.
    """
    from .textutils import build_search_text

    stale = 0
    rows = conn.execute(
        "SELECT id, title, summary, details, country, region, source_name, search_blob "
        "FROM reports WHERE search_blob IS NULL OR search_blob = '' LIMIT ?", (int(limit),)
    ).fetchall()
    for r in rows:
        expected = build_search_text(
            r["title"], r["summary"], r["details"] or "", r["country"],
            r["region"] or "", r["source_name"] or "",
        )
        if expected != (r["search_blob"] or ""):
            conn.execute("UPDATE reports SET search_blob = ? WHERE id = ?",
                         (expected, r["id"]))
            stale += 1
    if stale:
        conn.commit()
    return {"search_reindexed": stale}


def refresh(conn: sqlite3.Connection, *, pull_news: bool = True,
            max_records: int = 12) -> dict:
    """دورة تحديث واحدة. تُعيد ملخّص ما جرى."""
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    summary: dict = {"ran_at": started}

    # 1) ثبّت الحالة ونُحرّر القفل قبل أي طلب شبكة بطيء. بدونه يبقى اتصال SQLite
    #    في وضع كتابة أثناء جمع المصادر، فتفشل كتابات المستخدم
    #    (تسجيل الدخول/التبرّع) بـ«database is locked».
    conn.commit()

    # 2) إثراء بمعرّفات ويكيداتا لعدد محدود
    try:
        summary["wikidata"] = importers.enrich_report_entities(conn, limit=8)
    except Exception as exc:  # noqa: BLE001 — لا نُفشل الدورة بسبب مصدر خارجي
        summary["wikidata_error"] = str(exc)[:160]
    conn.commit()

    # 3) سحب دفعة إخبارية دوريّة (اختياري)
    if pull_news:
        q = _next_rotation(conn)
        conn.commit()  # تحرير القفل قبل جمع GDELT البطيء
        try:
            summary["news"] = importers.ingest_gdelt(
                conn, query=importers.GDELT_QUERIES[q], category=q,
                maxrecords=max_records)
        except Exception as exc:  # noqa: BLE001
            summary["news_error"] = str(exc)[:160]
        conn.commit()
        # مسار بديل عند تقييد/حجب GDELT DOC API: ملفات الأحداث الخام.
        try:
            from . import gdelt_raw
            summary["news_raw"] = gdelt_raw.ingest_gdelt_raw(
                conn, windows=2, maxrecords=max_records * 8)
        except Exception as exc:  # noqa: BLE001
            summary["news_raw_error"] = str(exc)[:160]
        conn.commit()
        # تغذيات RSS من المنظّمات الموثوقة (HRW/Amnesty/OHCHR/FIDH/UN).
        try:
            from . import rss_feeds
            summary["rss"] = rss_feeds.ingest_rss(conn, maxrecords=max_records)
        except Exception as exc:  # noqa: BLE001
            summary["rss_error"] = str(exc)[:160]
        conn.commit()
        # الجمع الآلي الواسع من فهرس المصادر (≈1000 مصدر) — دفعة صغيرة متناوبة.
        try:
            from . import harvest
            summary["harvest"] = harvest.harvest_batch(conn)
        except Exception as exc:  # noqa: BLE001
            summary["harvest_error"] = str(exc)[:160]
        conn.commit()

    # 4) تجميعات وإعادة فهرسة
    summary.update(recompute_aggregates(conn))

    # 5) اكتشاف مصادر جديدة (كل 5 دقائق افتراضيًّا) وإضافتها للقائمة بلا تكرار.
    try:
        from . import discovery
        report = discovery.maybe_discover(conn)
        if report is not None:
            summary["discovery"] = {
                "added": report["added_count"],
                "duplicates": report["duplicate_count"],
                "rejected": report["rejected_count"],
                "by_group": report["by_group"],
            }
    except Exception as exc:  # noqa: BLE001 — لا نُفشل الدورة بسبب الاكتشاف
        summary["discovery_error"] = str(exc)[:160]
    conn.commit()

    # 6) منظومة الرصد المستمر: جمع مستحق → طابور معالجة → تحقق كل 5 دقائق.
    #    كل مهمّة مُبوّبة بفترتها داخل `monitor_tick`، فدورة الدقيقة تعني توزيع
    #    المهام لا إعادة تحميل كل المصادر بلا تمييز.
    try:
        from . import monitoring
        tick = monitoring.monitor_tick(conn)
        if tick.get("ran"):
            summary["monitoring"] = {k: v for k, v in tick.items()
                                     if k not in ("ran_at",)}
    except Exception as exc:  # noqa: BLE001 — لا نُفشل الدورة بسبب الرصد
        summary["monitoring_error"] = str(exc)[:160]
    conn.commit()

    # 7) إعادة ربط الجهات بعد الجمع: تشمل البلاغات المستوردة حديثًا في الدورة نفسها،
    #    والبلاغات القديمة الناقصة. ترتيبها هنا يضمن أن إعادة التشغيل بلا جمع جديد
    #    لا تُضيف شيئًا (idempotent).
    summary["entities_linked"] = relink_entities(conn)
    conn.commit()

    _set_meta(conn, _REFRESH_META_KEY, started)
    conn.commit()
    try:
        db.log_ingest(conn, "scheduler", summary.get("news", {}).get("fetched", 0),
                      summary.get("news", {}).get("inserted", 0),
                      summary.get("news", {}).get("skipped", 0),
                      note=f"linked={summary['entities_linked']} reindex={summary['search_reindexed']}")
    except sqlite3.OperationalError:
        # قد يكون القفل مشغولاً بطلب آخر — لا نُفشل الدورة لأجل سجل فقط
        pass
    return summary


def last_refresh(conn: sqlite3.Connection) -> str | None:
    return _get_meta(conn, _REFRESH_META_KEY)
