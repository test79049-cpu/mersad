"""نظام الاكتشاف الدوري للمصادر الجديدة.

الهدف: البحث دوريًّا عن مواقع ومكتبات وقواعد بيانات ومصادر تسريبات وشفافية
(حكومية وغير حكومية) ومنصّات توثيق الانتهاكات الحقوقية والإنسانية والبيئية
والدينية والفكرية، وحقوق الأقليات، والحقوق الرقمية/الذكاء الاصطناعي، وحقوق
السكان الأصليين، وحقوق LGBTQ+، ثم إضافتها إلى قائمة مصادر الموقع.

المنهجية (بلا مفاتيح ولا حصص، مفتوحة ومجانية):
    1) مجموعة مرشّحين مُنتقاة يدويًّا تغطّي التصنيفات الـ15 المرجعية وكل مجالات
       المنصّة (taxonomy)، كلٌّ ببياناته الوصفية ورخصته.
    2) **بوّابة قبول**: يُرفض أي مرشّح ليس مجانيًّا أو غير مفتوح/بيانات مفتوحة.
    3) **منع التكرار** بمطابقة الاسم المُطبَّع والمضيف (URL) مع المصادر
       الموجودة مسبقًا في `sources` و`source_catalog` — فلا يُضاف مصدر مرّتين.
    4) إضافة المقبول إلى `source_catalog` (ومنه يظهر في صفحة المصادر ويُجمع
       منه تلقائيًّا إن كان له تغذية)، مع تسجيل كل عملية في سجل الاكتشاف
       لتوليد تقرير يوضح المُضاف وتصنيفه.

يعمل من ثلاث واجهات: دورة المجدول (يوميًّا افتراضيًّا)، و`app.cli discover`،
و`POST /api/discovery/run`. كلها تستدعي `discover()` نفسها.
"""

from __future__ import annotations

import logging
import os
import re
import urllib.parse
from datetime import datetime, timezone

from . import db
from .taxonomy import CATEGORY_KEYS
from .textutils import normalize_arabic

log = logging.getLogger("mirsad.discovery")

# تصنيفات الاكتشاف المرجعية (15) كما طُلبت، مربوطة بمجالات المنصّة الداخلية.
DISCOVERY_GROUPS: list[dict] = [
    {"key": "leaks_transparency", "name": "التسريبات والشفافية",
     "name_en": "Leaks & transparency",
     "desc": "تسريبات حكومية، أوراق الشركات، السجلات المفتوحة والعقوبات.",
     "categories": ["criminal_justice", "economic_social", "human_rights"]},
    {"key": "human_rights", "name": "حقوق الإنسان والانتهاكات",
     "name_en": "Human rights & abuses",
     "desc": "توثيق جرائم الحرب، الاعتقال التعسفي، والتوثيق الميداني.",
     "categories": ["human_rights", "peace_security"]},
    {"key": "environmental", "name": "الحقوق البيئية",
     "name_en": "Environmental rights",
     "desc": "النزاعات البيئية، تدمير البيئة، وحقوق المجتمعات المحلية.",
     "categories": ["environment"]},
    {"key": "ai_digital", "name": "الذكاء الاصطناعي والحقوق الرقمية",
     "name_en": "AI & digital rights",
     "desc": "أضرار الخوارزميات، الرقابة الرقمية، حجب الإنترنت، والخصوصية.",
     "categories": ["ai_ethics", "expression"]},
    {"key": "indigenous", "name": "حقوق السكان الأصليين",
     "name_en": "Indigenous peoples' rights",
     "desc": "أراضي الأجداد والانتهاكات البيئية والحقوقية الموجّهة لهم.",
     "categories": ["minorities"]},
    {"key": "lgbtq", "name": "حقوق LGBTQ+",
     "name_en": "LGBTQ+ rights",
     "desc": "التشريعات التمييزية ورصد العنف والاضطهاد الجندري.",
     "categories": ["inclusivity", "minorities"]},
    {"key": "minorities_belief", "name": "الأقليات والحريات الفكرية والدينية",
     "name_en": "Minorities, thought & belief",
     "desc": "حقوق الأقليات العرقية واللغوية والدينية، وحرية المعتقد.",
     "categories": ["minorities", "beliefs"]},
    {"key": "press_freedom", "name": "حرية الصحافة",
     "name_en": "Press freedom",
     "desc": "الاعتداءات على الصحفيين، سجنهم، والرقابة على الإعلام.",
     "categories": ["expression"]},
    {"key": "labor_economic", "name": "حقوق العمال والعدالة الاقتصادية",
     "name_en": "Labour & economic justice",
     "desc": "انتهاكات الشركات، حقوق النقابات، وظروف العمل القسرية.",
     "categories": ["labor_rights", "economic_social"]},
    {"key": "disability_transitional", "name": "ذوو الإعاقة والعدالة الانتقالية",
     "name_en": "Disability & transitional justice",
     "desc": "إتاحة الحقوق، الاختفاء القسري، والأرشيفات الرقمية.",
     "categories": ["disability_rights", "transitional_justice", "prisoners_rights"]},
    {"key": "women_gender", "name": "حقوق المرأة والعدالة الجندرية",
     "name_en": "Women's & gender justice",
     "desc": "توثيق العنف القائم على النوع الاجتماعي والتمييز القانوني.",
     "categories": ["women_children"]},
    {"key": "refugees_migrants", "name": "حقوق اللاجئين والمهاجرين والنازحين",
     "name_en": "Refugees, migrants & displaced",
     "desc": "توثيق انتهاكات الحدود، الإعادة القسرية، وتتبّع حركة النزوح.",
     "categories": ["refugees_migrants"]},
    {"key": "children", "name": "حقوق الأطفال وحمايتهم",
     "name_en": "Children's rights",
     "desc": "توثيق عمل الأطفال، تجنيدهم في النزاعات، وتجريدهم من الحقوق.",
     "categories": ["women_children"]},
    {"key": "elderly", "name": "حقوق كبار السن",
     "name_en": "Rights of older persons",
     "desc": "التمييز العمري، الإهمال الصحي، والانتهاكات الموجّهة لكبار السن.",
     "categories": ["elderly_rights", "health"]},
    {"key": "osint_forensics", "name": "أرشيف الأدلة الرقمية الجنائية (OSINT)",
     "name_en": "OSINT & digital forensics",
     "desc": "منصّات أرشفة أدلة الفيديو والصور لجرائم الحرب قبل حجبها.",
     "categories": ["human_rights", "peace_security", "transitional_justice"]},
]

GROUP_BY_KEY = {g["key"]: g for g in DISCOVERY_GROUPS}

# أنواع المصادر كما وردت في الطلب (مواقع/مكتبات/قواعد بيانات/منصّات توثيق).
SOURCE_KINDS = ["website", "database", "leaks", "documentation", "library"]

# مفاتيح الرخص المقبولة (مجاني + مفتوح المصدر/بيانات مفتوحة).
_OPEN_LICENSE_HINTS = (
    "cc0", "cc by", "cc-by", "public domain", "odbl", "odc", "mit", "apache",
    "bsd", "gpl", "agpl", "mpl", "open data", "open-data", "open source",
    "open-source", "creative commons", "ملكية عامة", "مفتوح", "مجاني",
)


# ---------------------------------------------------------------------------
# مجموعة المرشّحين: كل مدخل يغطّي تصنيفًا مرجعيًّا، ببياناته ورخصته.
# ---------------------------------------------------------------------------
# (key, الاسم العربي, الاسم الإنجليزي, المجموعة المرجعية, النوع, الرابط,
#  الرخصة, التغطية, الوصول, تغذية اختيارية)
CANDIDATES: list[tuple] = [
    # --- التسريبات والشفافية ---
    ("ddosecrets", "دي دي أو سيكرتس", "Distributed Denial of Secrets", "leaks_transparency",
     "leaks", "https://ddosecrets.com/", "مفتوح المصدر / بيانات مفتوحة",
     "أرشيف تسريبات حكومية وشركات للصحفيين والباحثين", "تنزيل مباشر", None),
    ("icij_offshore", "الاتحاد الدولي للصحفيين الاستقصائيين — أوراق أوفشور",
     "ICIJ Offshore Leaks Database", "leaks_transparency", "database",
     "https://offshoreleaks.icij.org/", "ODbL 1.0 (بيانات مفتوحة)",
     "أكثر من 800 ألف كيان أوفشور من أوراق بنما وغيرها", "بحث + تنزيل", None),
    ("opensanctions_disc", "أوبن سانكشنز", "OpenSanctions", "leaks_transparency",
     "database", "https://www.opensanctions.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "قوائم العقوبات والمسؤولين والكيانات عالية المخاطر عالميًّا",
     "API عام + تنزيل", None),
    ("opencorporates", "أوبن كوربوريتس", "OpenCorporates", "leaks_transparency",
     "database", "https://opencorporates.com/", "ODbL 1.0 (بيانات مفتوحة جزئيًّا)",
     "أكبر قاعدة بيانات مفتوحة للشركات في العالم", "بحث + API", None),
    ("aleph_occrp", "أليف — مركز تقارير الجريمة المنظّمة والفساد",
     "OCCRP Aleph", "leaks_transparency", "database",
     "https://aleph.occrp.org/", "ODbL 1.0 (بيانات مفتوحة)",
     "فهرس سجلات الشركات والأشخاص والوثائق المسرّبة", "بحث + API", None),

    # --- حقوق الإنسان والانتهاكات ---
    ("huridocs_disc", "هيوريدوكس", "HURIDOCS", "human_rights",
     "documentation", "https://huridocs.org/", "مفتوح المصدر (GPL/AGPL)",
     "أدوات ومنهجيات ومنصّة توثيق انتهاكات حقوق الإنسان", "تنزيل + كود", None),
    ("bellingcat", "بيلينغكات", "Bellingcat", "human_rights",
     "documentation", "https://www.bellingcat.com/", "Creative Commons (بإسناد)",
     "تحقيقات مفتوحة المصدر في جرائم الحرب والانتهاكات", "موقع + أدلة", None),
    ("ohchr_disc", "المفوضية السامية لحقوق الإنسان", "UN OHCHR", "human_rights",
     "documentation", "https://www.ohchr.org/en/countries", "بيانات أممية (مفتوحة)",
     "توثيق رسمي لانتهاكات حقوق الإنسان حسب البلد", "موقع + قواعد", None),
    ("amnesty_disc", "منظمة العفو الدولية", "Amnesty International", "human_rights",
     "documentation", "https://www.amnesty.org/en/latest/", "CC BY-NC-SA 3.0",
     "توثيق دولي لانتهاكات حقوق الإنسان والحريات", "موقع + RSS",
     "https://www.amnesty.org/en/latest/feed/"),
    ("hrw_disc", "هيومن رايتس ووتش", "Human Rights Watch", "human_rights",
     "documentation", "https://www.hrw.org/", "CC BY-NC-SA 3.0",
     "أبحاث وتقارير ميدانية عن الانتهاكات في 100+ دولة", "موقع + RSS",
     "https://www.hrw.org/rss/news"),
    ("ushmm_holocaust", "متحف ذكرى الهولوكوست — أرشيف الشهادات",
     "US Holocaust Memorial Museum — Collections", "human_rights",
     "library", "https://collections.ushmm.org/", "بيانات مفتوحة (وصول حر)",
     "أرشيف شهادات ووثائق عن الإبادة الجماعية والجرائم الجماعية",
     "بحث + تنزيل", None),
    ("carter_center", "مركز كارتر — برنامج النزاعات",
     "Carter Center — Conflict Resolution Program", "human_rights",
     "documentation", "https://www.cartercenter.org/peace/conflict_resolution/",
     "مفتوح (منشورات مجانية)",
     "رصد وتوثيق النزاعات وحقوق الإنسان", "موقع", None),

    # --- الحقوق البيئية ---
    ("ejatlas", "أطلس العدالة البيئية", "Environmental Justice Atlas", "environmental",
     "database", "https://ejatlas.org/", "CC BY-SA 4.0 (بيانات مفتوحة)",
     "توثيق آلاف النزاعات البيئية حول العالم", "بحث + تنزيل", None),
    ("gfw", "مراقبة الغابات العالمية", "Global Forest Watch", "environmental",
     "database", "https://www.globalforestwatch.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "تنبيهات إزالة الغابات وبيانات التغطية الشجرية", "خرائط + API", None),
    ("unep_opendata", "برنامج الأمم المتحدة للبيئة — بيانات مفتوحة",
     "UNEP Open Data", "environmental", "database",
     "https://www.unep.org/resources", "CC BY 4.0 (بيانات مفتوحة)",
     "بيانات بيئية ومناخية أممية مفتوحة", "تنزيل + API", None),
    ("business_humanrights", "مركز الأعمال وحقوق الإنسان",
     "Business & Human Rights Resource Centre", "environmental",
     "database", "https://www.business-humanrights.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "توثيق انتهاكات الشركات البيئية والحقوقية", "بحث + API", None),
    ("fridays_future", "أيام الجمعة من أجل المستقبل", "Fridays for Future",
     "environmental", "website", "https://fridaysforfuture.org/",
     "Creative Commons (بإسناد)", "حركة مناخية عالمية وتوثيق مطالبات العدالة المناخية",
     "موقع", None),

    # --- الذكاء الاصطناعي والحقوق الرقمية ---
    ("ai_incident", "قاعدة حوادث الذكاء الاصطناعي", "AI Incident Database", "ai_digital",
     "database", "https://incidentdatabase.ai/", "CC BY-SA 4.0 (بيانات مفتوحة)",
     "توثيق حوادث أضرار أنظمة الذكاء الاصطناعي", "بحث + API", None),
    ("algorithmwatch", "مراقبة الخوارزميات", "AlgorithmWatch", "ai_digital",
     "documentation", "https://algorithmwatch.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "رصد أضرار الخوارزميات والتمييز الآلي", "موقع + تقارير", None),
    ("accessnow_disc", "أكسس ناو", "Access Now", "ai_digital",
     "documentation", "https://www.accessnow.org/", "Creative Commons (بإسناد)",
     "الدفاع عن الحقوق الرقمية وحجب الإنترنت والخصوصية", "موقع + RSS",
     "https://www.accessnow.org/feed/"),
    ("eff_disc", "مؤسسة الحدود الإلكترونية", "Electronic Frontier Foundation",
     "ai_digital", "documentation", "https://www.eff.org/", "CC BY 3.0",
     "الخصوصية والرقابة الرقمية وحقوق المستخدمين", "موقع + RSS",
     "https://www.eff.org/rss/updates.xml"),
    ("oecd_ai", "الذكاء الاصطناعي — مرصد سياسات OECD",
     "OECD.AI Policy Observatory", "ai_digital", "database",
     "https://oecd.ai/", "بيانات مفتوحة (بإسناد)",
     "مؤشرات وسياسات الذكاء الاصطناعي عبر الدول", "API + تنزيل", None),
    ("ranking_digital_rights", "تصنيف الحقوق الرقمية",
     "Ranking Digital Rights", "ai_digital", "database",
     "https://rankingdigitalrights.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "تقييم شركات الاتصال والإنترنت في الخصوصية وحرية التعبير",
     "بيانات + تقارير", None),

    # --- حقوق السكان الأصليين ---
    ("indigenous_nav", "مُرشِد الشعوب الأصلية", "Indigenous Navigator", "indigenous",
     "database", "https://indigenousnavigator.org/", "بيانات مفتوحة (بإسناد)",
     "بيانات مؤشّرات حقوق الشعوب الأصلية عبر الدول", "بحث + تنزيل", None),
    ("iwgia", "المجموعة الدولية لشؤون الشعوب الأصلية", "IWGIA", "indigenous",
     "documentation", "https://www.iwgia.org/", "Creative Commons (بإسناد)",
     "تقارير سنوية وتوثيق انتهاكات حقوق الشعوب الأصلية", "موقع + تنزيل", None),
    ("un_permforum", "المنتدى الدائم لقضايا الشعوب الأصلية",
     "UN Permanent Forum on Indigenous Issues", "indigenous",
     "documentation", "https://www.un.org/development/desa/indigenouspeoples/",
     "بيانات أممية (مفتوحة)", "وثائق أممية عن حقوق الشعوب الأصلية وأراضي الأجداد",
     "موقع", None),
    ("survival_intl", "سرفايفل إنترناشونال", "Survival International",
     "indigenous", "documentation", "https://www.survivalinternational.org/",
     "Creative Commons (بإسناد)", "توثيق حقوق القبائل المعزولة وأراضيها", "موقع", None),

    # --- حقوق LGBTQ+ ---
    ("ilga_world", "إلغا وورلد", "ILGA World", "lgbtq",
     "database", "https://ilga.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "قوانين المثلية والهوية الجندرية وتوثيق الاضطهاد في 190+ دولة",
     "تقارير + بيانات", None),
    ("outright", "أوترايت إنترناشونال", "OutRight Action International", "lgbtq",
     "documentation", "https://outrightinternational.org/", "Creative Commons (بإسناد)",
     "رصد العنف والاضطهاد الموجّه ضدّ LGBTQ+ عالميًّا", "موقع + تقارير", None),
    ("equaldex", "إكوالديكس", "Equaldex", "lgbtq",
     "database", "https://www.equaldex.com/", "بيانات مفتوحة (بإسناد)",
     "قاعدة بيانات تفاعلية لقوانين LGBTQ+ حسب البلد", "بحث + تنزيل", None),
    ("tgeu", "الرابطة الأوروبية للمتحوّلين جندريًّا", "TGEU", "lgbtq",
     "documentation", "https://tgeu.org/", "Creative Commons (بإسناد)",
     "رصد جرائم الكراهية والعنف ضدّ المتحوّلين جندريًّا", "موقع + تقارير",
     "https://tgeu.org/feed/"),

    # --- الأقليات والحريات الفكرية والدينية ---
    ("mrg", "مجموعة حقوق الأقليات", "Minority Rights Group (MRG)", "minorities_belief",
     "documentation", "https://minorityrights.org/", "Creative Commons (بإسناد)",
     "توثيق حقوق الأقليات العرقية واللغوية والدينية", "موقع + قاعدة", None),
    ("uscirf_disc", "اللجنة الأمريكية للحرية الدينية الدولية", "USCIRF",
     "minorities_belief", "documentation", "https://www.uscirf.gov/",
     "بيانات حكومية مفتوحة (ملكية عامة)", "رصد انتهاكات الحرية الدينية عالميًّا",
     "موقع + RSS", "https://www.uscirf.gov/rss.xml"),
    ("pew_religion_disc", "مركز بيو — الدين والحياة العامة",
     "Pew Research — Religion & Public Life", "minorities_belief", "database",
     "https://www.pewresearch.org/religion/", "بيانات مفتوحة (بإسناد)",
     "دراسات كمّية عن الحريات الدينية والأقليات", "تنزيل + RSS",
     "https://www.pewresearch.org/topic/religion/feed/"),
    ("forum18", "فورم 18", "Forum 18 News Service", "minorities_belief",
     "documentation", "https://www.forum18.org/", "Creative Commons (بإسناد)",
     "رصد انتهاكات حرية المعتقد والعقيدة", "موقع + أرشيف", None),
    ("open_democracy", "الشبكة المفتوحة للديمقراطية", "OpenDemocracy",
     "minorities_belief", "documentation", "https://www.opendemocracy.net/",
     "Creative Commons (بإسناد)", "صحافة استقصائية عن الحقوق والحريات المدنية",
     "موقع", None),

    # --- حرية الصحافة ---
    ("rsf_disc", "مراسلون بلا حدود", "Reporters Without Borders (RSF)",
     "press_freedom", "database", "https://rsf.org/en/index", "CC BY 4.0 (بإسناد)",
     "مؤشر حرية الصحافة العالمي في 180 دولة", "تنزيل + تقارير", None),
    ("cpj_disc", "لجنة حماية الصحفيين", "Committee to Protect Journalists (CPJ)",
     "press_freedom", "database", "https://cpj.org/", "Creative Commons (بإسناد)",
     "قاعدة بيانات الصحفيين المسجونين والقتلى", "بحث + بيانات",
     "https://cpj.org/feed/"),
    ("ipi", "المعهد الدولي للصحافة", "International Press Institute (IPI)",
     "press_freedom", "database", "https://ipi.media/", "Creative Commons (بإسناد)",
     "رصد الاعتقالات والاعتداءات على الصحفيين", "موقع + خريطة", None),
    ("mfo", "منظمة حرية الإعلام", "Media Freedom Organisation", "press_freedom",
     "documentation", "https://www.mediafreedom.org/", "Creative Commons (بإسناد)",
     "حملات ومناصرة لحرية الإعلام وحماية الصحفيين", "موقع", None),
    ("foei_media", "الصحافة الحرة", "Free Press Unlimited", "press_freedom",
     "documentation", "https://www.freepressunlimited.org/", "Creative Commons (بإسناد)",
     "دعم الصحافة المستقلة وحماية الإعلاميين", "موقع", None),

    # --- حقوق العمال والعدالة الاقتصادية ---
    ("ituc_disc", "الاتحاد الدولي للنقابات", "International Trade Union Confederation",
     "labor_economic", "database", "https://www.ituc-csi.org/rights-index",
     "CC BY 4.0 (بيانات مفتوحة)", "مؤشر حقوق العمل العالمية حسب الدول",
     "تنزيل + تقارير", None),
    ("bhrrc_disc", "مركز موارد الأعمال وحقوق الإنسان",
     "Business & Human Rights Resource Centre", "labor_economic",
     "database", "https://www.business-humanrights.org/en/latest-news/",
     "CC BY 4.0 (بيانات مفتوحة)", "توثيق انتهاكات الشركات العمالية والاقتصادية",
     "بحث + RSS", None),
    ("cleanclothes_disc", "حملة الملابس النظيفة", "Clean Clothes Campaign",
     "labor_economic", "documentation", "https://cleanclothes.org/",
     "Creative Commons (بإسناد)", "حقوق عمّال صناعة الملابس وسلاسل التوريد",
     "موقع + تقارير", None),
    ("ilo_disc", "منظمة العمل الدولية — إحصاءات", "ILO Statistics",
     "labor_economic", "database", "https://ilostat.ilo.org/data/",
     "CC BY 4.0 (بيانات مفتوحة)", "مؤشرات العمل والعمل القسري وعمالة الأطفال",
     "API + تنزيل", None),
    ("wiego", "عاملات في الاقتصاد غير المنظّم", "Women in Informal Employment",
     "labor_economic", "database", "https://www.wiego.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "بيانات عمّال الاقتصاد غير المنظّم وحقوقهم", "تنزيل + تقارير", None),

    # --- ذوو الإعاقة والعدالة الانتقالية ---
    ("ida", "التحالف الدولي للإعاقة", "International Disability Alliance (IDA)",
     "disability_transitional", "documentation", "https://www.internationaldisabilityalliance.org/",
     "Creative Commons (بإسناد)", "مناصرة حقوق ذوي الإعاقة عبر الأمم المتحدة",
     "موقع + تقارير", None),
    ("witness", "ويتنس", "WITNESS", "disability_transitional",
     "documentation", "https://www.witness.org/", "Creative Commons (بإسناد)",
     "استخدام الفيديو لتوثيق انتهاكات حقوق الإنسان", "موقع + أدلّة", None),
    ("eyewitness", "آي ويتنس", "Eyewitness", "disability_transitional",
     "documentation", "https://www.eyewitness.global/", "Creative Commons (بإسناد)",
     "أرشفة وتحليل الأدلّة البصرية لجرائم الحرب", "موقع", None),
    ("ictj_disc", "المركز الدولي للعدالة الانتقالية",
     "International Center for Transitional Justice (ICTJ)",
     "disability_transitional", "documentation", "https://www.ictj.org/",
     "Creative Commons (بإسناد)", "العدالة الانتقالية وجبر الضرر والاختفاء القسري",
     "موقع + أرشيف", None),
    ("disability_rights_fund", "صندوق حقوق الإعاقة", "Disability Rights Fund",
     "disability_transitional", "documentation", "https://disabilityrightsfund.org/",
     "Creative Commons (بإسناد)", "تمويل ومناصرة حقوق ذوي الإعاقة مجتمعيًّا",
     "موقع", None),

    # --- حقوق المرأة والعدالة الجندرية ---
    ("unwomen_data", "بيانات هيئة الأمم المتحدة للمرأة",
     "UN Women Data Hub", "women_gender", "database",
     "https://data.unwomen.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "مؤشرات المساواة الجندرية والعنف القائم على النوع الاجتماعي",
     "API + تنزيل", None),
    ("oecd_gender", "بوّابة بيانات OECD الجندرية", "OECD Gender Data Portal",
     "women_gender", "database", "https://www.oecd.org/gender/data/",
     "CC BY 4.0 (بيانات مفتوحة)", "بيانات التمييز القانوني والاقتصادي ضدّ النساء",
     "تنزيل + API", None),
    ("equalitynow_disc", "إكواليتي ناو", "Equality Now", "women_gender",
     "documentation", "https://www.equalitynow.org/", "Creative Commons (بإسناد)",
     "حملات قانونية ضدّ العنف والتمييز الجندري", "موقع + تقارير", None),
    ("who_gender", "منظمة الصحة العالمية — العنف الجندري",
     "WHO — Gender-based violence", "women_gender", "database",
     "https://www.who.int/data/gho", "CC BY-NC-SA 3.0 IGO",
     "بيانات صحية عن العنف القائم على النوع الاجتماعي", "API + تنزيل", None),
    ("gbv_area", "منطقة المعرفة بشأن العنف الجندري",
     "GBV AoR — Knowledge Hub", "women_gender", "database",
     "https://gbvaor.net/", "بيانات مفتوحة (بإسناد)",
     "أدوات وبيانات تنسيق الاستجابة للعنف الجندري", "موقع + تنزيل", None),

    # --- حقوق اللاجئين والمهاجرين والنازحين ---
    ("unhcr_data", "بوّابة بيانات مفوضية اللاجئين",
     "UNHCR Operational Data Portal", "refugees_migrants", "database",
     "https://data.unhcr.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "بيانات اللاجئين والنازحين التشغيلية حسب البلد", "API + تنزيل", None),
    ("missing_migrants", "مشروع المهاجرين المفقودين",
     "IOM Missing Migrants Project", "refugees_migrants", "database",
     "https://missingmigrants.iom.int/", "CC BY 4.0 (بيانات مفتوحة)",
     "تتبّع وفيات المهاجرين على طرق الهجرة عالميًّا", "تنزيل + API", None),
    ("bvmn", "شبكة رصد العنف على الحدود",
     "Border Violence Monitoring Network (BVMN)", "refugees_migrants",
     "documentation", "https://www.borderviolence.eu/", "Creative Commons (بإسناد)",
     "توثيق انتهاكات الحدود والإعادة القسرية في البلقان", "موقع + تقارير", None),
    ("iom_dtm", "مصفوفة تتبّع النزوح", "IOM Displacement Tracking Matrix (DTM)",
     "refugees_migrants", "database", "https://dtm.iom.int/", "CC BY 4.0 (بيانات مفتوحة)",
     "تتبّع حركة النزوح والاحتياجات عبر الأزمات", "API + تنزيل", None),
    ("mixed_migration", "مركز الهجرة المختلطة", "Mixed Migration Centre",
     "refugees_migrants", "database", "https://mixedmigration.org/",
     "CC BY 4.0 (بيانات مفتوحة)", "بيانات وأبحاث عن رحلات المهاجرين وحمايتهم",
     "تنزيل + تقارير", None),

    # --- حقوق الأطفال وحمايتهم ---
    ("unicef_data", "بوّابة بيانات اليونيسف", "UNICEF Data Portal",
     "children", "database", "https://data.unicef.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "مؤشرات حقوق الطفل وعمل الأطفال والتجنيد", "API + تنزيل", None),
    ("child_rights_connect", "شبكة حقوق الطفل", "Child Rights Connect",
     "children", "documentation", "https://childrightsconnect.org/",
     "Creative Commons (بإسناد)", "شبكة دولية لمناصرة حقوق الطفل", "موقع + تقارير", None),
    ("plan_intl_disc", "بلان إنترناشونال", "Plan International", "children",
     "documentation", "https://plan-international.org/", "Creative Commons (بإسناد)",
     "توثيق حقوق الفتيات والأطفال في الأزمات", "موقع + تقارير", None),
    ("save_children_disc", "أنقذوا الأطفال", "Save the Children", "children",
     "documentation", "https://www.savethechildren.net/", "Creative Commons (بإسناد)",
     "حماية الأطفال في النزاعات والطوارئ", "موقع + تقارير", None),
    ("ecpat", "إكبات الدولية", "ECPAT International", "children",
     "documentation", "https://ecpat.org/", "Creative Commons (بإسناد)",
     "مكافحة الاستغلال الجنسي للأطفال", "موقع + تقارير", None),

    # --- حقوق كبار السن ---
    ("helpage_data", "بوّابة بيانات هيلمب إيج", "HelpAge International Data Portal",
     "elderly", "database", "https://data.helpage.org/", "CC BY 4.0 (بيانات مفتوحة)",
     "مؤشرات حقوق كبار السن والتمييز العمري", "تنزيل + API", None),
    ("ifa", "الرابطة الدولية للشيخوخة", "International Federation on Ageing (IFA)",
     "elderly", "documentation", "https://www.ifa-fiv.org/", "Creative Commons (بإسناد)",
     "مناصرة حقوق كبار السن عالميًّا", "موقع + تقارير", None),
    ("un_ageing", "الأمم المتحدة — الشيخوخة", "UN — Ageing", "elderly",
     "documentation", "https://social.un.org/ageing-working-group/",
     "بيانات أممية (مفتوحة)", "وثائق أممية عن حقوق كبار السن", "موقع", None),
    ("global_ageing", "مرصد الشيخوخة العالمي", "Global AgeWatch", "elderly",
     "database", "https://www.helpage.org/global-agewatch/", "CC BY 4.0 (بيانات مفتوحة)",
     "مؤشر جودة حياة كبار السن حسب الدول", "تنزيل", None),

    # --- أرشيف الأدلة الرقمية الجنائية (OSINT) ---
    ("mnemonic", "منصة منيمونيك للأرشيف", "Mnemonic", "osint_forensics",
     "documentation", "https://mnemonic.org/", "مفتوح المصدر (AGPL)",
     "أرشفة أدلة جرائم الحرب السورية واليمنية والسودانية", "موقع + كود", None),
    ("syrian_archive", "الأرشيف السوري", "Syrian Archive", "osint_forensics",
     "documentation", "https://syrianarchive.org/", "Creative Commons (بإسناد)",
     "أرشفة أدلة الفيديو لجرائم الحرب في سوريا", "بحث + تنزيل", None),
    ("yemen_archive", "أرشيف اليمن", "Yemen Archive", "osint_forensics",
     "documentation", "https://www.yemenarchive.org/", "Creative Commons (بإسناد)",
     "أرشفة انتهاكات النزاع في اليمن", "موقع", None),
    ("citizen_evidence", "مختبر أدلة المواطنين", "Citizen Evidence Lab — Amnesty",
     "osint_forensics", "documentation", "https://citizenevidence.org/",
     "Creative Commons (بإسناد)", "تحليل وأرشفة الأدلة الرقمية للانتهاكات",
     "موقع + أدوات", None),
    ("archiving_ai", "أرشفة الذكاء الاصطناعي للحقوق",
     "Archiving the Evidence — OSINT", "osint_forensics", "documentation",
     "https://www.bellingcat.com/category/resources/", "Creative Commons (بإسناد)",
     "منهجيات حفظ الأدلة الرقمية قبل حجبها", "موقع", None),

    # --- مصادر ذات تغذية (تُجمع دوريًّا) ضمن المجموعات المرجعية ---
    ("icj_ruleoflaw", "اللجنة الدولية للحقوقيين", "International Commission of Jurists",
     "human_rights", "documentation", "https://www.icj.org/", "Creative Commons (بإسناد)",
     "توثيق سيادة القانون والعدالة والمحاكمات الجائرة", "موقع + تغذية",
     "https://www.icj.org/feed/"),
    ("frontline_defenders", "المدافعون عن الخطوط الأمامية", "Front Line Defenders",
     "human_rights", "documentation", "https://www.frontlinedefenders.org/",
     "Creative Commons (بإسناد)", "توثيق الاعتداءات على المدافعين عن حقوق الإنسان",
     "موقع + تغذية", "https://www.frontlinedefenders.org/en/rss.xml"),
    ("protection_intl", "بروتكشن إنترناشونال", "Protection International",
     "human_rights", "documentation", "https://www.protectioninternational.org/",
     "Creative Commons (بإسناد)", "حماية المدافعين عن حقوق الإنسان في النزاعات",
     "موقع + تغذية", "https://www.protectioninternational.org/feed/"),
    ("article19", "المادة 19", "ARTICLE 19", "press_freedom", "documentation",
     "https://www.article19.org/", "Creative Commons (بإسناد)",
     "الدفاع عن حرية التعبير والمعلومات عالميًّا", "موقع + تغذية",
     "https://www.article19.org/feed/"),
    ("privacy_intl", "برايفسي إنترناشونال", "Privacy International", "ai_digital",
     "documentation", "https://privacyinternational.org/", "Creative Commons (بإسناد)",
     "رصد انتهاكات الخصوصية والمراقبة الجماعية", "موقع + تغذية",
     "https://privacyinternational.org/rss.xml"),
    ("icc_coalition", "التحالف من أجل المحكمة الجنائية الدولية",
     "Coalition for the ICC", "disability_transitional", "documentation",
     "https://www.coalitionfortheicc.org/", "Creative Commons (بإسناد)",
     "العدالة الدولية ومحاسبة جرائم الحرب", "موقع + تغذية",
     "https://www.coalitionfortheicc.org/rss.xml"),
    ("ids_displacement", "معهد دراسات التنمية — النزوح",
     "Institute of Development Studies (IDS)", "refugees_migrants", "documentation",
     "https://www.ids.ac.uk/", "CC BY 4.0 (بيانات مفتوحة)",
     "أبحاث النزوح والهجرة وحقوق المهاجرين", "موقع + تغذية",
     "https://www.ids.ac.uk/feed/"),
]


# ---------------------------------------------------------------------------
# بوّابة القبول ومعايير الأهلية
# ---------------------------------------------------------------------------

def license_is_open(license_text: str) -> bool:
    """يقبل الرخصة إن دلّت على مجانية أو مفتوحة المصدر أو بيانات مفتوحة."""
    text = (license_text or "").strip().lower()
    if not text:
        return False
    return any(h in text for h in _OPEN_LICENSE_HINTS)


def _host(url: str) -> str:
    """مضيف موحّد (بلا www) لمقارنة الروابط ومنع التكرار."""
    if not url:
        return ""
    try:
        netloc = urllib.parse.urlparse(url).netloc.lower()
    except ValueError:
        return ""
    return netloc[4:] if netloc.startswith("www.") else netloc


def _norm_name(name: str) -> str:
    """اسم مُطبَّع للمقارنة: تطبيع عربي + حروف صغيرة + إزالة الرموز والمسافات."""
    text = normalize_arabic(name or "").lower()
    text = re.sub(r"[^\w\u0600-\u06FF]+", "", text)
    return text


def candidate_key(name: str, url: str) -> str:
    """مفتاح فريد ثابت للمرشّح (يُستخدم في `source_catalog` ومنع التكرار)."""
    host = _host(url) or "unknown"
    slug = re.sub(r"[^a-z0-9]+", "_", (host or "").replace(".", "_")).strip("_")
    return f"discovered:{slug}"[:80]


def build_dedup_index(conn) -> dict:
    """يبني فهرس منع تكرار مرّة واحدة: أسماء مُطبَّعة ومضيفات موجودة مسبقًا.

    يقرأ `sources` و`source_catalog` دفعةً واحدة بدل مسحهما لكل مرشّح (كان
    المسح لكل مرشّح يبطئ الإقلاع كثيرًا مع فهرس من آلاف المصادر).
    """
    names: dict[str, str] = {}
    hosts: dict[str, str] = {}
    for r in conn.execute("SELECT name, url FROM sources").fetchall():
        if r["name"]:
            names.setdefault(_norm_name(r["name"]), r["name"])
        if r["url"] and _host(r["url"]):
            hosts.setdefault(_host(r["url"]), r["url"])
    for r in conn.execute(
        "SELECT name, name_en, url, feed_url FROM source_catalog"
    ).fetchall():
        for n in (r["name"], r["name_en"]):
            if n:
                names.setdefault(_norm_name(n), n)
        for u in (r["url"], r["feed_url"]):
            if u and _host(u):
                hosts.setdefault(_host(u), u)
    return {"names": names, "hosts": hosts}


def is_duplicate(conn, name: str, url: str, index: dict | None = None) -> str | None:
    """يتحقّق من وجود المصدر مسبقًا (بالاسم أو المضيف) في `sources` أو `source_catalog`.

    يعيد سبب التكرار (نصًّا) إن وُجد، وإلا None. مرّر `index` (من
    `build_dedup_index`) لتفادي إعادة بناء الفهرس لكل مرشّح.
    """
    index = index or build_dedup_index(conn)
    host = _host(url)
    norm = _norm_name(name)
    hit = index["names"].get(norm)
    if hit:
        return f"اسم مطابق: {hit}"
    if host and host in index["hosts"]:
        return f"رابط مطابق: {index['hosts'][host]}"
    return None


def _candidate_to_entry(c: tuple) -> dict:
    """يحوّل صفّ المرشّح إلى مدخل فهرس متوافق مع `source_catalog`."""
    (key, name_ar, name_en, group, kind, url, license, coverage, access, feed) = c
    grp = GROUP_BY_KEY.get(group, {})
    cats = grp.get("categories", ["human_rights"])
    return {
        "key": f"discovered:{key}",
        "name": name_ar,
        "name_en": name_en,
        "domain": cats[0],
        "categories": cats,
        "group": group,
        "kind": "feed" if feed else "dataset",
        "source_kind": kind,
        "url": url,
        "feed_url": feed,
        "region": None,
        "license": license,
        "coverage": coverage,
        "access": access,
        "severity": "medium",
        "enabled": 1 if feed else 0,
        "discovered": 1,
    }


# ---------------------------------------------------------------------------
# دورة الاكتشاف
# ---------------------------------------------------------------------------

def discover(conn, *, limit: int | None = None, dry_run: bool = False,
             log_run: bool = True) -> dict:
    """يبحث عن مصادر جديدة، يتحقّق من عدم تكرارها، ويضيف المقبول.

    يعيد تقريرًا: المُضاف (مصنَّفًا)، والمكرَّر، والمرفوض، وملخّصًا لكل تصنيف.
    """
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    candidates = CANDIDATES[: int(limit)] if limit else CANDIDATES
    added: list[dict] = []
    duplicates: list[dict] = []
    rejected: list[dict] = []
    # فهرس منع التكرار يُبنى مرّة واحدة لكل دورة (أداء مع فهرس من آلاف المصادر).
    dedup_index = build_dedup_index(conn)

    for c in candidates:
        entry = _candidate_to_entry(c)
        # 1) معايير القبول: مجاني/مفتوح المصدر أو بيانات مفتوحة.
        if not license_is_open(entry["license"]):
            rejected.append({"key": entry["key"], "name": entry["name"],
                             "reason": "رخصة غير مفتوحة/غير مجانية"})
            continue
        # 2) منع التكرار بالاسم/الرابط مع كل المصادر الحالية.
        dup = is_duplicate(conn, entry["name"], entry["url"], index=dedup_index)
        if dup:
            duplicates.append({"key": entry["key"], "name": entry["name"], "reason": dup})
            continue
        # 3) منع تكرار المفتاح ذاته (لو سبق إدراجه من دورة سابقة).
        if db.catalog_key_exists(conn, entry["key"]):
            duplicates.append({"key": entry["key"], "name": entry["name"],
                               "reason": "مفتاح موجود مسبقًا"})
            continue

        if not dry_run:
            db.add_discovered_source(conn, entry)
            # حدّث الفهرس حتى لا يُضاف نفس المصدر مرّتين داخل الدورة نفسها.
            dedup_index["names"].setdefault(_norm_name(entry["name"]), entry["name"])
            if _host(entry["url"]):
                dedup_index["hosts"].setdefault(_host(entry["url"]), entry["url"])
        added.append({
            "key": entry["key"], "name": entry["name"], "name_en": entry["name_en"],
            "group": entry["group"], "group_name": GROUP_BY_KEY.get(entry["group"], {}).get("name"),
            "source_kind": entry["source_kind"], "domain": entry["domain"],
            "categories": entry["categories"], "url": entry["url"],
            "license": entry["license"], "coverage": entry["coverage"],
            "access": entry["access"], "feed": bool(entry["feed_url"]),
        })

    # ملخّص التصنيف للمصادر المُضافة (للأعلى في الموقع والتقرير).
    by_group: dict[str, int] = {}
    by_kind: dict[str, int] = {}
    by_domain: dict[str, int] = {}
    for a in added:
        by_group[a["group_name"] or a["group"]] = by_group.get(a["group_name"] or a["group"], 0) + 1
        by_kind[a["source_kind"]] = by_kind.get(a["source_kind"], 0) + 1
        by_domain[a["domain"]] = by_domain.get(a["domain"], 0) + 1

    report = {
        "ran_at": started,
        "candidates": len(candidates),
        "added_count": len(added),
        "duplicate_count": len(duplicates),
        "rejected_count": len(rejected),
        "added": added,
        "duplicates": duplicates[:50],
        "rejected": rejected,
        "by_group": by_group,
        "by_kind": by_kind,
        "by_domain": by_domain,
        "dry_run": bool(dry_run),
    }
    if not dry_run and log_run:
        db.log_discovery_run(conn, report)
    log.info("اكتشاف المصادر: +%s جديد، %s مكرّر، %s مرفوض",
             len(added), len(duplicates), len(rejected))
    return report


def ensure_groups(conn) -> None:
    """يزرع/يزامن المصادر الأساسية المرجعية للتصنيفات الـ15 فورًا عند الإقلاع.

    يضمن وجود المصادر المذكورة في الطلب (DDoSecrets, ICIJ, OpenSanctions…)
    في القائمة من أول تشغيل، ثم تتولّى دورة الاكتشاف إضافة الباقي دوريًّا.
    """
    try:
        discover(conn, dry_run=False)
    except Exception as exc:  # noqa: BLE001 — لا نُفشل الإقلاع بسبب الاكتشاف
        log.warning("تعذّر الاكتشاف الأولي: %s", exc)


# فترة الاكتشاف الافتراضية بالثواني (5 دقائق) — قابلة للضبط.
DISCOVERY_INTERVAL = int(os.getenv("MIRSAD_DISCOVERY_INTERVAL", "300"))
# أقصى عمر لسجل تقرير بلا تغيير قبل تسجيل دورة جديدة (تفادي إغراق السجل).
_REPORT_KEEPALIVE = 86400
_META_KEY = "last_discovery"


def _get_meta(conn, key: str) -> str | None:
    row = conn.execute("SELECT value FROM schema_meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def _set_meta(conn, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO schema_meta(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    conn.commit()


def is_due(conn, interval: int | None = None, now: str | None = None) -> bool:
    """هل حان وقت دورة اكتشاف جديدة وفق الفترة المضبوطة؟"""
    interval = DISCOVERY_INTERVAL if interval is None else interval
    last = _get_meta(conn, _META_KEY)
    if not last:
        return True
    now_dt = datetime.fromisoformat(now) if now else datetime.now(timezone.utc)
    try:
        last_dt = datetime.fromisoformat(last)
    except ValueError:
        return True
    if last_dt.tzinfo is None:
        last_dt = last_dt.replace(tzinfo=timezone.utc)
    return (now_dt - last_dt).total_seconds() >= interval


def maybe_discover(conn, *, interval: int | None = None, dry_run: bool = False) -> dict | None:
    """يشغّل الاكتشاف إن حان وقته فقط (تُستدعى من دورة المجدول).

    لا يسجّل تقريرًا في السجل إن لم يُضِف شيئًا وكان آخر تقرير حديثًا، تفاديًا
    لإغراق `source_discovery_log` بدورة كل 5 دقائق بلا تغيير.
    """
    if not is_due(conn, interval=interval):
        return None
    report = discover(conn, dry_run=dry_run, log_run=False)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    _set_meta(conn, _META_KEY, now)
    # سجّل تقريرًا عند وجود إضافات، أو إن مرّ يوم كامل بلا تقرير مسجَّل.
    if not dry_run:
        last_report = db.latest_discovery_report(conn)
        last_ran = (last_report or {}).get("ran_at")
        stale = True
        if last_ran:
            try:
                lr = datetime.fromisoformat(last_ran)
                if lr.tzinfo is None:
                    lr = lr.replace(tzinfo=timezone.utc)
                stale = (datetime.now(timezone.utc) - lr).total_seconds() >= _REPORT_KEEPALIVE
            except ValueError:
                stale = True
        if report["added_count"] > 0 or stale:
            db.log_discovery_run(conn, report)
    return report
