"""نماذج Pydantic لتحقّق المدخلات في واجهة البرمجة."""

from datetime import date
from typing import Optional

from pydantic import BaseModel, Field, HttpUrl, field_validator

from .taxonomy import CATEGORY_BY_KEY, SEVERITY_BY_KEY


class ReportIn(BaseModel):
    title: str = Field(min_length=6, max_length=240)
    category: str
    severity: str
    country: str = Field(min_length=2, max_length=80)
    region: Optional[str] = Field(default=None, max_length=120)
    occurred_on: Optional[str] = None
    summary: str = Field(min_length=20, max_length=2000)
    details: Optional[str] = Field(default=None, max_length=8000)
    source_name: Optional[str] = Field(default=None, max_length=200)
    source_url: Optional[str] = Field(default=None, max_length=500)

    @field_validator("category")
    @classmethod
    def _valid_category(cls, v: str) -> str:
        if v not in CATEGORY_BY_KEY:
            raise ValueError("فئة غير صحيحة")
        return v

    @field_validator("severity")
    @classmethod
    def _valid_severity(cls, v: str) -> str:
        if v not in SEVERITY_BY_KEY:
            raise ValueError("مستوى خطورة غير صحيح")
        return v

    @field_validator("occurred_on")
    @classmethod
    def _valid_date(cls, v: Optional[str]) -> Optional[str]:
        if not v:
            return None
        try:
            date.fromisoformat(v)
        except ValueError as exc:
            raise ValueError("صيغة التاريخ يجب أن تكون YYYY-MM-DD") from exc
        return v


class EntityOut(BaseModel):
    id: int
    name: str
    kind: str
    wikidata_id: Optional[str] = None
