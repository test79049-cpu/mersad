"""فهرس المصادر الواسع (≈1000 مصدر) لتغذية الجمع الآلي.

الفهرس ثلاثة أنواع من المداخل:

- `feed`: تغذية RSS/Atom مباشرة من منظّمة أو وكالة أو صحيفة موثوقة (مُختبرة).
- `search`: تغذية بحث موضوعي على Google News (استعلام × إصدار إقليمي)؛ تعمل
  كـ«مصدر مركّب» يجمع مئات المواقع الإخبارية تحت استعلام واحد دقيق. هذا هو ما
  يمنح المنصّة اتّساعاً عالمياً بلا مفاتيح ولا حصص.
- `dataset`: قاعدة بيانات/واجهة مفتوحة (مرجع وإسناد؛ لا تُسحب دوريّاً).

الفهرس **مولَّد** من هذا الملف إلى `app/data/source_catalog.json` عبر
`python -m app.cli catalog`. لا نكتب الـ1000 مدخل يدوياً؛ نبنيها من قوائم
مضبوطة (استعلامات موضوعية + إصدارات إقليمية) لتبقى قابلة للصيانة والتحقّق.
"""

from __future__ import annotations

import json
import urllib.parse
from pathlib import Path

from .config import DATA_DIR

CATALOG_PATH = DATA_DIR / "source_catalog.json"

# ---------------------------------------------------------------------------
# الاستعلامات الموضوعية لكل مجال (دقيقة قدر الإمكان لتفادي الضجيج)
# ---------------------------------------------------------------------------
# (مفتاح، وسم عربي، الاستعلام)
DOMAIN_QUERIES: dict[str, list[tuple[str, str, str]]] = {
    "human_rights": [
        ("hr_detention", "اعتقال تعسفي", '"arbitrary detention" OR "political prisoners"'),
        ("hr_torture", "تعذيب", 'torture OR "ill-treatment" prisoners'),
        ("hr_protest", "قمع الاحتجاج", '"crackdown on protests" OR "dispersed protesters"'),
        ("hr_expression", "حرية التعبير", '"freedom of expression" OR "press freedom" violation'),
        ("hr_killings", "قتل خارج القانون", '"extrajudicial killing" OR "unlawful killing"'),
        ("hr_disappearance", "اختفاء قسري", '"enforced disappearance" OR "forced disappearance"'),
        ("hr_trial", "محاكمة جائرة", '"unfair trial" OR "mass trial" activists'),
        ("hr_ar_1", "اعتقال واحتجاز", 'اعتقال تعسفي OR معتقلين سياسيين'),
        ("hr_ar_2", "تعذيب ومحاكمات", 'تعذيب في السجون OR محاكمة جائرة'),
        ("hr_ar_3", "قمع الاحتجاجات", 'قمع احتجاجات OR فض اعتصام بالقوة'),
    ],
    "animal_rights": [
        ("ar_cruelty", "القسوة على الحيوان", '"animal cruelty" OR "animal abuse"'),
        ("ar_wildlife", "تهريب الحياة الفطرية", '"wildlife trafficking" OR "illegal wildlife trade"'),
        ("ar_poaching", "الصيد الجائر", 'poaching OR "endangered species" killed'),
        ("ar_factory", "مزارع المصانع", '"factory farming" OR "animal welfare" violation'),
        ("ar_slaughter", "المسالخ", '"slaughterhouse" abuse OR "live animal exports"'),
        ("ar_pets", "إيذاء الحيوانات الأليفة", '"animal hoarding" OR "pet abuse"'),
        ("ar_circus", "استغلال في الترفيه", '"animals in circuses" OR "animal entertainment" abuse'),
        ("ar_ar_1", "الرفق بالحيوان", 'الرفق بالحيوان OR قسوة على الحيوان'),
        ("ar_ar_2", "الاتجار بالحيوانات", 'الاتجار بالحيوانات البرية OR صيد جائر'),
        ("ar_ar_3", "مسالخ ومزارع", 'مسالخ OR مزارع الحيوانات انتهاكات'),
    ],
    "environment": [
        ("env_spill", "تسرّب نفطي", '"oil spill" OR "chemical spill"'),
        ("env_pollution", "تلوّث صناعي", '"industrial pollution" OR "toxic emissions"'),
        ("env_deforest", "إزالة الغابات", '"deforestation" OR "illegal logging"'),
        ("env_climate", "أزمة المناخ", '"climate change" impacts OR "climate crisis"'),
        ("env_waste", "نفايات سامة", '"toxic waste" OR "hazardous waste" dumping'),
        ("env_water", "تلوّث المياه", '"water pollution" OR "contaminated water"'),
        ("env_mining", "تعدين ضار", '"illegal mining" OR "mining pollution"'),
        ("env_ar_1", "تلوّث بيئي", 'تلوث بيئي OR تسرب نفطي'),
        ("env_ar_2", "إزالة الغابات", 'إزالة الغابات OR قطع الأشجار الجائر'),
        ("env_ar_3", "أزمة المناخ", 'أزمة المناخ OR انبعاثات كربونية'),
    ],
    "labor_rights": [
        ("lab_forced", "عمل قسري", '"forced labor" OR "modern slavery"'),
        ("lab_child", "عمالة الأطفال", '"child labor" OR "child labour"'),
        ("lab_wages", "أجور غير مدفوعة", '"unpaid wages" OR "wage theft" workers'),
        ("lab_union", "قمع النقابات", '"union busting" OR "anti-union" repression'),
        ("lab_safety", "سلامة العمال", '"workplace accident" OR "occupational safety" violation'),
        ("lab_migrant", "عمال مهاجرون", '"migrant workers" abuse OR exploitation'),
        ("lab_strike", "إضرابات عمالية", '"workers strike" OR "labour protest"'),
        ("lab_ar_1", "العمل القسري", 'العمل القسري OR عمالة الأطفال'),
        ("lab_ar_2", "حقوق العمال", 'انتهاكات حقوق العمال OR أجور غير مدفوعة'),
        ("lab_ar_3", "نقابات وإضرابات", 'قمع النقابات OR إضراب عمالي'),
    ],
    "minorities": [
        ("min_ethnic", "تمييز عرقي", '"ethnic discrimination" OR "racial discrimination"'),
        ("min_refugee", "لاجئون ونازحون", '"refugees" OR "internally displaced" abuse'),
        ("min_religious", "أقليات دينية", '"religious minority" persecution'),
        ("min_indigenous", "شعوب أصلية", '"indigenous rights" OR "indigenous land" conflict'),
        ("min_roma", "أقليات مهمّشة", '"Roma" discrimination OR "stateless"'),
        ("min_displacement", "تهجير قسري", '"forced displacement" OR "ethnic cleansing"'),
        ("min_lgbt", "أقليات جنسية", '"LGBT" persecution OR "sexual minorities" rights'),
        ("min_ar_1", "الأقليات", 'اضطهاد الأقليات OR تمييز عرقي'),
        ("min_ar_2", "تهجير ولجوء", 'تهجير قسري OR أوضاع اللاجئين'),
        ("min_ar_3", "شعوب أصلية", 'حقوق الشعوب الأصلية OR نزاع أراض'),
    ],
    "beliefs": [
        ("bel_persecution", "اضطهاد ديني", '"religious persecution" OR "religious freedom" violation'),
        ("bel_blasphemy", "قوانين التجديف", '"blasphemy law" OR "apostasy" prosecution'),
        ("bel_atheist", "حرية الإلحاد", '"atheist" persecution OR "freedom of religion"'),
        ("bel_convert", "حرية تغيير الدين", '"conversion" persecution OR "forced conversion"'),
        ("bel_worship", "تقييد العبادة", '"restriction on worship" OR "banned religious group"'),
        ("bel_ar_1", "اضطهاد ديني", 'اضطهاد ديني OR تقييد حرية المعتقد'),
        ("bel_ar_2", "تجديف وإلحاد", 'قانون التجديف OR اضطهاد الملحدين'),
        ("bel_ar_3", "حرية العبادة", 'تقييد الشعائر OR حرية العبادة'),
    ],
    "ai_ethics": [
        ("ai_surveillance", "مراقبة جماعية", '"mass surveillance" OR "spyware" activists'),
        ("ai_bias", "تحيّز خوارزمي", '"algorithmic bias" OR "AI discrimination"'),
        ("ai_facial", "التعرّف على الوجوه", '"facial recognition" ban OR misuse'),
        ("ai_privacy", "انتهاك الخصوصية", '"data privacy" violation OR "personal data" breach'),
        ("ai_deepfake", "تزييف عميق", '"deepfake" disinformation OR "synthetic media" abuse'),
        ("ai_autonomous", "أنظمة ذاتية", '"autonomous weapons" OR "AI decision-making" rights'),
        ("ai_ar_1", "الذكاء الاصطناعي والأخلاق", 'الذكاء الاصطناعي انتهاكات OR تحيز خوارزمي'),
        ("ai_ar_2", "المراقبة والخصوصية", 'مراقبة جماعية OR انتهاك الخصوصية'),
    ],
    "women_children": [
        ("wc_marriage", "زواج قسري", '"child marriage" OR "forced marriage"'),
        ("wc_violence", "عنف أسري", '"domestic violence" OR "gender-based violence"'),
        ("wc_childlabour", "عمالة الأطفال", '"child labour" OR "child trafficking"'),
        ("wc_girls", "تعليم الفتيات", '"girls education" ban OR denied schooling'),
        ("wc_ar_1", "المرأة والطفل", 'حقوق المرأة OR حقوق الطفل انتهاكات'),
        ("wc_ar_2", "زواج وعنف", 'زواج قسري OR عنف أسري'),
    ],
    "refugees_migrants": [
        ("rm_return", "إعادة قسرية", '"refoulement" OR "forced return" refugees'),
        ("rm_detention", "احتجاز المهاجرين", '"migrant detention" OR "immigration detention"'),
        ("rm_sea", "وفيات في البحر", '"migrant boat" capsized OR "deaths at sea"'),
        ("rm_deport", "ترحيل جماعي", '"mass deportation" OR "collective expulsion"'),
        ("rm_ar_1", "لاجئون ومهاجرون", 'حقوق اللاجئين OR أوضاع المهاجرين'),
        ("rm_ar_2", "ترحيل وإعادة", 'إعادة قسرية OR ترحيل مهاجرين'),
    ],
    "expression": [
        ("ex_press", "حرية الصحافة", '"press freedom" OR "journalist" jailed'),
        ("ex_censor", "حجب ورقيب", '"censorship" OR "website blocking"'),
        ("ex_assembly", "حرية التجمّع", '"peaceful assembly" dispersed OR protest ban'),
        ("ex_ar_1", "حرية التعبير", 'حرية التعبير OR قمع الصحافة'),
        ("ex_ar_2", "حجب وتضييق", 'حجب مواقع OR تقييد الإعلام'),
    ],
    "transitional_justice": [
        ("tj_impunity", "إفلات من العقاب", '"impunity" OR "no accountability" crimes'),
        ("tj_truth", "لجان الحقيقة", '"truth commission" OR "transitional justice"'),
        ("tj_reparations", "جبر الضرر", '"reparations" OR "redress" victims'),
        ("tj_ar_1", "العدالة الانتقالية", 'العدالة الانتقالية OR الإفلات من العقاب'),
        ("tj_ar_2", "تعويضات ولجان", 'لجنة الحقيقة OR جبر الضرر'),
    ],
    "economic_social": [
        ("es_eviction", "طرد قسري", '"forced eviction" OR "unlawful eviction"'),
        ("es_housing", "الحق في السكن", '"right to housing" OR "homelessness" crisis'),
        ("es_socialsec", "الضمان الاجتماعي", '"social security" denied OR "welfare" cuts'),
        ("es_ar_1", "حقوق اقتصادية واجتماعية", 'الحق في السكن OR الضمان الاجتماعي'),
        ("es_ar_2", "طرد وفقر", 'طرد قسري OR حرمان من الخدمات'),
    ],
    "health": [
        ("he_access", "الحق في الصحة", '"right to health" OR "denied treatment"'),
        ("he_medicine", "نقص الأدوية", '"medicine shortage" OR "no access to healthcare"'),
        ("he_facility", "استهداف المرافق الصحية", '"attacks on hospitals" OR "medical facility" targeted'),
        ("he_ar_1", "الحق في الصحة", 'الحق في العلاج OR حرمان من الرعاية الصحية'),
        ("he_ar_2", "أزمات صحية", 'نقص الأدوية OR استهداف مستشفيات'),
    ],
    "education_culture": [
        ("ec_education", "الحق في التعليم", '"right to education" OR "denied schooling"'),
        ("ec_heritage", "التراث الثقافي", '"cultural heritage" destroyed OR "heritage site"'),
        ("ec_language", "الهوية واللغة", '"minority language" education OR "cultural identity"'),
        ("ec_ar_1", "التعليم والثقافة", 'الحق في التعليم OR الهوية الثقافية'),
        ("ec_ar_2", "تراث ولغة", 'هدم مواقع تراث OR تعليم بلغة الأقلية'),
    ],
    "poverty_food": [
        ("pf_food", "الأمن الغذائي", '"food insecurity" OR "famine"'),
        ("pf_water", "الحق في الماء", '"right to water" OR "water shortage"'),
        ("pf_housing", "الفقر والسكن", '"extreme poverty" OR "housing crisis"'),
        ("pf_ar_1", "الفقر والأمن الغذائي", 'الأمن الغذائي OR الحق في الماء'),
        ("pf_ar_2", "مجاعات وأزمات", 'مجاعة OR انعدام الأمن الغذائي'),
    ],
    "criminal_justice": [
        ("cj_trial", "المحاكمة العادلة", '"fair trial" violation OR "unfair trial"'),
        ("cj_death", "عقوبة الإعدام", '"death penalty" OR "capital punishment"'),
        ("cj_law", "سيادة القانون", '"rule of law" breakdown OR "judicial independence"'),
        ("cj_ar_1", "العدالة الجنائية", 'المحاكمة العادلة OR عقوبة الإعدام'),
        ("cj_ar_2", "قضاء وسيادة القانون", 'استقلال القضاء OR محاكمة جائرة'),
    ],
    "prisoners_rights": [
        ("pr_conditions", "ظروف الاحتجاز", '"prison conditions" OR "overcrowded prison"'),
        ("pr_healthcare", "الرعاية في السجون", '"prison healthcare" denied OR "medical neglect" inmates'),
        ("pr_rehab", "إعادة التأهيل", '"prisoner rehabilitation" OR "solitary confinement"'),
        ("pr_ar_1", "حقوق المحتجزين", 'ظروف الاحتجاز OR رعاية المحتجزين'),
        ("pr_ar_2", "سجون وإعادة تأهيل", 'اكتظاظ السجون OR إعادة تأهيل المحتجزين'),
    ],
    "disability_rights": [
        ("dr_access", "إمكانية الوصول", '"accessibility" denied OR "disability discrimination"'),
        ("dr_inclusion", "الإدماج والتمكين", '"disability inclusion" OR "equal opportunity" disability'),
        ("dr_employment", "العمل ذوو الإعاقة", '"persons with disabilities" employment discrimination'),
        ("dr_ar_1", "حقوق ذوي الإعاقة", 'حقوق ذوي الإعاقة OR إمكانية الوصول'),
        ("dr_ar_2", "إدماج وتمييز", 'تمييز ضد ذوي الإعاقة OR إدماج ذوي الإعاقة'),
    ],
    "peace_security": [
        ("ps_civilians", "حماية المدنيين", '"protection of civilians" OR "attacks on civilians"'),
        ("ps_disarm", "نزع السلاح", '"disarmament" OR "weapons of mass destruction"'),
        ("ps_warcrimes", "جرائم حرب", '"war crimes" OR "international humanitarian law" violation'),
        ("ps_ar_1", "السلام والأمن", 'حماية المدنيين OR نزع السلاح'),
        ("ps_ar_2", "حروب وجرائم", 'جرائم حرب OR استهداف المدنيين'),
    ],
    "elderly_rights": [
        ("el_pension", "المعاش والتقاعد", '"pension" denied OR "retirement" rights'),
        ("el_care", "رعاية كبار السن", '"elderly care" neglect OR "older persons" abuse'),
        ("el_ageism", "التمييز العمري", '"age discrimination" OR "ageism"'),
        ("el_ar_1", "حقوق كبار السن", 'حقوق كبار السن OR رعاية المسنين'),
        ("el_ar_2", "معاش وتمييز عمري", 'حرمان من المعاش OR تمييز عمري'),
    ],
    "inclusivity": [
        ("in_diversity", "التنوّع والإدماج", '"diversity" exclusion OR "social inclusion"'),
        ("in_hatespeech", "خطاب الكراهية", '"hate speech" OR "discrimination" targeted group'),
        ("in_intersectional", "التمييز المتعدّد", '"intersectional discrimination" OR "marginalised group"'),
        ("in_ar_1", "الحقوق الفئوية والتنوّع", 'التنوّع والإدماج OR التمييز المتعدد'),
        ("in_ar_2", "كراهية واستبعاد", 'خطاب الكراهية OR استبعاد الفئات المهمشة'),
    ],
}

# ---------------------------------------------------------------------------
# الإصدارات الإقليمية لبحث Google News
# ---------------------------------------------------------------------------
# (gl, hl, ceid، الوسم العربي)
EN_EDITIONS = [
    ("US", "en-US", "US:en", "الولايات المتحدة"),
    ("GB", "en-GB", "GB:en", "المملكة المتحدة"),
    ("CA", "en-CA", "CA:en", "كندا"),
    ("AU", "en-AU", "AU:en", "أستراليا"),
    ("IN", "en-IN", "IN:en", "الهند"),
    ("KE", "en-KE", "KE:en", "كينيا"),
    ("NG", "en-NG", "NG:en", "نيجيريا"),
    ("ZA", "en-ZA", "ZA:en", "جنوب أفريقيا"),
    ("IE", "en-IE", "IE:en", "أيرلندا"),
    ("PH", "en-PH", "PH:en", "الفلبين"),
    ("SG", "en-SG", "SG:en", "سنغافورة"),
    ("PK", "en-PK", "PK:en", "باكستان"),
    ("BD", "en-BD", "BD:en", "بنغلاديش"),
    ("GH", "en-GH", "GH:en", "غانا"),
    ("UG", "en-UG", "UG:en", "أوغندا"),
    ("TZ", "en-TZ", "TZ:en", "تنزانيا"),
    ("NZ", "en-NZ", "NZ:en", "نيوزيلندا"),
    ("ZW", "en-ZW", "ZW:en", "زيمبابوي"),
]
AR_EDITIONS = [
    ("EG", "ar", "EG:ar", "مصر"),
    ("SA", "ar", "SA:ar", "السعودية"),
    ("AE", "ar", "AE:ar", "الإمارات"),
    ("MA", "ar", "MA:ar", "المغرب"),
    ("JO", "ar", "JO:ar", "الأردن"),
    ("DZ", "ar", "DZ:ar", "الجزائر"),
    ("IQ", "ar", "IQ:ar", "العراق"),
    ("TN", "ar", "TN:ar", "تونس"),
    ("LB", "ar", "LB:ar", "لبنان"),
    ("KW", "ar", "KW:ar", "الكويت"),
    ("QA", "ar", "QA:ar", "قطر"),
    ("LY", "ar", "LY:ar", "ليبيا"),
]

_GNEWS = "https://news.google.com/rss/search"


def _gnews_url(query: str, gl: str, hl: str, ceid: str) -> str:
    qs = urllib.parse.urlencode({"q": query, "hl": hl, "gl": gl, "ceid": ceid})
    return f"{_GNEWS}?{qs}"


# ---------------------------------------------------------------------------
# التغذيات المباشرة المُختبرة (feed)
# ---------------------------------------------------------------------------
# (مفتاح، الاسم العربي، الاسم الإنجليزي، المجال، الخطورة، الرابط)
CURATED_FEEDS = [
    ("hrw", "هيومن رايتس ووتش", "Human Rights Watch",
     "human_rights", "high", "https://www.hrw.org/rss/news"),
    ("amnesty", "منظمة العفو الدولية", "Amnesty International",
     "human_rights", "high", "https://www.amnesty.org/en/latest/feed/"),
    ("ohchr", "المفوضية السامية لحقوق الإنسان", "OHCHR",
     "human_rights", "medium", "https://www.ohchr.org/en/rss.xml"),
    ("fidh", "الاتحاد الدولي لحقوق الإنسان", "FIDH",
     "human_rights", "high", "https://www.fidh.org/spip.php?page=backend"),
    ("un_news_hr", "أخبار الأمم المتحدة — حقوق الإنسان", "UN News — Human Rights",
     "human_rights", "medium",
     "https://news.un.org/feed/subscribe/en/news/topic/human-rights/feed/rss.xml"),
    ("un_news_env", "أخبار الأمم المتحدة — المناخ", "UN News — Climate",
     "environment", "medium",
     "https://news.un.org/feed/subscribe/en/news/topic/climate-change/feed/rss.xml"),
    ("un_news_econ", "أخبار الأمم المتحدة — التنمية", "UN News — Economic Development",
     "labor_rights", "medium",
     "https://news.un.org/feed/subscribe/en/news/topic/economic-development/feed/rss.xml"),
    ("un_news_women", "أخبار الأمم المتحدة — المرأة", "UN News — Women",
     "minorities", "medium",
     "https://news.un.org/feed/subscribe/en/news/topic/women/feed/rss.xml"),
    ("greenpeace", "غرين بيس", "Greenpeace International",
     "environment", "medium", "https://www.greenpeace.org/international/feed/"),
    ("unep", "برنامج الأمم المتحدة للبيئة", "UNEP",
     "environment", "medium", "https://www.unep.org/rss.xml"),
    ("insideclimate", "إنسايد كلايمت نيوز", "Inside Climate News",
     "environment", "medium", "https://insideclimatenews.org/feed/"),
    ("solidaritycenter", "مركز التضامن", "Solidarity Center",
     "labor_rights", "medium", "https://www.solidaritycenter.org/feed/"),
    ("irin", "ذا نيو هيومانيتريان", "The New Humanitarian",
     "minorities", "high", "https://www.thenewhumanitarian.org/rss.xml"),
    ("migrationpolicy", "معهد سياسات الهجرة", "Migration Policy Institute",
     "minorities", "medium", "https://www.migrationpolicy.org/rss.xml"),
    ("uscirf", "اللجنة الأمريكية للحرية الدينية الدولية", "USCIRF",
     "beliefs", "high", "https://www.uscirf.gov/rss.xml"),
    ("pew_religion", "مركز بيو — الدين", "Pew Research — Religion",
     "beliefs", "medium", "https://www.pewresearch.org/topic/religion/feed/"),
    ("religionnews", "خدمة أخبار الدين", "Religion News Service",
     "beliefs", "medium", "https://religionnews.com/feed/"),
    ("aiindex_rss", "مؤشر الذكاء الاصطناعي", "Stanford HAI AI Index",
     "ai_ethics", "medium", "https://aiindex.stanford.edu/feed/"),
    ("ainow", "معهد AI Now", "AI Now Institute",
     "ai_ethics", "medium", "https://ainowinstitute.org/feed"),
    ("accessnow", "أكسس ناو", "Access Now",
     "ai_ethics", "medium", "https://www.accessnow.org/feed/"),
    ("eff", "مؤسسة الحدود الإلكترونية", "EFF",
     "ai_ethics", "medium", "https://www.eff.org/rss/updates.xml"),
    ("peta", "بيتا", "PETA UK",
     "animal_rights", "medium", "https://www.peta.org.uk/feed/"),
    ("sea_shepherd", "سي شبرد", "Sea Shepherd",
     "animal_rights", "high", "https://seashepherd.org/feed/"),
    ("animal_equality", "أنيمال إكواليتي", "Animal Equality",
     "animal_rights", "medium", "https://www.animalequality.org/feed/"),
    ("vegnews", "فيغ نيوز", "VegNews",
     "animal_rights", "medium", "https://vegnews.com/rss"),
]


def build_catalog() -> list[dict]:
    """يبني قائمة المصادر الكاملة (≈1000 مدخل) قابلة للتحقّق وإعادة التوليد."""
    entries: list[dict] = []
    seen: set[str] = set()

    def _add(e: dict) -> None:
        if e["key"] in seen:
            return
        seen.add(e["key"])
        entries.append(e)

    # 1) تغذيات مباشرة مُختبرة
    for key, name, name_en, dom, sev, url in CURATED_FEEDS:
        _add({
            "key": f"feed:{key}", "name": name, "name_en": name_en,
            "domain": dom, "severity": sev, "kind": "feed",
            "url": url, "feed_url": url, "region": None, "license": None,
            "enabled": 1,
        })

    # 2) تغذيات بحث موضوعية (استعلام × إصدار إقليمي)
    for dom, queries in DOMAIN_QUERIES.items():
        for qkey, qlabel, query in queries:
            is_ar = qkey.endswith(("_ar_1", "_ar_2", "_ar_3"))
            editions = AR_EDITIONS if is_ar else EN_EDITIONS
            for gl, hl, ceid, region_ar in editions:
                key = f"search:{qkey}:{gl}"
                _add({
                    "key": key,
                    "name": f"بحث إخباري — {qlabel} ({region_ar})",
                    "name_en": f"News search — {qlabel} ({gl})",
                    "domain": dom, "severity": "medium", "kind": "search",
                    "url": _gnews_url(query, gl, hl, ceid),
                    "feed_url": _gnews_url(query, gl, hl, ceid),
                    "region": region_ar, "license": "محتوى إخباري (استخدام مرجعي)",
                    "query": query, "edition": ceid,
                    "enabled": 1,
                })

    # 3) قواعد بيانات وواجهات مفتوحة (مرجع وإسناد؛ لا تُسحب دوريّاً)
    from .sources_registry import OPEN_DATASETS

    for d in OPEN_DATASETS:
        _add({
            "key": f"dataset:{d['key']}", "name": d["name"],
            "name_en": d.get("name_en", d["name"]), "domain": d.get("category_hint") or "human_rights",
            "severity": "medium", "kind": "dataset", "url": d.get("url"),
            "feed_url": None, "region": None, "license": d.get("license"),
            "enabled": 0,
        })

    return entries


def write_catalog() -> dict:
    """يولّد الفهرس ويكتبه إلى JSON. يعيد ملخّصاً بالعدد لكل نوع."""
    entries = build_catalog()
    CATALOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CATALOG_PATH.write_text(
        json.dumps(entries, ensure_ascii=False, indent=1), encoding="utf-8"
    )
    by_kind: dict[str, int] = {}
    by_domain: dict[str, int] = {}
    for e in entries:
        by_kind[e["kind"]] = by_kind.get(e["kind"], 0) + 1
        by_domain[e["domain"]] = by_domain.get(e["domain"], 0) + 1
    return {"total": len(entries), "by_kind": by_kind, "by_domain": by_domain,
            "path": str(CATALOG_PATH)}


def load_catalog() -> list[dict]:
    """يقرأ الفهرس من JSON، ويولّده إن لم يكن موجوداً."""
    if not CATALOG_PATH.exists():
        write_catalog()
    try:
        return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
