"""منظومة الرصد والتحقق والتحديث الآلي المستمر (الأقسام 2.2، 7، 11، 13).

تدير ثلاث مهام مجدولة متكاملة:

- **المجدول الرئيسي (كل دقيقة)**: يحدّد المصادر المستحقة للفحص ويعطي الأولوية
  للعاجل وسريع التغيّر، يجلب الجديد، ويضع العناصر في طابور المعالجة. دورة الدقيقة
  تعني تشغيل المجدول وتوزيع المهام، **لا** إعادة تحميل كل المصادر بلا تمييز.
- **خط المعالجة المستمر**: يفرّغ طابور المعالجة (تطبيع/استخراج/تصنيف/كشف تكرار)
  دون انتظار انتهاء دورة الجمع.
- **مجدول التحقق (كل خمس دقائق)**: يعالج السجلات المستحقة للتحقق على دفعات بحسب
  الأولوية، ويحدّث حالات التوثيق وفق الأدلة الجديدة.

إضافة إلى مهام المصالحة الدورية وآلية الاسترداد (استئناف المهام بعد الانقطاع،
إعادة المحاولة، ومنع تنفيذ التغيير نفسه مرّتين)، ومراقبة تراكم الطوابير والتنبيهات.
"""

from __future__ import annotations

import logging
import os
import sqlite3
from datetime import datetime, timedelta, timezone

from . import backfill, db, dedup, pipeline, verification

log = logging.getLogger("mirsad.monitoring")

# فترات التشغيل (ثوانٍ).
COLLECT_INTERVAL = int(os.getenv("MIRSAD_MONITOR_INTERVAL", "60"))
VERIFY_INTERVAL = int(os.getenv("MIRSAD_VERIFY_INTERVAL", "300"))
RECONCILE_INTERVAL = int(os.getenv("MIRSAD_RECONCILE_INTERVAL", "1800"))
# حدود الدفعات.
COLLECT_SOURCES = int(os.getenv("MIRSAD_COLLECT_SOURCES", "8"))
PROCESS_BATCH = int(os.getenv("MIRSAD_PROCESS_BATCH", "25"))
VERIFY_BATCH = int(os.getenv("MIRSAD_VERIFY_BATCH", "30"))
# عتبة تراكم الطابور (تنبيه).
BACKLOG_THRESHOLD = int(os.getenv("MIRSAD_BACKLOG_THRESHOLD", "500"))

_META_KEYS = {
    "collect": "monitor_last_collect",
    "process": "monitor_last_process",
    "verify": "monitor_last_verify",
    "reconcile": "monitor_last_reconcile",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _get_meta(conn: sqlite3.Connection, key: str) -> str | None:
    row = conn.execute("SELECT value FROM schema_meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else None


def _set_meta(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO schema_meta(key, value) VALUES(?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (key, value))
    conn.commit()


def _is_due(conn: sqlite3.Connection, kind: str, interval: int) -> bool:
    last = _get_meta(conn, _META_KEYS[kind])
    if not last:
        return True
    try:
        last_dt = datetime.fromisoformat(last)
        if last_dt.tzinfo is None:
            last_dt = last_dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return True
    return (datetime.now(timezone.utc) - last_dt).total_seconds() >= interval


# --- الأولوية (القسم 11) ---

_PRIORITY = {"critical": 1, "high": 2, "medium": 5, "low": 8}


def source_priority(source: dict) -> int:
    """أولوية فحص المصدر: الحرجة وسريعة التغيّر أولًا."""
    pri = _PRIORITY.get(source.get("severity") or "medium", 5)
    if (source.get("source_kind") or "") in ("news", "feed", "rss", "api"):
        pri -= 1  # سريعة التغيّر
    if (source.get("coverage") or "") in ("breaking", "live"):
        pri -= 1
    return max(1, pri)


# --- المجدول الرئيسي (كل دقيقة) ---

def collect_cycle(conn: sqlite3.Connection, *, sources: int = COLLECT_SOURCES,
                  task_id: str | None = None) -> dict:
    """دورة جمع واحدة: المصادر المستحقة → طابور المعالجة → معالجة مستمرة."""
    run_id = db.start_monitoring_run(conn, "collect")
    due = db.catalog_due_balanced(conn, limit=sources)
    # ترتيب بالأولوية (العاجل وسريع التغيّر أولًا).
    due = sorted(due, key=source_priority)
    total = {"sources": 0, "fetched": 0, "queued": 0, "processed": 0, "errors": 0,
             "new": 0, "updates": 0, "review": 0, "duplicates": 0}
    for src in due:
        res = pipeline.ingest(conn, src)
        total["sources"] += 1
        total["fetched"] += res["fetched"]
        total["errors"] += 1 if res["error"] else 0
        status = "error" if res["error"] else "ok"
        db.mark_catalog_run(conn, src["key"], status=status, fetched=res["fetched"],
                            inserted=res["inserted"], error=res["error"],
                            interval_seconds=COLLECT_INTERVAL)
        # مهمّة معالجة لكل مصدر جلب عناصر (معرّف فريد يمنع التكرار).
        if res["inserted"]:
            db.enqueue_task(conn, f"process:{src['key']}:{_now()}", "process",
                            priority=source_priority(src),
                            payload={"source": src["key"]})
            total["queued"] += 1
        if res["error"]:
            db.add_alert(conn, "source_down", f"تعطّل مصدر: {src.get('name')}",
                         severity="warning", source=src["key"],
                         detail=res["error"])
    conn.commit()

    # خط المعالجة المستمر: نفرّغ الطابور فورًا دون انتظار دورة الجمع كلها.
    proc = process_cycle(conn, limit=PROCESS_BATCH, task_id=task_id)
    total["processed"] = proc["processed"]
    total["new"] = proc["new"]
    total["updates"] = proc["updates"]
    total["review"] = proc["review"]
    total["duplicates"] = proc["exact"]

    db.finish_monitoring_run(conn, run_id, sources_checked=total["sources"],
                             items_fetched=total["fetched"],
                             items_processed=total["processed"], added=total["new"],
                             updated=total["updates"], duplicates=total["duplicates"],
                             review=total["review"], errors=total["errors"])
    _set_meta(conn, _META_KEYS["collect"], _now())
    _check_backlog(conn)
    return total


def process_cycle(conn: sqlite3.Connection, *, limit: int = PROCESS_BATCH,
                  task_id: str | None = None) -> dict:
    """يفرّغ طابور المعالجة: معالجة المستندات المعلّقة عبر خط المعالجة الكامل."""
    run_id = db.start_monitoring_run(conn, "process")
    summary = pipeline.process_pending(conn, limit=limit, task_id=task_id)
    # إنهاء مهام المعالجة المرتبطة.
    for task in db.claim_tasks(conn, "process", limit=limit):
        db.finish_task(conn, task["task_id"], ok=True)
    db.finish_monitoring_run(conn, run_id, items_processed=summary["processed"],
                             added=summary["new"], updated=summary["updates"],
                             duplicates=summary["exact"], review=summary["review"],
                             errors=summary["errors"])
    _set_meta(conn, _META_KEYS["process"], _now())
    return summary


# --- مجدول التحقق (كل خمس دقائق) ---

def verify_cycle(conn: sqlite3.Connection, *, limit: int = VERIFY_BATCH,
                 stale_minutes: int = 5) -> dict:
    """يعالج السجلات المستحقة للتحقق على دفعات بحسب الأولوية (القسم 7)."""
    run_id = db.start_monitoring_run(conn, "verify")
    rows = db.reports_needing_verification(conn, limit=limit,
                                           stale_minutes=stale_minutes)
    total = {"checked": 0, "changed": 0, "verified": 0, "disputed": 0, "badges": 0}
    for rep in rows:
        prev_state = rep.get("verification_state")
        prev_badge = rep.get("badge")
        res = verification.apply(conn, rep["id"], actor="verify_scheduler")
        total["checked"] += 1
        if res.get("changed"):
            total["changed"] += 1
        if res.get("state") == "verified":
            total["verified"] += 1
        if res.get("state") == "disputed":
            total["disputed"] += 1
        if res.get("badge") and not prev_badge:
            total["badges"] += 1
            db.add_alert(conn, "independent_source",
                         f"تأكيد واقعة #{rep['id']} بمصادر مستقلة",
                         severity="info", report_id=rep["id"])
        if res.get("state") == "disputed" and prev_state != "disputed":
            db.add_alert(conn, "conflict", f"تعارض معلومات في الواقعة #{rep['id']}",
                         severity="warning", report_id=rep["id"])
    db.finish_monitoring_run(conn, run_id, items_processed=total["checked"],
                             updated=total["changed"])
    _set_meta(conn, _META_KEYS["verify"], _now())
    return total


# --- مهام المصالحة الدورية ---

def reconcile_cycle(conn: sqlite3.Connection) -> dict:
    """مصالحة دورية: مهام عالقة، تكرارات محتملة، فجوات أرشيف، أخطاء متكررة."""
    run_id = db.start_monitoring_run(conn, "reconcile")
    total = {"stale_tasks": 0, "orphan_docs": 0, "unresolved_dups": 0,
             "blocked_archive": 0}
    # 1) استرداد المهام العالقة بعد انقطاع.
    total["stale_tasks"] = db.reset_stale_tasks(conn, older_than_minutes=15)
    # 2) مستندات معالجة بلا سجل مرتبط (مراجعة/يتيمة) — تُعاد للمعالجة إن لزم.
    total["orphan_docs"] = conn.execute(
        "SELECT COUNT(*) n FROM documents WHERE state = 'review'").fetchone()["n"]
    # 3) تكرارات محتملة (وُسمت dup_of أو بانتظار المراجعة) — تُنبّه.
    total["unresolved_dups"] = conn.execute(
        "SELECT COUNT(*) n FROM documents WHERE dup_reason IS NOT NULL "
        "AND state = 'review'").fetchone()["n"]
    if total["unresolved_dups"]:
        db.add_alert(conn, "conflict",
                     f"{total['unresolved_dups']} عنصرًا بانتظار مراجعة التكرار",
                     severity="info", detail="تطابق محتمل يحتاج قرارًا بشريًّا")
    # 4) مصادر تعذّر أرشيفها.
    total["blocked_archive"] = conn.execute(
        "SELECT COUNT(*) n FROM archive_progress WHERE status = 'blocked'").fetchone()["n"]
    db.finish_monitoring_run(conn, run_id, summary=total)
    _set_meta(conn, _META_KEYS["reconcile"], _now())
    return total


def _check_backlog(conn: sqlite3.Connection) -> None:
    """ينبّه عند تراكم الطابور أو بطء المعالجة (القسم 13)."""
    stats = db.task_queue_stats(conn)
    pending = stats["queued"] + stats["failed"]
    if pending >= BACKLOG_THRESHOLD:
        db.add_alert(conn, "backlog", f"تراكم مهام: {pending} مهمّة معلّقة",
                     severity="warning",
                     detail="سرعة المعالجة أقل من معدّل وصول المحتوى")
    docs = conn.execute(
        "SELECT COUNT(*) n FROM documents WHERE state = 'pending'").fetchone()["n"]
    if docs >= BACKLOG_THRESHOLD:
        db.add_alert(conn, "backlog", f"تراكم مستندات: {docs} بانتظار المعالجة",
                     severity="warning")


# --- المنسّق العام ---

def monitor_tick(conn: sqlite3.Connection, *, backfill_sources: int = 0) -> dict:
    """دورة موحّدة يستدعيها المجدول: تشغّل ما استحقّ من المهام فقط.

    كل مهمّة مُبوّبة بفترتها (`_is_due`) فلا تُنفَّذ إلا عند الاستحقاق، ومنع
    التداخل مضمون لأن المجدول يستدعي `monitor_tick` تسلسليًّا داخل قفل واحد.
    """
    out: dict = {"ran_at": _now(), "ran": []}
    if _is_due(conn, "collect", COLLECT_INTERVAL):
        out["collect"] = collect_cycle(conn)
        out["ran"].append("collect")
    if _is_due(conn, "verify", VERIFY_INTERVAL):
        out["verify"] = verify_cycle(conn)
        out["ran"].append("verify")
    if _is_due(conn, "reconcile", RECONCILE_INTERVAL):
        out["reconcile"] = reconcile_cycle(conn)
        out["ran"].append("reconcile")
    if backfill_sources:
        out["backfill"] = backfill.backfill_batch(conn, sources=backfill_sources)
        out["ran"].append("backfill")
    return out


def run_now(conn: sqlite3.Connection, kind: str) -> dict:
    """تشغيل فوري لمهمّة محدّدة (API/CLI). يتجاوز بوابة الاستحقاق."""
    if kind == "collect":
        return collect_cycle(conn)
    if kind == "process":
        return process_cycle(conn)
    if kind == "verify":
        return verify_cycle(conn)
    if kind == "reconcile":
        return reconcile_cycle(conn)
    raise ValueError(f"مهمّة غير معروفة: {kind}")


def status(conn: sqlite3.Connection) -> dict:
    """حالة المنظومة (للوحة التحكم وواجهة API)."""
    return {
        "intervals": {"collect": COLLECT_INTERVAL, "verify": VERIFY_INTERVAL,
                      "reconcile": RECONCILE_INTERVAL},
        "last": {k: _get_meta(conn, v) for k, v in _META_KEYS.items()},
        "metrics": db.monitoring_metrics(conn),
        "runs": db.monitoring_runs(conn, limit=10),
        "archive": backfill.archive_report(conn),
    }
