"""البحث والاكتشاف (الدفعة 10).

بحث موحّد عبر البلاغات والمنشورات والادّعاءات والكيانات والمصادر والأعضاء،
مع اقتراحات إكمال، تصحيح إملائي مقترح، إبراز، ومقتطف سياق. التطبيع العربي
قائم على ``textutils`` (همزات/تاء مربوطة/تشكيل) فيكون البحث مطابقًا بالمعنى
لا بالرسم فقط.
"""
from __future__ import annotations

import difflib
import html
import logging
import sqlite3
from typing import Any

from . import db
from .taxonomy import CATEGORY_BY_KEY, ENTITY_KIND_BY_KEY, category_name
from .textutils import normalize_arabic, tokenize

log = logging.getLogger("mirsad.search")

# أنواع المحتوى القابلة للبحث الموحّد.
SEARCH_KINDS = [
    {"key": "report", "label": "بلاغ", "label_en": "Report"},
    {"key": "post", "label": "منشور", "label_en": "Post"},
    {"key": "claim", "label": "ادّعاء", "label_en": "Claim"},
    {"key": "entity", "label": "كيان", "label_en": "Entity"},
    {"key": "source", "label": "مصدر", "label_en": "Source"},
    {"key": "member", "label": "عضو", "label_en": "Member"},
    {"key": "group", "label": "مجموعة", "label_en": "Group"},
]
SEARCH_KIND_BY_KEY = {k["key"]: k for k in SEARCH_KINDS}

# كلمات إيقاف عربية شائعة تُستبعد من الاقتراحات (لا من المطابقة).
_STOPWORDS = {
    "في", "من", "على", "عن", "إلى", "الى", "مع", "هذا", "هذه", "ذلك", "التي",
    "الذي", "كان", "قد", "ما", "لا", "أن", "ان", "أو", "او", "ثم", "كل", "بعد",
    "قبل", "بين", "حول", "ضد", "عند", "لقد", "هل", "لم", "لن", "به", "له",
}


def search_kind_label(key: str, lang: str = "ar") -> str:
    k = SEARCH_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def _norm_char_index(text: str) -> list[int]:
    """خريطة كل موضع في النصّ المطبَّع إلى موضع مقابل في النصّ الأصلي.

    التطبيع لا يحافظ على الطول (يحذف التشكيل والتطويل ويطوي المسافات المتتالية)،
    فالبحث في النصّ المطبَّع وإسقاط الموضع مباشرةً على الأصل يزيح الإبراز. نبني
    الخريطة بمحاكاة تطبيع كل محرف على حدة: يحتفظ كل محرف مطبَّع غير فارغ بموضعه،
    وتُحذف محارف التشكيل/التطويل، وتبقى مسافة واحدة من كل مجموعة مسافات (بعد
    تجريد الأطراف) لتطابق مخرَج ``normalize_arabic`` طولًا وترتيبًا.
    """
    out: list[int] = []
    nonspace = [i for i, c in enumerate(text) if not c.isspace()]
    if not nonspace:
        return out
    first_ns, last_ns = nonspace[0], nonspace[-1]
    for i, ch in enumerate(text):
        nm = normalize_arabic(ch)
        if nm:
            out.extend([i] * len(nm))
        elif ch.isspace() and first_ns < i < last_ns and not text[i - 1].isspace():
            out.append(i)  # المسافة الوحيدة الباقية من كل مجموعة مسافات
    return out


def _blob_match(blob: str | None, tokens: list[str]) -> bool:
    if not blob:
        return False
    return all(tok in blob for tok in tokens)


def _snippet(text: str | None, tokens: list[str], width: int = 140) -> str:
    """مقتطف سياق حول أول كلمة مطابقة (نصّ عربي مطبَّع للبحث، والأصل للعرض)."""
    if not text:
        return ""
    norm = normalize_arabic(text)
    index = _norm_char_index(text)
    pos = -1
    for tok in tokens:
        i = norm.find(tok)
        if i >= 0:
            pos = index[i] if i < len(index) else i
            break
    if pos < 0:
        return text[:width].strip()
    start = max(0, pos - width // 2)
    end = min(len(text), pos + width // 2)
    prefix = "…" if start > 0 else ""
    suffix = "…" if end < len(text) else ""
    return f"{prefix}{text[start:end].strip()}{suffix}"


def _highlight(text: str | None, tokens: list[str]) -> str:
    """يغلّف الكلمات المطابقة بوسم <mark> على النصّ الأصلي.

    يُبحث في النصّ المطبَّع، لكن تُحوَّل مواضع المطابقة إلى النصّ الأصلي عبر
    ``_norm_char_index`` قبل الإبراز، فلا تُقتطع الكلمة عند وجود تشكيل/تطويل
    أو مسافات مكرّرة (كان الإبراز يزيح سابقًا فيظهر «أطفا» بدل «أطفال»).
    النصّ المُعاد مُهرَّب بالكامل (لا يُسمح بوسوم من المحتوى) فلا يصلح لحقن HTML
    عبر عنوان/اسم مستورد، ويُعرض في القوالب بـ``| safe`` بأمان.
    """
    if not text or not tokens:
        return html.escape(text or "")
    norm = normalize_arabic(text)
    index = _norm_char_index(text)
    spans: list[tuple[int, int]] = []
    for tok in tokens:
        start = 0
        while True:
            i = norm.find(tok, start)
            if i < 0:
                break
            j = min(i + len(tok), len(index))
            if i < len(index):
                spans.append((index[i], index[j - 1] + 1))
            start = j
    if not spans:
        return html.escape(text)
    spans.sort()
    out, cursor = [], 0
    for s, e in spans:
        if s < cursor:
            continue
        out.append(html.escape(text[cursor:s]))
        out.append("<mark>")
        out.append(html.escape(text[s:e]))
        out.append("</mark>")
        cursor = e
    out.append(html.escape(text[cursor:]))
    return "".join(out)


def _all_vocabulary(conn: sqlite3.Connection, limit: int = 4000) -> list[str]:
    """مفردات مقترحة من عناوين البلاغات والكيانات والوسوم (لتصحيح/الإكمال)."""
    words: set[str] = set()
    for row in conn.execute("SELECT title FROM reports LIMIT 3000"):
        for w in tokenize(row["title"] or ""):
            if len(w) >= 3 and w not in _STOPWORDS:
                words.add(w)
    for row in conn.execute("SELECT name FROM entities LIMIT 2000"):
        for w in tokenize(row["name"] or ""):
            if len(w) >= 3 and w not in _STOPWORDS:
                words.add(w)
    return sorted(words)[:limit]


def suggest_correction(conn: sqlite3.Connection, query: str) -> str | None:
    """اقتراح تصحيح إملائي إذا كان الاستعلام لا يطابق شيئًا."""
    tokens = tokenize(query)
    if not tokens:
        return None
    vocab = _all_vocabulary(conn)
    corrected: list[str] = []
    changed = False
    for tok in tokens:
        if tok in vocab or tok in _STOPWORDS:
            corrected.append(tok)
            continue
        close = difflib.get_close_matches(tok, vocab, n=1, cutoff=0.72)
        if close:
            corrected.append(close[0])
            changed = True
        else:
            corrected.append(tok)
    return " ".join(corrected) if changed else None


def complete(conn: sqlite3.Connection, prefix: str, limit: int = 8) -> list[str]:
    """اقتراحات إكمال للاستعلام من المفردات (بادئة مطابقة)."""
    prefix = normalize_arabic(prefix.strip())
    if not prefix:
        return []
    vocab = _all_vocabulary(conn)
    return [w for w in vocab if w.startswith(prefix)][:limit]


def suggest_queries(conn: sqlite3.Connection, query: str, limit: int = 6) -> list[dict]:
    """اقتراح استعلامات مكمّلة: كيانات/بلاغات بارزة تطابق بادئة الاستعلام."""
    tokens = tokenize(query)
    if not tokens:
        return []
    last = tokens[-1]
    out: list[dict] = []
    for row in conn.execute(
        "SELECT name, COUNT(DISTINCT report_id) AS n FROM entities "
        "WHERE name LIKE ? GROUP BY name ORDER BY n DESC LIMIT ?",
        (f"%{query.strip()}%", limit),
    ).fetchall():
        out.append({"kind": "entity", "value": row["name"], "count": row["n"]})
    for w in complete(conn, last, limit):
        if not any(o["value"] == w for o in out):
            out.append({"kind": "term", "value": w, "count": 0})
    return out[:limit]


# ---------------------------------------------------------------------------
# البحث الموحّد
# ---------------------------------------------------------------------------

def _search_reports(conn, tokens, limit) -> list[dict]:
    rows = db.query_reports(conn, search=" ".join(tokens), sort="relevance", limit=limit)
    out = []
    for r in rows:
        text = f"{r['title']} {r.get('summary') or ''}"
        out.append({
            "kind": "report", "id": r["id"], "title": r["title"],
            "url": f"/reports/{r['id']}", "category": r.get("category"),
            "category_label": category_name(r.get("category", "")),
            "severity": r.get("severity"), "country": r.get("country"),
            "verified": bool(r.get("verified")), "reported_on": r.get("reported_on"),
            "snippet": _snippet(text, tokens), "highlight": _highlight(r["title"], tokens),
            "score": 1.0,
        })
    return out


def _search_posts(conn, tokens, limit) -> list[dict]:
    from . import social
    rows = social.query_posts(conn, search=" ".join(tokens), limit=limit)
    out = []
    for p in rows:
        text = f"{p['title']} {p.get('body') or ''}"
        out.append({
            "kind": "post", "id": p["id"], "title": p["title"],
            "url": f"/post/{p['id']}", "author": p.get("author_handle"),
            "author_name": p.get("author_name"), "tags": p.get("tags"),
            "created_at": p.get("created_at"), "snippet": _snippet(text, tokens),
            "highlight": _highlight(p["title"], tokens), "score": 0.9,
        })
    return out


def _search_claims(conn, tokens, limit) -> list[dict]:
    out = []
    for r in conn.execute(
        "SELECT * FROM claims ORDER BY created_at DESC LIMIT 500"
    ).fetchall():
        blob = f"{r['title']} {r['summary'] or ''}"
        if _blob_match(normalize_arabic(blob), tokens):
            out.append({
                "kind": "claim", "id": r["id"], "ref": r["ref"], "title": r["title"],
                "url": f"/verification/{r['ref']}", "status": r["status"],
                "snippet": _snippet(blob, tokens), "highlight": _highlight(r["title"], tokens),
                "score": 0.85,
            })
        if len(out) >= limit:
            break
    return out


def _search_entities(conn, tokens, limit) -> list[dict]:
    out = []
    for r in conn.execute(
        "SELECT name, MAX(wikidata_id) AS wid, COUNT(DISTINCT report_id) AS n "
        "FROM entities GROUP BY name ORDER BY n DESC LIMIT 800"
    ).fetchall():
        if _blob_match(normalize_arabic(r["name"]), tokens):
            out.append({
                "kind": "entity", "id": r["name"], "title": r["name"],
                "url": f"/entity/{r['name']}", "count": r["n"],
                "wikidata_id": r["wid"], "highlight": _highlight(r["name"], tokens),
                "score": 0.8,
            })
        if len(out) >= limit:
            break
    return out


def _search_sources(conn, tokens, limit) -> list[dict]:
    out = []
    for r in conn.execute("SELECT * FROM sources ORDER BY name").fetchall():
        blob = f"{r['name']} {r['key'] or ''} {r['note'] or ''}"
        if _blob_match(normalize_arabic(blob), tokens):
            out.append({
                "kind": "source", "id": r["key"], "title": r["name"],
                "url": f"/sources", "source_url": r["url"],
                "snippet": _snippet(blob, tokens), "highlight": _highlight(r["name"], tokens),
                "score": 0.7,
            })
        if len(out) >= limit:
            break
    return out


def _search_members(conn, tokens, limit) -> list[dict]:
    from . import social
    out = []
    for m in social.query_members(conn, limit=None):
        if not m.get("published"):
            continue
        blob = f"{m['display_name']} {m['handle']} {m.get('org') or ''} {m.get('interests') or ''}"
        if _blob_match(normalize_arabic(blob), tokens):
            out.append({
                "kind": "member", "id": m["handle"], "title": m["display_name"],
                "url": f"/member/{m['handle']}", "role": m.get("role"),
                "verified": bool(m.get("verified")),
                "highlight": _highlight(m["display_name"], tokens), "score": 0.65,
            })
        if len(out) >= limit:
            break
    return out


def _search_groups(conn, tokens, limit) -> list[dict]:
    out = []
    # المجموعات السرّية تُستثنى دائمًا من نتائج البحث (مطابقة لـ social.query_groups).
    for r in conn.execute(
        "SELECT * FROM groups WHERE status='active' AND visibility <> 'secret' ORDER BY name"
    ).fetchall():
        blob = f"{r['name']} {r['purpose'] or ''}"
        if _blob_match(normalize_arabic(blob), tokens):
            out.append({
                "kind": "group", "id": r["slug"], "title": r["name"],
                "url": f"/group/{r['slug']}", "snippet": _snippet(blob, tokens),
                "highlight": _highlight(r["name"], tokens), "score": 0.6,
            })
        if len(out) >= limit:
            break
    return out


_SEARCHERS = {
    "report": _search_reports,
    "post": _search_posts,
    "claim": _search_claims,
    "entity": _search_entities,
    "source": _search_sources,
    "member": _search_members,
    "group": _search_groups,
}


def unified_search(conn: sqlite3.Connection, query: str, *,
                   kinds: list[str] | None = None, per_kind: int = 12,
                   safe: bool = True) -> dict[str, Any]:
    """بحث موحّد عبر كل أنواع المحتوى.

    ``safe`` يُخفي/يوسم المحتوى الحسّاس (خطورة critical غير موثّق) من النتائج.
    يعيد النتائج مجمّعة بالنوع + عدد كل نوع + اقتراح تصحيح إن لم توجد نتائج.
    """
    tokens = tokenize(query)
    if not tokens:
        return {"query": query, "total": 0, "groups": {}, "counts": {}, "correction": None}
    active = [k for k in (kinds or list(_SEARCHERS)) if k in _SEARCHERS]
    groups: dict[str, list[dict]] = {}
    counts: dict[str, int] = {}
    for kind in active:
        try:
            results = _SEARCHERS[kind](conn, tokens, per_kind)
        except Exception:
            # لا نُسقط البحث كاملًا لفشل نوع واحد، لكن يجب ألا يمرّ الفشل صامتًا.
            log.warning("unified_search: فشل البحث في النوع %s", kind, exc_info=True)
            results = []
        if kind == "report" and safe:
            results = [r for r in results
                       if not (r.get("severity") == "critical" and not r.get("verified"))]
        counts[kind] = len(results)
        if results:
            groups[kind] = results
    total = sum(counts.values())
    correction = None if total else suggest_correction(conn, query)
    return {"query": query, "tokens": tokens, "total": total,
            "groups": groups, "counts": counts, "correction": correction}


def results_to_rows(conn: sqlite3.Connection, query: str, *,
                    kinds: list[str] | None = None, per_kind: int = 12,
                    safe: bool = True) -> list[dict]:
    """نتائج مسطّحة مرتّبة بالصلة (للعرض/التصدير)."""
    data = unified_search(conn, query, kinds=kinds, per_kind=per_kind, safe=safe)
    rows: list[dict] = []
    for kind, items in data["groups"].items():
        for it in items:
            it = dict(it)
            it["kind_label"] = search_kind_label(kind)
            rows.append(it)
    rows.sort(key=lambda r: r.get("score", 0), reverse=True)
    return rows


def trending_terms(conn: sqlite3.Connection, limit: int = 12) -> list[dict]:
    """مصطلحات صاعدة: أكثر الكلمات تكرارًا في عناوين البلاغات الحديثة."""
    freq: dict[str, int] = {}
    for row in conn.execute(
        "SELECT title FROM reports ORDER BY reported_on DESC LIMIT 300"
    ).fetchall():
        for w in set(tokenize(row["title"] or "")):
            if len(w) >= 4 and w not in _STOPWORDS:
                freq[w] = freq.get(w, 0) + 1
    return [{"term": w, "count": n}
            for w, n in sorted(freq.items(), key=lambda x: x[1], reverse=True)[:limit]]


def related_terms(conn: sqlite3.Connection, term: str, limit: int = 8) -> list[str]:
    """مصطلحات مشتركة الظهور مع مصطلح (اقتراحات ذات صلة)."""
    tokens = tokenize(term)
    if not tokens:
        return []
    target = tokens[0]
    co: dict[str, int] = {}
    for row in conn.execute("SELECT title FROM reports LIMIT 2000").fetchall():
        words = set(tokenize(row["title"] or ""))
        if target in words:
            for w in words:
                if w != target and len(w) >= 4 and w not in _STOPWORDS:
                    co[w] = co.get(w, 0) + 1
    return [w for w, _ in sorted(co.items(), key=lambda x: x[1], reverse=True)[:limit]]


def discovery_boards(conn: sqlite3.Connection) -> dict[str, list[dict]]:
    """لوحات اكتشاف: الأكثر قراءة/تحقّقًا/تعاونًا/تصاعدًا."""
    most_verified = [dict(r) for r in conn.execute(
        "SELECT id, title, reported_on FROM reports WHERE verified=1 "
        "ORDER BY reported_on DESC LIMIT 6"
    ).fetchall()]
    from . import social
    most_cooperative = [dict(r) for r in conn.execute(
        """SELECT member, COUNT(*) AS n, COALESCE(SUM(weight),0) AS w
           FROM endorsements GROUP BY member ORDER BY w DESC LIMIT 6"""
    ).fetchall()]
    active_sources = [dict(r) for r in conn.execute(
        """SELECT source_name, COUNT(*) AS n FROM reports
           WHERE source_name IS NOT NULL
           GROUP BY source_name ORDER BY n DESC LIMIT 6"""
    ).fetchall()]
    top_categories = [dict(r) for r in conn.execute(
        """SELECT category, COUNT(*) AS n FROM reports
           GROUP BY category ORDER BY n DESC LIMIT 6"""
    ).fetchall()]
    for c in top_categories:
        c["label"] = category_name(c["category"])
    urgent = [dict(r) for r in conn.execute(
        """SELECT id, title, severity, reported_on FROM reports
           WHERE severity IN ('critical','high') ORDER BY reported_on DESC LIMIT 6"""
    ).fetchall()]
    regions = [dict(r) for r in conn.execute(
        """SELECT country, COUNT(*) AS n FROM reports
           GROUP BY country ORDER BY n DESC LIMIT 6"""
    ).fetchall()]
    return {"most_verified": most_verified, "most_cooperative": most_cooperative,
            "active_sources": active_sources, "top_categories": top_categories,
            "urgent": urgent, "regions": regions}


def entity_kind_label_safe(name: str) -> str:
    return name


def seed_searches(conn: sqlite3.Connection) -> None:
    """بحوث محفوظة تجريبية (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM saved_searches").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    rows = [
        ("sami.verify", "أطفال", "report,claim"),
        ("noor.mod", "خطاب كراهية", "report,post"),
        ("ziad.act", "اعتقال", "report,entity"),
    ]
    for member, query, kinds in rows:
        if member in handles:
            conn.execute(
                "INSERT OR IGNORE INTO saved_searches(member, query, kinds) VALUES (?,?,?)",
                (member, query, kinds),
            )
    conn.commit()




def save_search(conn: sqlite3.Connection, handle: str, query: str,
                kinds: str = "", notify: bool = True) -> dict[str, Any]:
    query = (query or "").strip()
    if not handle or not query:
        return {"ok": False, "error": "invalid"}
    cur = conn.execute(
        """INSERT OR IGNORE INTO saved_searches(member, query, kinds, notify)
           VALUES (?,?,?,?)""",
        (handle, query[:200], kinds[:120], 1 if notify else 0),
    )
    conn.commit()
    if cur.rowcount == 0:
        return {"ok": False, "error": "already_saved"}
    return {"ok": True, "id": cur.lastrowid}


def unsave_search(conn: sqlite3.Connection, handle: str, search_id: int) -> bool:
    cur = conn.execute(
        "DELETE FROM saved_searches WHERE id=? AND member=?", (search_id, handle)
    )
    conn.commit()
    return cur.rowcount > 0


def saved_searches(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM saved_searches WHERE member=? ORDER BY created_at DESC", (handle,)
    ).fetchall()]


def search_counts_since(conn: sqlite3.Connection, handle: str) -> list[dict]:
    """عدد النتائج الجديدة لكل بحث محفوظ (تنبيه النتائج الجديدة)."""
    out = []
    for s in saved_searches(conn, handle):
        kinds = [k for k in (s.get("kinds") or "").split(",") if k in SEARCH_KIND_BY_KEY]
        data = unified_search(conn, s["query"], kinds=kinds or None, per_kind=5)
        out.append({"id": s["id"], "query": s["query"], "new_count": data["total"]})
    return out
