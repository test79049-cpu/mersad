"""مجدول (scheduler) يعمل داخل التطبيق لتحديث قاعدة البيانات دوريّاً.

الافتراضي: دورة كل 60 ثانية. يعمل في خيط خلفي منفصل عبر asyncio، ويتحوّل
تلقائياً إلى no-op إن كانت الميزة معطّلة (`MIRSAD_REFRESH=0`).

التصميم: خيط واحد، حلقة async بسيطة، مع قفل (lock) يمنع تراكم التشغيلات.
لا يعتمد على مكتبات جدولة خارجية (احترام قيد «مكتبات مفتوحة فقط» وتقليل
الاعتماديات).
"""

from __future__ import annotations

import asyncio
import logging
import os

from . import db, refresh as refresh_mod

log = logging.getLogger("mirsad.scheduler")

# الفترة بالثواني (افتراضي دقيقة واحدة)
INTERVAL = int(os.getenv("MIRSAD_REFRESH_INTERVAL", "60"))
ENABLED = os.getenv("MIRSAD_REFRESH", "1") not in ("0", "false", "False")


class Scheduler:
    def __init__(self, interval: int = INTERVAL, pull_news: bool = True):
        self.interval = max(10, interval)
        self.pull_news = pull_news
        self._task: asyncio.Task | None = None
        self._running = False
        self._lock = asyncio.Lock()
        self.last_result: dict | None = None
        self.runs = 0

    async def _tick(self) -> None:
        if self._lock.locked():
            # تشغيل سابق ما زال جارياً — تجاوز هذه الدورة
            return
        async with self._lock:
            await asyncio.to_thread(self._run_once)

    def _run_once(self) -> None:
        conn = db.connect()
        try:
            self.last_result = refresh_mod.refresh(conn, pull_news=self.pull_news)
            self.runs += 1
            log.info("دورة تحديث #%s: %s", self.runs,
                     {k: v for k, v in self.last_result.items() if k != "ran_at"})
        except Exception as exc:  # noqa: BLE001 — المهمّة الخلفية يجب ألا تُسقط التطبيق
            log.warning("فشل دورة التحديث: %s", exc)
        finally:
            conn.close()

    async def _loop(self) -> None:
        # مهلة قصيرة عند البدء ثم دورة منتظمة
        await asyncio.sleep(min(10, self.interval))
        while self._running:
            await self._tick()
            await asyncio.sleep(self.interval)

    def start(self) -> None:
        if not ENABLED or self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.info("بدأ المجدول (كل %s ثانية)", self.interval)

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    def status(self) -> dict:
        return {
            "enabled": ENABLED,
            "running": self._running,
            "interval_seconds": self.interval,
            "runs": self.runs,
            "last_result": self.last_result,
        }


scheduler = Scheduler()
