"""مجموعة الدول: أسماء عربية وإنجليزية، رموز ISO، إحداثيات، ومناطق.

مصدر البيانات: مجموعة «mledoze/countries» مفتوحة المصدر (ODbL) المرآة من
البيانات الرسمية لـ ISO 3166، مع الترجمات العربية.
"""

import json
import unicodedata
from functools import lru_cache

from .config import DATA_DIR

_DATASET_PATH = DATA_DIR / "countries.json"

# أسماء عربية شائعة تختلف عن تسمية المجموعة الأصلية.
_ALIASES = {
    "هنغاريا": "HUN",
    "المجر": "HUN",
    "المكسيك": "MEX",
    "المسكيك": "MEX",
    "تايلاند": "THA",
    "تايلند": "THA",
    "الكونغو": "COD",
    "الكونغو الديمقراطية": "COD",
    "ساحل العاج": "CIV",
    "كوت ديفوار": "CIV",
    "المملكة المتحدة": "GBR",
    "بريطانيا": "GBR",
    "الولايات المتحدة": "USA",
    "أمريكا": "USA",
    "فلسطين": "PSE",
    "الأراضي الفلسطينية": "PSE",
}


@lru_cache(maxsize=1)
def all_countries() -> list[dict]:
    with open(_DATASET_PATH, encoding="utf-8") as fh:
        return json.load(fh)


@lru_cache(maxsize=1)
def _indexes() -> dict:
    rows = all_countries()
    by_ar, by_en, by_iso2, by_iso3 = {}, {}, {}, {}
    for c in rows:
        by_ar[c["ar"]] = c
        by_en[c["en"].lower()] = c
        by_iso2[c["iso2"]] = c
        by_iso3[c["iso3"]] = c
    return {"ar": by_ar, "en": by_en, "iso2": by_iso2, "iso3": by_iso3}


def _norm(text: str) -> str:
    """يطبّع النص العربي: يزيل التشكيل ويوحّد الألف والهمزات."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    text = text.replace("ة", "ه").replace("ى", "ي")
    return text.strip().lower()


@lru_cache(maxsize=1)
def _norm_index() -> dict:
    idx = {}
    for c in all_countries():
        idx[_norm(c["ar"])] = c
        idx.setdefault(_norm(c["en"]), c)
    return idx


def find(name_or_code: str) -> dict | None:
    """يجد دولة بالاسم العربي/الإنجليزي أو رمز ISO، مع تطبيع النص."""
    if not name_or_code:
        return None
    key = name_or_code.strip()
    idx = _indexes()
    if key.upper() in idx["iso2"]:
        return idx["iso2"][key.upper()]
    if key.upper() in idx["iso3"]:
        return idx["iso3"][key.upper()]
    if key in idx["ar"]:
        return idx["ar"][key]
    if key.lower() in idx["en"]:
        return idx["en"][key.lower()]
    alias = _ALIASES.get(key) or _ALIASES.get(_norm(key))
    if alias:
        return idx["iso3"].get(alias) or idx["iso2"].get(alias)
    return _norm_index().get(_norm(key))


def arabic_name(name_or_code: str) -> str:
    c = find(name_or_code)
    return c["ar"] if c else name_or_code


def english_name(name_or_code: str) -> str:
    c = find(name_or_code)
    return c["en"] if c else name_or_code


def coords(name_or_code: str) -> list[float] | None:
    c = find(name_or_code)
    return c["latlng"] if c else None


def region_of(name_or_code: str) -> str:
    c = find(name_or_code)
    return c["region"] if c else ""


def iso3(name_or_code: str) -> str | None:
    c = find(name_or_code)
    return c["iso3"] if c else None


def search(query: str, limit: int = 10) -> list[dict]:
    """بحث حرّ عن الدول بالاسم العربي أو الإنجليزي."""
    q = _norm(query)
    if not q:
        return []
    hits = []
    for c in all_countries():
        if q in _norm(c["ar"]) or q in _norm(c["en"]):
            hits.append({**c, "text": f"{c['ar']} ({c['en']})"})
        if len(hits) >= limit:
            break
    return hits
