"""طبقة قاعدة البيانات: المخطّط، البيانات التجريبية، ودوال الاستعلام.

تستخدم SQLite مع امتداد FTS5 للبحث النصّي الكامل (يدعم العربية عبر
المُرمِّز unicode61 مع إزالة التشكيل).
"""

import os
import re
import sqlite3
import time
from datetime import date, datetime, timedelta, timezone
from typing import Any

from .config import API_MAX_LIMIT, DB_PATH, PAGE_SIZE
from .countries import arabic_name, coords, iso3, region_of
from .seed_data import SEED_ROWS
from .seed_en import SEED_EN
from .taxonomy import CATEGORIES, CATEGORY_KEYS, SEVERITIES
from .textutils import build_search_text, normalize_arabic, tokenize

SCHEMA_VERSION = 23

# ذاكرة مؤقّتة داخليّة للإحصاءات الثقيلة (تُعاد الحساب عند كتابة جديدة).
# الإحصاءات تُقرأ في معظم الصفحات وتُجمّع على كامل الجدول، فذاكرتها تُقلّل زمن التحميل.
_STATS_CACHE: dict[str, Any] = {"value": None, "stamp": None}

# تخزين مؤقّت داخل العملية للاستعلامات الثقيلة المتكرّرة (ملخّص الدول، الجمع الحيّ).
# يُبطَل تلقائيًّا عند تغيّر بيانات `reports`، أو بانتهاء مدّة الصلاحية للاستعلامات
# الزمنية. الغرض تقليل زمن تحميل الصفحة الرئيسية دون إعادة حساب مسح كامل كل طلب.
_QUERY_CACHE: dict[str, Any] = {}


def _reports_stamp(conn: sqlite3.Connection) -> tuple:
    row = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(MAX(reported_on), '') AS m, "
        "COALESCE(MAX(id), 0) AS i FROM reports"
    ).fetchone()
    return (DB_PATH, row["n"], row["m"], row["i"])


def _cached_query(conn: sqlite3.Connection, name: str, compute, ttl: float = 0.0):
    """يُنفّذ `compute()` ويخزّن نتيجته مؤقّتًا.

    يُعاد الحساب عند تغيّر بصمة بيانات `reports`، أو عند تجاوز `ttl` ثانية
    (لللاستعلامات المعتمدة على الوقت مثل نوافذ آخر ساعة/24 ساعة).
    """
    stamp = _reports_stamp(conn)
    now = time.monotonic()
    entry = _QUERY_CACHE.get(name)
    if entry is not None:
        cached_stamp, cached_at, value = entry
        if cached_stamp == stamp and (ttl <= 0 or (now - cached_at) < ttl):
            return value
    value = compute()
    _QUERY_CACHE[name] = (stamp, now, value)
    return value

SCHEMA = """
CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sources (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    key       TEXT UNIQUE NOT NULL,
    name      TEXT NOT NULL,
    url       TEXT,
    kind      TEXT NOT NULL DEFAULT 'manual',
    license   TEXT,
    note      TEXT
);

CREATE TABLE IF NOT EXISTS reports (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    title         TEXT NOT NULL,
    title_en      TEXT,
    category      TEXT NOT NULL,
    severity      TEXT NOT NULL,
    status        TEXT NOT NULL,
    country       TEXT NOT NULL,
    country_code  TEXT,
    region        TEXT,
    lat           REAL,
    lng           REAL,
    occurred_on   TEXT,
    reported_on   TEXT NOT NULL,
    summary       TEXT NOT NULL,
    summary_en    TEXT,
    details       TEXT,
    source_name   TEXT,
    source_url    TEXT,
    source_id     INTEGER REFERENCES sources(id),
    external_id   TEXT,
    dedup_key     TEXT,
    verified      INTEGER NOT NULL DEFAULT 0,
    verification_state TEXT,                -- حالة التحقق الموحّدة (تتزامن مع verification_records)
    confidence    REAL,                     -- درجة الثقة المحسوبة (0..1)
    badge         INTEGER NOT NULL DEFAULT 0, -- شارة «موثّق من مصادر مستقلة»
    content_digest TEXT,                    -- بصمة المحتوى لمنع التكرار الدقيق
    discovered_at TEXT,                     -- وقت رصد الواقعة آليًّا (منفصل عن الوقوع/النشر)
    updated_at    TEXT,                     -- وقت آخر تحديث جوهري
    search_blob   TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_reports_category ON reports(category);
CREATE INDEX IF NOT EXISTS idx_reports_country  ON reports(country);
CREATE INDEX IF NOT EXISTS idx_reports_severity ON reports(severity);
CREATE INDEX IF NOT EXISTS idx_reports_reported ON reports(reported_on);
CREATE INDEX IF NOT EXISTS idx_reports_sev_reported ON reports(severity, reported_on);
CREATE INDEX IF NOT EXISTS idx_reports_dedup ON reports(dedup_key);
-- فهرس على created_at لتسريع نوافذ «الجمع الحيّ» (آخر ساعة/24 ساعة) في الرئيسية.
CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at);
-- فهرس تعبيري لشهر الوقوع (يسرّع تجميع الخط الزمني على عشرات آلاف الصفوف).
CREATE INDEX IF NOT EXISTS idx_reports_ym
    ON reports(substr(COALESCE(occurred_on, reported_on), 1, 7));
CREATE UNIQUE INDEX IF NOT EXISTS idx_reports_external
    ON reports(external_id) WHERE external_id IS NOT NULL;

-- مصادر متعدّدة للبلاغ الواحد: عند ورود الحدث نفسه من أكثر من مصدر يُدمَج
-- البلاغ وتُسجَّل كل مصادره هنا بدل إنشاء بلاغ مكرّر.
CREATE TABLE IF NOT EXISTS report_sources (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    source_name TEXT NOT NULL,
    source_url  TEXT,
    external_id TEXT,
    added_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_report_sources_report ON report_sources(report_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_report_sources_ext
    ON report_sources(external_id) WHERE external_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS entities (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id   INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    name        TEXT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'unknown',
    wikidata_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_entities_report ON entities(report_id);
-- فهرس على الاسم يسرّع تجميع ملخّص الكيانات وعدّ الأنواع (GROUP BY name).
CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name);

CREATE TABLE IF NOT EXISTS ingest_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    source_key TEXT NOT NULL,
    ran_at     TEXT NOT NULL DEFAULT (datetime('now')),
    fetched    INTEGER NOT NULL DEFAULT 0,
    inserted   INTEGER NOT NULL DEFAULT 0,
    skipped    INTEGER NOT NULL DEFAULT 0,
    status     TEXT NOT NULL DEFAULT 'ok',
    note       TEXT
);
CREATE INDEX IF NOT EXISTS idx_ingest_log_source ON ingest_log(source_key, ran_at);

-- فهرس المصادر الواسع (≈1000 مصدر): تغذيات مباشرة، بحوث إخبارية موضوعية،
-- وقواعد بيانات مفتوحة. يُملأ من `app/catalog.py` عبر `db.sync_catalog()`.
CREATE TABLE IF NOT EXISTS source_catalog (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    key          TEXT UNIQUE NOT NULL,
    name         TEXT NOT NULL,
    name_en      TEXT,
    domain       TEXT NOT NULL,
    severity     TEXT NOT NULL DEFAULT 'medium',
    kind         TEXT NOT NULL DEFAULT 'feed',
    url          TEXT,
    feed_url     TEXT,
    region       TEXT,
    license      TEXT,
    enabled      INTEGER NOT NULL DEFAULT 1,
    last_run     TEXT,
    last_status  TEXT,
    last_error   TEXT,
    fail_count   INTEGER NOT NULL DEFAULT 0,
    next_run     TEXT,
    items_total  INTEGER NOT NULL DEFAULT 0,
    inserted_total INTEGER NOT NULL DEFAULT 0,
    -- حقول الاكتشاف: نوع المصدر كما ورد في الطلب، والتغطية والوصول، والتصنيف
    -- المرجعي (مجموعة الاكتشاف) والمجالات التي يخدمها، وهل اكتُشف آليًّا.
    source_kind  TEXT,
    coverage     TEXT,
    access       TEXT,
    group_key    TEXT,
    categories   TEXT,
    discovered   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_catalog_domain ON source_catalog(domain);
CREATE INDEX IF NOT EXISTS idx_catalog_kind ON source_catalog(kind);
CREATE INDEX IF NOT EXISTS idx_catalog_due ON source_catalog(enabled, next_run);
CREATE INDEX IF NOT EXISTS idx_catalog_discovered ON source_catalog(discovered);

-- سجل دورات اكتشاف المصادر: تقرير كل دورة (المُضاف/المكرّر/المرفوض) لعرضه في الموقع.
CREATE TABLE IF NOT EXISTS source_discovery_log (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ran_at        TEXT NOT NULL,
    candidates    INTEGER NOT NULL DEFAULT 0,
    added_count   INTEGER NOT NULL DEFAULT 0,
    duplicate_count INTEGER NOT NULL DEFAULT 0,
    rejected_count INTEGER NOT NULL DEFAULT 0,
    report        TEXT
);
CREATE INDEX IF NOT EXISTS idx_discovery_ran ON source_discovery_log(ran_at DESC);

-- أعضاء المنصّة الاجتماعية: سجل تعاون بين الناشطين.
-- ملاحظة: لا تُخزَّن بيانات شخصية حسّاسة هنا؛ الحقول الاختيارية تبقى فارغة
-- افتراضيًا، والملف العام يخفي الحقول غير المنشورة عبر published.
CREATE TABLE IF NOT EXISTS members (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    handle        TEXT UNIQUE NOT NULL,
    display_name  TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'member',
    status        TEXT NOT NULL DEFAULT 'active',
    bio           TEXT,
    bio_en        TEXT,
    country       TEXT,
    langs         TEXT,
    interests     TEXT,
    org           TEXT,
    avatar_seed   TEXT,
    verified      INTEGER NOT NULL DEFAULT 0,
    published     INTEGER NOT NULL DEFAULT 1,
    is_seed       INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_members_role   ON members(role);
CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);

-- منشورات المجتمع: نشر الحقائق والتعاون بين الناشطين.
-- author_handle يربط العضو بالمنشور؛ report_id يربط ببلاغ موثّق (اختياري).
-- الحذف ناعم عبر status='hidden' (لا حذف نهائي من الواجهة).
CREATE TABLE IF NOT EXISTS posts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    author_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    kind          TEXT NOT NULL DEFAULT 'update',
    visibility    TEXT NOT NULL DEFAULT 'public',
    status        TEXT NOT NULL DEFAULT 'published',
    title         TEXT NOT NULL,
    title_en      TEXT,
    body          TEXT NOT NULL,
    body_en       TEXT,
    report_id     INTEGER REFERENCES reports(id) ON DELETE SET NULL,
    tags          TEXT,
    search_blob   TEXT,
    is_seed       INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_posts_author  ON posts(author_handle);
CREATE INDEX IF NOT EXISTS idx_posts_kind    ON posts(kind);
CREATE INDEX IF NOT EXISTS idx_posts_status  ON posts(status);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(created_at);
CREATE INDEX IF NOT EXISTS idx_posts_report  ON posts(report_id);

CREATE VIRTUAL TABLE IF NOT EXISTS posts_fts USING fts5(
    search_blob,
    content='posts', content_rowid='id',
    tokenize="unicode61 remove_diacritics 0"
);
CREATE TRIGGER IF NOT EXISTS posts_ai AFTER INSERT ON posts BEGIN
    INSERT INTO posts_fts(rowid, search_blob) VALUES (new.id, new.search_blob);
END;
CREATE TRIGGER IF NOT EXISTS posts_ad AFTER DELETE ON posts BEGIN
    INSERT INTO posts_fts(posts_fts, rowid, search_blob)
    VALUES ('delete', old.id, old.search_blob);
END;
CREATE TRIGGER IF NOT EXISTS posts_au AFTER UPDATE ON posts BEGIN
    INSERT INTO posts_fts(posts_fts, rowid, search_blob)
    VALUES ('delete', old.id, old.search_blob);
    INSERT INTO posts_fts(rowid, search_blob) VALUES (new.id, new.search_blob);
END;

-- تفاعلات المنشورات: إعجاب/تأييد/تعليق. الحذف ناعم (state=removed) للتعليقات.
CREATE TABLE IF NOT EXISTS reactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    member_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    kind        TEXT NOT NULL DEFAULT 'like',
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(post_id, member_handle, kind)
);
CREATE INDEX IF NOT EXISTS idx_reactions_post ON reactions(post_id);

CREATE TABLE IF NOT EXISTS comments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id       INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    author_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    parent_id     INTEGER REFERENCES comments(id) ON DELETE CASCADE,
    body          TEXT NOT NULL,
    state         TEXT NOT NULL DEFAULT 'visible',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id);
CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments(parent_id);

-- مرفقات المنشورات: بيانات وصفية فقط في الدفعات الأولى (بلا محتوى ثنائي).
CREATE TABLE IF NOT EXISTS attachments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id     INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    label       TEXT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'link',
    url         TEXT,
    sensitivity TEXT NOT NULL DEFAULT 'normal',
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_attachments_post ON attachments(post_id);

-- قوائم الكتم/الحجب (على مستوى العضو، للعرض فقط في هذه الدفعة).
CREATE TABLE IF NOT EXISTS member_blocks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    target_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(owner_handle, target_handle)
);

-- إبلاغات عن محتوى المجتمع (تُغذّي طابور الإشراف).
CREATE TABLE IF NOT EXISTS content_reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    target_kind  TEXT NOT NULL,
    target_id    INTEGER NOT NULL,
    reporter_handle TEXT,
    reason       TEXT NOT NULL,
    note         TEXT,
    state        TEXT NOT NULL DEFAULT 'open',
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_content_reports_state ON content_reports(state);

-- مجموعات المجتمع وعضويتها (الدفعة 4)
CREATE TABLE IF NOT EXISTS groups (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    slug         TEXT NOT NULL UNIQUE,
    name         TEXT NOT NULL,
    name_en      TEXT,
    kind         TEXT NOT NULL DEFAULT 'working',
    visibility   TEXT NOT NULL DEFAULT 'public',
    purpose      TEXT,
    purpose_en   TEXT,
    country      TEXT,
    category     TEXT,
    rules        TEXT,
    status       TEXT NOT NULL DEFAULT 'active',
    is_seed      INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_groups_kind ON groups(kind);
CREATE INDEX IF NOT EXISTS idx_groups_visibility ON groups(visibility);

CREATE TABLE IF NOT EXISTS group_members (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id     INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    member_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    role         TEXT NOT NULL DEFAULT 'member',
    status       TEXT NOT NULL DEFAULT 'active',
    joined_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(group_id, member_handle)
);
CREATE INDEX IF NOT EXISTS idx_group_members_group ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_group_members_member ON group_members(member_handle);

-- ربط المنشورات بالمجموعات (تدفّق كل مجموعة).
CREATE TABLE IF NOT EXISTS group_posts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    group_id   INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
    post_id    INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(group_id, post_id)
);
CREATE INDEX IF NOT EXISTS idx_group_posts_group ON group_posts(group_id);

-- المحادثات والرسائل (الدفعة 5). بيانات تجريبية فقط حتى إضافة مصادقة حقيقية.
CREATE TABLE IF NOT EXISTS conversations (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT NOT NULL DEFAULT 'direct',
    title      TEXT,
    title_en   TEXT,
    status     TEXT NOT NULL DEFAULT 'active',
    is_seed    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS conversation_members (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    member_handle   TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    role            TEXT NOT NULL DEFAULT 'member',
    joined_at       TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(conversation_id, member_handle)
);
CREATE INDEX IF NOT EXISTS idx_conv_members_conv ON conversation_members(conversation_id);
CREATE INDEX IF NOT EXISTS idx_conv_members_member ON conversation_members(member_handle);

CREATE TABLE IF NOT EXISTS messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_handle   TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    body            TEXT NOT NULL,
    state           TEXT NOT NULL DEFAULT 'visible',
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id);

-- التحقّق من الحقائق والتوثيق (الدفعة 6)
CREATE TABLE IF NOT EXISTS claims (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    ref             TEXT NOT NULL UNIQUE,
    title           TEXT NOT NULL,
    title_en        TEXT,
    summary         TEXT,
    summary_en      TEXT,
    category        TEXT,
    status          TEXT NOT NULL DEFAULT 'unverified',
    reporter_handle TEXT REFERENCES members(handle) ON DELETE SET NULL,
    assignee_handle TEXT REFERENCES members(handle) ON DELETE SET NULL,
    report_id       INTEGER REFERENCES reports(id) ON DELETE SET NULL,
    is_seed         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
CREATE INDEX IF NOT EXISTS idx_claims_assignee ON claims(assignee_handle);

CREATE TABLE IF NOT EXISTS claim_sources (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    claim_id     INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
    url          TEXT,
    label        TEXT,
    label_en     TEXT,
    kind         TEXT NOT NULL DEFAULT 'secondary',
    reliability  TEXT NOT NULL DEFAULT '3',
    notes        TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_claim_sources_claim ON claim_sources(claim_id);

CREATE TABLE IF NOT EXISTS claim_reviews (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    claim_id        INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
    reviewer_handle TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    decision        TEXT NOT NULL,
    note            TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_claim_reviews_claim ON claim_reviews(claim_id);

CREATE TABLE IF NOT EXISTS claim_timeline (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    claim_id   INTEGER NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
    actor_handle TEXT,
    action     TEXT NOT NULL,
    detail     TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_claim_timeline_claim ON claim_timeline(claim_id);

-- الإشراف والحوكمة (الدفعة 7)
CREATE TABLE IF NOT EXISTS moderation_actions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    target_kind   TEXT NOT NULL,
    target_id     INTEGER NOT NULL,
    target_handle TEXT,
    action        TEXT NOT NULL,
    reason        TEXT NOT NULL,
    moderator     TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    report_id     INTEGER REFERENCES content_reports(id) ON DELETE SET NULL,
    expires_at    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_mod_actions_target ON moderation_actions(target_kind, target_id);
CREATE INDEX IF NOT EXISTS idx_mod_actions_moderator ON moderation_actions(moderator);

CREATE TABLE IF NOT EXISTS appeals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    action_id   INTEGER NOT NULL REFERENCES moderation_actions(id) ON DELETE CASCADE,
    member      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    statement   TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending',
    reviewer    TEXT REFERENCES members(handle) ON DELETE SET NULL,
    review_note TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    reviewed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_appeals_action ON appeals(action_id);
CREATE INDEX IF NOT EXISTS idx_appeals_status ON appeals(status);

CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    actor      TEXT,
    action     TEXT NOT NULL,
    target     TEXT,
    detail     TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

-- السمعة والثقة (الدفعة 8)
CREATE TABLE IF NOT EXISTS endorsements (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    member        TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    endorser      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    dimension     TEXT NOT NULL DEFAULT 'accuracy',
    weight        REAL NOT NULL DEFAULT 1.0,
    note          TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(member, endorser, dimension)
);
CREATE INDEX IF NOT EXISTS idx_endorsements_member ON endorsements(member);

CREATE TABLE IF NOT EXISTS vouches (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    member      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    voucher     TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    kind        TEXT NOT NULL DEFAULT 'peer',
    statement   TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(member, voucher, kind)
);
CREATE INDEX IF NOT EXISTS idx_vouches_member ON vouches(member);

CREATE TABLE IF NOT EXISTS member_badges (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    member     TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    badge      TEXT NOT NULL,
    awarded_by TEXT,
    note       TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(member, badge)
);
CREATE INDEX IF NOT EXISTS idx_member_badges_member ON member_badges(member);

CREATE TABLE IF NOT EXISTS trust_snapshots (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    member     TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    score      REAL NOT NULL DEFAULT 0,
    level      TEXT NOT NULL DEFAULT '0',
    breakdown  TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trust_snapshots_member ON trust_snapshots(member);

-- الإشعارات والتنبيهات (الدفعة 9)
CREATE TABLE IF NOT EXISTS notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    member      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    category    TEXT NOT NULL DEFAULT 'system',
    priority    TEXT NOT NULL DEFAULT 'normal',
    channel     TEXT NOT NULL DEFAULT 'inapp',
    kind        TEXT NOT NULL,
    title       TEXT NOT NULL,
    body        TEXT,
    link        TEXT,
    actor       TEXT,
    subject_kind TEXT,
    subject_id  INTEGER,
    read        INTEGER NOT NULL DEFAULT 0,
    digest_sent INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_member ON notifications(member, read);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at);

CREATE TABLE IF NOT EXISTS notification_prefs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    member          TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    category        TEXT NOT NULL,
    channel         TEXT NOT NULL DEFAULT 'inapp',
    enabled         INTEGER NOT NULL DEFAULT 1,
    muted_until     TEXT,
    UNIQUE(member, category, channel)
);
CREATE INDEX IF NOT EXISTS idx_notification_prefs_member ON notification_prefs(member);

CREATE TABLE IF NOT EXISTS subscriptions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    member       TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    kind         TEXT NOT NULL DEFAULT 'category',
    value        TEXT NOT NULL,
    notify       INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(member, kind, value)
);
CREATE INDEX IF NOT EXISTS idx_subscriptions_member ON subscriptions(member);
CREATE INDEX IF NOT EXISTS idx_subscriptions_kind ON subscriptions(kind, value);

CREATE TABLE IF NOT EXISTS quiet_hours (
    member     TEXT PRIMARY KEY REFERENCES members(handle) ON DELETE CASCADE,
    start_hour INTEGER NOT NULL DEFAULT 22,
    end_hour   INTEGER NOT NULL DEFAULT 7,
    tz         TEXT NOT NULL DEFAULT 'UTC',
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- البحث والاكتشاف (الدفعة 10): بحوث محفوظة
CREATE TABLE IF NOT EXISTS saved_searches (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    member     TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    query      TEXT NOT NULL,
    kinds      TEXT NOT NULL DEFAULT '',
    notify     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(member, query)
);
CREATE INDEX IF NOT EXISTS idx_saved_searches_member ON saved_searches(member);

-- الحملات والمناصرة (الدفعة 11)
CREATE TABLE IF NOT EXISTS campaigns (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    slug         TEXT NOT NULL UNIQUE,
    title        TEXT NOT NULL,
    title_en     TEXT,
    summary      TEXT,
    summary_en   TEXT,
    demands      TEXT,
    audience     TEXT,
    category     TEXT,
    country      TEXT,
    goal         INTEGER NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'active',
    deadline     TEXT,
    risk_level   TEXT NOT NULL DEFAULT 'low',
    ethics_ack   INTEGER NOT NULL DEFAULT 0,
    is_seed      INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);

CREATE TABLE IF NOT EXISTS campaign_team (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id  INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    member       TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    role         TEXT NOT NULL DEFAULT 'volunteer',
    UNIQUE(campaign_id, member)
);
CREATE INDEX IF NOT EXISTS idx_campaign_team_campaign ON campaign_team(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_signatures (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    member        TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    display_name  TEXT,
    anonymous     INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(campaign_id, member)
);
CREATE INDEX IF NOT EXISTS idx_campaign_sigs_campaign ON campaign_signatures(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_targets (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL DEFAULT 'official',
    name          TEXT NOT NULL,
    contact       TEXT,
    verified      INTEGER NOT NULL DEFAULT 0,
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaign_targets_campaign ON campaign_targets(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_pledges (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    target_id     INTEGER REFERENCES campaign_targets(id) ON DELETE SET NULL,
    text          TEXT NOT NULL,
    state         TEXT NOT NULL DEFAULT 'pending',
    due_on        TEXT,
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaign_pledges_campaign ON campaign_pledges(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_events (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    kind          TEXT NOT NULL DEFAULT 'online',
    title         TEXT NOT NULL,
    starts_at     TEXT,
    place         TEXT,
    lat           REAL,
    lng           REAL,
    attendance    INTEGER NOT NULL DEFAULT 0,
    is_seed       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_campaign_events_campaign ON campaign_events(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_updates (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    title         TEXT NOT NULL,
    body          TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_campaign_updates_campaign ON campaign_updates(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_waves (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    label         TEXT NOT NULL,
    scheduled_at  TEXT,
    state         TEXT NOT NULL DEFAULT 'scheduled',
    sent_count    INTEGER NOT NULL DEFAULT 0,
    response_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_campaign_waves_campaign ON campaign_waves(campaign_id);

CREATE TABLE IF NOT EXISTS campaign_media (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    outlet        TEXT NOT NULL,
    kind          TEXT NOT NULL DEFAULT 'press',
    url           TEXT,
    published_on  TEXT,
    sentiment     TEXT NOT NULL DEFAULT 'neutral',
    verified      INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_campaign_media_campaign ON campaign_media(campaign_id);

-- التكامل والأتمتة (الدفعة 12)
CREATE TABLE IF NOT EXISTS api_keys (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    prefix      TEXT NOT NULL,
    scopes      TEXT NOT NULL DEFAULT 'read',
    rate_limit  INTEGER NOT NULL DEFAULT 60,
    version     TEXT NOT NULL DEFAULT 'v1',
    active      INTEGER NOT NULL DEFAULT 1,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    last_used   TEXT
);

CREATE TABLE IF NOT EXISTS api_usage (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key_id  INTEGER NOT NULL REFERENCES api_keys(id) ON DELETE CASCADE,
    day         TEXT NOT NULL,
    count       INTEGER NOT NULL DEFAULT 0,
    UNIQUE(api_key_id, day)
);

CREATE TABLE IF NOT EXISTS webhooks (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    url         TEXT NOT NULL,
    secret      TEXT NOT NULL,
    events      TEXT NOT NULL DEFAULT '',
    active      INTEGER NOT NULL DEFAULT 1,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS webhook_deliveries (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    webhook_id   INTEGER NOT NULL REFERENCES webhooks(id) ON DELETE CASCADE,
    event        TEXT NOT NULL,
    payload      TEXT,
    signature    TEXT,
    state        TEXT NOT NULL DEFAULT 'pending',
    attempts     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    delivered_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_webhook_deliveries_hook ON webhook_deliveries(webhook_id);

CREATE TABLE IF NOT EXISTS connectors (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    name        TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'demo',
    mode        TEXT NOT NULL DEFAULT 'simulated',
    last_sync   TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS automation_rules (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    trigger     TEXT NOT NULL,
    conditions  TEXT,
    actions     TEXT,
    enabled     INTEGER NOT NULL DEFAULT 1,
    run_count   INTEGER NOT NULL DEFAULT 0,
    fail_count  INTEGER NOT NULL DEFAULT 0,
    dangerous   INTEGER NOT NULL DEFAULT 0,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS rule_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id     INTEGER NOT NULL REFERENCES automation_rules(id) ON DELETE CASCADE,
    status      TEXT NOT NULL DEFAULT 'ok',
    detail      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_rule_runs_rule ON rule_runs(rule_id);

CREATE TABLE IF NOT EXISTS jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,
    payload     TEXT,
    state       TEXT NOT NULL DEFAULT 'queued',
    priority    INTEGER NOT NULL DEFAULT 5,
    attempts    INTEGER NOT NULL DEFAULT 0,
    worker      TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    started_at  TEXT,
    finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state);

CREATE TABLE IF NOT EXISTS workers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    status      TEXT NOT NULL DEFAULT 'idle',
    jobs_done   INTEGER NOT NULL DEFAULT 0,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    last_seen   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- الإدارة والتشغيل والتحليلات (الدفعة 13)
CREATE TABLE IF NOT EXISTS system_flags (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS announcements (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    level       TEXT NOT NULL DEFAULT 'info',
    title       TEXT NOT NULL,
    body        TEXT,
    active      INTEGER NOT NULL DEFAULT 1,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS service_health (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    service     TEXT NOT NULL,
    state       TEXT NOT NULL DEFAULT 'ok',
    latency_ms  INTEGER NOT NULL DEFAULT 0,
    error_rate  REAL NOT NULL DEFAULT 0.0,
    checked_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_service_health_service ON service_health(service);

CREATE TABLE IF NOT EXISTS incidents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'warning',
    state       TEXT NOT NULL DEFAULT 'open',
    detail      TEXT,
    postmortem  TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    actor       TEXT,
    action      TEXT NOT NULL,
    target      TEXT,
    detail      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_log_action ON audit_log(action);

CREATE TABLE IF NOT EXISTS retention_policies (
    class       TEXT PRIMARY KEY,
    days        INTEGER NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS roadmap (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    state       TEXT NOT NULL DEFAULT 'planned',
    quarter     TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS governance_decisions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    decision    TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS volunteers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    member      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    hours       REAL NOT NULL DEFAULT 0,
    certified   INTEGER NOT NULL DEFAULT 0,
    is_seed     INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS page_views (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,
    path_bucket TEXT NOT NULL DEFAULT 'other',
    count       INTEGER NOT NULL DEFAULT 0,
    UNIQUE(day, path_bucket)
);

-- الملفات الحسّاسة (الدفعة 14) — بيانات وصفية تجريبية فقط، بلا محتوى أو تشفير فعلي
CREATE TABLE IF NOT EXISTS vault_items (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    owner           TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    title           TEXT NOT NULL,
    kind            TEXT NOT NULL DEFAULT 'document',
    classification  TEXT NOT NULL DEFAULT 'internal',
    state           TEXT NOT NULL DEFAULT 'draft',
    fake_size       INTEGER NOT NULL DEFAULT 0,
    fake_digest     TEXT NOT NULL DEFAULT '',
    note            TEXT,
    is_seed         INTEGER NOT NULL DEFAULT 0,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vault_items_owner ON vault_items(owner);

CREATE TABLE IF NOT EXISTS vault_access (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id     INTEGER NOT NULL REFERENCES vault_items(id) ON DELETE CASCADE,
    member      TEXT NOT NULL REFERENCES members(handle) ON DELETE CASCADE,
    state       TEXT NOT NULL DEFAULT 'pending',
    purpose     TEXT,
    is_seed     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(item_id, member)
);
CREATE INDEX IF NOT EXISTS idx_vault_access_item ON vault_access(item_id);

CREATE TABLE IF NOT EXISTS vault_receipts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id     INTEGER NOT NULL REFERENCES vault_items(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL,
    actor       TEXT,
    detail      TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_vault_receipts_item ON vault_receipts(item_id);

CREATE TABLE IF NOT EXISTS vault_policies (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============ المصادقة (تسجيل الدخول/الإنشاء) ============
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT,
    display_name  TEXT NOT NULL,
    avatar_url    TEXT,
    role          TEXT NOT NULL DEFAULT 'member',
    status        TEXT NOT NULL DEFAULT 'active',
    created_at    TEXT NOT NULL DEFAULT (datetime('now')),
    last_login_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email
    ON users(email) WHERE email IS NOT NULL;

-- هويّات المزوّدين (google/github/x/...): ربط الحساب بمزوّده الخارجي.
CREATE TABLE IF NOT EXISTS user_identities (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider     TEXT NOT NULL,
    provider_uid TEXT NOT NULL,
    email        TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_provider
    ON user_identities(provider, provider_uid);
CREATE INDEX IF NOT EXISTS idx_identity_user ON user_identities(user_id);

-- الجلسات: تُخزَّن بصمة الرمز فقط (لا الرمز نفسه) لتفادي تسرّبه.
CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at TEXT NOT NULL,
    user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

-- تبرّعات (بيئة تجريبية: تُسجَّل النيّة فقط، بلا بوابة دفع حقيقية).
CREATE TABLE IF NOT EXISTS donations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT NOT NULL,              -- coffee | charity
    amount       REAL,
    currency     TEXT NOT NULL DEFAULT 'USD',
    frequency    TEXT NOT NULL DEFAULT 'once',  -- once | monthly
    target_key   TEXT,                       -- مفتاح المنظّمة عند تبرّع الخيرية
    target_name  TEXT,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    donor_name   TEXT,
    message      TEXT,
    anonymous    INTEGER NOT NULL DEFAULT 0,
    status       TEXT NOT NULL DEFAULT 'recorded',  -- recorded | completed | cancelled
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_donations_kind ON donations(kind, created_at);

CREATE TABLE IF NOT EXISTS donation_stats (
    key         TEXT PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ===========================================================================
-- منظومة الرصد والتحقق والتحقق الآلي المستمر (Monitoring & Verification).
-- الفصل منطقي بين: الواقعة الأساسية (reports)، المستندات المستلمة (documents)،
-- علاقات المصادر بالوقائع، تاريخ التغييرات، حالات التحقق، المهام والأخطاء.
-- ===========================================================================

-- المستندات المستلمة: المحتوى المستخرج وبياناته الأصلية وبصمته ووقت جلبه.
-- عنصر واحد من مصدر واحد. لا يصبح بلاغًا حتى يجتاز خط المعالجة والتحقق.
CREATE TABLE IF NOT EXISTS documents (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source_key     TEXT,
    source_name    TEXT,
    source_url     TEXT,
    url            TEXT NOT NULL,
    canonical_url  TEXT,
    external_id    TEXT,
    title          TEXT,
    title_en       TEXT,
    summary        TEXT,
    body           TEXT,
    raw            TEXT,                    -- نسخة المحتوى الأصلي للتحقق
    content_digest TEXT,                    -- بصمة المحتوى (كشف التكرار الدقيق)
    content_hash   TEXT,                    -- بصمة النصّ المطبَّع (تشابه)
    lang           TEXT,
    published_on   TEXT,
    occurred_on    TEXT,                    -- تاريخ الواقعة إن توفر
    fetched_at     TEXT NOT NULL DEFAULT (datetime('now')),
    category       TEXT,
    severity       TEXT,
    doc_type       TEXT NOT NULL DEFAULT 'news',  -- violation|report|news|correction|claim
    tags           TEXT,                    -- وسوم متعدّدة (JSON)
    country        TEXT,
    region         TEXT,
    entities       TEXT,                    -- الجهات المستخرجة (JSON)
    stage          TEXT NOT NULL DEFAULT 'ingested',
    state          TEXT NOT NULL DEFAULT 'pending',  -- pending|processed|review|rejected
    report_id      INTEGER REFERENCES reports(id) ON DELETE SET NULL,
    dup_of         INTEGER REFERENCES documents(id) ON DELETE SET NULL,
    dup_reason     TEXT,
    confidence     REAL,
    UNIQUE(source_key, external_id)
);
CREATE INDEX IF NOT EXISTS idx_documents_state ON documents(state, stage);
CREATE INDEX IF NOT EXISTS idx_documents_digest ON documents(content_digest);
CREATE INDEX IF NOT EXISTS idx_documents_hash ON documents(content_hash);
CREATE INDEX IF NOT EXISTS idx_documents_url ON documents(canonical_url);
CREATE INDEX IF NOT EXISTS idx_documents_report ON documents(report_id);
CREATE INDEX IF NOT EXISTS idx_documents_fetched ON documents(fetched_at DESC);

-- علاقات المصادر بالوقائع: ما الذي يدعمه كل مصدر، وهل هو مستقل أم منقول عن غيره.
CREATE TABLE IF NOT EXISTS evidence (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id     INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    document_id   INTEGER REFERENCES documents(id) ON DELETE SET NULL,
    source_key    TEXT,
    source_name   TEXT NOT NULL,
    source_url    TEXT,
    source_kind   TEXT NOT NULL DEFAULT 'secondary', -- primary|secondary|testimony|official|derived
    reliability   REAL NOT NULL DEFAULT 0.5,
    independence  TEXT NOT NULL DEFAULT 'unknown',    -- independent|derived|unknown
    derived_from  TEXT,                               -- المصدر الأصلي عند النقل
    supports      TEXT NOT NULL DEFAULT 'supports',   -- supports|contradicts|corrects|context
    note          TEXT,
    added_by      TEXT NOT NULL DEFAULT 'system',
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_evidence_report ON evidence(report_id);
CREATE INDEX IF NOT EXISTS idx_evidence_source ON evidence(source_key);

-- تاريخ التغييرات: القيم القديمة والجديدة وسبب التعديل ومصدره ووقت التنفيذ.
CREATE TABLE IF NOT EXISTS change_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    entity      TEXT NOT NULL,             -- reports|documents|evidence|verification
    entity_id   INTEGER NOT NULL,
    field       TEXT,
    old_value   TEXT,
    new_value   TEXT,
    reason      TEXT,
    source      TEXT,
    actor       TEXT NOT NULL DEFAULT 'system',
    task_id     TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_change_entity ON change_history(entity, entity_id);
CREATE INDEX IF NOT EXISTS idx_change_created ON change_history(created_at DESC);

-- حالات التحقق: حالة كل ادعاء ووقت تقييمه والأسباب والأدلة المرتبطة به.
CREATE TABLE IF NOT EXISTS verification_records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id     INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    state         TEXT NOT NULL DEFAULT 'new',  -- new|checking|multi_source|verified|disputed|corrected|withdrawn|unresolved
    confidence    REAL NOT NULL DEFAULT 0.0,
    badge         INTEGER NOT NULL DEFAULT 0,    -- شارة «موثّق من مصادر مستقلة»
    reasons       TEXT,                          -- أسباب التقييم (JSON)
    criteria      TEXT,                          -- تفصيل المعايير (JSON)
    independent_sources INTEGER NOT NULL DEFAULT 0,
    conflicting   INTEGER NOT NULL DEFAULT 0,
    prev_state    TEXT,
    note          TEXT,
    evaluated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    evaluated_by  TEXT NOT NULL DEFAULT 'system'
);
CREATE INDEX IF NOT EXISTS idx_verification_report ON verification_records(report_id, evaluated_at DESC);
CREATE INDEX IF NOT EXISTS idx_verification_state ON verification_records(state);

-- المهام والأخطاء: طابور المهام ودورات الجلب والمعالجة وإعادة المحاولة والنتائج.
CREATE TABLE IF NOT EXISTS task_queue (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id      TEXT NOT NULL UNIQUE,       -- معرّف تنفيذ فريد (منع التكرار)
    kind         TEXT NOT NULL,              -- collect|process|verify|reconcile|backfill
    priority     INTEGER NOT NULL DEFAULT 5, -- 1 أعلى
    payload      TEXT,                       -- JSON
    state        TEXT NOT NULL DEFAULT 'queued', -- queued|running|done|failed|dead
    attempts     INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    available_at TEXT NOT NULL DEFAULT (datetime('now')),
    locked_at    TEXT,
    last_error   TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_task_state ON task_queue(state, available_at);
CREATE INDEX IF NOT EXISTS idx_task_kind ON task_queue(kind, state);
CREATE INDEX IF NOT EXISTS idx_task_priority ON task_queue(state, priority, available_at);

-- تقدّم الاستيراد التاريخي والأرشيف لكل مصدر (لاستكمال العملية بعد التعطل).
CREATE TABLE IF NOT EXISTS archive_progress (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source_key    TEXT NOT NULL UNIQUE,
    status        TEXT NOT NULL DEFAULT 'pending', -- pending|running|done|partial|blocked
    cursor        TEXT,                            -- موضع التقدّم (صفحة/تاريخ/رابط)
    range_start   TEXT,
    range_end     TEXT,
    covered_start TEXT,                            -- النطاق التاريخي الذي جرى
    covered_end   TEXT,
    inaccessible  TEXT,                            -- الفترات التي تعذّر الوصول إليها (JSON)
    batches_done  INTEGER NOT NULL DEFAULT 0,
    items_found   INTEGER NOT NULL DEFAULT 0,
    items_imported INTEGER NOT NULL DEFAULT 0,
    note          TEXT,
    updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_archive_status ON archive_progress(status);

-- سجل دورات المنظومة: كل دورة (جمع/معالجة/تحقق/مصالحة) ونتيجتها.
CREATE TABLE IF NOT EXISTS monitoring_runs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    kind          TEXT NOT NULL,              -- collect|verify|reconcile|backfill|process
    started_at    TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at   TEXT,
    state         TEXT NOT NULL DEFAULT 'running',
    sources_checked INTEGER NOT NULL DEFAULT 0,
    items_fetched INTEGER NOT NULL DEFAULT 0,
    items_processed INTEGER NOT NULL DEFAULT 0,
    added         INTEGER NOT NULL DEFAULT 0,
    updated       INTEGER NOT NULL DEFAULT 0,
    duplicates    INTEGER NOT NULL DEFAULT 0,
    review        INTEGER NOT NULL DEFAULT 0,
    errors        INTEGER NOT NULL DEFAULT 0,
    summary       TEXT
);
CREATE INDEX IF NOT EXISTS idx_monitoring_kind ON monitoring_runs(kind, started_at DESC);

-- التنبيهات: أولوية التنبيه منفصلة عن حالة التحقق.
CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,       -- possible_violation|new_claim|independent_source|conflict|correction|source_down|backlog
    severity    TEXT NOT NULL DEFAULT 'info', -- info|warning|critical
    report_id   INTEGER REFERENCES reports(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    detail      TEXT,
    source      TEXT,
    acked       INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_acked ON alerts(acked, severity);

-- البحث النصّي الكامل (يعتمد على عمود search_blob المطبَّع)
CREATE VIRTUAL TABLE IF NOT EXISTS reports_fts USING fts5(
    search_blob,
    content='reports', content_rowid='id',
    tokenize="unicode61 remove_diacritics 0"
);

CREATE TRIGGER IF NOT EXISTS reports_ai AFTER INSERT ON reports BEGIN
    INSERT INTO reports_fts(rowid, search_blob) VALUES (new.id, new.search_blob);
END;
CREATE TRIGGER IF NOT EXISTS reports_ad AFTER DELETE ON reports BEGIN
    INSERT INTO reports_fts(reports_fts, rowid, search_blob)
    VALUES ('delete', old.id, old.search_blob);
END;
CREATE TRIGGER IF NOT EXISTS reports_au AFTER UPDATE ON reports BEGIN
    INSERT INTO reports_fts(reports_fts, rowid, search_blob)
    VALUES ('delete', old.id, old.search_blob);
    INSERT INTO reports_fts(rowid, search_blob) VALUES (new.id, new.search_blob);
END;
"""

# مصادر مفتوحة مُدرجة في السجل — تُستخدم للربط والإسناد
OPEN_SOURCES = [
    ("ucdp_ged", "برنامج بيانات النزاعات Uppsala (UCDP GED)",
     "https://ucdp.uu.se/downloads/", "open_dataset", "CC BY 4.0"),
    ("acled", "مشروع بيانات مواقع النزاع المسلح (ACLED)",
     "https://acleddata.com/", "open_dataset", "CC BY-NC 4.0"),
    ("gdelt", "مشروع GDELT لرصد الأحداث العالمية",
     "https://www.gdeltproject.org/", "open_dataset", "CC BY 4.0"),
    ("ilostat", "قاعدة بيانات العمل الدولية (ILOSTAT)",
     "https://ilostat.ilo.org/", "open_dataset", "CC BY 4.0"),
    ("who_gho", "المرصد الصحي العالمي لمنظمة الصحة العالمية",
     "https://www.who.int/data/gho", "open_dataset", "CC BY-NC-SA 3.0 IGO"),
    ("wikidata", "ويكيداتا — قاعدة المعرفة الحرة",
     "https://www.wikidata.org/", "open_dataset", "CC0"),
    ("restcountries", "مجموعة بيانات الدول المفتوحة (mledoze/countries)",
     "https://github.com/mledoze/countries", "open_dataset", "ODbL"),
    ("worldbank", "مؤشرات التنمية العالمية — البنك الدولي",
     "https://data.worldbank.org/", "open_dataset", "CC BY 4.0"),
    ("unhcr", "مفوضية اللاجئين — بيانات السكان",
     "https://www.unhcr.org/refugee-statistics/", "open_dataset", "CC BY 4.0"),
    ("fao", "منظمة الأغذية والزراعة (FAOSTAT)",
     "https://www.fao.org/faostat/", "open_dataset", "CC BY 4.0"),
    ("gbif", "المرفق العالمي لمعلومات التنوّع الحيوي",
     "https://www.gbif.org/", "open_dataset", "CC BY 4.0"),
    ("opensanctions", "OpenSanctions — قوائم العقوبات والمسؤولين",
     "https://www.opensanctions.org/", "open_dataset", "CC BY 4.0"),
    ("freedomhouse", "فريدوم هاوس — الحريات في العالم",
     "https://freedomhouse.org/report/freedom-world", "open_dataset", "CC BY 4.0"),
    ("vdem", "مشروع V-Dem — متغيّرات الديمقراطية",
     "https://www.v-dem.net/data/", "open_dataset", "CC BY-SA 4.0"),
    ("climatetrace", "مبادرة تتبّع الانبعاثات (Climate TRACE)",
     "https://climatetrace.org/", "open_dataset", "CC BY 4.0"),
    ("ituc", "مؤشر حقوق العمل العالمية (ITUC)",
     "https://www.ituc-csi.org/rights-index", "open_dataset", "CC BY 4.0"),
    ("manual", "بلاغ مباشر عبر المنصة", None, "manual", None),
    ("hrw", "هيومن رايتس ووتش (HRW)", "https://www.hrw.org/", "news_feed", "CC BY-NC-SA 3.0"),
    ("amnesty", "منظمة العفو الدولية (Amnesty)", "https://www.amnesty.org/",
     "news_feed", "CC BY-NC-ND 4.0"),
    ("ohchr", "المفوضية السامية لحقوق الإنسان (OHCHR)", "https://www.ohchr.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("fidh", "الاتحاد الدولي لحقوق الإنسان (FIDH)", "https://www.fidh.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("un_news_hr", "أخبار الأمم المتحدة — حقوق الإنسان",
     "https://news.un.org/en/", "news_feed", "CC BY 4.0"),
    ("un_news_env", "أخبار الأمم المتحدة — البيئة",
     "https://news.un.org/en/", "news_feed", "CC BY 4.0"),
    ("un_news_women", "أخبار الأمم المتحدة — المرأة",
     "https://news.un.org/en/", "news_feed", "CC BY 4.0"),
    ("greenpeace", "غرين بيس (Greenpeace)", "https://www.greenpeace.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("unep", "برنامج الأمم المتحدة للبيئة (UNEP)", "https://www.unep.org/",
     "news_feed", "CC BY-SA 3.0 IGO"),
    ("insideclimate", "Inside Climate News", "https://insideclimatenews.org/",
     "news_feed", "CC BY-NC-ND 4.0"),
    ("solidaritycenter", "مركز التضامن (Solidarity Center)",
     "https://www.solidaritycenter.org/", "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("un_news_econ", "أخبار الأمم المتحدة — التنمية الاقتصادية",
     "https://news.un.org/en/", "news_feed", "CC BY 4.0"),
    ("irin", "ذا نيو هيومانيتريان (TNH)", "https://www.thenewhumanitarian.org/",
     "news_feed", "CC BY-NC-ND 4.0"),
    ("migrationpolicy", "معهد سياسات الهجرة (MPI)", "https://www.migrationpolicy.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("uscirf", "اللجنة الأمريكية للحرية الدينية الدولية (USCIRF)",
     "https://www.uscirf.gov/", "news_feed", "ملكية عامة (حكومة أمريكية)"),
    ("pew_religion", "مركز بيو للأبحاث — الدين", "https://www.pewresearch.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("religionnews", "Religion News Service", "https://religionnews.com/",
     "news_feed", "CC BY-NC-ND 4.0"),
    ("aiindex_rss", "مؤشر الذكاء الاصطناعي (Stanford HAI)",
     "https://aiindex.stanford.edu/", "news_feed", "CC BY-ND 4.0"),
    ("ainow", "معهد AI Now", "https://ainowinstitute.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("accessnow", "Access Now", "https://www.accessnow.org/",
     "news_feed", "CC BY 4.0"),
    ("eff", "مؤسسة الحدود الإلكترونية (EFF)", "https://www.eff.org/",
     "news_feed", "CC BY 3.0 US"),
    ("peta", "بيتا (PETA)", "https://www.peta.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("sea_shepherd", "Sea Shepherd", "https://seashepherd.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("animal_equality", "Animal Equality", "https://www.animalequality.org/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
    ("vegnews", "VegNews", "https://vegnews.com/",
     "news_feed", "بيانات مرجعية (استخدام غير تجاري)"),
]


def connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # WAL يسمح بالقراءة المتزامنة مع الكتابة؛ مناسب لخادم متعدّد الطلبات.
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def _schema_version(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute(
            "SELECT value FROM schema_meta WHERE key = 'version'"
        ).fetchone()
        return int(row["value"]) if row else 0
    except sqlite3.OperationalError:
        return 0


def _migrate(conn: sqlite3.Connection) -> None:
    """ترحيل تدريجي يحافظ على البيانات: يضيف الأعمدة/الجداول الناقصة."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(reports)")}
    if "dedup_key" not in cols:
        conn.execute("ALTER TABLE reports ADD COLUMN dedup_key TEXT")
    # أعمدة الرصد والتحقق (لقواعد أقدم من SCHEMA_VERSION 23).
    for col, decl in (("verification_state", "TEXT"), ("confidence", "REAL"),
                      ("badge", "INTEGER NOT NULL DEFAULT 0"), ("content_digest", "TEXT"),
                      ("discovered_at", "TEXT"), ("updated_at", "TEXT")):
        if col not in cols:
            conn.execute(f"ALTER TABLE reports ADD COLUMN {col} {decl}")
    # أعمدة الاكتشاف على فهرس المصادر (لقواعد أقدم من SCHEMA_VERSION 22).
    cat_cols = {r["name"] for r in conn.execute("PRAGMA table_info(source_catalog)")}
    for col, decl in (("source_kind", "TEXT"), ("coverage", "TEXT"), ("access", "TEXT"),
                      ("group_key", "TEXT"), ("categories", "TEXT"),
                      ("discovered", "INTEGER NOT NULL DEFAULT 0")):
        if cat_cols and col not in cat_cols:
            conn.execute(f"ALTER TABLE source_catalog ADD COLUMN {col} {decl}")
    # جداول المصادقة/التبرّعات تُنشأ ضمن SCHEMA عبر executescript لاحقاً؛
    # هنا نُهيّئ جداول المصادقة إن كانت القاعدة أقدم لتفادي أخطاء الاستعلام.
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            email         TEXT,
            display_name  TEXT NOT NULL,
            avatar_url    TEXT,
            role          TEXT NOT NULL DEFAULT 'member',
            status        TEXT NOT NULL DEFAULT 'active',
            created_at    TEXT NOT NULL DEFAULT (datetime('now')),
            last_login_at TEXT
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email
            ON users(email) WHERE email IS NOT NULL;
        CREATE TABLE IF NOT EXISTS user_identities (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            provider     TEXT NOT NULL,
            provider_uid TEXT NOT NULL,
            email        TEXT,
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_provider
            ON user_identities(provider, provider_uid);
        CREATE INDEX IF NOT EXISTS idx_identity_user ON user_identities(user_id);
        CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            expires_at TEXT NOT NULL,
            user_agent TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
        CREATE TABLE IF NOT EXISTS donations (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            kind         TEXT NOT NULL,
            amount       REAL,
            currency     TEXT NOT NULL DEFAULT 'USD',
            frequency    TEXT NOT NULL DEFAULT 'once',
            target_key   TEXT,
            target_name  TEXT,
            user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
            donor_name   TEXT,
            message      TEXT,
            anonymous    INTEGER NOT NULL DEFAULT 0,
            status       TEXT NOT NULL DEFAULT 'recorded',
            created_at   TEXT NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS idx_donations_kind ON donations(kind, created_at);
        CREATE TABLE IF NOT EXISTS donation_stats (
            key         TEXT PRIMARY KEY,
            value       TEXT NOT NULL,
            updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
        );
        """
    )


def init_db(force: bool = False) -> None:
    """ينشئ الجداول ويعبّئها. يُرحّل تدريجياً بدل حذف البيانات عند تغيّر المخطّط."""
    if force and os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = connect()
    try:
        if os.path.exists(DB_PATH) and _schema_version(conn) not in (0, SCHEMA_VERSION):
            # ترحيل في المكان بدل حذف القاعدة (نحفظ البلاغات المستوردة).
            _migrate(conn)

        conn.executescript(SCHEMA)
        conn.execute(
            "INSERT OR REPLACE INTO schema_meta(key, value) VALUES('version', ?)",
            (str(SCHEMA_VERSION),),
        )
        _seed_sources(conn)
        _sync_catalog(conn)
        count = conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()["n"]
        if count == 0:
            _seed(conn)
        else:
            # مجالات أُضيفت بعد التهيئة الأولى: تُزرع بياناتها دون المساس بالقائم.
            _seed_missing_categories(conn)
        # أعضاء المنصّة الاجتماعية (بيانات عرض) — تُعبّأ إن كان الجدول فارغًا.
        from . import social
        social.seed_members(conn)
        social.seed_posts(conn)
        social.seed_interactions(conn)
        social.seed_groups(conn)
        social.seed_conversations(conn)
        social.seed_claims(conn)
        social.seed_moderation(conn)
        social.seed_reputation(conn)
        social.seed_notifications(conn)
        from . import search as search_mod
        search_mod.seed_searches(conn)
        from . import campaigns as campaigns_mod
        campaigns_mod.seed_campaigns(conn)
        from . import integrations as integrations_mod
        integrations_mod.seed_integrations(conn)
        from . import ops as ops_mod
        ops_mod.seed_admin(conn)
        from . import sensitive as sensitive_mod
        sensitive_mod.seed_vault(conn)
        # تبرّعات عرضية + تنظيف الجلسات المنتهية.
        from . import donations as donations_mod
        donations_mod.seed_donations(conn)
        from . import auth as auth_mod
        auth_mod.purge_expired(conn)
        conn.commit()
    finally:
        conn.close()


def _sync_catalog(conn: sqlite3.Connection) -> None:
    """يزامن فهرس المصادر الواسع (≈1000 مصدر) من `app/catalog.py`."""
    try:
        from .catalog import build_catalog
        sync_catalog(conn, build_catalog())
    except Exception:  # noqa: BLE001 — لا نُفشل الإقلاع بسبب الفهرس
        pass


def _seed_sources(conn: sqlite3.Connection) -> None:
    conn.executemany(
        """INSERT OR IGNORE INTO sources(key, name, url, kind, license)
           VALUES (?,?,?,?,?)""",
        OPEN_SOURCES,
    )


# ---------------------------------------------------------------------------
# البيانات الأولية: في وحدة منفصلة لتسهيل الصيانة والتوسيع.
# ---------------------------------------------------------------------------


def _seed(conn: sqlite3.Connection) -> None:
    conn.executemany(
        """INSERT INTO reports
           (title, title_en, category, severity, status, country, country_code, region, lat, lng,
            occurred_on, reported_on, summary, summary_en, details, source_name, source_url,
            source_id, verified, search_blob)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        _build_seed_rows(conn),
    )
    _seed_entities(conn)


def _build_seed_rows(conn: sqlite3.Connection, only_categories: set[str] | None = None) -> list:
    """يبني صفوف الإدراج من `SEED_ROWS` (اختياريًّا لمجالات محدّدة فقط)."""
    today = date.today()
    src_ids = {r["key"]: r["id"] for r in conn.execute("SELECT id, key FROM sources")}
    rows = []
    for i, (title, cat, sev, status, country, region, days_ago, summary, source, src_key) in enumerate(SEED_ROWS):
        if only_categories is not None and cat not in only_categories:
            continue
        # توزيع البلاغات على عدة سنوات (بيانات عرض) ليصبح التتبّع السنوي ذا معنى.
        spread = timedelta(days=365 * (i % 4) + (i % 7) * 11)
        occurred = today - timedelta(days=days_ago + 5) - spread
        reported = today - timedelta(days=days_ago) - spread
        title_en, summary_en = SEED_EN.get(title, (None, None))
        details = (
            f"{summary} يندرج هذا البلاغ ضمن فئة «{_cat_name(cat)}» بمستوى خطورة «{_sev_name(sev)}». "
            "تتضمّن المادة الأولية شهادات ميدانية ووثائق تُراجَع من فريق التحقق قبل النشر النهائي. "
            "تُحدَّث حالة البلاغ كلما توفّرت معطيات إضافية أو ردود رسمية."
        )
        verified = 1 if status in ("verified", "action_taken") else 0
        c = coords(country) or [None, None]
        blob = build_search_text(title, summary, details, country, region or "", source)
        rows.append((
            title, title_en, cat, sev, status, country, iso3(country), region,
            c[0], c[1], occurred.isoformat(), reported.isoformat(), summary, summary_en, details,
            source, f"https://example.org/reports/{1000 + i}", src_ids.get(src_key), verified, blob,
        ))
    return rows


def _seed_missing_categories(conn: sqlite3.Connection) -> int:
    """يزرع بيانات المجالات التي لا تحتوي أي بلاغ.

    ضروري حين تُضاف مجالات جديدة بعد التهيئة الأولى (لا يُعاد `_seed` الكامل
    لأن الجدول غير فارغ). يزرع فقط المجالات الناقصة دون المساس بالبيانات القائمة.
    """
    have = {r["category"] for r in conn.execute("SELECT DISTINCT category FROM reports")}
    missing = set(CATEGORY_KEYS) - have
    if not missing:
        return 0
    rows = _build_seed_rows(conn, only_categories=missing)
    if not rows:
        return 0
    conn.executemany(
        """INSERT INTO reports
           (title, title_en, category, severity, status, country, country_code, region, lat, lng,
            occurred_on, reported_on, summary, summary_en, details, source_name, source_url,
            source_id, verified, search_blob)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    _seed_entities(conn)
    return len(rows)


def _seed_entities(conn: sqlite3.Connection) -> None:
    """يضيف كيانات كل بلاغ: المصدر + الدولة + الجهات المطابقة آلياً.

    تُطابَق الأسماء والمرادفات من `actors.ACTORS` داخل نص البلاغ، ما يجعل
    صفحات الكيانات (شركات، أفراد، منظّمات، حكومات) ممتلئة ببيانات مترابطة.
    """
    from . import actors

    reports = conn.execute(
        "SELECT id, title, summary, details, country, source_name FROM reports "
        "WHERE NOT EXISTS (SELECT 1 FROM entities e WHERE e.report_id = reports.id)"
    ).fetchall()
    rows = []
    for r in reports:
        seen: set[str] = set()
        if r["source_name"]:
            kind = "organization"
            if actors.by_name(r["source_name"]):
                kind = actors.by_name(r["source_name"])["kind"]
            rows.append((r["id"], r["source_name"], kind, None))
            seen.add(r["source_name"])
        if r["country"]:
            rows.append((r["id"], r["country"], "country", None))
            seen.add(r["country"])
        haystack = " ".join(filter(None, [r["title"], r["summary"], r["details"]]))
        for actor in actors.match_actors(haystack):
            if actor["name"] not in seen:
                rows.append((r["id"], actor["name"], actor["kind"], None))
                seen.add(actor["name"])
    if rows:
        conn.executemany(
            "INSERT INTO entities(report_id, name, kind, wikidata_id) VALUES (?,?,?,?)",
            rows,
        )
    conn.commit()


def _cat_name(key: str) -> str:
    return next((c["name"] for c in CATEGORIES if c["key"] == key), key)


def _sev_name(key: str) -> str:
    return next((s["label"] for s in SEVERITIES if s["key"] == key), key)


# ---------------------------------------------------------------------------
# الاستعلامات
# ---------------------------------------------------------------------------

_SEV_ORDER = ("CASE severity WHEN 'critical' THEN 4 WHEN 'high' THEN 3 "
              "WHEN 'medium' THEN 2 ELSE 1 END")


def _build_filters(
    *,
    category: str | None = None,
    severity: str | None = None,
    status: str | None = None,
    country: str | None = None,
    category_in: list[str] | None = None,
    severity_in: list[str] | None = None,
    search: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    verified: bool | None = None,
) -> tuple[list[str], list, bool]:
    """يبني شروط WHERE المشتركة بين الاستعلام والعدّ. يعيد (شروط، معاملات، use_fts)."""
    where, params = [], []
    use_fts = bool(search and search.strip())
    if use_fts:
        where.append("reports_fts MATCH ?")
        params.append(_fts_query(search))
    if category:
        where.append("category = ?"); params.append(category)
    if category_in:
        where.append(f"category IN ({','.join('?' * len(category_in))})"); params += category_in
    if severity:
        where.append("severity = ?"); params.append(severity)
    if severity_in:
        where.append(f"severity IN ({','.join('?' * len(severity_in))})"); params += severity_in
    if status:
        where.append("status = ?"); params.append(status)
    if country:
        where.append("country = ?"); params.append(country)
    if date_from:
        where.append("reported_on >= ?"); params.append(date_from)
    if date_to:
        where.append("reported_on <= ?"); params.append(date_to)
    if verified is not None:
        where.append("verified = ?"); params.append(1 if verified else 0)
    return where, params, use_fts


def query_reports(
    conn: sqlite3.Connection,
    *,
    category: str | None = None,
    severity: str | None = None,
    status: str | None = None,
    country: str | None = None,
    category_in: list[str] | None = None,
    severity_in: list[str] | None = None,
    search: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    verified: bool | None = None,
    sort: str = "recent",
    limit: int | None = None,
    offset: int = 0,
) -> list[dict[str, Any]]:
    where, params, use_fts = _build_filters(
        category=category, severity=severity, status=status, country=country,
        category_in=category_in, severity_in=severity_in, search=search,
        date_from=date_from, date_to=date_to, verified=verified)

    order = {
        "recent": "reported_on DESC, id DESC",
        "oldest": "reported_on ASC, id ASC",
        "occurred": "COALESCE(occurred_on, reported_on) DESC, id DESC",
        "occurred_asc": "COALESCE(occurred_on, reported_on) ASC, id ASC",
        "severity": f"{_SEV_ORDER} DESC, reported_on DESC",
        "title": "title ASC",
        "verified": "verified DESC, reported_on DESC, id DESC",
        "relevance": "rank ASC" if use_fts else "reported_on DESC",
    }.get(sort, "reported_on DESC, id DESC")

    if use_fts:
        select = "SELECT r.*, bm25(reports_fts) AS rank FROM reports r JOIN reports_fts ON reports_fts.rowid = r.id"
    else:
        select = "SELECT * FROM reports"

    sql = select
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {order}"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def _fts_query(text: str) -> str:
    """يبني استعلام FTS آمن من نص مطبَّع: كل كلمة بادئة مطابقة."""
    tokens = tokenize(text)
    if not tokens:
        return '""'
    return " AND ".join(f'"{t}"*' for t in tokens)


def timeline_milestones(conn: sqlite3.Connection, limit: int = 6) -> list[dict]:
    """محطات الخط الزمني للرئيسية: بلاغ بارز واحد لكل شهر (الأحدث أولًا).

    يختار لكل شهر بلاغًا واحدًا (الأعلى خطورة ثم الأحدث). تُحدَّد أحدث الأشهر
    أولاً عبر الفهرس التعبيري (`idx_reports_ym`) مع إيقاف مبكر، ثم يُجلب البلاغ
    البارز لكل شهر باستعلام صغير — أسرع بكثير من نافذة على كامل الجدول.
    """
    months = conn.execute(
        """SELECT ym FROM (
             SELECT substr(COALESCE(occurred_on, reported_on), 1, 7) AS ym
             FROM reports
             GROUP BY ym ORDER BY ym DESC LIMIT ?
           ) WHERE ym IS NOT NULL""", (int(limit),),
    ).fetchall()
    out: list[dict] = []
    for m in months:
        row = conn.execute(
            f"""SELECT * FROM reports
                WHERE substr(COALESCE(occurred_on, reported_on), 1, 7) = ?
                ORDER BY {_SEV_ORDER} DESC,
                         COALESCE(occurred_on, reported_on) DESC, id DESC
                LIMIT 1""", (m["ym"],),
        ).fetchone()
        if row:
            out.append(dict(row))
    return out


def count_recent(conn: sqlite3.Connection, days: int = 7) -> int:
    """عدد البلاغات المُضافة خلال آخر `days` يومًا (لعدّاد «جديد» في التنقّل)."""
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM reports WHERE created_at >= datetime('now', ?)",
        (f"-{int(days)} days",),
    ).fetchone()
    return row["n"] if row else 0


def count_since(conn: sqlite3.Connection, since: str) -> int:
    """عدد البلاغات المُضافة بعد طابع زمني معيّن (لعدّاد «جديد منذ زيارتك»)."""
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM reports WHERE created_at > ?", (since,)
    ).fetchone()
    return row["n"] if row else 0


def latest_created_at(conn: sqlite3.Connection) -> str | None:
    row = conn.execute("SELECT MAX(created_at) AS m FROM reports").fetchone()
    return row["m"] if row else None


def count_reports(conn: sqlite3.Connection, **filters: Any) -> int:
    """عدد البلاغات المطابقة للمرشّحات عبر استعلام COUNT مباشر (لا يجلب الصفوف)."""
    allowed = ("category", "severity", "status", "country", "search",
               "date_from", "date_to", "category_in", "severity_in", "verified")
    where, params, use_fts = _build_filters(
        **{k: v for k, v in filters.items() if k in allowed})
    if use_fts:
        sql = ("SELECT COUNT(*) AS n FROM reports r "
               "JOIN reports_fts ON reports_fts.rowid = r.id")
    else:
        sql = "SELECT COUNT(*) AS n FROM reports"
    if where:
        sql += " WHERE " + " AND ".join(where)
    return int(conn.execute(sql, params).fetchone()["n"])


def get_report(conn: sqlite3.Connection, report_id: int) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    return dict(row) if row else None


def related_reports(conn: sqlite3.Connection, report: dict[str, Any], limit: int = 4) -> list[dict]:
    rows = conn.execute(
        """SELECT * FROM reports WHERE category = ? AND id != ?
           ORDER BY reported_on DESC LIMIT ?""",
        (report["category"], report["id"], limit),
    ).fetchall()
    return [dict(r) for r in rows]


def adjacent_reports(conn: sqlite3.Connection, report_id: int) -> dict[str, dict | None]:
    """البلاغ السابق/التالي في السجل مرتَّبًا بالمعرّف (للتنقّل بين البلاغات)."""
    prev_row = conn.execute(
        "SELECT id, title FROM reports WHERE id < ? ORDER BY id DESC LIMIT 1",
        (report_id,),
    ).fetchone()
    next_row = conn.execute(
        "SELECT id, title FROM reports WHERE id > ? ORDER BY id ASC LIMIT 1",
        (report_id,),
    ).fetchone()
    return {
        "prev": dict(prev_row) if prev_row else None,
        "next": dict(next_row) if next_row else None,
    }


def stats(conn: sqlite3.Connection) -> dict[str, Any]:
    """إحصاءات مجمّعة على كامل الجدول.

    ثقيلة (عدّة مسح كامل)، لذا تُخزَّن مؤقّتًا داخل العملية وتُعاد الحساب فقط
    عند تغيّر عدد البلاغات أو أحدث طابع زمني (كتابة جديدة عبر المجدول/الاستيراد).
    """
    stamp = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(MAX(reported_on), '') AS m, "
        "COALESCE(MAX(id), 0) AS i FROM reports"
    ).fetchone()
    key = (DB_PATH, stamp["n"], stamp["m"], stamp["i"])
    if _STATS_CACHE["value"] is not None and _STATS_CACHE["stamp"] == key:
        return _STATS_CACHE["value"]
    total = stamp["n"]
    by_category = {r["category"]: r["n"] for r in conn.execute(
        "SELECT category, COUNT(*) AS n FROM reports GROUP BY category")}
    by_severity = {r["severity"]: r["n"] for r in conn.execute(
        "SELECT severity, COUNT(*) AS n FROM reports GROUP BY severity")}
    by_status = {r["status"]: r["n"] for r in conn.execute(
        "SELECT status, COUNT(*) AS n FROM reports GROUP BY status")}
    by_country = [{"country": r["country"], "code": r["country_code"],
                   "lat": r["lat"], "lng": r["lng"], "count": r["n"]}
                  for r in conn.execute(
        """SELECT country, country_code, lat, lng, COUNT(*) AS n FROM reports
           GROUP BY country ORDER BY n DESC, country ASC""")]
    by_month = [{"month": r["m"], "count": r["n"]} for r in conn.execute(
        """SELECT substr(reported_on,1,7) AS m, COUNT(*) AS n FROM reports
           GROUP BY m ORDER BY m ASC""")]
    by_month_verified = [{"month": r["m"], "count": r["n"]} for r in conn.execute(
        """SELECT substr(reported_on,1,7) AS m, COUNT(*) AS n FROM reports
           WHERE verified = 1 GROUP BY m ORDER BY m ASC""")]
    verified = conn.execute("SELECT COUNT(*) AS n FROM reports WHERE verified = 1").fetchone()["n"]
    entities = conn.execute("SELECT COUNT(*) AS n FROM entities").fetchone()["n"]
    result = {
        "total": total,
        "verified": verified,
        "entities": entities,
        "entities_by_kind": entity_counts(conn),
        "by_category": by_category,
        "by_severity": by_severity,
        "by_status": by_status,
        "by_country": by_country,
        "by_month": by_month,
        "by_month_verified": by_month_verified,
        "country_count": len(by_country),
    }
    _STATS_CACHE["value"] = result
    _STATS_CACHE["stamp"] = key
    return result


def insert_report(conn: sqlite3.Connection, data: dict[str, Any]) -> int:
    """يُدرج بلاغاً. يحسب رمز الدولة والإحداثيات وحقل البحث المطبَّع."""
    payload = {**data}
    raw_country = (data.get("country") or "").strip()
    # وحّد اسم الدولة إلى الصيغة العربية القياسية واملأ المنطقة تلقائياً.
    normalized = arabic_name(raw_country) if raw_country else ""
    if normalized:
        payload["country"] = normalized
    payload.setdefault("country_code", iso3(raw_country))
    if not (payload.get("region") or "").strip() and raw_country:
        payload["region"] = region_of(raw_country)
    c = coords(raw_country) or [None, None]
    payload.setdefault("lat", c[0])
    payload.setdefault("lng", c[1])
    payload.setdefault("external_id", None)
    payload.setdefault("source_id", None)
    payload.setdefault(
        "dedup_key",
        compute_dedup_key(data.get("title", ""), data.get("category", ""),
                          data.get("country", ""), data.get("occurred_on")),
    )
    payload["search_blob"] = build_search_text(
        data.get("title", ""), data.get("summary", ""), data.get("details") or "",
        data.get("country", ""), data.get("region") or "", data.get("source_name") or "",
    )
    cur = conn.execute(
        """INSERT INTO reports
           (title, category, severity, status, country, country_code, region, lat, lng,
            occurred_on, reported_on, summary, details, source_name, source_url,
            source_id, external_id, dedup_key, verified, search_blob)
           VALUES (:title,:category,:severity,:status,:country,:country_code,:region,:lat,:lng,
                   :occurred_on,:reported_on,:summary,:details,:source_name,:source_url,
                   :source_id,:external_id,:dedup_key,:verified,:search_blob)""",
        payload,
    )
    conn.commit()
    return int(cur.lastrowid)


def report_exists(conn: sqlite3.Connection, external_id: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM reports WHERE external_id = ? LIMIT 1", (external_id,)
    ).fetchone()
    return row is not None


def compute_dedup_key(title: str, category: str, country: str,
                      occurred_on: str | None = None) -> str:
    """بصمة تقريبية للبلاغ لمنع التكرار عبر المصادر.

    تعتمد على تطبيع العنوان (توحيد الألف/التاء/التشكيل، إزالة الترقيم وكلمات
    المصدر الشائعة) + المجال + الدولة + تاريخ الوقوع. هكذا يُعتبر البلاغ نفسه
    الوارد من مصدرين مختلفين تكراراً واحداً.
    """
    import hashlib

    normalized = normalize_arabic(title or "").lower()
    normalized = re.sub(r"[^\w\u0600-\u06FF ]+", " ", normalized)
    tokens = [t for t in normalized.split() if t and t not in _DEDUP_STOPWORDS]
    basis = "|".join([" ".join(tokens), category or "", country or "",
                      (occurred_on or "")[:10]])
    return hashlib.sha1(basis.encode("utf-8")).hexdigest()[:24]


# كلمات مصدرية/وظيفية لا تميّز البلاغ، تُستبعد من بصمة منع التكرار.
_DEDUP_STOPWORDS = {
    "مرصود", "في", "من", "على", "عن", "الى", "إلى", "او", "أو", "the", "a",
    "an", "of", "in", "on", "at", "for", "and", "or", "to", "news", "report",
    "reports", "خبر", "بلاغ", "تقرير",
}


def find_duplicate(conn: sqlite3.Connection, dedup_key: str) -> int | None:
    """يعيد معرّف بلاغ مطابق للبصمة إن وُجد."""
    row = conn.execute(
        "SELECT id FROM reports WHERE dedup_key = ? LIMIT 1", (dedup_key,)
    ).fetchone()
    return int(row["id"]) if row else None


def attach_source(conn: sqlite3.Connection, report_id: int, source_name: str,
                  source_url: str | None, external_id: str | None) -> bool:
    """يسجّل مصدراً إضافياً للبلاغ. يعيد True إن أُضيف، False إن كان مسجّلاً."""
    try:
        conn.execute(
            """INSERT INTO report_sources(report_id, source_name, source_url, external_id)
               VALUES (?,?,?,?)""",
            (report_id, source_name, source_url, external_id),
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


def sources_for(conn: sqlite3.Connection, report_id: int) -> list[dict]:
    """يعيد قائمة مصادر البلاغ (الأساسي أولاً ثم الإضافية)."""
    rows = conn.execute(
        """SELECT source_name, source_url FROM report_sources
           WHERE report_id = ? ORDER BY id""", (report_id,)
    ).fetchall()
    out = [{"source_name": r["source_name"], "source_url": r["source_url"]} for r in rows]
    base = conn.execute(
        "SELECT source_name, source_url FROM reports WHERE id = ?", (report_id,)
    ).fetchone()
    if base and base["source_name"]:
        out.insert(0, {"source_name": base["source_name"], "source_url": base["source_url"]})
    return out


def backfill_dedup_keys(conn: sqlite3.Connection, limit: int | None = None) -> int:
    """يملأ dedup_key للبلاغات التي تفتقده (بلاغات مستوردة قبل إضافة العمود)."""
    sql = "SELECT id, title, category, country, occurred_on FROM reports WHERE dedup_key IS NULL"
    if limit:
        sql += f" LIMIT {int(limit)}"
    rows = conn.execute(sql).fetchall()
    for r in rows:
        conn.execute(
            "UPDATE reports SET dedup_key = ? WHERE id = ?",
            (compute_dedup_key(r["title"], r["category"], r["country"], r["occurred_on"]),
             r["id"]),
        )
    conn.commit()
    return len(rows)


def deduplicate_reports(conn: sqlite3.Connection) -> dict:
    """يدمج البلاغات المكرّرة (نفس dedup_key): يبقي الأقدم ويضمّ المصادر الأخرى.

    عند الدمج تُنقل المصادر الإضافية إلى البلاغ المُبقى (report_sources)، وتُحذف
    صفوف المكرّرة وكياناتها. يعيد إحصاء الدمج.
    """
    groups = conn.execute(
        """SELECT dedup_key, COUNT(*) AS n, MIN(id) AS keep_id
           FROM reports WHERE dedup_key IS NOT NULL
           GROUP BY dedup_key HAVING n > 1"""
    ).fetchall()
    merged = removed = sources_added = 0
    for g in groups:
        keep = g["keep_id"]
        dupes = conn.execute(
            "SELECT id, source_name, source_url, external_id FROM reports "
            "WHERE dedup_key = ? AND id <> ?", (g["dedup_key"], keep),
        ).fetchall()
        for d in dupes:
            if d["source_name"]:
                try:
                    conn.execute(
                        """INSERT OR IGNORE INTO report_sources
                           (report_id, source_name, source_url, external_id)
                           VALUES (?,?,?,?)""",
                        (keep, d["source_name"], d["source_url"],
                         f"merged:{d['id']}"),
                    )
                    sources_added += 1
                except sqlite3.IntegrityError:
                    pass
            conn.execute("DELETE FROM reports WHERE id = ?", (d["id"],))
            removed += 1
        merged += 1
    conn.commit()
    return {"groups": merged, "removed": removed, "sources_added": sources_added}


def add_entity(conn: sqlite3.Connection, report_id: int, name: str,
               kind: str = "unknown", wikidata_id: str | None = None) -> int:
    cur = conn.execute(
        "INSERT INTO entities(report_id, name, kind, wikidata_id) VALUES (?,?,?,?)",
        (report_id, name, kind, wikidata_id),
    )
    return int(cur.lastrowid)


def entities_for(conn: sqlite3.Connection, report_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM entities WHERE report_id = ? ORDER BY id", (report_id,)
    ).fetchall()
    return [dict(r) for r in rows]


_KIND_RANK = ("CASE kind "
              "WHEN 'person' THEN 6 WHEN 'company' THEN 5 "
              "WHEN 'government' THEN 4 WHEN 'organization' THEN 3 "
              "WHEN 'country' THEN 2 ELSE 1 END")
_RANK_KIND = {6: "person", 5: "company", 4: "government", 3: "organization",
              2: "country", 1: "other"}
_KIND_TO_RANK = {v: k for k, v in _RANK_KIND.items()}


def entities_summary(conn: sqlite3.Connection, kind: str | None = None,
                     limit: int | None = 500) -> list[dict]:
    """يجمّع الكيانات المتكرّرة مع عدد البلاغات المرتبطة بها.

    يُوحَّد نوع كل اسم (أعلى أولوية) لتفادي انقسام الكيان الواحد بين أنواع.
    مُخزَّن مؤقّتًا (60 ثانية) لأن التجميع يمسح عشرات آلاف صفوف `entities`.
    """
    def _compute() -> list[dict]:
        having, params = "", []
        if kind:
            rank = _KIND_TO_RANK.get(kind)
            if rank is None:
                # نوع غير معروف: لا نتائج بدل رفع KeyError وردّ 500.
                return []
            having = f"HAVING MAX({_KIND_RANK}) = ?"
            params.append(rank)
        sql = f"""SELECT name,
                         MAX({_KIND_RANK}) AS kind_rank,
                         MAX(wikidata_id) AS wikidata_id,
                         COUNT(DISTINCT report_id) AS count
                  FROM entities
                  GROUP BY name
                  {having}
                  ORDER BY count DESC, name ASC"""
        if limit:
            sql += " LIMIT ?"
            params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["kind"] = _RANK_KIND.get(d.pop("kind_rank"), "other")
            out.append(d)
        return out

    return _cached_query(conn, f"entities_summary:{kind}:{limit}", _compute, ttl=60.0)


def entity_reports(conn: sqlite3.Connection, name: str) -> list[dict]:
    rows = conn.execute(
        """SELECT DISTINCT reports.* FROM reports
           JOIN entities ON entities.report_id = reports.id
           WHERE entities.name = ?
           ORDER BY reports.reported_on DESC""",
        (name,),
    ).fetchall()
    return [dict(r) for r in rows]


def entity_kind(conn: sqlite3.Connection, name: str) -> str | None:
    """يعيد نوع الكيان الموحّد لاسم محدّد (أعلى أولوية)."""
    row = conn.execute(
        f"SELECT MAX({_KIND_RANK}) AS r FROM entities WHERE name = ?", (name,)
    ).fetchone()
    if not row or row["r"] is None:
        return None
    return _RANK_KIND.get(row["r"], "other")


def entity_counts(conn: sqlite3.Connection) -> dict[str, int]:
    """عدد الكيانات الفريد لكل نوع (بعد التوحيد). مُخزَّن مؤقّتًا 60 ثانية."""
    def _compute() -> dict[str, int]:
        summary = entities_summary(conn, limit=None)
        out: dict[str, int] = {}
        for e in summary:
            out[e["kind"]] = out.get(e["kind"], 0) + 1
        return out

    return _cached_query(conn, "entity_counts", _compute, ttl=60.0)


def cooccurring_entities(conn: sqlite3.Connection, name: str,
                         limit: int = 12) -> list[dict]:
    """الكيانات التي تتشارك بلاغات مع الكيان المحدّد، مرتّبة بعدد البلاغات المشتركة.

    تُستخدم لبناء شبكة علاقات (من يظهر مع مَن في نفس البلاغات).
    """
    rows = conn.execute(
        f"""SELECT e2.name,
                   MAX({_KIND_RANK.replace('kind ', 'e2.kind ')}) AS kind_rank,
                   COUNT(DISTINCT e1.report_id) AS shared
            FROM entities e1
            JOIN entities e2 ON e2.report_id = e1.report_id
            WHERE e1.name = ? AND e2.name <> ?
            GROUP BY e2.name
            ORDER BY shared DESC, e2.name ASC
            LIMIT ?""",
        (name, name, limit),
    ).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["kind"] = _RANK_KIND.get(d.pop("kind_rank"), "other")
        out.append(d)
    return out


def list_sources(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute("SELECT * FROM sources ORDER BY kind, name").fetchall()
    return [dict(r) for r in rows]


def log_ingest(conn: sqlite3.Connection, source_key: str, fetched: int,
               inserted: int, skipped: int, status: str = "ok",
               note: str | None = None) -> None:
    conn.execute(
        """INSERT INTO ingest_log(source_key, fetched, inserted, skipped, status, note)
           VALUES (?,?,?,?,?,?)""",
        (source_key, fetched, inserted, skipped, status, note),
    )
    conn.commit()


def ingest_history(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM ingest_log ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]


def distinct_countries(conn: sqlite3.Connection) -> list[str]:
    return [r["country"] for r in conn.execute(
        "SELECT DISTINCT country FROM reports ORDER BY country ASC")]


def countries_summary(conn: sqlite3.Connection) -> list[dict]:
    """ملخّص لكل دولة: عدد البلاغات، مستوى الخطورة الأعلى، والفئات الممثَّلة.

    مُخزَّن مؤقّتًا لأن الاستعلام يجمع كامل الجدول ويُطلب في الرئيسية والخريطة
    وصفحات الدول.
    """
    def _compute() -> list[dict]:
        rows = conn.execute(
            """SELECT country,
                      COUNT(*) AS total,
                      SUM(verified) AS verified,
                      MAX(CASE severity WHEN 'critical' THEN 4 WHEN 'high' THEN 3
                                        WHEN 'medium' THEN 2 ELSE 1 END) AS sev_rank,
                      MAX(reported_on) AS last_on,
                      MAX(region) AS region,
                      GROUP_CONCAT(DISTINCT category) AS cats
               FROM reports GROUP BY country ORDER BY total DESC, country ASC"""
        ).fetchall()
        sev_by_rank = {4: "critical", 3: "high", 2: "medium", 1: "low"}
        out = []
        for r in rows:
            d = dict(r)
            d["top_severity"] = sev_by_rank.get(d.pop("sev_rank"), "low")
            d["categories"] = (d.pop("cats") or "").split(",")
            out.append(d)
        return out

    return _cached_query(conn, "countries_summary", _compute)


def country_reports(conn: sqlite3.Connection, country: str) -> list[dict]:
    return query_reports(conn, country=country, sort="severity", limit=200)


def geo_points(conn: sqlite3.Connection, limit: int | None = None) -> list[dict]:
    """نقاط للخريطة: بلاغات لها إحداثيات.

    `year` و`month` مشتقّان من تاريخ النشر (`reported_on`) ليتوافقا مع ترتيب
    اللوحة الجانبية والخريطة الحرارائية على الخريطة. عند تمرير `limit` تُعاد
    أحدث النقاط فقط (لتفادي حمولات ضخمة على الخريطة عند آلاف البلاغات).

    تحذير: `limit` يأخذ أحدث النقاط بترتيب زمني خالص، فقد تتركّز كلها في شهر
    واحد عند وجود دفعة استيراد كبيرة، فتُفقد بقية الشهور من الشريط الزمني.
    للعرض الكامل استخدم `geo_points_sampled`.
    """
    sql = """SELECT id, title, title_en, category, severity, country, lat, lng, reported_on,
                    verified,
                    CAST(strftime('%Y', reported_on) AS INTEGER) AS year,
                    substr(reported_on,1,7) AS month
             FROM reports WHERE lat IS NOT NULL AND lng IS NOT NULL
             ORDER BY reported_on DESC, id DESC"""
    if limit:
        sql += f" LIMIT {int(limit)}"
    rows = conn.execute(sql).fetchall()
    return [dict(r) for r in rows]


def geo_points_sampled(conn: sqlite3.Connection, per_month: int = 140,
                       max_total: int = 9000) -> list[dict]:
    """نقاط الخريطة مع ضمان تمثيل كل شهر (لا الاقتصار على الأحدث فقط).

    يأخذ لكل شهر حتى `per_month` نقطة، مرتّبة بالأولوية (خطورة أعلى ثم الأحدث)،
    فتبقى الشهور التاريخية ممثَّلة في الشريط الزمني للخريطة بدل أن تحتكر أحدث
    دفعة استيراد كل النقاط. الشهور ذات العدد الكبير تُعرض كعيّنة موزّعة.
    """
    per_month = max(1, int(per_month))
    sql = f"""
        WITH ranked AS (
            SELECT id, title, title_en, category, severity, country, lat, lng,
                   reported_on, verified,
                   substr(reported_on, 1, 7) AS month,
                   ROW_NUMBER() OVER (
                       PARTITION BY substr(reported_on, 1, 7)
                       ORDER BY CASE severity
                                    WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                                    WHEN 'medium' THEN 2 WHEN 'low' THEN 3
                                    ELSE 4 END,
                                reported_on DESC, id DESC
                   ) AS rn
            FROM reports
            WHERE lat IS NOT NULL AND lng IS NOT NULL
        )
        SELECT id, title, title_en, category, severity, country, lat, lng,
               reported_on, verified, month,
               CAST(strftime('%Y', reported_on) AS INTEGER) AS year
        FROM ranked WHERE rn <= {per_month}
        ORDER BY reported_on DESC, id DESC
        LIMIT {max(1, int(max_total))}"""
    rows = conn.execute(sql).fetchall()
    return [dict(r) for r in rows]


def geo_point_count(conn: sqlite3.Connection) -> int:
    """عدد البلاغات ذات الإحداثيات (لإعلام المستخدم بالتغطية الكاملة)."""
    return int(conn.execute(
        "SELECT COUNT(*) AS n FROM reports WHERE lat IS NOT NULL AND lng IS NOT NULL"
    ).fetchone()["n"])


def daily_activity(conn: sqlite3.Connection, days: int = 365) -> list[dict]:
    """عدد البلاغات لكل يوم خلال آخر `days` يوماً (للخريطة الحرارائية التقويمية)."""
    rows = conn.execute(
        """SELECT reported_on AS day, COUNT(*) AS count FROM reports
           WHERE reported_on >= date('now', ?)
           GROUP BY day ORDER BY day ASC""",
        (f"-{int(days)} days",),
    ).fetchall()
    return [dict(r) for r in rows]


def reports_by_ids(conn: sqlite3.Connection, ids: list[int]) -> list[dict]:
    """بلاغات محدّدة بمعرّفاتها (لتصدير المحدّد من الواجهة)."""
    if not ids:
        return []
    placeholders = ",".join("?" * len(ids))
    rows = conn.execute(
        f"SELECT * FROM reports WHERE id IN ({placeholders}) ORDER BY reported_on DESC",
        ids,
    ).fetchall()
    return [dict(r) for r in rows]


def filter_counts(conn: sqlite3.Connection) -> dict:
    """أعداد البلاغات لكل مجال وخطورة وحالة ودولة (لعرضها بجانب خيارات التصفية)."""
    by_cat = {r["category"]: r["n"] for r in conn.execute(
        "SELECT category, COUNT(*) AS n FROM reports GROUP BY category")}
    by_sev = {r["severity"]: r["n"] for r in conn.execute(
        "SELECT severity, COUNT(*) AS n FROM reports GROUP BY severity")}
    by_status = {r["status"]: r["n"] for r in conn.execute(
        "SELECT status, COUNT(*) AS n FROM reports GROUP BY status")}
    by_country = {r["country"]: r["n"] for r in conn.execute(
        "SELECT country, COUNT(*) AS n FROM reports GROUP BY country")}
    return {"category": by_cat, "severity": by_sev, "status": by_status,
            "country": by_country,
            "total": conn.execute("SELECT COUNT(*) AS n FROM reports").fetchone()["n"],
            "verified": conn.execute(
                "SELECT COUNT(*) AS n FROM reports WHERE verified = 1").fetchone()["n"]}


def category_severity_matrix(conn: sqlite3.Connection) -> dict:
    """مصفوفة المجال × الخطورة لعرض أعمدة مركّبة."""
    out: dict[str, dict[str, int]] = {}
    for r in conn.execute(
        """SELECT category, severity, COUNT(*) AS n FROM reports
           GROUP BY category, severity"""
    ):
        out.setdefault(r["category"], {})[r["severity"]] = r["n"]
    return out


def source_report_counts(conn: sqlite3.Connection) -> dict:
    """عدد البلاغات وآخر تاريخ لكل مصدر (بعنوان المصدر النصّي)."""
    out: dict[str, dict] = {}
    for r in conn.execute(
        """SELECT source_name AS name, COUNT(*) AS n, MAX(reported_on) AS last
           FROM reports WHERE source_name IS NOT NULL GROUP BY source_name"""
    ):
        out[r["name"]] = {"count": r["n"], "last": r["last"]}
    return out


# ---------------------------------------------------------------------------
# فهرس المصادر الواسع (source_catalog)
# ---------------------------------------------------------------------------

def catalog_key_exists(conn: sqlite3.Connection, key: str) -> bool:
    """هل مفتاح المصدر موجود مسبقًا في فهرس المصادر؟"""
    return conn.execute(
        "SELECT 1 FROM source_catalog WHERE key = ? LIMIT 1", (key,)
    ).fetchone() is not None


def add_discovered_source(conn: sqlite3.Connection, entry: dict) -> bool:
    """يضيف مصدرًا مكتشفًا إلى فهرس المصادر (وإلى جدول `sources` للإسناد).

    يعيد True إن أُضيف، وFalse إن كان المفتاح موجودًا مسبقًا (منع تكرار إضافي).
    """
    key = entry["key"]
    if catalog_key_exists(conn, key):
        return False
    cats = entry.get("categories") or []
    conn.execute(
        """INSERT INTO source_catalog
           (key, name, name_en, domain, severity, kind, url, feed_url, region,
            license, enabled, source_kind, coverage, access, group_key, categories,
            discovered)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",
        (key, entry["name"], entry.get("name_en"), entry["domain"],
         entry.get("severity", "medium"), entry.get("kind", "feed"),
         entry.get("url"), entry.get("feed_url"), entry.get("region"),
         entry.get("license"), int(entry.get("enabled", 1)),
         entry.get("source_kind"), entry.get("coverage"), entry.get("access"),
         entry.get("group"), ",".join(cats)),
    )
    # إدراج في `sources` ليظهر ضمن قائمة المصادر والإسناد (بلا تكرار).
    conn.execute(
        """INSERT OR IGNORE INTO sources(key, name, url, kind, license, note)
           VALUES (?,?,?,?,?,?)""",
        (key, entry["name"], entry.get("url"),
         "open_dataset" if entry.get("kind") == "dataset" else "news_feed",
         entry.get("license"), entry.get("coverage")),
    )
    conn.commit()
    return True


def log_discovery_run(conn: sqlite3.Connection, report: dict) -> None:
    """يسجّل دورة اكتشاف في `source_discovery_log` (تقرير للعرض في الموقع)."""
    import json as _json
    conn.execute(
        """INSERT INTO source_discovery_log
           (ran_at, candidates, added_count, duplicate_count, rejected_count, report)
           VALUES (?,?,?,?,?,?)""",
        (report.get("ran_at"), int(report.get("candidates", 0)),
         int(report.get("added_count", 0)), int(report.get("duplicate_count", 0)),
         int(report.get("rejected_count", 0)),
         _json.dumps(report, ensure_ascii=False)),
    )
    conn.commit()


def discovery_history(conn: sqlite3.Connection, limit: int = 10) -> list[dict]:
    """آخر دورات الاكتشاف (بلا حمولة التقرير الكاملة)."""
    rows = conn.execute(
        """SELECT id, ran_at, candidates, added_count, duplicate_count, rejected_count
           FROM source_discovery_log ORDER BY ran_at DESC, id DESC LIMIT ?""",
        (int(limit),),
    ).fetchall()
    return [dict(r) for r in rows]


def latest_discovery_report(conn: sqlite3.Connection) -> dict | None:
    """أحدث تقرير اكتشاف كامل (للعرض في صفحة المصادر)."""
    import json as _json
    row = conn.execute(
        "SELECT report FROM source_discovery_log ORDER BY ran_at DESC, id DESC LIMIT 1"
    ).fetchone()
    if not row or not row["report"]:
        return None
    try:
        return _json.loads(row["report"])
    except (ValueError, TypeError):
        return None


def discovered_sources(conn: sqlite3.Connection, limit: int | None = None) -> list[dict]:
    """المصادر المكتشفة آليًّا (مصنَّفة) لعرضها في الموقع."""
    sql = """SELECT key, name, name_en, domain, kind, source_kind, url, feed_url,
                    license, coverage, access, group_key, categories, enabled
             FROM source_catalog WHERE discovered = 1
             ORDER BY group_key, name ASC"""
    args: list[Any] = []
    if limit:
        # حدّ أقصى يمنع القيم الضخمة (خارج نطاق SQLite) من رفع IntegrityError/500.
        sql += " LIMIT ?"
        args.append(max(1, min(int(limit), API_MAX_LIMIT)))
    out = []
    for r in conn.execute(sql, args).fetchall():
        d = dict(r)
        d["categories"] = [c for c in (d.get("categories") or "").split(",") if c]
        out.append(d)
    return out


def discovered_count(conn: sqlite3.Connection) -> int:
    return int(conn.execute(
        "SELECT COUNT(*) AS n FROM source_catalog WHERE discovered = 1"
    ).fetchone()["n"])


def sync_catalog(conn: sqlite3.Connection, entries: list[dict]) -> dict:
    """يزامن فهرس المصادر: يُدرج الجديد ويحدّث الوصف دون فقدان حالة التشغيل."""
    inserted = updated = 0
    for e in entries:
        row = conn.execute("SELECT id FROM source_catalog WHERE key = ?", (e["key"],)).fetchone()
        if row:
            conn.execute(
                """UPDATE source_catalog SET name=?, name_en=?, domain=?, severity=?,
                       kind=?, url=?, feed_url=?, region=?, license=?, enabled=?
                   WHERE key=?""",
                (e["name"], e.get("name_en"), e["domain"], e.get("severity", "medium"),
                 e.get("kind", "feed"), e.get("url"), e.get("feed_url"), e.get("region"),
                 e.get("license"), int(e.get("enabled", 1)), e["key"]),
            )
            updated += 1
        else:
            conn.execute(
                """INSERT INTO source_catalog
                   (key, name, name_en, domain, severity, kind, url, feed_url, region,
                    license, enabled)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (e["key"], e["name"], e.get("name_en"), e["domain"],
                 e.get("severity", "medium"), e.get("kind", "feed"), e.get("url"),
                 e.get("feed_url"), e.get("region"), e.get("license"),
                 int(e.get("enabled", 1))),
            )
            inserted += 1
    conn.commit()
    return {"inserted": inserted, "updated": updated, "total": len(entries)}


def catalog_due(conn: sqlite3.Connection, limit: int = 20, now: str | None = None,
                only_harvestable: bool = True) -> list[dict]:
    """يعيد المصادر المستحقّة للتشغيل الآن، مرتّبة بالأقدم تشغيلاً (تناوب عادل).

    `only_harvestable` يستبعد قواعد البيانات المرجعية (kind='dataset').
    """
    now = now or datetime.now(timezone.utc).isoformat(timespec="seconds")
    where = ["enabled = 1", "(next_run IS NULL OR next_run <= ?)"]
    params: list = [now]
    if only_harvestable:
        where.append("kind IN ('feed', 'search') AND feed_url IS NOT NULL")
    sql = (f"SELECT * FROM source_catalog WHERE {' AND '.join(where)} "
           f"ORDER BY (last_run IS NOT NULL), last_run ASC, id ASC LIMIT ?")
    params.append(int(limit))
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def catalog_due_balanced(conn: sqlite3.Connection, limit: int = 12,
                         now: str | None = None) -> list[dict]:
    """يختار المصادر المستحقّة بتوازن بين المجالات (round-robin).

    يمنع هيمنة مجال واحد (كحقوق الإنسان) على دفعات الجمع، فيتناوب مجالًا مجالًا
    حتى بلوغ الحدّ. يبقى الترتيب داخل كل مجال بالأقدم تشغيلاً.
    """
    now = now or datetime.now(timezone.utc).isoformat(timespec="seconds")
    rows = conn.execute(
        """SELECT * FROM source_catalog
           WHERE enabled = 1 AND kind IN ('feed', 'search') AND feed_url IS NOT NULL
             AND (next_run IS NULL OR next_run <= ?)
           ORDER BY (last_run IS NOT NULL), last_run ASC, id ASC""", (now,),
    ).fetchall()
    buckets: dict[str, list[dict]] = {}
    for r in rows:
        buckets.setdefault(r["domain"], []).append(dict(r))
    out: list[dict] = []
    # نُدوّر على المجالات مرّةً مرّة حتى ينضب الجميع أو نبلغ الحدّ.
    while len(out) < limit and any(buckets.values()):
        for dom in list(buckets):
            if len(out) >= limit:
                break
            if buckets[dom]:
                out.append(buckets[dom].pop(0))
    return out


def mark_catalog_run(conn: sqlite3.Connection, key: str, *, status: str,
                     fetched: int = 0, inserted: int = 0, error: str | None = None,
                     next_run: str | None = None, interval_seconds: int = 3600) -> None:
    """يسجّل نتيجة تشغيل مصدر: الحالة، العدّادات، والعملية التالية (backoff عند الفشل)."""
    row = conn.execute(
        "SELECT fail_count, items_total, inserted_total FROM source_catalog WHERE key = ?",
        (key,),
    ).fetchone()
    fails = (row["fail_count"] if row else 0)
    fails = fails + 1 if status != "ok" else 0
    # تراجع أسّي عند الفشل: الفاصل × 2^المرات (بسقف 24 ساعة).
    factor = min(2 ** fails, 24) if fails else 1
    now = datetime.now(timezone.utc)
    if next_run is None:
        next_run = (now + timedelta(seconds=interval_seconds * factor)).isoformat(timespec="seconds")
    conn.execute(
        """UPDATE source_catalog SET last_run=?, last_status=?, last_error=?,
               fail_count=?, next_run=?, items_total=items_total+?, inserted_total=inserted_total+?
           WHERE key=?""",
        (now.isoformat(timespec="seconds"), status, (error or None) and str(error)[:300],
         fails, next_run, int(fetched), int(inserted), key),
    )
    conn.commit()


def catalog_health(conn: sqlite3.Connection) -> dict:
    """ملخّص صحّة الفهرس: إجماليات لكل نوع، وعدد السليم/المتعطّل، وآخر تشغيل."""
    totals = conn.execute(
        "SELECT COUNT(*) AS total, SUM(enabled) AS enabled FROM source_catalog"
    ).fetchone()
    by_kind = {r["kind"]: r["n"] for r in conn.execute(
        "SELECT kind, COUNT(*) AS n FROM source_catalog GROUP BY kind")}
    by_domain = {r["domain"]: r["n"] for r in conn.execute(
        "SELECT domain, COUNT(*) AS n FROM source_catalog GROUP BY domain")}
    ok = conn.execute(
        "SELECT COUNT(*) AS n FROM source_catalog WHERE last_status = 'ok'").fetchone()["n"]
    failed = conn.execute(
        "SELECT COUNT(*) AS n FROM source_catalog WHERE last_status IS NOT NULL "
        "AND last_status <> 'ok'").fetchone()["n"]
    never = conn.execute(
        "SELECT COUNT(*) AS n FROM source_catalog WHERE last_run IS NULL "
        "AND enabled = 1").fetchone()["n"]
    last = conn.execute(
        "SELECT MAX(last_run) AS t FROM source_catalog").fetchone()["t"]
    harvested = conn.execute(
        "SELECT COALESCE(SUM(inserted_total),0) AS n FROM source_catalog").fetchone()["n"]
    return {
        "total": totals["total"] or 0, "enabled": totals["enabled"] or 0,
        "by_kind": by_kind, "by_domain": by_domain,
        "ok": ok, "failed": failed, "never_run": never,
        "last_run": last, "inserted_total": harvested,
    }


def repair_bad_dates(conn: sqlite3.Connection) -> int:
    """يصلح تواريخ غير ISO (نتيجة خطأ تحليل قديم): يجعلها تاريخ الإدراج.

    كانت تواريخ RSS تُقتطع بـ`[:10]` فتصبح مثل «Wed, 26 Au» بلا سنة؛ لا يمكن
    استرجاع السنة، فنستخدم تاريخ الإدراج (`created_at`) كأقرب قيمة صحيحة.
    """
    rows = conn.execute(
        "SELECT id, title, category, country, occurred_on, reported_on, created_at "
        "FROM reports"
    ).fetchall()
    fixed = 0
    for r in rows:
        changed = False
        new_occurred = r["occurred_on"]
        for col in ("occurred_on", "reported_on"):
            v = (r[col] or "")[:10]
            ok = len(v) == 10 and v[4] == "-" and v[7] == "-" and v.replace("-", "").isdigit()
            if not ok:
                fallback = (r["created_at"] or "")[:10]
                if len(fallback) == 10 and fallback[4] == "-":
                    conn.execute(f"UPDATE reports SET {col} = ? WHERE id = ?",
                                 (fallback, r["id"]))
                    if col == "occurred_on":
                        new_occurred = fallback
                    fixed += 1
                    changed = True
        if changed:
            # أعد حساب بصمة منع التكرار بعد تصحيح التاريخ (كانت مبنية على تاريخ مشوّه).
            conn.execute(
                "UPDATE reports SET dedup_key = ? WHERE id = ?",
                (compute_dedup_key(r["title"], r["category"], r["country"], new_occurred),
                 r["id"]),
            )
    if fixed:
        conn.commit()
    return fixed


def prune_ingest_log(conn: sqlite3.Connection, keep: int = 500) -> int:
    """يبقي آخر `keep` سجلاً فقط في ingest_log حتى لا يتضخّم الجدول مع 1000 مصدر."""
    cur = conn.execute(
        "DELETE FROM ingest_log WHERE id NOT IN "
        "(SELECT id FROM ingest_log ORDER BY id DESC LIMIT ?)", (int(keep),))
    conn.commit()
    return cur.rowcount


def urgent_reports(conn: sqlite3.Connection, limit: int = 8, hours: int = 72) -> list[dict]:
    """بلاغات حرجة/مرتفعة حديثة لنافذة «عاجل». تُرتَّب بالأشدّ ثم الأحدث.

    إن خلا النطاق الزمني من بلاغات حرجة/مرتفعة نعود لأحدث البلاغات عموماً.
    """
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).date().isoformat()
    rows = conn.execute(
        """SELECT * FROM reports
           WHERE severity IN ('critical', 'high')
             AND COALESCE(occurred_on, reported_on) >= ?
           ORDER BY CASE severity WHEN 'critical' THEN 0 ELSE 1 END,
                    COALESCE(occurred_on, reported_on) DESC, id DESC
           LIMIT ?""", (cutoff, int(limit)),
    ).fetchall()
    if rows:
        return [dict(r) for r in rows]
    return [dict(r) for r in conn.execute(
        "SELECT * FROM reports ORDER BY reported_on DESC, id DESC LIMIT ?",
        (int(limit),)).fetchall()]


def collection_stats(conn: sqlite3.Connection) -> dict:
    """مؤشرات الجمع الحيّ: المُضاف خلال آخر ساعة/24 ساعة، والحرجة، وآخر إضافة.

    مُخزَّن مؤقّتًا بصلاحية قصيرة (30 ثانية) لأن حساب نافذتَي الساعة/24 ساعة
    يمسح كامل الجدول، والواجهة لا تحتاج دقّة أعلى من ذلك.
    """
    def _compute() -> dict:
        row = conn.execute(
            """SELECT
                 SUM(created_at >= datetime('now', '-1 hour'))  AS h1,
                 SUM(created_at >= datetime('now', '-24 hours')) AS h24,
                 SUM(created_at >= datetime('now', '-24 hours')
                     AND severity = 'critical') AS crit24,
                 SUM(verified = 1) AS verified
               FROM reports"""
        ).fetchone()
        return {
            "added_1h": row["h1"] or 0,
            "added_24h": row["h24"] or 0,
            "critical_24h": row["crit24"] or 0,
            "verified": row["verified"] or 0,
            "latest": latest_created_at(conn),
        }

    return _cached_query(conn, "collection_stats", _compute, ttl=30.0)


# ---------------------------------------------------------------------------
# منظومة الرصد والتحقق المستمر: دوال الوصول إلى الجداول الجديدة.
# ---------------------------------------------------------------------------

import json as _json


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def insert_document(conn: sqlite3.Connection, data: dict[str, Any]) -> int:
    """يُدرج مستندًا مستلمًا. يتجاهل التكرار على (source_key, external_id)."""
    payload = {
        "source_key": data.get("source_key"),
        "source_name": data.get("source_name"),
        "source_url": data.get("source_url"),
        "url": data.get("url"),
        "canonical_url": data.get("canonical_url") or data.get("url"),
        "external_id": data.get("external_id"),
        "title": data.get("title"),
        "title_en": data.get("title_en"),
        "summary": data.get("summary"),
        "body": data.get("body"),
        "raw": data.get("raw"),
        "content_digest": data.get("content_digest"),
        "content_hash": data.get("content_hash"),
        "lang": data.get("lang"),
        "published_on": data.get("published_on"),
        "occurred_on": data.get("occurred_on"),
        "category": data.get("category"),
        "severity": data.get("severity"),
        "doc_type": data.get("doc_type", "news"),
        "tags": _json.dumps(data.get("tags") or [], ensure_ascii=False),
        "country": data.get("country"),
        "region": data.get("region"),
        "entities": _json.dumps(data.get("entities") or [], ensure_ascii=False),
        "stage": data.get("stage", "ingested"),
        "state": data.get("state", "pending"),
        "report_id": data.get("report_id"),
        "dup_of": data.get("dup_of"),
        "dup_reason": data.get("dup_reason"),
        "confidence": data.get("confidence"),
    }
    try:
        cur = conn.execute(
            """INSERT INTO documents
               (source_key, source_name, source_url, url, canonical_url, external_id,
                title, title_en, summary, body, raw, content_digest, content_hash, lang,
                published_on, occurred_on, category, severity, doc_type, tags, country,
                region, entities, stage, state, report_id, dup_of, dup_reason, confidence)
               VALUES (:source_key,:source_name,:source_url,:url,:canonical_url,:external_id,
                       :title,:title_en,:summary,:body,:raw,:content_digest,:content_hash,:lang,
                       :published_on,:occurred_on,:category,:severity,:doc_type,:tags,:country,
                       :region,:entities,:stage,:state,:report_id,:dup_of,:dup_reason,:confidence)""",
            payload,
        )
        conn.commit()
        return int(cur.lastrowid)
    except sqlite3.IntegrityError:
        row = conn.execute(
            "SELECT id FROM documents WHERE source_key = ? AND external_id = ?",
            (payload["source_key"], payload["external_id"]),
        ).fetchone()
        return int(row["id"]) if row else 0


def _document_row(row: sqlite3.Row) -> dict:
    d = dict(row)
    for k in ("tags", "entities"):
        try:
            d[k] = _json.loads(d.get(k) or "[]")
        except (ValueError, TypeError):
            d[k] = []
    return d


def document_by_id(conn: sqlite3.Connection, doc_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM documents WHERE id = ?", (doc_id,)).fetchone()
    return _document_row(row) if row else None


def documents_pending(conn: sqlite3.Connection, limit: int = 50) -> list[dict]:
    """مستندات تنتظر المعالجة، مرتّبة بالأولوية (الخطورة ثم الأقدم)."""
    rows = conn.execute(
        """SELECT * FROM documents WHERE state = 'pending'
           ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                                  WHEN 'medium' THEN 2 ELSE 3 END,
                    fetched_at ASC
           LIMIT ?""", (int(limit),),
    ).fetchall()
    return [_document_row(r) for r in rows]


def documents_for_report(conn: sqlite3.Connection, report_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM documents WHERE report_id = ? ORDER BY fetched_at DESC",
        (report_id,),
    ).fetchall()
    return [_document_row(r) for r in rows]


def set_document_stage(conn: sqlite3.Connection, doc_id: int, stage: str,
                       state: str | None = None) -> None:
    if state:
        conn.execute("UPDATE documents SET stage = ?, state = ? WHERE id = ?",
                     (stage, state, doc_id))
    else:
        conn.execute("UPDATE documents SET stage = ? WHERE id = ?", (stage, doc_id))
    conn.commit()


def documents_by_digest(conn: sqlite3.Connection, digest: str,
                        exclude_id: int | None = None) -> list[dict]:
    sql = "SELECT * FROM documents WHERE content_digest = ?"
    args: list[Any] = [digest]
    if exclude_id:
        sql += " AND id <> ?"
        args.append(exclude_id)
    return [_document_row(r) for r in conn.execute(sql, args).fetchall()]


def documents_by_hash(conn: sqlite3.Connection, content_hash: str,
                      exclude_id: int | None = None) -> list[dict]:
    sql = "SELECT * FROM documents WHERE content_hash = ?"
    args: list[Any] = [content_hash]
    if exclude_id:
        sql += " AND id <> ?"
        args.append(exclude_id)
    return [_document_row(r) for r in conn.execute(sql, args).fetchall()]


def document_by_url(conn: sqlite3.Connection, url: str) -> dict | None:
    row = conn.execute(
        "SELECT * FROM documents WHERE canonical_url = ? OR url = ? LIMIT 1",
        (url, url)).fetchone()
    return _document_row(row) if row else None


def add_evidence(conn: sqlite3.Connection, report_id: int, *, source_name: str,
                 source_url: str | None = None, source_key: str | None = None,
                 document_id: int | None = None, source_kind: str = "secondary",
                 reliability: float = 0.5, independence: str = "unknown",
                 derived_from: str | None = None, supports: str = "supports",
                 note: str | None = None, added_by: str = "system") -> int:
    """يضيف علاقة مصدر بواقعة. يمنع تكرار (report_id, source_url)."""
    if source_url:
        dup = conn.execute(
            "SELECT id FROM evidence WHERE report_id = ? AND source_url = ? LIMIT 1",
            (report_id, source_url)).fetchone()
        if dup:
            return int(dup["id"])
    cur = conn.execute(
        """INSERT INTO evidence
           (report_id, document_id, source_key, source_name, source_url, source_kind,
            reliability, independence, derived_from, supports, note, added_by)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (report_id, document_id, source_key, source_name, source_url, source_kind,
         reliability, independence, derived_from, supports, note, added_by))
    conn.commit()
    return int(cur.lastrowid)


def evidence_for_report(conn: sqlite3.Connection, report_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM evidence WHERE report_id = ? ORDER BY created_at ASC",
        (report_id,)).fetchall()
    return [dict(r) for r in rows]


def evidence_counts(conn: sqlite3.Connection, report_id: int) -> dict:
    """عدّ الأدلة حسب نوع الدعم والاستقلال."""
    rows = conn.execute(
        """SELECT supports, independence, COUNT(*) AS n FROM evidence
           WHERE report_id = ? GROUP BY supports, independence""", (report_id,)).fetchall()
    out = {"supports": 0, "contradicts": 0, "corrects": 0, "context": 0,
           "independent": 0, "derived": 0, "unknown": 0, "total": 0}
    for r in rows:
        out[r["supports"]] = out.get(r["supports"], 0) + r["n"]
        out[r["independence"]] = out.get(r["independence"], 0) + r["n"]
        out["total"] += r["n"]
    return out


def log_change(conn: sqlite3.Connection, entity: str, entity_id: int, *,
               field: str | None = None, old_value: Any = None, new_value: Any = None,
               reason: str | None = None, source: str | None = None,
               actor: str = "system", task_id: str | None = None) -> int:
    """يسجّل تغييرًا في تاريخ التغييرات (قيمة قديمة/جديدة/سبب/مصدر/وقت)."""
    cur = conn.execute(
        """INSERT INTO change_history
           (entity, entity_id, field, old_value, new_value, reason, source, actor, task_id)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (entity, entity_id, field,
         None if old_value is None else str(old_value),
         None if new_value is None else str(new_value),
         reason, source, actor, task_id))
    conn.commit()
    return int(cur.lastrowid)


def change_history(conn: sqlite3.Connection, *, entity: str | None = None,
                   entity_id: int | None = None, limit: int = 50,
                   search: str | None = None) -> list[dict]:
    sql = "SELECT * FROM change_history WHERE 1=1"
    args: list[Any] = []
    if entity:
        sql += " AND entity = ?"
        args.append(entity)
    if entity_id is not None:
        sql += " AND entity_id = ?"
        args.append(entity_id)
    if search:
        sql += (" AND (field LIKE ? OR old_value LIKE ? OR new_value LIKE ? "
                "OR reason LIKE ? OR source LIKE ?)")
        like = f"%{search}%"
        args += [like, like, like, like, like]
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def add_verification_record(conn: sqlite3.Connection, report_id: int, *,
                            state: str, confidence: float, badge: int = 0,
                            reasons: list | None = None, criteria: dict | None = None,
                            independent_sources: int = 0, conflicting: int = 0,
                            prev_state: str | None = None, note: str | None = None,
                            evaluated_by: str = "system") -> int:
    """يسجّل تقييم تحقق جديدًا ويحدّث حالة البلاغ وبصمته وثقتها."""
    cur = conn.execute(
        """INSERT INTO verification_records
           (report_id, state, confidence, badge, reasons, criteria, independent_sources,
            conflicting, prev_state, note, evaluated_by)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (report_id, state, float(confidence), int(badge),
         _json.dumps(reasons or [], ensure_ascii=False),
         _json.dumps(criteria or {}, ensure_ascii=False),
         int(independent_sources), int(conflicting), prev_state, note, evaluated_by))
    conn.execute(
        "UPDATE reports SET verification_state = ?, confidence = ?, badge = ?, "
        "updated_at = ? WHERE id = ?",
        (state, float(confidence), int(badge), _now_iso(), report_id))
    conn.commit()
    return int(cur.lastrowid)


def _parse_verification_row(row: sqlite3.Row) -> dict:
    d = dict(row)
    for k in ("reasons", "criteria"):
        try:
            d[k] = _json.loads(d.get(k) or ("[]" if k == "reasons" else "{}"))
        except (ValueError, TypeError):
            d[k] = [] if k == "reasons" else {}
    return d


def latest_verification(conn: sqlite3.Connection, report_id: int) -> dict | None:
    row = conn.execute(
        "SELECT * FROM verification_records WHERE report_id = ? "
        "ORDER BY id DESC LIMIT 1", (report_id,)).fetchone()
    return _parse_verification_row(row) if row else None


def verification_history(conn: sqlite3.Connection, report_id: int,
                         limit: int = 20) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM verification_records WHERE report_id = ? "
        "ORDER BY id DESC LIMIT ?", (report_id, int(limit))).fetchall()
    return [_parse_verification_row(r) for r in rows]


def verified_badge_reports(conn: sqlite3.Connection, limit: int = 50) -> list[dict]:
    """البلاغات التي تحمل شارة «موثّق من مصادر مستقلة»."""
    return [dict(r) for r in conn.execute(
        "SELECT * FROM reports WHERE badge = 1 "
        "ORDER BY COALESCE(occurred_on, reported_on) DESC LIMIT ?",
        (int(limit),)).fetchall()]


def enqueue_task(conn: sqlite3.Connection, task_id: str, kind: str, *,
                 priority: int = 5, payload: Any = None, max_attempts: int = 3,
                 available_at: str | None = None) -> bool:
    """يضيف مهمّة بمعرّف فريد. يعيد False إن كانت موجودة (منع التكرار)."""
    try:
        conn.execute(
            """INSERT INTO task_queue
               (task_id, kind, priority, payload, max_attempts, available_at)
               VALUES (?,?,?,?,?, COALESCE(?, datetime('now')))""",
            (task_id, kind, int(priority),
             _json.dumps(payload, ensure_ascii=False) if payload is not None else None,
             int(max_attempts), available_at))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


def claim_tasks(conn: sqlite3.Connection, kind: str, limit: int = 20,
                now: str | None = None) -> list[dict]:
    """يحجز مهامًا جاهزة (queued/failed مع استحقاق) ويعلّمها running."""
    now = now or _now_iso()
    rows = conn.execute(
        """SELECT * FROM task_queue
           WHERE kind = ? AND state IN ('queued','failed') AND available_at <= ?
           ORDER BY priority ASC, available_at ASC LIMIT ?""",
        (kind, now, int(limit))).fetchall()
    out = []
    for r in rows:
        conn.execute(
            "UPDATE task_queue SET state = 'running', locked_at = ?, "
            "attempts = attempts + 1, updated_at = ? WHERE id = ?",
            (now, now, r["id"]))
        d = dict(r)
        d["state"] = "running"
        d["attempts"] = (d.get("attempts") or 0) + 1
        out.append(d)
    conn.commit()
    return out


def finish_task(conn: sqlite3.Connection, task_id: str, *, ok: bool = True,
                error: str | None = None, retry_after: str | None = None) -> None:
    """يُنهي مهمّة. عند الفشل يعيدها للمحاولة أو يجعلها dead بعد نفاد المحاولات."""
    row = conn.execute("SELECT attempts, max_attempts FROM task_queue "
                       "WHERE task_id = ?", (task_id,)).fetchone()
    if not row:
        return
    if ok:
        conn.execute("UPDATE task_queue SET state = 'done', last_error = NULL, "
                     "updated_at = ? WHERE task_id = ?", (_now_iso(), task_id))
    elif row["attempts"] >= row["max_attempts"]:
        conn.execute("UPDATE task_queue SET state = 'dead', last_error = ?, "
                     "updated_at = ? WHERE task_id = ?", (error, _now_iso(), task_id))
    else:
        conn.execute(
            "UPDATE task_queue SET state = 'failed', last_error = ?, "
            "available_at = COALESCE(?, datetime('now')), updated_at = ? "
            "WHERE task_id = ?", (error, retry_after, _now_iso(), task_id))
    conn.commit()


def reset_stale_tasks(conn: sqlite3.Connection, older_than_minutes: int = 15) -> int:
    """يعيد المهام العالقة (running منذ مدّة) إلى الطابور (استرداد بعد الانقطاع)."""
    cur = conn.execute(
        """UPDATE task_queue SET state = 'failed', locked_at = NULL, updated_at = ?
           WHERE state = 'running' AND locked_at < datetime('now', ?)""",
        (_now_iso(), f"-{int(older_than_minutes)} minutes"))
    conn.commit()
    return cur.rowcount


def task_queue_stats(conn: sqlite3.Connection) -> dict:
    rows = conn.execute(
        "SELECT state, COUNT(*) AS n FROM task_queue GROUP BY state").fetchall()
    out = {"queued": 0, "running": 0, "done": 0, "failed": 0, "dead": 0, "total": 0}
    for r in rows:
        out[r["state"]] = r["n"]
        out["total"] += r["n"]
    oldest = conn.execute(
        "SELECT MIN(created_at) AS t FROM task_queue WHERE state IN ('queued','failed')"
    ).fetchone()
    out["oldest_pending"] = oldest["t"] if oldest else None
    return out


def query_tasks(conn: sqlite3.Connection, *, state: str | None = None,
                kind: str | None = None, limit: int = 50) -> list[dict]:
    sql = "SELECT * FROM task_queue WHERE 1=1"
    args: list[Any] = []
    if state:
        sql += " AND state = ?"
        args.append(state)
    if kind:
        sql += " AND kind = ?"
        args.append(kind)
    sql += " ORDER BY priority ASC, id DESC LIMIT ?"
    args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def archive_progress(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM archive_progress ORDER BY source_key").fetchall()]


def archive_for_source(conn: sqlite3.Connection, source_key: str) -> dict | None:
    row = conn.execute("SELECT * FROM archive_progress WHERE source_key = ?",
                       (source_key,)).fetchone()
    return dict(row) if row else None


def upsert_archive_progress(conn: sqlite3.Connection, source_key: str, **fields) -> None:
    """يحدّث/ينشئ صفّ تقدّم الاستيراد لمصدر (حفظ الموضع للاستكمال)."""
    if archive_for_source(conn, source_key) is None:
        conn.execute(
            "INSERT INTO archive_progress(source_key, status) VALUES (?, 'pending')",
            (source_key,))
    allowed = {"status", "cursor", "range_start", "range_end", "covered_start",
               "covered_end", "inaccessible", "batches_done", "items_found",
               "items_imported", "note"}
    sets, args = [], []
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k} = ?")
            if k == "inaccessible" and not isinstance(v, str):
                v = _json.dumps(v, ensure_ascii=False)
            args.append(v)
    if sets:
        sets.append("updated_at = ?")
        args.append(_now_iso())
        args.append(source_key)
        conn.execute(f"UPDATE archive_progress SET {', '.join(sets)} "
                     "WHERE source_key = ?", args)
    conn.commit()


def start_monitoring_run(conn: sqlite3.Connection, kind: str) -> int:
    cur = conn.execute("INSERT INTO monitoring_runs(kind) VALUES (?)", (kind,))
    conn.commit()
    return int(cur.lastrowid)


def finish_monitoring_run(conn: sqlite3.Connection, run_id: int, *,
                          state: str = "done", **counters) -> None:
    allowed = {"sources_checked", "items_fetched", "items_processed", "added",
               "updated", "duplicates", "review", "errors"}
    sets, args = ["state = ?", "finished_at = ?"], [state, _now_iso()]
    for k, v in counters.items():
        if k in allowed:
            sets.append(f"{k} = ?")
            args.append(int(v))
    if counters.get("summary"):
        sets.append("summary = ?")
        summary = counters["summary"]
        args.append(_json.dumps(summary, ensure_ascii=False)
                    if not isinstance(summary, str) else summary)
    args.append(run_id)
    conn.execute(f"UPDATE monitoring_runs SET {', '.join(sets)} WHERE id = ?", args)
    conn.commit()


def monitoring_runs(conn: sqlite3.Connection, kind: str | None = None,
                    limit: int = 20) -> list[dict]:
    if kind:
        rows = conn.execute(
            "SELECT * FROM monitoring_runs WHERE kind = ? "
            "ORDER BY id DESC LIMIT ?", (kind, int(limit))).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM monitoring_runs ORDER BY id DESC LIMIT ?",
            (int(limit),)).fetchall()
    return [dict(r) for r in rows]


def add_alert(conn: sqlite3.Connection, kind: str, title: str, *,
              severity: str | None = None, report_id: int | None = None,
              detail: str | None = None, source: str | None = None) -> int:
    from .taxonomy import ALERT_KIND_BY_KEY
    if severity is None:
        severity = ALERT_KIND_BY_KEY.get(kind, {}).get("severity", "info")
    cur = conn.execute(
        """INSERT INTO alerts(kind, severity, report_id, title, detail, source)
           VALUES (?,?,?,?,?,?)""",
        (kind, severity, report_id, title, detail, source))
    conn.commit()
    return int(cur.lastrowid)


def query_alerts(conn: sqlite3.Connection, *, acked: bool | None = None,
                 limit: int = 50) -> list[dict]:
    sql = "SELECT * FROM alerts WHERE 1=1"
    args: list[Any] = []
    if acked is not None:
        sql += " AND acked = ?"
        args.append(1 if acked else 0)
    sql += (" ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 "
            "ELSE 2 END, id DESC LIMIT ?")
    args.append(int(limit))
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def ack_alert(conn: sqlite3.Connection, alert_id: int) -> bool:
    cur = conn.execute("UPDATE alerts SET acked = 1 WHERE id = ?", (alert_id,))
    conn.commit()
    return cur.rowcount > 0


def alert_stats(conn: sqlite3.Connection) -> dict:
    row = conn.execute(
        """SELECT SUM(acked = 0) AS open,
                  SUM(acked = 0 AND severity = 'critical') AS critical,
                  SUM(acked = 0 AND severity = 'warning') AS warning,
                  COUNT(*) AS total FROM alerts""").fetchone()
    return {"open": row["open"] or 0, "critical": row["critical"] or 0,
            "warning": row["warning"] or 0, "total": row["total"] or 0}


def monitoring_metrics(conn: sqlite3.Connection) -> dict:
    """مؤشرات لوحة التحكم المركزية (القسم 12)."""
    docs = conn.execute(
        """SELECT COUNT(*) AS total,
                  SUM(state = 'pending') AS pending,
                  SUM(state = 'processed') AS processed,
                  SUM(state = 'review') AS review,
                  SUM(dup_of IS NOT NULL) AS dups FROM documents""").fetchone()
    reports = conn.execute(
        """SELECT COUNT(*) AS total,
                  SUM(verification_state IS NULL OR verification_state = 'new') AS new,
                  SUM(verification_state = 'checking') AS checking,
                  SUM(verification_state = 'multi_source') AS multi,
                  SUM(verification_state = 'verified') AS verified,
                  SUM(verification_state = 'disputed') AS disputed,
                  SUM(verification_state = 'corrected') AS corrected,
                  SUM(verification_state = 'withdrawn') AS withdrawn,
                  SUM(verification_state = 'unresolved') AS unresolved,
                  SUM(badge = 1) AS badged,
                  SUM(discovered_at IS NOT NULL) AS auto FROM reports""").fetchone()
    sources = conn.execute(
        """SELECT COUNT(*) AS total, SUM(enabled = 1) AS active,
                  SUM(last_status = 'error') AS failing FROM source_catalog""").fetchone()
    changes = conn.execute("SELECT COUNT(*) AS n FROM change_history").fetchone()["n"]
    evidence = conn.execute("SELECT COUNT(*) AS n FROM evidence").fetchone()["n"]
    archive = conn.execute(
        """SELECT COUNT(*) AS total, SUM(status = 'done') AS done,
                  SUM(status = 'partial') AS partial,
                  SUM(status = 'blocked') AS blocked FROM archive_progress""").fetchone()
    return {
        "documents": {k: (docs[k] or 0) for k in docs.keys()},
        "reports": {k: (reports[k] or 0) for k in reports.keys()},
        "sources": {k: (sources[k] or 0) for k in sources.keys()},
        "changes": changes,
        "evidence": evidence,
        "archive": {k: (archive[k] or 0) for k in archive.keys()},
        "tasks": task_queue_stats(conn),
        "alerts": alert_stats(conn),
    }


def reports_needing_verification(conn: sqlite3.Connection, limit: int = 20,
                                 stale_minutes: int = 5) -> list[dict]:
    """البلاغات المستحقة للتحقق، مرتّبة بالأولوية (حرج ثم الأقدم تقييمًا).

    يُوزَّع العمل على دفعات بدل إعادة فحص القاعدة كاملة (القسم 7).
    """
    rows = conn.execute(
        """SELECT r.* FROM reports r
           WHERE COALESCE(r.verification_state, 'new') IN
                 ('new', 'checking', 'multi_source', 'disputed', 'unresolved')
             AND (r.updated_at IS NULL OR r.updated_at < datetime('now', ?))
           ORDER BY CASE r.severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                                    WHEN 'medium' THEN 2 ELSE 3 END,
                    COALESCE(r.updated_at, r.created_at) ASC
           LIMIT ?""", (f"-{int(stale_minutes)} minutes", int(limit))).fetchall()
    return [dict(r) for r in rows]
