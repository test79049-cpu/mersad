"""سجل المنظّمات الخيرية وحقوق الإنسان للتبرّع المباشر.

بيانات مرجعية عامة (أسماء، مجالات، بلد، موقع). لا تُعالَج أي مدفوعات داخل
الموقع؛ الروابط تفتح صفحة المنظّمة الرسمية للتبرّع مباشرةً.
"""

from __future__ import annotations

from typing import Any

# (key, name_ar, name_en, focus_ar, focus_en, country_ar, country_en, url, cat)
CHARITIES: list[tuple] = [
    ("amnesty", "منظمة العفو الدولية", "Amnesty International",
     "حقوق الإنسان والحريات الأساسية", "Human rights and fundamental freedoms",
     "المملكة المتحدة", "United Kingdom", "https://www.amnesty.org/en/donate/", "human_rights"),
    ("hrw", "هيومن رايتس ووتش", "Human Rights Watch",
     "رصد انتهاكات حقوق الإنسان", "Investigating human-rights abuses",
     "الولايات المتحدة", "United States", "https://www.hrw.org/support", "human_rights"),
    ("icrc", "اللجنة الدولية للصليب الأحمر", "International Committee of the Red Cross",
     "حماية ضحايا النزاعات المسلّحة", "Protecting victims of armed conflict",
     "سويسرا", "Switzerland", "https://www.icrc.org/en/donate", "peace_security"),
    ("msf", "أطباء بلا حدود", "Médecins Sans Frontières",
     "الرعاية الطبية الطارئة", "Emergency medical care",
     "سويسرا", "Switzerland", "https://www.msf.org/donate", "health"),
    ("unhcr", "مفوضية الأمم المتحدة لشؤون اللاجئين", "UNHCR",
     "حماية اللاجئين والنازحين", "Protecting refugees and displaced people",
     "سويسرا", "Switzerland", "https://donate.unhcr.org/", "refugees_migrants"),
    ("unicef", "اليونيسف", "UNICEF",
     "حقوق الطفل والطفولة", "Children's rights and wellbeing",
     "الولايات المتحدة", "United States", "https://www.unicef.org/take-action", "women_children"),
    ("savethechildren", "أنقذوا الأطفال", "Save the Children",
     "حماية الأطفال في الأزمات", "Protecting children in crisis",
     "المملكة المتحدة", "United Kingdom", "https://www.savethechildren.org/us/ways-to-help", "women_children"),
    ("oxfam", "أوكسفام", "Oxfam",
     "الفقر والعدالة الاقتصادية", "Poverty and economic justice",
     "المملكة المتحدة", "United Kingdom", "https://www.oxfam.org/en/donate", "poverty_food"),
    ("wfp", "برنامج الأغذية العالمي", "World Food Programme",
     "الأمن الغذائي ومكافحة الجوع", "Food security and hunger relief",
     "إيطاليا", "Italy", "https://www.wfp.org/support-us", "poverty_food"),
    ("unep", "برنامج الأمم المتحدة للبيئة", "UN Environment Programme",
     "حماية البيئة والمناخ", "Environmental and climate protection",
     "كينيا", "Kenya", "https://www.unep.org/donate", "environment"),
    ("greenpeace", "غرين بيس", "Greenpeace",
     "العدالة المناخية والبيئة", "Climate justice and environment",
     "هولندا", "Netherlands", "https://www.greenpeace.org/international/support/", "environment"),
    ("wwf", "الصندوق العالمي للطبيعة", "World Wide Fund for Nature",
     "الحفاظ على الحياة الفطرية", "Wildlife conservation",
     "سويسرا", "Switzerland", "https://www.worldwildlife.org/donate", "animal_rights"),
    ("iucn", "الاتحاد الدولي لحفظ الطبيعة", "IUCN",
     "حفظ التنوّع الحيوي", "Biodiversity conservation",
     "سويسرا", "Switzerland", "https://www.iucn.org/donate", "animal_rights"),
    ("ifawe", "المؤسسة الدولية لرفاهية الحيوان", "International Fund for Animal Welfare",
     "حماية الحيوانات من القسوة", "Ending animal cruelty",
     "الولايات المتحدة", "United States", "https://www.ifaw.org/donate", "animal_rights"),
    ("humane_society", "الجمعية الإنسانية الدولية", "Humane Society International",
     "حماية الحيوان عالميًّا", "Animal protection worldwide",
     "الولايات المتحدة", "United States", "https://www.hsi.org/donate/", "animal_rights"),
    ("ohchr", "المفوضية السامية لحقوق الإنسان", "OHCHR",
     "تعزيز وحماية حقوق الإنسان", "Promoting and protecting human rights",
     "سويسرا", "Switzerland", "https://www.ohchr.org/en/donors", "human_rights"),
    ("fidh", "الاتحاد الدولي لحقوق الإنسان", "FIDH",
     "شبكات حقوق الإنسان الدولية", "International human-rights networks",
     "فرنسا", "France", "https://www.fidh.org/en/get-involved/donate/", "human_rights"),
    ("accessnow", "أكسس ناو", "Access Now",
     "الحقوق الرقمية وحرية الإنترنت", "Digital rights and internet freedom",
     "الولايات المتحدة", "United States", "https://www.accessnow.org/donate/", "ai_ethics"),
    ("eff", "مؤسسة الحدود الإلكترونية", "Electronic Frontier Foundation",
     "الخصوصية والحقوق الرقمية", "Privacy and digital rights",
     "الولايات المتحدة", "United States", "https://www.eff.org/help", "ai_ethics"),
    ("cdt", "مركز الديمقراطية والتكنولوجيا", "Center for Democracy & Technology",
     "سياسات الإنترنت والحقوق", "Internet policy and rights",
     "الولايات المتحدة", "United States", "https://cdt.org/donate/", "ai_ethics"),
    ("article19", "المادة 19", "ARTICLE 19",
     "حرية التعبير والإعلام", "Freedom of expression and media",
     "المملكة المتحدة", "United Kingdom", "https://www.article19.org/donate/", "expression"),
    ("rsf", "مراسلون بلا حدود", "Reporters Without Borders",
     "حماية الصحفيين", "Protecting journalists",
     "فرنسا", "France", "https://rsf.org/en/donate", "expression"),
    ("cpj", "لجنة حماية الصحفيين", "Committee to Protect Journalists",
     "سلامة الصحفيين", "Journalist safety",
     "الولايات المتحدة", "United States", "https://cpj.org/donate/", "expression"),
    ("pen", "منظمة القلم الدولية", "PEN International",
     "حماية الكتّاب وحرية الفكر", "Protecting writers and free thought",
     "المملكة المتحدة", "United Kingdom", "https://www.pen-international.org/support-us/", "beliefs"),
    ("uscirf", "لجنة الحريات الدينية الدولية", "US Commission on International Religious Freedom",
     "حرية الدين والمعتقد", "Freedom of religion or belief",
     "الولايات المتحدة", "United States", "https://www.uscirf.gov/", "beliefs"),
    ("minority_rights", "مجموعة حقوق الأقليات", "Minority Rights Group",
     "حقوق الأقليات والشعوب الأصلية", "Minority and indigenous rights",
     "المملكة المتحدة", "United Kingdom", "https://minorityrights.org/donate/", "minorities"),
    ("survival", "سرفايفل إنترناشونال", "Survival International",
     "حماية الشعوب الأصلية", "Protecting indigenous peoples",
     "المملكة المتحدة", "United Kingdom", "https://www.survivalinternational.org/support", "minorities"),
    ("cultural_survival", "الحفاظ على الثقافة", "Cultural Survival",
     "حقوق وثقافات الشعوب الأصلية", "Indigenous rights and cultures",
     "الولايات المتحدة", "United States", "https://www.culturalsurvival.org/donate", "minorities"),
    ("unwomen", "هيئة الأمم المتحدة للمرأة", "UN Women",
     "المساواة بين الجنسين", "Gender equality",
     "الولايات المتحدة", "United States", "https://www.unwomen.org/en/donate", "women_children"),
    ("equalitynow", "المساواة الآن", "Equality Now",
     "حقوق المرأة والقانون", "Women's rights and the law",
     "الولايات المتحدة", "United States", "https://www.equalitynow.org/donate/", "women_children"),
    ("globalfundwomen", "الصندوق العالمي للمرأة", "Global Fund for Women",
     "حركات حقوق المرأة", "Women's rights movements",
     "الولايات المتحدة", "United States", "https://www.globalfundforwomen.org/donate/", "women_children"),
    ("girlsnotbrides", "فتيات لا عرائس", "Girls Not Brides",
     "مناهضة زواج الأطفال", "Ending child marriage",
     "المملكة المتحدة", "United Kingdom", "https://www.girlsnotbrides.org/get-involved/", "women_children"),
    ("ilo", "منظمة العمل الدولية", "International Labour Organization",
     "حقوق العمل والعدالة الاجتماعية", "Labour rights and social justice",
     "سويسرا", "Switzerland", "https://www.ilo.org/", "labor_rights"),
    ("solidaritycenter", "مركز التضامن", "Solidarity Center",
     "حقوق العمال المنظّمة", "Organized workers' rights",
     "الولايات المتحدة", "United States", "https://www.solidaritycenter.org/donate/", "labor_rights"),
    ("cleanclothes", "حملة الملابس النظيفة", "Clean Clothes Campaign",
     "حقوق عمّال الملابس", "Garment workers' rights",
     "هولندا", "Netherlands", "https://cleanclothes.org/donate", "labor_rights"),
    ("ictj", "المركز الدولي للعدالة الانتقالية", "International Center for Transitional Justice",
     "العدالة الانتقالية وجبر الضرر", "Transitional justice and reparations",
     "الولايات المتحدة", "United States", "https://www.ictj.org/donate", "transitional_justice"),
    ("impunity", "التحالف الدولي ضد الإفلات من العقاب", "International Coalition against Impunity",
     "مناهضة الإفلات من العقاب", "Fighting impunity",
     "سويسرا", "Switzerland", "https://www.impunitywatch.org/", "transitional_justice"),
    ("reprieve", "ريبرايف", "Reprieve",
     "مناهضة عقوبة الإعدام", "Ending the death penalty",
     "المملكة المتحدة", "United Kingdom", "https://reprieve.org.uk/donate/", "criminal_justice"),
    ("fairtrials", "محاكمات عادلة", "Fair Trials",
     "الحق في محاكمة عادلة", "The right to a fair trial",
     "المملكة المتحدة", "United Kingdom", "https://www.fairtrials.org/donate", "criminal_justice"),
    ("prisoners_rights", "منظّمة حقوق السجناء", "Prisoners' Rights Organization",
     "حقوق المحتجزين والسجناء", "Prisoners' and detainees' rights",
     "المملكة المتحدة", "United Kingdom", "https://www.prisonersrights.org/", "prisoners_rights"),
    ("penal_reform", "إصلاح العقوبات الدولية", "Penal Reform International",
     "إصلاح أنظمة العدالة الجنائية", "Criminal-justice reform",
     "المملكة المتحدة", "United Kingdom", "https://www.penalreform.org/donate/", "prisoners_rights"),
    ("helpage", "هيلب إيدج إنترناشونال", "HelpAge International",
     "حقوق كبار السن", "Older people's rights",
     "المملكة المتحدة", "United Kingdom", "https://www.helpage.org/donate/", "elderly_rights"),
    ("ifa", "الرابطة الدولية للشيخوخة", "International Federation on Ageing",
     "سياسات كبار السن", "Ageing policy",
     "كندا", "Canada", "https://www.ifa-fiv.org/", "elderly_rights"),
    ("sightsavers", "سايت سيفرز", "Sightsavers",
     "حقوق ذوي الإعاقة وصحة العيون", "Disability rights and eye health",
     "المملكة المتحدة", "United Kingdom", "https://www.sightsavers.org/donate/", "disability_rights"),
    ("inclusion_intl", "إنكلوجن إنترناشونال", "Inclusion International",
     "حقوق الأشخاص ذوي الإعاقة", "Rights of people with disabilities",
     "المملكة المتحدة", "United Kingdom", "https://inclusion-international.org/donate/", "disability_rights"),
    ("hrw_disability", "الحقوق الدولية للإعاقة", "Disability Rights International",
     "الإدماج ومناهضة الاحتجاز", "Inclusion and ending detention",
     "الولايات المتحدة", "United States", "https://www.driadvocacy.org/donate/", "disability_rights"),
    ("crisisgroup", "مجموعة الأزمات الدولية", "International Crisis Group",
     "منع النزاعات والسلام", "Conflict prevention and peace",
     "بلجيكا", "Belgium", "https://www.crisisgroup.org/support-us", "peace_security"),
    ("interpeace", "إنتربيس", "Interpeace",
     "بناء السلام والمصالحة", "Peacebuilding and reconciliation",
     "سويسرا", "Switzerland", "https://www.interpeace.org/donate/", "peace_security"),
    ("education_cannot_wait", "التعليم لا ينتظر", "Education Cannot Wait",
     "التعليم في الأزمات", "Education in emergencies",
     "الولايات المتحدة", "United States", "https://www.educationcannotwait.org/donate", "education_culture"),
    ("unesco", "اليونسكو", "UNESCO",
     "التعليم والثقافة والتراث", "Education, culture and heritage",
     "فرنسا", "France", "https://www.unesco.org/en/donate", "education_culture"),
]


def _row(t: tuple) -> dict[str, Any]:
    (key, name_ar, name_en, focus_ar, focus_en, country_ar, country_en, url, cat) = t
    return {
        "key": key, "name_ar": name_ar, "name_en": name_en,
        "focus_ar": focus_ar, "focus_en": focus_en,
        "country_ar": country_ar, "country_en": country_en,
        "url": url, "category": cat,
    }


def all_charities() -> list[dict[str, Any]]:
    return [_row(t) for t in CHARITIES]


def by_key(key: str) -> dict[str, Any] | None:
    for t in CHARITIES:
        if t[0] == key:
            return _row(t)
    return None


def count() -> int:
    return len(CHARITIES)


def filter_charities(cat: str = "", q: str = "", lang: str = "ar") -> list[dict[str, Any]]:
    """يُرشّح المنظّمات بالمجال أو نصّ البحث (بالاسم/المجال/البلد)."""
    items = all_charities()
    if cat:
        items = [c for c in items if c["category"] == cat]
    if q:
        needle = q.strip().lower()
        def hay(c: dict) -> str:
            return " ".join([c["name_ar"], c["name_en"], c["focus_ar"], c["focus_en"],
                             c["country_ar"], c["country_en"]]).lower()
        items = [c for c in items if needle in hay(c)]
    return items
