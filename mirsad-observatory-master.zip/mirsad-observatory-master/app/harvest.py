"""محرّك الجمع الآلي من فهرس المصادر الواسع (≈1000 مصدر).

يعمل على دفعات صغيرة محدودة (batch) داخل دورة المجدول، فيتناوب على المصادر
بالأقدم تشغيلاً (`db.catalog_due`) بدل سحبها كلّها دفعة واحدة — وهذا ما يجعل
المعالجة عبر ~1000 مصدر ممكنة بلا إشباع الشبكة ولا تعطيل الطلبات.

المسار لكل مصدر:
    1) جلب التغذية (RSS/Atom) عبر عميل HTTP مع تخزين مؤقّت وتقييد معدّل.
    2) تحليل العناصر وتصنيفها آلياً (`importers.classify`) وترجيح المجال المرجعي.
    3) استخراج الدولة من العنوان، وبناء بلاغ غير موثّق (يتطلّب مراجعة بشرية).
    4) **منع التكرار على مستويين**: `external_id` (الرابط) و`dedup_key` (المحتوى).
       عند تطابق البصمة يُسجَّل المصدر الإضافي في `report_sources` بدل بلاغ جديد.
    5) تسجيل نتيجة المصدر (حالة/عدّادات/العملية التالية) في `source_catalog`
       و`ingest_log`، مع تراجع أسّي عند الفشل (`db.mark_catalog_run`).

التكلفة مضبوطة: `BATCH` مصدر لكل دورة، و`PER_SOURCE` عنصر كحدّ أقصى لكل مصدر،
وإيقاف المصدر مؤقّتاً عند تجاوز حدّ الفشل (`MAX_FAILS`).
"""

from __future__ import annotations

import logging
import os
import time
from datetime import date

from . import db
from .importers import _guess_country, classify
from .rss_feeds import _feed_text, parse_feed

log = logging.getLogger("mirsad.harvest")

# عدد المصادر لكل دفعة (تناوب عادل)، وحدّ العناصر لكل مصدر.
BATCH = int(os.getenv("MIRSAD_HARVEST_BATCH", "12"))
PER_SOURCE = int(os.getenv("MIRSAD_HARVEST_PER_SOURCE", "12"))
# حدّ الفشل المتتالي قبل تعطيل المصدر مؤقّتاً.
MAX_FAILS = int(os.getenv("MIRSAD_HARVEST_MAX_FAILS", "5"))
# سقف زمني لكل دفعة (ثانية) حتى لا تطول دورة المجدول.
BATCH_BUDGET = float(os.getenv("MIRSAD_HARVEST_BUDGET", "45"))


def harvest_source(conn, src: dict, *, maxrecords: int = PER_SOURCE,
                   dry_run: bool = False) -> dict:
    """يجمع من مصدر واحد ويعيد ملخّصاً (fetched/inserted/skipped/merged/error)."""
    url = src.get("feed_url") or src.get("url")
    ref_cat = src.get("domain") or "human_rights"
    ref_sev = src.get("severity") or "medium"
    src_name = src.get("name") or src["key"]
    result = {"key": src["key"], "fetched": 0, "inserted": 0, "skipped": 0,
              "merged": 0, "error": None}

    try:
        raw = _feed_text(url)
        items = parse_feed(raw)[:maxrecords]
    except Exception as exc:  # noqa: BLE001 — مصدر معطّل لا يُفشل الدفعة
        result["error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        return result

    for it in items:
        result["fetched"] += 1
        ext_id = f"catalog:{src['key']}:{it['link']}"
        if db.report_exists(conn, ext_id):
            result["skipped"] += 1
            continue

        text = f"{it['title']} {it['summary']}"
        auto_cat, severity, confidence = classify(text)
        category = auto_cat if confidence > 0 else ref_cat
        if severity == "medium" and ref_sev in ("high", "critical"):
            severity = ref_sev
        country, code, lat, lng = _guess_country(it["title"])
        occurred = it.get("date") or date.today().isoformat()

        dedup = db.compute_dedup_key(it["title"], category, country, occurred)
        existing = db.find_duplicate(conn, dedup)
        if existing:
            # الحدث نفسه من مصدر آخر: نُسجّله كمصدر إضافي بدل بلاغ مكرّر.
            if not dry_run and db.attach_source(conn, existing, src_name,
                                                it["link"], ext_id):
                result["merged"] += 1
            else:
                result["skipped"] += 1
            continue

        if dry_run:
            result["inserted"] += 1
            continue

        source_id = None
        row = conn.execute("SELECT id FROM sources WHERE key = ?",
                           (src["key"],)).fetchone()
        if row:
            source_id = row["id"]
        db.insert_report(conn, {
            "title": it["title"][:240],
            "category": category,
            "severity": severity,
            "status": "new",
            "country": country or "غير محدّد",
            "country_code": code,
            "region": None,
            "lat": lat, "lng": lng,
            "occurred_on": occurred,
            "reported_on": occurred,
            "dedup_key": dedup,
            "summary": (it["summary"] or it["title"])[:600],
            "details": (f"سجل مجمّع آلياً من «{src_name}» "
                        f"(المجال المرجعي: {ref_cat}). يتطلّب مراجعة بشرية قبل التوثيق."),
            "source_name": src_name,
            "source_url": it["link"],
            "source_id": source_id,
            "external_id": ext_id,
            "verified": 0,
        })
        result["inserted"] += 1

    return result


def harvest_batch(conn, *, batch: int = BATCH, per_source: int = PER_SOURCE,
                  budget: float = BATCH_BUDGET, dry_run: bool = False,
                  interval_seconds: int = 3600) -> dict:
    """يشغّل دفعة محدودة من المصادر المستحقّة ضمن سقف زمني.

    يعيد ملخّصاً تراكمياً؛ يُستدعى من المجدول ومن `app.cli harvest`.
    """
    due = db.catalog_due_balanced(conn, limit=batch)
    started = time.monotonic()
    total = {"sources": 0, "fetched": 0, "inserted": 0, "skipped": 0,
             "merged": 0, "errors": 0, "stopped_early": False}
    for src in due:
        if time.monotonic() - started > budget:
            total["stopped_early"] = True
            break
        res = harvest_source(conn, src, maxrecords=per_source, dry_run=dry_run)
        total["sources"] += 1
        total["fetched"] += res["fetched"]
        total["inserted"] += res["inserted"]
        total["skipped"] += res["skipped"]
        total["merged"] += res["merged"]
        if res["error"]:
            total["errors"] += 1
        if not dry_run:
            status = "error" if res["error"] else "ok"
            db.mark_catalog_run(
                conn, src["key"], status=status, fetched=res["fetched"],
                inserted=res["inserted"], error=res["error"],
                interval_seconds=interval_seconds,
            )
            # تعطيل مؤقّت للمصادر المتعطّلة باستمرار (تُعاد المحاولة بعد backoff طويل).
            row = conn.execute("SELECT fail_count FROM source_catalog WHERE key = ?",
                               (src["key"],)).fetchone()
            if row and row["fail_count"] >= MAX_FAILS:
                db.mark_catalog_run(conn, src["key"], status="error",
                                    error=res["error"] or "تجاوز حدّ الفشل",
                                    interval_seconds=interval_seconds * 24)
            try:
                db.log_ingest(conn, src["key"], res["fetched"], res["inserted"],
                              res["skipped"], status=status,
                              note=(res["error"] or f"merged={res['merged']}")[:300])
            except Exception:  # noqa: BLE001 — السجل لا يُفشل الجمع
                pass
    if not dry_run:
        db.prune_ingest_log(conn, keep=500)
    return total


def harvest_many(conn, *, sources: int = 60, per_source: int = 20,
                 dry_run: bool = False) -> dict:
    """يشغّل عدة دفعات متتالية حتى استيفاء عدد المصادر المطلوب (للاستخدام اليدوي/CLI)."""
    agg = {"sources": 0, "fetched": 0, "inserted": 0, "skipped": 0,
           "merged": 0, "errors": 0}
    remaining = sources
    while remaining > 0:
        step = min(BATCH, remaining)
        res = harvest_batch(conn, batch=step, per_source=per_source, budget=600,
                            dry_run=dry_run)
        agg["sources"] += res["sources"]
        agg["fetched"] += res["fetched"]
        agg["inserted"] += res["inserted"]
        agg["skipped"] += res["skipped"]
        agg["merged"] += res["merged"]
        agg["errors"] += res["errors"]
        remaining -= res["sources"]
        if res["sources"] == 0:
            break
    return agg
