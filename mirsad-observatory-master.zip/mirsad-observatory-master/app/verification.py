"""محرّك التحقق وتقييم الثقة (القسمان 8 و9).

يقيّم كل واقعة وفق معايير موثّقة وقابلة للضبط (وليس عدد المصادر وحده)، ويفصل
**الثقة في المصدر** عن **الثقة في الادعاء** الذي ينقله. الناتج حالة تحقق موحّدة
+ درجة ثقة + أسباب قابلة للشرح + أهلية الشارة.

مبادئ إلزامية:
- عدد المصادر أو درجة التشابه النصّي وحدهما لا يكفيان للتوثيق.
- فشل الاتصال بمصدر لا يخفض الثقة ولا يحذف السجل.
- أي نموذج ذكاء اصطناعي يقدّم اقتراحات لا تُعامل وحدها دليلًا مستقلًا.
"""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from . import db
from .dedup import host_of
from .taxonomy import TRUST_CRITERIA

# عتبة أهلية الشارة: مصادر مستقلة كافية + ثقة معتبرة.
BADGE_MIN_INDEPENDENT = 2
BADGE_MIN_CONFIDENCE = 0.60
# عتبات حالة «موثّق».
VERIFIED_MIN_CONFIDENCE = 0.60


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def source_reliability(source: dict | None) -> float:
    """ثقة المصدر من سجله (0..1). تبدأ معتدلة وتتأثر بالنجاح/الفشل التاريخي."""
    if not source:
        return 0.5
    base = 0.5
    kind = (source.get("source_kind") or source.get("kind") or "").lower()
    # مصادر رسمية/أولية تُرجّح قليلًا، والمنقولة/المجهولة تُخفض قليلًا.
    if kind in ("official", "government", "primary"):
        base = 0.65
    elif kind in ("secondary", "feed", "api", "rss"):
        base = 0.55
    elif kind in ("aggregator", "social", "manual"):
        base = 0.4
    fails = int(source.get("fail_count") or 0)
    base -= min(fails * 0.03, 0.15)
    return max(0.1, min(1.0, base))


def independence_of(ev: dict, others: list[dict]) -> str:
    """يصنّف استقلال دليل: مستقل / منقول (derived) / غير معروف.

    يُعتبر الدليل منقولًا إن كان نقلًا صريحًا عن دليل آخر، أو شارك مصدره
    (المضيف أو المفتاح) دليلًا آخر أكثر موثوقية (أو أسبق عند تساوي الموثوقية)،
    فلا يُحتسب مضيف واحد مصدرين مستقلّين. لا يُفترض الاستقلال عند الشك.
    """
    if ev.get("independence") in ("independent", "derived"):
        return ev["independence"]
    if ev.get("derived_from") and ev["derived_from"] in (
            o.get("source_name") for o in others):
        return "derived"
    ev_host = host_of(ev.get("source_url"))
    ev_key = ev.get("source_key")
    for other in others:
        if other.get("id") == ev.get("id"):
            continue
        same_host = ev_host and ev_host == host_of(other.get("source_url"))
        same_key = ev_key and ev_key == other.get("source_key")
        if not (same_host or same_key):
            continue
        # مضيف/مفتاح مشترك: يبقى الأكثر موثوقية (ثم الأسبق) مستقلًّا والبقية منقولة.
        o_rel = float(other.get("reliability") or 0)
        e_rel = float(ev.get("reliability") or 0)
        if (o_rel, -(other.get("id") or 0)) > (e_rel, -(ev.get("id") or 0)):
            return "derived"
    return "independent" if ev.get("source_url") else "unknown"


def _criterion_scores(conn: sqlite3.Connection, report: dict,
                      evidence: list[dict]) -> tuple[dict, list[str]]:
    """يحسب كل معيار ثقة (0..1) مع أسباب مقروءة."""
    reasons: list[str] = []
    counts = db.evidence_counts(conn, report["id"])

    # 1) موثوقية المصادر (متوسط مرجّح بالدعم).
    supporting = [e for e in evidence if e.get("supports") == "supports"]
    reliabilities = [float(e.get("reliability") or 0.5) for e in supporting]
    source_reliability_score = (sum(reliabilities) / len(reliabilities)) if reliabilities else 0.3

    # 2) الاستقلال: نسبة المصادر المستقلة من المدعِمة.
    independent = 0
    derived = 0
    for e in supporting:
        ind = independence_of(e, evidence)
        if ind == "independent":
            independent += 1
        elif ind == "derived":
            derived += 1
    independence_score = 0.0
    if supporting:
        independence_score = independent / len(supporting)
    if independent:
        reasons.append(f"{independent} مصدر مستقل يؤيد الواقعة")
    if derived:
        reasons.append(f"{derived} مصدر منقول عن أصل مشترك (لا يُحتسب مستقلًا)")

    # 3) شاهد مباشر مقابل ناقل.
    direct = sum(1 for e in supporting if e.get("source_kind") in ("primary", "testimony"))
    direct_score = min(direct / 1.0, 1.0) * 0.5 + (0.5 if direct else 0.0)

    # 4) وثائق/أدلة أصلية قابلة للفحص.
    docs = sum(1 for e in supporting if e.get("source_kind") in ("primary", "official"))
    original_score = 1.0 if docs else 0.0
    if docs:
        reasons.append("يتوفّر دليل/وثيقة أصلية قابلة للفحص")

    # 5) توافق التفاصيل الجوهرية (من عدم وجود تعارض + تعدّد المصادر).
    conflict = counts.get("contradicts", 0)
    detail_score = 0.5
    if len(supporting) >= 2 and conflict == 0:
        detail_score = 0.9
    elif len(supporting) >= 2:
        detail_score = 0.4
    elif len(supporting) == 1:
        detail_score = 0.5
    else:
        detail_score = 0.2

    # 6) اتساق التسلسل الزمني والمكاني (وجود تاريخ وقوع ودولة).
    chronology = 0.0
    if report.get("occurred_on"):
        chronology += 0.5
    if report.get("country"):
        chronology += 0.5

    # 7) وجود نفي/تصحيح/معلومات مضادة (يخفض؛ يُذكر في الأسباب).
    counter_score = 0.0 if conflict else 1.0
    if conflict:
        reasons.append(f"{conflict} مصدر ينقض/يعارض الواقعة")

    # 8) حداثة المعلومات واتصالها بالواقعة.
    recency = 0.7
    if report.get("occurred_on") and report.get("reported_on"):
        recency = 1.0

    scores = {
        "source_reliability": round(source_reliability_score, 3),
        "independence": round(independence_score, 3),
        "direct_witness": round(direct_score, 3),
        "original_documents": round(original_score, 3),
        "detail_agreement": round(detail_score, 3),
        "chronology": round(chronology, 3),
        "counter_info": round(counter_score, 3),
        "recency": round(recency, 3),
    }
    return scores, reasons


def _weighted_confidence(scores: dict) -> float:
    total_w = sum(c["weight"] for c in TRUST_CRITERIA) or 1.0
    acc = sum(scores.get(c["key"], 0.0) * c["weight"] for c in TRUST_CRITERIA)
    return max(0.0, min(1.0, acc / total_w))


def evaluate(conn: sqlite3.Connection, report: dict, *,
             evidence: list[dict] | None = None) -> dict:
    """يقيّم واقعة ويعيد النتيجة (حالة/ثقة/أسباب/شارة) دون الكتابة."""
    evidence = evidence if evidence is not None else db.evidence_for_report(conn, report["id"])
    counts = db.evidence_counts(conn, report["id"])
    scores, reasons = _criterion_scores(conn, report, evidence)
    confidence = _weighted_confidence(scores)

    independent = 0
    for e in evidence:
        if e.get("supports") == "supports" and independence_of(e, evidence) == "independent":
            independent += 1
    conflict = counts.get("contradicts", 0)
    corrections = counts.get("corrects", 0)
    total_support = counts.get("supports", 0)

    # --- تحديد الحالة الموحّدة ---
    if conflict and conflict * 2 >= max(1, total_support):
        state = "disputed"
        reasons.append("معلومات جوهرية متناقضة بين المصادر")
    elif corrections and not total_support:
        state = "corrected"
        reasons.append("جرى تصحيح بعض المعلومات مع حفظ التاريخ السابق")
    elif independent >= BADGE_MIN_INDEPENDENT and confidence >= VERIFIED_MIN_CONFIDENCE:
        state = "verified"
        reasons.append("اجتازت الأدلة المتاحة معايير التحقق (مصادر مستقلة كافية)")
    elif total_support >= 2:
        state = "multi_source"
        if independent < BADGE_MIN_INDEPENDENT:
            reasons.append("مصادر متعددة لكن استقلالها/كفايتها لم يُحسم بعد")
    elif total_support == 1:
        state = "checking"
        reasons.append("مصدر واحد؛ يتطلّب جمع أدلة إضافية")
    else:
        state = "unresolved"
        reasons.append("لا توجد أدلة كافية للوصول إلى نتيجة")

    badge = 1 if (state == "verified"
                  and independent >= BADGE_MIN_INDEPENDENT
                  and confidence >= BADGE_MIN_CONFIDENCE) else 0

    return {
        "state": state,
        "confidence": round(confidence, 3),
        "badge": badge,
        "independent_sources": independent,
        "conflicting": conflict,
        "reasons": reasons,
        "criteria": scores,
    }


def persist_independence(conn: sqlite3.Connection, evidence: list[dict]) -> None:
    """يثبّت تصنيف استقلال الأدلة في الجدول كي تتّسق العدّادات والشرح.

    idempotent: يكتب فقط عند تغيّر القيمة.
    """
    changed = False
    for e in evidence:
        ind = independence_of(e, evidence)
        if e.get("independence") != ind:
            conn.execute("UPDATE evidence SET independence = ? WHERE id = ?",
                         (ind, e["id"]))
            changed = True
    if changed:
        conn.commit()


def apply(conn: sqlite3.Connection, report_id: int, *,
          actor: str = "system", task_id: str | None = None,
          evidence: list[dict] | None = None) -> dict:
    """يقيّم واقعة، يسجّل النتيجة، ويسجّل تغيّر الحالة في تاريخ التغييرات.

    يمنع تكرار الآثار الجانبية: لا يسجّل سجلًّا جديدًا إن لم تتغيّر الحالة
    والثقة والشارة، فلا تتضخّم جداول التاريخ عند إعادة الفحص.
    """
    row = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    if not row:
        return {"error": "report not found"}
    report = dict(row)
    evidence = evidence if evidence is not None else db.evidence_for_report(conn, report_id)
    persist_independence(conn, evidence)
    result = evaluate(conn, report, evidence=evidence)

    prev_state = report.get("verification_state")
    prev_conf = report.get("confidence")
    prev_badge = report.get("badge")

    changed = (prev_state != result["state"]
               or prev_badge != result["badge"]
               or (prev_conf is None or abs(float(prev_conf) - result["confidence"]) > 0.01))

    # متزامنة مع حقل reports.verified (تُستخدم في الواجهات الحالية).
    verified_flag = 1 if result["state"] == "verified" else 0
    if changed:
        db.add_verification_record(
            conn, report_id, state=result["state"], confidence=result["confidence"],
            badge=result["badge"], reasons=result["reasons"], criteria=result["criteria"],
            independent_sources=result["independent_sources"],
            conflicting=result["conflicting"], prev_state=prev_state,
            evaluated_by=actor)
        conn.execute("UPDATE reports SET verified = ? WHERE id = ?",
                     (verified_flag, report_id))
        conn.commit()
        db.log_change(conn, "reports", report_id, field="verification_state",
                      old_value=prev_state, new_value=result["state"],
                      reason="تقييم آلي للثقة",
                      source="verification_engine", actor=actor, task_id=task_id)
        if prev_badge != result["badge"]:
            db.log_change(conn, "reports", report_id, field="badge",
                          old_value=prev_badge, new_value=result["badge"],
                          reason="تغيّر أهلية شارة التوثيق",
                          source="verification_engine", actor=actor, task_id=task_id)
        result["changed"] = True
    else:
        result["changed"] = False

    result["prev_state"] = prev_state
    result["report_id"] = report_id
    return result


def badge_explanation(conn: sqlite3.Connection, report_id: int) -> dict:
    """يشرح شارة التوثيق: المصادر المؤيدة، الاستقلال، آخر تحقق، المتحقّق/غير المحسوم.

    يُعرض عند النقر على الشارة (القسم 9).
    """
    report = conn.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    if not report:
        return {}
    report = dict(report)
    evidence = db.evidence_for_report(conn, report_id)
    latest = db.latest_verification(conn, report_id) or {}
    supporting = []
    for e in evidence:
        ind = independence_of(e, evidence)
        supporting.append({
            "source_name": e["source_name"], "source_url": e["source_url"],
            "kind": e.get("source_kind"), "supports": e.get("supports"),
            "independence": ind, "reliability": e.get("reliability"),
            "derived_from": e.get("derived_from"),
        })
    confirmed, unresolved = [], []
    (confirmed if report.get("occurred_on") else unresolved).append("تاريخ الوقوع")
    (confirmed if report.get("country") else unresolved).append("الموقع/الدولة")
    (confirmed if evidence else unresolved).append("وجود مصادر مؤيدة")
    # التفاصيل غير المؤكدة من المعايير الضعيفة.
    criteria = latest.get("criteria") or {}
    for key, label in (("original_documents", "وثائق أصلية"),
                       ("independence", "استقلال المصادر")):
        if criteria.get(key, 0) < 0.5:
            unresolved.append(label)
    return {
        "report_id": report_id,
        "badge": int(report.get("badge") or 0),
        "state": report.get("verification_state"),
        "confidence": report.get("confidence"),
        "sources": supporting,
        "independent_sources": latest.get("independent_sources", 0),
        "last_checked": latest.get("evaluated_at"),
        "confirmed": confirmed,
        "unresolved": unresolved,
        "conflicts": latest.get("conflicting", 0),
        "reasons": latest.get("reasons", []),
    }
