"""عميل ويكيداتا: البحث عن كيانات (دول، منظمات) للحصول على معرّفات QID.

يستخدم واجهة MediaWiki العامة، بدون مفتاح، مع احترام سياسة الاستخدام.
"""

from .clients import get_json
from .config import WIKIDATA_API


def search_entity(query: str, language: str = "ar", limit: int = 5) -> list[dict]:
    """يبحث عن كيانات مطابقة ويعيد [{id, label, description, url}]."""
    if not query or not query.strip():
        return []
    params = {
        "action": "wbsearchentities",
        "search": query.strip(),
        "language": language,
        "uselang": language,
        "format": "json",
        "limit": limit,
        "origin": "*",
    }
    try:
        data = get_json(WIKIDATA_API, params=params, ttl=86400, min_interval=0.4)
    except RuntimeError:
        return []

    out = []
    for hit in data.get("search", []):
        qid = hit.get("id")
        out.append({
            "id": qid,
            "label": hit.get("label") or qid,
            "description": hit.get("description") or "",
            "url": f"https://www.wikidata.org/wiki/{qid}" if qid else None,
        })
    return out


def find_country_qid(country_ar: str, country_en: str | None = None) -> dict | None:
    """يحاول إيجاد كيان الدولة في ويكيداتا بالعربية ثم بالإنجليزية."""
    for lang, q in (("ar", country_ar), ("en", country_en or country_ar)):
        if not q:
            continue
        for r in search_entity(q, language=lang, limit=3):
            if r["id"] and r["id"].startswith("Q"):
                return r
    return None


def enrich_entities(names: list[str], language: str = "ar") -> list[dict]:
    """يثري قائمة أسماء بمعرّفات ويكيداتا (يتجاهل ما لا يُوجد)."""
    enriched = []
    for name in names:
        hits = search_entity(name, language=language, limit=1)
        if hits:
            enriched.append({"name": name, **hits[0]})
        else:
            enriched.append({"name": name, "id": None, "label": name,
                             "description": "", "url": None})
    return enriched
