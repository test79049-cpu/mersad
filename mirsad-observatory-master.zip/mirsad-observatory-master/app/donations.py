"""طبقة التبرّعات: تسجيل النوايا وإحصاءات العرض.

بيئة تجريبية: لا تُعالَج مدفوعات حقيقية ولا تُخزَّن بيانات بطاقات. تُسجَّل
نيّة التبرّع فقط لإظهارها في الواجهة، ويمكن ربط بوابة دفع لاحقًا.
"""

from __future__ import annotations

import sqlite3
from typing import Any

from . import charities

COFFEE_PRESETS = [3, 5, 10, 25]
CHARITY_PRESETS = [5, 10, 25, 50, 100]


def record_donation(conn: sqlite3.Connection, data: dict[str, Any]) -> int:
    cur = conn.execute(
        """INSERT INTO donations
           (kind, amount, currency, frequency, target_key, target_name, user_id,
            donor_name, message, anonymous, status)
           VALUES (?,?,?,?,?,?,?,?,?,?, 'recorded')""",
        (data.get("kind", "coffee"), data.get("amount"), data.get("currency", "USD"),
         data.get("frequency", "once"), data.get("target_key"), data.get("target_name"),
         data.get("user_id"), data.get("donor_name"), data.get("message"),
         1 if data.get("anonymous") else 0))
    conn.commit()
    return int(cur.lastrowid)


def stats(conn: sqlite3.Connection) -> dict[str, Any]:
    """إحصاءات عرض عامة (تُظهر أثر التبرّعات دون كشف بيانات الأفراد)."""
    total = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM donations").fetchone()
    coffee = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM donations "
        "WHERE kind = 'coffee'").fetchone()
    charity = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS s FROM donations "
        "WHERE kind = 'charity'").fetchone()
    top = [dict(r) for r in conn.execute(
        """SELECT COALESCE(target_name, target_key) AS name, COUNT(*) AS n,
                  COALESCE(SUM(amount), 0) AS total
           FROM donations WHERE kind = 'charity'
           GROUP BY target_key ORDER BY total DESC, n DESC LIMIT 8""")]
    return {
        "donations": int(total["n"]),
        "total": float(total["s"] or 0),
        "coffee_count": int(coffee["n"]),
        "coffee_total": float(coffee["s"] or 0),
        "charity_count": int(charity["n"]),
        "charity_total": float(charity["s"] or 0),
        "top_charities": top,
        "charity_orgs": charities.count(),
    }


def recent(conn: sqlite3.Connection, limit: int = 12) -> list[dict]:
    """أحدث التبرّعات (مجهولة الهوية عند اختيار المتبرّع)."""
    rows = conn.execute(
        """SELECT kind, amount, currency, frequency, target_name, donor_name,
                  message, anonymous, created_at
           FROM donations ORDER BY id DESC LIMIT ?""", (int(limit),)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        if d["anonymous"]:
            d["donor_name"] = None
        out.append(d)
    return out


def seed_donations(conn: sqlite3.Connection) -> None:
    """يزرع تبرّعات عرضية عند فراغ الجدول لإظهار الواجهة ممتلئة."""
    if conn.execute("SELECT COUNT(*) AS n FROM donations").fetchone()["n"]:
        return
    sample = [
        ("coffee", 5, "once", None, None, "ليان", "استمروا 👏"),
        ("coffee", 10, "monthly", None, None, None, None),
        ("charity", 25, "once", "msf", "أطباء بلا حدود", "أحمد", "دعم للفرق الطبية"),
        ("charity", 50, "once", "unicef", "اليونيسف", None, None),
        ("coffee", 3, "once", None, None, "سلمى", None),
        ("charity", 100, "monthly", "unhcr", "مفوضية الأمم المتحدة لشؤون اللاجئين", "فريق مِرصد", None),
    ]
    conn.executemany(
        """INSERT INTO donations
           (kind, amount, currency, frequency, target_key, target_name, donor_name,
            message, anonymous, status)
           VALUES (?,?, 'USD', ?,?,?,?,?, 0, 'recorded')""",
        [(k, a, f, tk, tn, dn, msg) for (k, a, f, tk, tn, dn, msg) in sample])
    conn.commit()
