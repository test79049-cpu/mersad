"""English renderings of the seed catalogue, keyed by the Arabic title.

تُستخدم لتعبئة الأعمدة title_en/summary_en في قاعدة البيانات، فيظهر المحتوى
بالعربية في النسخة العربية وبالإنجليزية في النسخة الإنجليزية.
"""

# {arabic_title: (english_title, english_summary)}
SEED_EN: dict[str, tuple[str, str]] = {
    # حقوق الإنسان
    "اعتقال تعسفي لناشطين في ذكرى احتجاجات سابقة": (
        "Arbitrary arrest of activists on the anniversary of past protests",
        "Security forces detained several human-rights activists after a peaceful gathering, without informing their families of the place of detention.",
    ),
    "تقييد حرية الصحافة وإغلاق مواقع إخبارية": (
        "Press-freedom restrictions and shutdown of news outlets",
        "Independent news websites were blocked and court orders were issued to suspend online newspapers that published reports on local corruption.",
    ),
    "استخدام مفرط للقوة ضد متظاهرين سلميين": (
        "Excessive use of force against peaceful protesters",
        "Witnesses reported tear gas and live ammunition fired at protesters by the national police, causing injuries among civilians.",
    ),
    "منع المحامين من الوصول إلى موكّلين محتجزين": (
        "Lawyers barred from reaching detained clients",
        "Lawyers were prevented for weeks from meeting clients held in detention centres run by the Interior Ministry, without any clear legal justification.",
    ),
    "احتجاز صحفي على خلفية تحقيق في فساد": (
        "Journalist detained over a corruption investigation",
        "An investigative journalist was arrested after publishing a report on public contracts, and his equipment and professional documents were seized.",
    ),
    "غارة على مقر منظّمة حقوقية مستقلة": (
        "Raid on the office of an independent rights organisation",
        "A security force stormed the office of a rights organisation and seized files, amid condemnations from the International Federation for Human Rights.",
    ),
    "إخفاء قسري لمحتجين بعد فضّ اعتصام": (
        "Enforced disappearance of protesters after a sit-in was dispersed",
        "Reports recurred of enforced disappearance of people arrested while a sit-in was dispersed, with no information about their fate.",
    ),
    "أحكام قاسية على مدوّنين بسبب منشورات": (
        "Harsh sentences for bloggers over online posts",
        "Prison sentences were handed down against individuals over posts criticising official policies, according to Reporters Without Borders.",
    ),
    "منع عائلات من زيارة معتقلين سياسيين": (
        "Families barred from visiting political detainees",
        "Requests by families to visit detained relatives were repeatedly refused for extended periods, without written legal grounds.",
    ),
    "تعذيب في مراكز احتجاز غير معلنة": (
        "Torture in undeclared detention centres",
        "Reports documented evidence of torture of detainees in centres run by security agencies, with an initial official denial.",
    ),
    # حقوق الحيوان
    "قسوة في مسلخ صناعي: ذبح دون صعق مسبق": (
        "Cruelty at an industrial abattoir: slaughter without prior stunning",
        "An investigation documented footage showing livestock being mistreated during slaughter without the required prior stunning at a large export facility.",
    ),
    "استغلال دلافين في عرض ترفيهي مغلق": (
        "Dolphins exploited in a closed entertainment show",
        "Several dolphins are held in small pools and forced into repeated performances, amid calls for their release.",
    ),
    "تهريب حياة فطرية: ضبط صقور محمية": (
        "Wildlife trafficking: protected falcons seized",
        "Authorities seized dozens of smuggled protected falcons and rescued birds held in cramped cages.",
    ),
    "سوء معاملة كلاب ضالة وتسميم جماعي": (
        "Mistreatment of stray dogs and mass poisoning",
        "Recurring reports of poisoned bait placed in residential neighbourhoods, leading to the death of a number of stray dogs and cats.",
    ),
    "مزرعة فرو تجارية تربية قسرية قاسية": (
        "Commercial fur farm with harsh forced breeding",
        "An investigation revealed harsh confinement of animals bred for fur, with mass culling when demand falls.",
    ),
    "تجارب علمية على قرود دون تخدير كافٍ": (
        "Scientific experiments on monkeys without adequate anaesthesia",
        "Internal documents indicate painful experiments on primates without effective anaesthesia or independent ethical review.",
    ),
    "صيد جائر يهدد فصيلة مهدّدة بالانقراض": (
        "Poaching threatens an endangered species",
        "Illegal hunting of an endangered species was observed in a reserve, with cross-border smuggling networks.",
    ),
    "نقل حيوانات حيّة في ظروف قاسية بالشاحنات": (
        "Live animals transported in harsh conditions by truck",
        "Reports of intensive transport of live animals over long distances in crowded containers without adequate water or ventilation.",
    ),
    "مسالخ غير مرخّصة تذبح دون رقابة بيطرية": (
        "Unlicensed abattoirs slaughtering without veterinary oversight",
        "Inspection rounds revealed unlicensed abattoirs operating without veterinary supervision and with poor hygiene.",
    ),
    # البيئة
    "تسرّب نفطي يهدد الشعاب المرجانية": (
        "Oil spill threatens coral reefs",
        "A spreading oil spill from a Shell facility polluted coasts and coral reefs, with a delayed public response.",
    ),
    "قطع أشجار محمية لصالح مشروع عقاري": (
        "Protected trees felled for a real-estate project",
        "Areas of ancient forest were cleared for a housing project despite the area being classified as a nature reserve.",
    ),
    "انبعاثات مصنع تتجاوز الحدود المسموحة": (
        "Factory emissions exceed permitted limits",
        "Monitoring stations recorded emissions from a global company's steel plant exceeding legal limits for several consecutive weeks.",
    ),
    "إفراط في ضخ المياه الجوفية يهدد القرى": (
        "Excessive groundwater pumping threatens villages",
        "Excessive pumping of groundwater to irrigate cash crops dried up entire village wells and deprived residents of drinking water.",
    ),
    "نفوق أسماك جماعي بعد تصريف صناعي": (
        "Mass fish kill after industrial discharge",
        "Untreated industrial water discharged into a river caused the death of thousands of fish and threatened aquatic ecosystems.",
    ),
    "إزالة غابات استوائية لتوسيع مزارع زيت النخيل": (
        "Tropical deforestation to expand palm-oil plantations",
        "Satellite imagery documented the clearing of large forest areas for plantations supplying a giant palm-oil company.",
    ),
    "مكبات نفايات سامة قرب أحياء سكنية": (
        "Toxic waste dumps near residential areas",
        "Residents discovered irregular dumps of suspected toxic waste close to their homes and their children's schools.",
    ),
    "مياه صرف غير معالجة تُفرَّغ في البحر": (
        "Untreated sewage discharged into the sea",
        "Reports of untreated sewage discharged directly into the sea, with health and environmental risks along the coast.",
    ),
    "انبعاثات ميثان من مواقع حفر غير مطابقة": (
        "Methane emissions from non-compliant drilling sites",
        "Satellites detected large methane emissions from energy companies' drilling sites without declared containment measures.",
    ),
    "تلوّث نهر بمخلفات تعدين معادن ثقيلة": (
        "River polluted by heavy-metal mining waste",
        "Water samples showed a high concentration of heavy metals downstream of a mine run by a major international mining company.",
    ),
    # أخلاقيات الذكاء الاصطناعي
    "نظام تحيّز في فرز طلبات التوظيف": (
        "Biased system for screening job applications",
        "An audit found that an automated hiring system at a tech company rejects candidates of migrant origin at above-average rates.",
    ),
    "مراقبة جماعية بالتعرف على الوجوه في الأماكن العامة": (
        "Mass facial-recognition surveillance in public spaces",
        "A Huawei-powered camera network with automated recognition tracks individuals' movements in public space without a declared legal framework.",
    ),
    "روبوت محادثة يقدّم استشارات طبية مغلوطة": (
        "Chatbot giving misleading medical advice",
        "Users reported receiving inaccurate medical recommendations from an automated assistant without a clear disclosure of its limits.",
    ),
    "خوارزمية تسعير تفرّق ضد أحياء محدودة الدخل": (
        "Pricing algorithm discriminates against low-income areas",
        "A dynamic pricing system was found to raise prices in low-income neighbourhoods at a higher rate than elsewhere.",
    ),
    "استخدام برمجيات تجسّس ضد صحفيين وناشطين": (
        "Spyware used against journalists and activists",
        "Forensic evidence indicates the use of NSO Group spyware against journalists and human-rights activists.",
    ),
    "قاعدة بيانات تعرّف على الوجوه بلا موافقة": (
        "Facial-recognition database built without consent",
        "Clearview AI collected images from the internet to build a facial-recognition database without the subjects' consent.",
    ),
    "نظام رعاية اجتماعية آلي يرفض مستحقّين": (
        "Automated welfare system rejects eligible claimants",
        "An algorithm classifying social-welfare claims rejected eligible cases, amid concerns of structural bias.",
    ),
    "أنظمة ترحيل قائمة على تحليلات آلية": (
        "Deportation systems based on automated analytics",
        "A report stated that Palantir analytics systems were used to support deportation decisions without effective judicial oversight.",
    ),
    "انتحال صوتي آلي لانتحال شخصية مسؤولين": (
        "AI voice cloning used to impersonate officials",
        "Reports of voice-cloning technology used to impersonate officials in targeted fraud operations.",
    ),
    "تسريب بيانات مستخدمين من منصّة كبرى": (
        "User data leak from a major platform",
        "Data of millions of users leaked from a Meta-owned platform, amid reports of inadequate protection.",
    ),
    # الحقوق العمالية
    "عمالة أطفال في سلاسل توريد زراعية": (
        "Child labour in agricultural supply chains",
        "A report documented the employment of underage children in harvesting export crops within global supply chains of Cargill.",
    ),
    "حوادث عمل متكررة في مواقع إنشائية": (
        "Recurring workplace accidents at construction sites",
        "Repeated fall and fatality accidents at construction sites due to the absence of safety equipment and training, according to a migrant-workers' rights network.",
    ),
    "منع التنظيم النقابي في مصنع نسيج": (
        "Union organising banned at a textile factory",
        "Workers who tried to form a union committee were dismissed, and threats were issued by an independent labour federation against similar initiatives.",
    ),
    "حرمان عمّال منازل من إجازات وأجور متأخرة": (
        "Domestic workers denied leave and owed wages",
        "Domestic workers reported wages delayed for months and denial of weekly rest days despite signed contracts.",
    ),
    "عمل قسري في مصانع تصنيع إلكترونيات": (
        "Forced labour in electronics manufacturing plants",
        "An investigation revealed forced working hours and restrictions on movement at supplier factories of Foxconn and Apple.",
    ),
    "عمل مهاجرون بلا رواتب في مشاريع موانئ": (
        "Migrant workers unpaid on port projects",
        "Migrant workers reported their passports being withheld and wages delayed on projects managed by DP World.",
    ),
    "حوادث وفاة في مناجم غير مطابقة للسلامة": (
        "Fatalities in mines not compliant with safety rules",
        "Mines operated by major mining companies recorded recurring deaths due to the absence of basic safety measures.",
    ),
    "تسريح تعسّفي بعد محاولات تنظيم نقابي": (
        "Arbitrary dismissals after union-organising attempts",
        "Workers were dismissed after engaging in collective bargaining, with reports of pressure to cancel union membership.",
    ),
    "عرقلة تفتيش عمل في مصانع أزياء": (
        "Obstruction of labour inspections at fashion factories",
        "Inspectors reported being blocked from entering supplier factories of the Inditex (Zara) group during surprise inspection campaigns.",
    ),
    # حقوق الأقليات
    "تهجير قسري لمجتمع إثني من أراضيه": (
        "Forced displacement of an ethnic community from its land",
        "An ethnic group was forced to leave its villages after an escalation of violence, amid reports of houses being burned.",
    ),
    "تمييز في تقديم الخدمات الصحية ضد أقلية لغوية": (
        "Discrimination in health services against a linguistic minority",
        "Families reported that health facilities refused to provide services in their mother tongue or systematically delayed their paperwork.",
    ),
    "حرمان أطفال أقلية من التسجيل المدني": (
        "Minority children denied civil registration",
        "Families from an ethnic-religious minority faced difficulties registering births and obtaining official documents for their children.",
    ),
    "خطاب كراهية يحرض ضد لاجئين في إعلام محلي": (
        "Hate speech inciting against refugees in local media",
        "Local media broadcast content inciting against refugees, followed by scattered verbal and physical assaults.",
    ),
    "عنف ضد مجتمعات السكان الأصليين": (
        "Violence against indigenous communities",
        "Reports of assaults and displacement against indigenous communities amid land disputes.",
    ),
    "إخلاء قسري لمخيّم لاجئين دون بديل سكني": (
        "Forced eviction of a refugee camp without alternative housing",
        "A refugee camp was forcibly evacuated without providing alternative housing, displacing hundreds of families.",
    ),
    "تمييز في التوظيف ضد أقلية دينية": (
        "Employment discrimination against a religious minority",
        "Reports of job applications from members of a religious minority being rejected despite meeting professional requirements.",
    ),
    "منع طلاب أقلية من الالتحاق بالمدارس": (
        "Minority students barred from attending schools",
        "Children from a religious minority were prevented from enrolling in public schools, with reports of intimidation of families.",
    ),
    "عقاب جماعي لمجتمع رعوي على خلفية نزاع": (
        "Collective punishment of a pastoral community amid conflict",
        "A siege was imposed on a pastoral community, denying it access to markets and healthcare under a policy of collective punishment.",
    ),
    # حرية الفكر والمعتقد
    "اضطهاد أفراد بسبب معتقداتهم غير الدينية": (
        "Persecution of individuals for their non-religious beliefs",
        "Individuals expressing non-religious views were tracked, with escalating prosecutions and social and legal pressure, according to the International Atheist Alliance.",
    ),
    "تقييد حرية الرأي في الجامعات": (
        "Restrictions on freedom of expression at universities",
        "Students were barred from organising intellectual seminars on contentious topics, and academic penalties were imposed on the organisers.",
    ),
    "منع بناء دور عبادة لأقلية دينية": (
        "Religious minority barred from building places of worship",
        "Repeated requests to build places of worship for a religious minority were refused, with reports of intimidation of those claiming the land.",
    ),
    "احتجاز بسبب منشورات على وسائل التواصل": (
        "Detention over social-media posts",
        "Individuals were arrested over posts criticising official policies, and harsh sentences were handed down against some of them.",
    ),
    "ملاحقة قضائية على خلفية «ازدراء الأديان»": (
        "Prosecution on 'blasphemy' grounds",
        "Legal proceedings were launched against individuals on belief-related charges, despite international calls to review the laws.",
    ),
    "إلزام موظفين بممارسات دينية في العمل": (
        "Employees forced into religious practices at work",
        "Reports of employees being compelled to perform religious practices at their workplaces despite this conflicting with their beliefs.",
    ),
    "تضييق على منظمات فكرية ونادي كتاب": (
        "Pressure on intellectual organisations and a book club",
        "The activities of a book club were banned and an independent intellectual organisation was dissolved without a stated reason.",
    ),
    "سحب جنسية ناشط على خلفية معتقده": (
        "Activist stripped of citizenship over his beliefs",
        "An activist was stripped of his citizenship over his views and beliefs, leaving him without documents or the ability to travel.",
    ),
    # أفراد وناشطون
    "اعتقال مؤسّس ويكيليكس بعد سنوات من الملاحقة": (
        "WikiLeaks founder arrested after years of pursuit",
        "Julian Assange remained in detention, amid reports from Reporters Without Borders on the impact on press freedom.",
    ),
    "كاشف المراقبة الجماعية يعيش في المنفى": (
        "Mass-surveillance whistleblower lives in exile",
        "Edward Snowden remains in exile after exposing large-scale mass-surveillance programmes, according to the International Observatory for Digital Rights.",
    ),
    "وفاة عامل منزل بعد سنوات من الحرمان من الأجور": (
        "Domestic worker dies after years of withheld wages",
        "Maria Santos died after years of working with delayed wages and unsafe housing conditions without compensation.",
    ),
    "إصابة عامل بناء مهاجر في موقع بلا سلامة": (
        "Migrant construction worker injured at an unsafe site",
        "Ali Al-Hashimi was severely injured at a construction site with no safety barriers and inadequate health insurance.",
    ),
    "ناشطة بيئية تواجه تهديدات بسبب حملة على البلاستيك": (
        "Environmental activist threatened over a plastics campaign",
        "Gloria Maji received threats after leading a successful campaign to regulate plastic waste.",
    ),
    "مدافع عن حرية المعتقد يُمنع من السفر": (
        "Freedom-of-belief advocate barred from travelling",
        "Ahmed Al-Zahrani was prevented from travelling over his public advocacy for freedom of belief, according to the International Atheist Alliance.",
    ),
    "قائدة مجتمعية تُستهدف بعد توثيقها انتهاكات": (
        "Community leader targeted after documenting abuses",
        "Fatima Mirghani faced harassment and threats after documenting abuses against a local community in Darfur.",
    ),
    "محامية مهاجرة توثّق غرق قارب في المتوسط": (
        "Migrant lawyer documents a boat sinking in the Mediterranean",
        "Mariam Al-Jabi documented survivors' testimonies from a migrant boat sinking, amid shortcomings in rescue operations.",
    ),
    "مؤسّس شركة مراقبة يواجه دعاوى في دول متعدّدة": (
        "Surveillance-company founder faces lawsuits in multiple countries",
        "NSO Group faces multiple lawsuits concerning the use of Pegasus spyware against journalists and activists.",
    ),
    # شركات كبرى وسلاسل التوريد
    "مخالفات سلامة في مصانع التجميع بعقود شركة فوكسكون": (
        "Safety violations at assembly plants under Foxconn contracts",
        "An investigation reported excessive working hours and safety violations at supplier facilities of Foxconn and Apple producing electronics.",
    ),
    "تسريب بيانات مستخدمين ورقابة خوارزمية على المحتوى": (
        "User data leak and algorithmic content moderation",
        "The International Observatory for Digital Rights documented concerns over Meta's algorithms and their impact on privacy and bias.",
    ),
    "استخدام بيع بيانات التعرّف على الوجوه بلا موافقة": (
        "Facial-recognition data sold without consent",
        "Clearview AI's Face technology was sold to law-enforcement agencies without individuals' consent, amid privacy lawsuits.",
    ),
    "عقود مراقبة أمنية تمسّ الخصوصية في منطقة نزاع": (
        "Security-surveillance contracts impinging on privacy in a conflict zone",
        "The use of analytics-based surveillance systems raised concerns over Palantir regarding privacy and residents' rights.",
    ),
    "تلويث نهر بسبب عمليات تعدين لشركة ريو تينتو": (
        "River polluted by Rio Tinto mining operations",
        "Mining-waste discharge polluted a local watercourse near Rio Tinto's operations.",
    ),
    "انبعاثات وانتهاكات بيئية من منشآت شركة توتال إنرجيز": (
        "Emissions and environmental violations at TotalEnergies facilities",
        "Local reports documented leaks and emissions from oil projects operated by TotalEnergies without adequate oversight.",
    ),
    "تسرّب نفطي من خطوط شركة إكسون موبيل": (
        "Oil spill from ExxonMobil pipelines",
        "A recurring leak from ExxonMobil's pipeline network destroyed farmland and residents' sources of livelihood.",
    ),
    "توريد عمالة قسرية في سلاسل شركة كارجيل الزراعية": (
        "Forced labour supplied in Cargill's agricultural chains",
        "A report indicated workers on cocoa farms selling their crops to Cargill under conditions close to forced labour.",
    ),
    "تمويل أنظمة تجسّس عبر شركة بالانتير وحكومة": (
        "Spy systems financed via Palantir and a government",
        "An investigation revealed contracts between government bodies and Palantir to operate data-analytics tools that impinge on privacy.",
    ),
    "مخالفات مصرفية وقيود على الموظفين في دي بي": (
        "Banking violations and restrictions on employees at DB",
        "Employees at the bank (DB) reported unfair labour practices and unjustified pressure on whistleblowers.",
    ),
    "ملابس من سلاسل إنتاج إنديتكس في مصانع غير آمنة": (
        "Clothing from Inditex supply chains in unsafe factories",
        "Reports indicated that supplier factories of one of its groups (Inditex) remain far from labour-safety standards.",
    ),
    "ممارسات احتكارية تخلّ بحقوق مستهلكين وعمال": (
        "Anti-competitive practices harming consumer and worker rights",
        "An investigation reported market concentration by large companies weakening workers' and suppliers' bargaining power.",
    ),
    "قيود على تقنية شركة هواوي ومساءلة الخصوصية": (
        "Restrictions on Huawei technology and privacy accountability",
        "Security reviews raised concerns over Huawei technology and data management in network devices and phones.",
    ),
    "تصريف كيميائي وخروقات من مصنع فولكس فاغن": (
        "Chemical discharge and violations at a Volkswagen plant",
        "Reports of environmental violations at an assembly facility of the Volkswagen group without adequate waste treatment.",
    ),
    # أفراد وناشطون ومنظمات جديدة
    "الملاحقة القضائية لناشطة مناخية بسبب احتجاج": (
        "Legal prosecution of a climate activist over a protest",
        "Activist Greta Thunberg protested against climate policies and faced legal prosecution in the context of climate protests.",
    ),
    "منع ناشط حقوقي من مغادرة البلاد": (
        "Rights activist barred from leaving the country",
        "An activist was prevented from travelling after documenting abuses, according to the International Federation for Human Rights.",
    ),
    "إدانة صحفي بسبب تقرير عن قمع سلمي": (
        "Journalist convicted over a report on peaceful suppression",
        "A journalist who published a report on the suppression of peaceful protests was sentenced to prison, according to the Committee to Protect Journalists.",
    ),
    "توثيق انتهاكات بحق مجتمع الروما في أوروبا": (
        "Abuses against the Roma community in Europe documented",
        "Amnesty International documented systematic discrimination against Roma in education and housing.",
    ),
    "منع ممارسة الشعائر الدينية لأقلية": (
        "Religious minority barred from practising its rites",
        "The freedom of a religious minority to practise its rites was restricted and its members were prevented from gathering, according to the International Atheist Alliance.",
    ),
    "اعتقال ناشط بسبب تغريدة عن اعتقالات": (
        "Activist arrested over a tweet about arrests",
        "An activist was arrested after a social-media post criticising arrests, in the context of restrictions on freedom of expression.",
    ),
    "العمل القسري في مخيمات النازحين": (
        "Forced labour in displacement camps",
        "The UN Human Rights Office documented evidence of forced labour and movement restrictions against the Rohingya community.",
    ),
    "قسوة بحق حيوانات المزارع في مزارع صناعية": (
        "Cruelty to farm animals on industrial farms",
        "An investigation documented inhumane conditions for farm animals at large milk- and meat-production facilities.",
    ),
    "قتل وحشي للفيلة لصيد العاج": (
        "Brutal killing of elephants for ivory",
        "Anti-poaching efforts recorded reports of elephants killed for their ivory in a national reserve.",
    ),
    "استغلال حيوانات التجارب في مختبرات": (
        "Exploitation of laboratory test animals",
        "Substances were tested on animals under harsh conditions without welfare safeguards, according to local reports.",
    ),
    "تلويث بحري وتهديد للسلاحف البحرية": (
        "Marine pollution threatening sea turtles",
        "Plastic and industrial waste polluted important sea-turtle nesting coasts, amid warnings of environmental risks.",
    ),
    "تدمير موائل بسبب التوسّع العمراني": (
        "Habitat destruction from urban expansion",
        "Unplanned urban expansion destroyed extensive habitats and displaced local communities.",
    ),
    "عمال مهاجرون بلا تأمين صحي في قطر": (
        "Migrant workers without health insurance in Qatar",
        "A migrant-workers' rights network documented cases of workers without health insurance or with delayed wages at construction sites.",
    ),
    "حادث منجم يودي بحياة عمّال في جنوب أفريقيا": (
        "Mine accident kills workers in South Africa",
        "Workers died after a mine collapse, amid calls to tighten labour-safety standards.",
    ),
    "تمييز ضد عمّال ذوي إعاقة في مصانع": (
        "Discrimination against workers with disabilities in factories",
        "A report described discrimination in hiring and promotion against workers with disabilities in the manufacturing sector.",
    ),
    "قصف مدرسة يؤدي إلى سقوط مدنيين": (
        "Shelling of a school causes civilian casualties",
        "A school was destroyed by shelling that caused civilian casualties, amid international condemnation and a failure to protect civilians.",
    ),
    "احتجاز تعسّفي لعاملين في منظمة مجتمع مدني": (
        "Arbitrary detention of civil-society organisation staff",
        "Employees of a civil-society organisation were detained without trial, according to local rights reports.",
    ),
    "حرمان أطفال من التعليم لأسباب هوياتية": (
        "Children denied education on identity grounds",
        "Children from a minority group were denied school enrolment due to institutional discrimination, according to the Minority Rights Group International.",
    ),
    "اعتقالات عقب احتجاجات على غلاء المعيشة": (
        "Arrests following protests over the cost of living",
        "Security forces arrested participants in peaceful protests over the cost of living, according to rights reports.",
    ),
    "حرمان لاجئين من المساعدة الإنسانية": (
        "Refugees denied humanitarian assistance",
        "The refugee agency documented refugees being denied humanitarian assistance in overcrowded camps.",
    ),
    "خروقات بيئية في مشاريع تعدين في بيرو": (
        "Environmental violations in mining projects in Peru",
        "Mining-waste discharge polluted local rivers, with discrimination against affected indigenous communities.",
    ),
    "تلويث هواء حضري يتجاوز الحدود الآمنة": (
        "Urban air pollution exceeds safe limits",
        "Air-pollution levels far exceeded safe limits, amid health warnings for residents.",
    ),
    "إبعاد قسري لمهاجرين دون إجراءات قانونية": (
        "Forced deportation of migrants without legal process",
        "Reports documented the deportation of migrants to their countries without effective judicial review.",
    ),
    "عنف جنسي في منطقة نزاع دون مساءلة": (
        "Sexual violence in a conflict zone without accountability",
        "The United Nations documented cases of sexual violence in the context of armed conflict without adequate accountability for perpetrators.",
    ),
    "تهديد مدافع عن حقوق الأرض بسبب معارضة مشروع": (
        "Land-rights defender threatened over opposing a project",
        "A land-rights defender received threats after opposing an extractive project affecting a local community.",
    ),
    "استخدام عمّال أطفال في مناجم صغيرة": (
        "Child labour used in small-scale mines",
        "The International Labour Organization documented child labour in small-scale mines extracting minerals without protection.",
    ),
    "قيود على حرية التجمع السلمي في مدن متعدّدة": (
        "Restrictions on freedom of peaceful assembly in several cities",
        "Wide restrictions were imposed on peaceful gatherings and freedom of expression, according to Reporters Without Borders.",
    ),

    # حقوق المرأة والطفل
    "زواج قسري لفتيات دون السن القانونية": (
        "Forced marriage of underage girls",
        "Reports documented cases of forced marriage of girls below the legal age, with no effective legal protection.",
    ),
    "عنف أسري دون ملاذ آمن للناجيات": (
        "Domestic violence with no safe shelter for survivors",
        "Survivors reported that adequate safe shelters were unavailable after repeated domestic violence.",
    ),
    "تشغيل أطفال في أعمال خطرة": (
        "Children employed in hazardous work",
        "The International Labour Organization documented children employed in hazardous work in small factories without protection or schooling.",
    ),

    # حقوق اللاجئين والمهاجرين
    "إعادة قسرية للاجئين إلى مناطق نزاع": (
        "Forced return of refugees to conflict zones",
        "UNHCR documented the return of people to conflict zones without an individual assessment of protection risks.",
    ),
    "وفيات مهاجرين في البحر المتوسط": (
        "Migrant deaths in the Mediterranean",
        "Migrant boats sank off the coast with delayed rescue operations, according to humanitarian organisations.",
    ),
    "احتجاز إداري مطوّل لمهاجرين": (
        "Prolonged administrative detention of migrants",
        "Migrants were held in administrative detention for prolonged periods without periodic judicial review of the necessity of detention.",
    ),

    # حرية التعبير
    "حجب مواقع إخبارية مستقلة": (
        "Blocking of independent news websites",
        "Independent news websites were blocked and the licences of newspapers that published critical reports were revoked.",
    ),
    "ملاحقة قضائية ضد مدوّنين ونشطاء": (
        "Prosecution of bloggers and activists",
        "Prison sentences were handed to bloggers over posts criticising official policies.",
    ),
    "فضّ تجمّع سلمي واعتقال مشاركين": (
        "Break-up of a peaceful gathering and arrest of participants",
        "A peaceful gathering was forcibly dispersed and participants were arrested after protesting a media shutdown.",
    ),

    # العدالة الانتقالية
    "إفلات من العقاب في جرائم ماضية": (
        "Impunity for past crimes",
        "No effective investigations were opened into grave violations committed during a past internal conflict.",
    ),
    "لجنة حقيقة توصي بجبر الضرر": (
        "Truth commission recommends redress",
        "A truth commission recommended redress and compensation for victims, with delayed implementation.",
    ),
    "رفض الكشف عن مصير مفقودين": (
        "Refusal to disclose the fate of the missing",
        "Families' requests to disclose the fate of relatives who went missing during a past armed conflict were refused.",
    ),

    # الحقوق الاقتصادية والاجتماعية
    "طرد قسري من مساكن دون تعويض": (
        "Forced eviction from homes without compensation",
        "Families were forced to vacate their homes without prior notice, compensation or alternative housing.",
    ),
    "حرمان فئة مهمّشة من الضمان الاجتماعي": (
        "Marginalised group denied social security",
        "A marginalised group was denied social-security entitlements due to administrative and stereotyping barriers.",
    ),
    "أجور متأخرة وانعدام حماية اجتماعية": (
        "Unpaid wages and no social protection",
        "Workers' wages were delayed for months with no social coverage or health insurance.",
    ),

    # الحق في الصحة
    "حرمان مرضى من علاج منقذ للحياة": (
        "Patients denied life-saving treatment",
        "Reports documented patients being denied life-saving medicines and treatments due to funding and logistical shortages.",
    ),
    "انقطاع الرعاية الصحية في مناطق نزاع": (
        "Collapse of healthcare in conflict zones",
        "Essential health services stopped in conflict zones because medical facilities were targeted.",
    ),
    "تمييز في الوصول إلى خدمات الصحة النفسية": (
        "Discrimination in access to mental-health services",
        "A report found discrimination and neglect in the provision of mental-health services to certain groups.",
    ),

    # التعليم والثقافة
    "منع فتيات من الالتحاق بالمدارس": (
        "Girls barred from attending school",
        "Girls were barred from secondary education by decisions restricting their right to education.",
    ),
    "هدم مواقع تراث ثقافي": (
        "Demolition of cultural-heritage sites",
        "Cultural-heritage sites were destroyed, damaging the cultural identity of local communities.",
    ),
    "تقييد التعليم بلغة الأقلية": (
        "Restrictions on education in a minority language",
        "The provision of education in a local minority language was restricted, raising concerns for cultural identity.",
    ),

    # الفقر والأمن الغذائي
    "انعدام الأمن الغذائي في مخيمات النزوح": (
        "Food insecurity in displacement camps",
        "The World Food Programme documented acute food insecurity inside displacement camps.",
    ),
    "أزمة مياه شرب في أحياء مهمّشة": (
        "Drinking-water crisis in marginalised neighbourhoods",
        "Safe drinking water was cut off from marginalised neighbourhoods for weeks with no alternative solutions.",
    ),
    "ارتفاع حاد في أسعار الغذاء الأساسي": (
        "Sharp rise in staple food prices",
        "Staple food prices rose sharply, deepening poverty and food insecurity.",
    ),

    # العدالة الجنائية وسيادة القانون
    "محاكمة غير عادلة أمام محكمة استثنائية": (
        "Unfair trial before an exceptional court",
        "A trial was held before an exceptional court without fair-trial guarantees or an effective right of appeal.",
    ),
    "حكم بإعدام بعد محاكمة غير منصفة": (
        "Death sentence after an unfair trial",
        "A death sentence was issued after a trial lacking defence guarantees, amid appeals to abolish the punishment.",
    ),
    "تأخير في الوصول إلى محامٍ": (
        "Delayed access to a lawyer",
        "Detainees were denied access to a lawyer for prolonged periods, undermining their right to a defence.",
    ),

    # حقوق المحتجزين
    "اكتظاظ مراكز احتجاز وتدهور الظروف": (
        "Overcrowded detention centres and deteriorating conditions",
        "Reports documented severe overcrowding and deteriorating detention conditions with a lack of healthcare.",
    ),
    "منع رعاية صحية عن محتجزين مرضى": (
        "Sick detainees denied healthcare",
        "Sick detainees were denied access to basic healthcare inside detention facilities.",
    ),
    "عقوبات بدنية داخل السجون": (
        "Corporal punishment inside prisons",
        "A report found detainees subjected to corporal punishment and cruel treatment inside prisons.",
    ),

    # حقوق الأشخاص ذوي الإعاقة
    "حرمان ذوي إعاقة من التعليم الدامج": (
        "Persons with disabilities denied inclusive education",
        "Children with disabilities were denied inclusive education because of missing accessibility and specialised staff.",
    ),
    "عدم تهيئة مرافق عامة لإمكانية الوصول": (
        "Public facilities not made accessible",
        "Public facilities lacked the minimum accessibility standards, preventing independent use.",
    ),
    "تمييز في التوظيف ضد ذوي إعاقة": (
        "Employment discrimination against persons with disabilities",
        "A report found discrimination in hiring and promotion against workers with disabilities.",
    ),

    # السلام والأمن الإنساني
    "هجمات على مدنيين في نزاع مسلّح": (
        "Attacks on civilians in armed conflict",
        "The Uppsala Conflict Data Program documented attacks that killed and injured civilians in armed conflict.",
    ),
    "استخدام أسلحة محظورة دولياً": (
        "Use of internationally prohibited weapons",
        "Reports emerged of the use of internationally prohibited weapons in civilian areas, pending verification.",
    ),
    "استهداف مرافق طبية في النزاع": (
        "Targeting of medical facilities in conflict",
        "Medical facilities were targeted in the conflict, harming civilians' access to care.",
    ),

    # حقوق كبار السن
    "إهمال كبار السن في مؤسسات الرعاية": (
        "Neglect of older people in care institutions",
        "Reports documented cases of neglect and lack of care inside residential institutions for older people.",
    ),
    "حرمان كبار السن من معاش تقاعدي": (
        "Older people denied a pension",
        "Older people were denied a basic pension due to administrative and stereotyping barriers.",
    ),
    "تمييز عمري في التوظيف والخدمات": (
        "Age discrimination in employment and services",
        "A report found age discrimination in employment and in access to some public services.",
    ),

    # الحقوق الفئوية والتنوّع
    "تمييز متعدّد ضد مجموعة فئوية": (
        "Intersecting discrimination against an identity group",
        "Reports documented multi-layered discrimination against an identity group in work and services.",
    ),
    "استبعاد فئة مهمّشة من برامج الإدماج": (
        "Marginalised group excluded from inclusion programmes",
        "A marginalised group was excluded from social-inclusion programmes due to unfair criteria.",
    ),
    "خطاب كراهية يستهدف التنوّع": (
        "Hate speech targeting diversity",
        "Hate speech targeting diversity escalated, raising concerns about its impact on social cohesion.",
    ),
}
