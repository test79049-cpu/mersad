"""الحملات والمناصرة (الدفعة 11).

حملات ببيانات تجريبية: أهداف ومطالب، توقيعات مع حماية هوية، أهداف مستهدفة،
وعود ومتابعتها، فعاليات، تحديثات، موجات إرسال منظّم (بموافقة)، وتحليل تغطية.
البيانات تجريبية بالكامل ولا يجري أي إرسال حقيقي.
"""
from __future__ import annotations

import sqlite3
from typing import Any

from .taxonomy import (
    CAMPAIGN_EVENT_KIND_BY_KEY,
    CAMPAIGN_ROLE_BY_KEY,
    CAMPAIGN_STATUS_BY_KEY,
    CAMPAIGN_TARGET_KIND_BY_KEY,
    PLEDGE_STATE_BY_KEY,
    WAVE_STATE_BY_KEY,
)

# علامة إخفاء هوية الموقّع المعرّض للانتقام.
ANON_LABEL = "موقّع مجهول"


def seed_campaigns(conn: sqlite3.Connection) -> None:
    """حملات تجريبية كاملة (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM campaigns").fetchone()["n"]:
        return
    campaigns = [
        {
            "slug": "end-child-detention", "title": "أوقفوا احتجاز الأطفال",
            "title_en": "End child detention",
            "summary": "حملة للضغط على الجهات لإنهاء احتجاز الأطفال في مراكز الاحتجاز.",
            "demands": "الإفراج عن الأطفال المحتجزين؛ تعويض المتضرّرين؛ نشر بيانات دورية.",
            "audience": "منظّمات حقوق الطفل، الصحافة، البرلمانيون",
            "category": "children", "country": "Syria", "goal": 10000,
            "status": "active", "deadline": "2026-12-31", "risk_level": "medium",
            "ethics_ack": 1,
        },
        {
            "slug": "stop-hate-speech", "title": "أوقفوا خطاب الكراهية",
            "title_en": "Stop hate speech",
            "summary": "مطالبة المنصّات بسياسات رادعة ضد خطاب الكراهية.",
            "demands": "سياسة إبلاغ شفّافة؛ إزالة فورية؛ تقارير شفافية فصلية.",
            "audience": "شركات التقنية، المنظّمات الرقمية",
            "category": "hate_speech", "country": "Iraq", "goal": 5000,
            "status": "active", "deadline": "2027-09-30", "risk_level": "low",
            "ethics_ack": 1,
        },
        {
            "slug": "protect-factory-workers", "title": "احموا عمّال المصانع",
            "title_en": "Protect factory workers",
            "summary": "توثيق إصابات العمل والمطالبة بمعايير سلامة.",
            "demands": "تعويضات؛ تفتيش مستقلّ؛ نشر تقارير السلامة.",
            "audience": "نقابات، منظّمات عمّالية",
            "category": "labor", "country": "Egypt", "goal": 3000,
            "status": "paused", "deadline": "2027-03-01", "risk_level": "high",
            "ethics_ack": 1,
        },
    ]
    for c in campaigns:
        cur = conn.execute(
            """INSERT INTO campaigns(slug, title, title_en, summary, demands, audience,
               category, country, goal, status, deadline, risk_level, ethics_ack, is_seed)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",
            (c["slug"], c["title"], c["title_en"], c["summary"], c["demands"], c["audience"],
             c["category"], c["country"], c["goal"], c["status"], c["deadline"],
             c["risk_level"], c["ethics_ack"]),
        )
        cid = cur.lastrowid
        _seed_campaign_detail(conn, cid, c["slug"])
    conn.commit()


def _seed_campaign_detail(conn: sqlite3.Connection, cid: int, slug: str) -> None:
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    team = {
        "end-child-detention": [("dina.act", "coordinator"), ("sami.verify", "researcher"),
                                ("yara.act", "spokesperson"), ("fadi.act", "legal")],
        "stop-hate-speech": [("yara.act", "coordinator"), ("noor.mod", "researcher"),
                             ("hala.verify", "volunteer")],
        "protect-factory-workers": [("omar.act", "coordinator"), ("khaled.act", "researcher"),
                                    ("lina.act", "legal")],
    }.get(slug, [])
    for handle, role in team:
        if handle in handles:
            conn.execute(
                "INSERT OR IGNORE INTO campaign_team(campaign_id, member, role) VALUES (?,?,?)",
                (cid, handle, role),
            )
    sigs = {
        "end-child-detention": [("yara.act", 0), ("omar.act", 0), ("lina.act", 0),
                                ("khaled.act", 0), ("dina.act", 0), ("rana.act", 1),
                                ("tariq.act", 0), ("maya.act", 1)],
        "stop-hate-speech": [("ziad.act", 0), ("salma.mem", 0), ("adam.mem", 1),
                             ("reem.mem", 0), ("noor.mod", 0)],
        "protect-factory-workers": [("omar.act", 0), ("bilal.mem", 0), ("nadia.mem", 1)],
    }.get(slug, [])
    for handle, anon in sigs:
        if handle in handles:
            conn.execute(
                """INSERT OR IGNORE INTO campaign_signatures(campaign_id, member, anonymous)
                   VALUES (?,?,?)""",
                (cid, handle, anon),
            )
    targets = {
        "end-child-detention": [("official", "وزارة العدل", "justice@example.gov", 1),
                                ("intl", "اليونيسف", "info@unicef.example", 1),
                                ("media", "شبكة صحافة مستقلة", "press@example.org", 0)],
        "stop-hate-speech": [("company", "منصّة تواصل كبرى", "policy@example.com", 1),
                             ("body", "هيئة تنظيم الإعلام", "media@example.gov", 0)],
        "protect-factory-workers": [("official", "وزارة العمل", "labor@example.gov", 1),
                                    ("company", "مجموعة مصانع النور", "hr@example.com", 0)],
    }.get(slug, [])
    for kind, name, contact, ver in targets:
        conn.execute(
            """INSERT INTO campaign_targets(campaign_id, kind, name, contact, verified)
               VALUES (?,?,?,?,?)""",
            (cid, kind, name, contact, ver),
        )
    pledges = {
        "end-child-detention": [("التزام بمراجعة قضائية لكل حالة خلال 30 يومًا", "pending", "2026-08-01"),
                                ("الإفراج عن الدفعة الأولى", "kept", "2026-06-15")],
        "stop-hate-speech": [("إطلاق سياسة إبلاغ شفّافة", "broken", "2026-07-01")],
    }.get(slug, [])
    for text, state, due in pledges:
        conn.execute(
            "INSERT INTO campaign_pledges(campaign_id, text, state, due_on) VALUES (?,?,?,?)",
            (cid, text, state, due),
        )
    events = {
        "end-child-detention": [("protest", "وقفة أمام البرلمان", "2026-06-20 10:00", "Damascus", 33.51, 36.29, 320),
                                ("briefing", "جلسة إحاطة للصحافة", "2026-07-05 14:00", "Beirut", 33.89, 35.50, 60)],
        "stop-hate-speech": [("online", "ندوة رقمية عن خطاب الكراهية", "2026-06-25 18:00", "Online", None, None, 480)],
    }.get(slug, [])
    for kind, title, starts, place, lat, lng, att in events:
        conn.execute(
            """INSERT INTO campaign_events(campaign_id, kind, title, starts_at, place, lat, lng, attendance, is_seed)
               VALUES (?,?,?,?,?,?,?,?,1)""",
            (cid, kind, title, starts, place, lat, lng, att),
        )
    updates = {
        "end-child-detention": [("تجاوب أولي من وزارة العدل", "أبدت الوزارة استعدادًا لمراجعة الحالات."),
                                ("توسيع الحملة لدولتين", "انضمّت منظّمات من دولتين إضافيتين.")],
        "stop-hate-speech": [("رفض مبدئي من المنصّة", "رفضت المنصّة حتى الآن الالتزام بسياسة شفّافة.")],
    }.get(slug, [])
    for title, body in updates:
        conn.execute(
            "INSERT INTO campaign_updates(campaign_id, title, body) VALUES (?,?,?)",
            (cid, title, body),
        )
    waves = {
        "end-child-detention": [("الموجة الأولى: البرلمانيون", "2026-06-10", "measured", 120, 18),
                                ("الموجة الثانية: الصحافة", "2026-07-01", "scheduled", 0, 0)],
        "stop-hate-speech": [("الموجة الأولى: المنصّات", "2026-06-12", "sent", 80, 4)],
    }.get(slug, [])
    for label, sched, state, sent, resp in waves:
        conn.execute(
            """INSERT INTO campaign_waves(campaign_id, label, scheduled_at, state, sent_count, response_count)
               VALUES (?,?,?,?,?,?)""",
            (cid, label, sched, state, sent, resp),
        )
    media = {
        "end-child-detention": [("شبكة صحافة مستقلة", "press", "2026-06-22", "positive", 1),
                                ("قناة محلية", "tv", "2026-06-23", "neutral", 0)],
        "stop-hate-speech": [("مجلة رقمية", "press", "2026-06-15", "negative", 0)],
    }.get(slug, [])
    for outlet, kind, pub, sent, ver in media:
        conn.execute(
            """INSERT INTO campaign_media(campaign_id, outlet, kind, published_on, sentiment, verified)
               VALUES (?,?,?,?,?,?)""",
            (cid, outlet, kind, pub, sent, ver),
        )


# ---------------------------------------------------------------------------
# استعلامات الحملات
# ---------------------------------------------------------------------------

def query_campaigns(conn: sqlite3.Connection, *, status: str | None = None,
                    category: str | None = None, country: str | None = None,
                    limit: int | None = None) -> list[dict[str, Any]]:
    where, params = [], []
    if status:
        where.append("status = ?"); params.append(status)
    if category:
        where.append("category = ?"); params.append(category)
    if country:
        where.append("country = ?"); params.append(country)
    sql = "SELECT * FROM campaigns"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC, id DESC"
    if limit:
        sql += " LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def campaign_by_slug(conn: sqlite3.Connection, slug: str) -> dict[str, Any] | None:
    r = conn.execute("SELECT * FROM campaigns WHERE slug=?", (slug,)).fetchone()
    return dict(r) if r else None


def campaign_by_id(conn: sqlite3.Connection, cid: int) -> dict[str, Any] | None:
    r = conn.execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
    return dict(r) if r else None


def is_campaign_coordinator(conn: sqlite3.Connection, campaign_id: int, member: str) -> bool:
    """هل العضو منسّق هذه الحملة؟ (لتقييد التعديلات الإدارية على فريق الحملة)."""
    return conn.execute(
        "SELECT 1 FROM campaign_team WHERE campaign_id=? AND member=? AND role='coordinator'",
        (campaign_id, member),
    ).fetchone() is not None


def signature_count(conn: sqlite3.Connection, campaign_id: int) -> int:
    return conn.execute(
        "SELECT COUNT(*) AS n FROM campaign_signatures WHERE campaign_id=?", (campaign_id,)
    ).fetchone()["n"]


def progress(conn: sqlite3.Connection, campaign: dict) -> dict[str, Any]:
    """تقدّم الحملة نحو الهدف: العدد والنسبة المئوية والمتبقّي والزمن."""
    n = signature_count(conn, campaign["id"])
    goal = campaign.get("goal") or 0
    pct = round(100.0 * n / goal, 1) if goal else 0.0
    return {"count": n, "goal": goal, "percent": min(pct, 100.0),
            "remaining": max(goal - n, 0)}


def campaign_team(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT t.*, m.display_name FROM campaign_team t
           JOIN members m ON m.handle = t.member
           WHERE t.campaign_id=? ORDER BY t.role""", (campaign_id,)
    ).fetchall()]


def campaign_signatures(conn: sqlite3.Connection, campaign_id: int, *,
                        limit: int = 50) -> list[dict]:
    """توقيعات مع حماية الهوية: الموقّع المجهول يظهر باسم عامّ بلا معرّف."""
    out = []
    for r in conn.execute(
        """SELECT s.*, m.display_name FROM campaign_signatures s
           JOIN members m ON m.handle = s.member
           WHERE s.campaign_id=? ORDER BY s.created_at DESC LIMIT ?""",
        (campaign_id, limit),
    ).fetchall():
        d = dict(r)
        if d.get("anonymous"):
            d["display_name"] = ANON_LABEL
            d["member"] = None
        out.append(d)
    return out


def campaign_targets(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_targets WHERE campaign_id=? ORDER BY kind, name",
        (campaign_id,)).fetchall()]


def campaign_pledges(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_pledges WHERE campaign_id=? ORDER BY due_on",
        (campaign_id,)).fetchall()]


def campaign_events(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_events WHERE campaign_id=? ORDER BY starts_at",
        (campaign_id,)).fetchall()]


def campaign_updates(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_updates WHERE campaign_id=? ORDER BY created_at DESC",
        (campaign_id,)).fetchall()]


def campaign_waves(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_waves WHERE campaign_id=? ORDER BY scheduled_at",
        (campaign_id,)).fetchall()]


def campaign_media(conn: sqlite3.Connection, campaign_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM campaign_media WHERE campaign_id=? ORDER BY published_on DESC",
        (campaign_id,)).fetchall()]


# ---------------------------------------------------------------------------
# أفعال الحملة
# ---------------------------------------------------------------------------

def sign_campaign(conn: sqlite3.Connection, campaign_id: int, member: str, *,
                  anonymous: bool = False) -> dict[str, Any]:
    """توقيع آمن: منع التوقيع المكرّر (فهرس فريد) وحماية هوية اختيارية."""
    c = campaign_by_id(conn, campaign_id)
    if not c:
        return {"ok": False, "error": "campaign_not_found"}
    if c["status"] not in ("active", "draft"):
        return {"ok": False, "error": "campaign_closed"}
    if c.get("deadline") and _past(conn, c["deadline"]):
        return {"ok": False, "error": "deadline_passed"}
    exists = conn.execute(
        "SELECT 1 FROM campaign_signatures WHERE campaign_id=? AND member=?",
        (campaign_id, member)).fetchone()
    if exists:
        return {"ok": False, "error": "already_signed"}
    conn.execute(
        "INSERT INTO campaign_signatures(campaign_id, member, anonymous) VALUES (?,?,?)",
        (campaign_id, member, 1 if anonymous else 0),
    )
    conn.commit()
    return {"ok": True, "count": signature_count(conn, campaign_id)}


def _past(conn: sqlite3.Connection, date_str: str) -> bool:
    row = conn.execute("SELECT date(?) < date('now') AS p", (date_str,)).fetchone()
    return bool(row["p"])


def add_campaign_update(conn: sqlite3.Connection, campaign_id: int, title: str,
                        body: str = "") -> int:
    cur = conn.execute(
        "INSERT INTO campaign_updates(campaign_id, title, body) VALUES (?,?,?)",
        (campaign_id, title, body),
    )
    conn.commit()
    return cur.lastrowid


def pledge_campaign_id(conn: sqlite3.Connection, pledge_id: int) -> int | None:
    """معرّف الحملة المالكة للوعد (أو None إن لم يوجد) — لحصر تعديل حالته على منسّقيها."""
    r = conn.execute(
        "SELECT campaign_id FROM campaign_pledges WHERE id=?", (pledge_id,)
    ).fetchone()
    return r["campaign_id"] if r else None


def set_pledge_state(conn: sqlite3.Connection, pledge_id: int, state: str) -> bool:
    if state not in PLEDGE_STATE_BY_KEY:
        return False
    cur = conn.execute(
        "UPDATE campaign_pledges SET state=?, updated_at=datetime('now') WHERE id=?",
        (state, pledge_id),
    )
    conn.commit()
    return cur.rowcount > 0


def schedule_wave(conn: sqlite3.Connection, campaign_id: int, label: str,
                  scheduled_at: str) -> int:
    """جدولة موجة إرسال منظّم (لا إرسال حقيقي؛ تجريبي)."""
    cur = conn.execute(
        """INSERT INTO campaign_waves(campaign_id, label, scheduled_at, state)
           VALUES (?,?,?,'scheduled')""",
        (campaign_id, label, scheduled_at),
    )
    conn.commit()
    return cur.lastrowid


def send_wave(conn: sqlite3.Connection, wave_id: int, *, max_send: int = 500) -> dict[str, Any]:
    """محاكاة إرسال موجة لمن يدعم الحملة (منع الإغراق: سقف للعدد).

    الإرسال تجريبي: يُسجَّل العدد فقط ولا يخرج أي بريد فعلي.
    """
    w = conn.execute("SELECT * FROM campaign_waves WHERE id=?", (wave_id,)).fetchone()
    if not w:
        return {"ok": False, "error": "wave_not_found"}
    if w["state"] != "scheduled":
        return {"ok": False, "error": "wave_not_scheduled"}
    n = signature_count(conn, w["campaign_id"])
    sent = min(n, max_send)
    conn.execute(
        "UPDATE campaign_waves SET state='sent', sent_count=? WHERE id=?", (sent, wave_id)
    )
    conn.commit()
    return {"ok": True, "sent": sent, "throttled": n > max_send}


def measure_wave(conn: sqlite3.Connection, wave_id: int, responses: int) -> bool:
    cur = conn.execute(
        "UPDATE campaign_waves SET state='measured', response_count=? WHERE id=?",
        (max(0, responses), wave_id),
    )
    conn.commit()
    return cur.rowcount > 0


def campaign_impact(conn: sqlite3.Connection, campaign_id: int) -> dict[str, Any]:
    """تقرير أثر الحملة: توقيعات، موجات، وعود، فعاليات، تغطية."""
    c = campaign_by_id(conn, campaign_id)
    if not c:
        return {}
    sigs = signature_count(conn, campaign_id)
    waves = campaign_waves(conn, campaign_id)
    pledges = campaign_pledges(conn, campaign_id)
    media = campaign_media(conn, campaign_id)
    sent = sum(w["sent_count"] for w in waves)
    responses = sum(w["response_count"] for w in waves)
    kept = sum(1 for p in pledges if p["state"] == "kept")
    broken = sum(1 for p in pledges if p["state"] == "broken")
    sentiment: dict[str, int] = {}
    for m in media:
        sentiment[m["sentiment"]] = sentiment.get(m["sentiment"], 0) + 1
    return {"signatures": sigs, "goal": c["goal"],
            "waves": len(waves), "sent": sent, "responses": responses,
            "response_rate": round(100.0 * responses / sent, 1) if sent else 0.0,
            "pledges": len(pledges), "kept": kept, "broken": broken,
            "media": len(media), "sentiment": sentiment}


def campaign_risk(conn: sqlite3.Connection, campaign_id: int) -> dict[str, Any]:
    """تقييم مخاطر الحملة وخطة أمان الناشطين (توصيات)."""
    c = campaign_by_id(conn, campaign_id)
    if not c:
        return {}
    level = c.get("risk_level", "low")
    advice = {
        "low": ["استخدم قنوات رسمية", "وثّق كل مراسلة"],
        "medium": ["فعّل حماية هوية الموقّعين المعرّضين", "حدّد ناطقًا رسميًّا",
                   "راجع المخاطر القانونية"],
        "high": ["فعّل الملف البديل للناشطين", "حدّد مسار دعم عند القمع",
                 "نسّق مع جهات حماية دولية", "أخفِ هوية الموقّعين"],
    }.get(level, [])
    return {"level": level, "advice": advice,
            "anonymous_signatures": conn.execute(
                "SELECT COUNT(*) AS n FROM campaign_signatures WHERE campaign_id=? AND anonymous=1",
                (campaign_id,)).fetchone()["n"]}


def campaign_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    total = conn.execute("SELECT COUNT(*) AS n FROM campaigns").fetchone()["n"]
    by_status = {r["status"]: r["n"] for r in conn.execute(
        "SELECT status, COUNT(*) AS n FROM campaigns GROUP BY status").fetchall()}
    sigs = conn.execute("SELECT COUNT(*) AS n FROM campaign_signatures").fetchone()["n"]
    anon = conn.execute(
        "SELECT COUNT(*) AS n FROM campaign_signatures WHERE anonymous=1").fetchone()["n"]
    pledges = conn.execute("SELECT COUNT(*) AS n FROM campaign_pledges").fetchone()["n"]
    broken = conn.execute(
        "SELECT COUNT(*) AS n FROM campaign_pledges WHERE state='broken'").fetchone()["n"]
    return {"total": total, "by_status": by_status, "signatures": sigs,
            "anonymous_signatures": anon, "pledges": pledges, "broken_pledges": broken}


def suggested_campaigns(conn: sqlite3.Connection, limit: int = 3) -> list[dict]:
    """اقتراح حملات بناءً على أنماط الانتهاكات (أكثر المجالات تكرارًا بلا حملة نشطة)."""
    rows = conn.execute(
        """SELECT r.category, COUNT(*) AS n FROM reports r
           WHERE r.category NOT IN (
             SELECT category FROM campaigns WHERE status='active' AND category IS NOT NULL)
           GROUP BY r.category ORDER BY n DESC LIMIT ?""", (limit,)
    ).fetchall()
    return [{"category": r["category"], "count": r["n"]} for r in rows]


def opportunities(conn: sqlite3.Connection, limit: int = 4) -> list[dict]:
    """فرص المناصرة: لحظات مناسبة (ارتفاع حديث في بلاغات مجال)."""
    rows = conn.execute(
        """SELECT category, COUNT(*) AS n FROM reports
           WHERE reported_on >= date('now','-90 days')
           GROUP BY category ORDER BY n DESC LIMIT ?""", (limit,)
    ).fetchall()
    return [{"category": r["category"], "count": r["n"],
             "reason": "ارتفاع بلاغات آخر 90 يومًا"} for r in rows]


def archive_campaign(conn: sqlite3.Connection, campaign_id: int) -> bool:
    """إغلاق الحملة مع الاحتفاظ بأرشيفها (status=closed، لا حذف)."""
    cur = conn.execute("UPDATE campaigns SET status='closed' WHERE id=?", (campaign_id,))
    conn.commit()
    return cur.rowcount > 0
