"""تصدير البيانات بصيغ مفتوحة: CSV، JSON، JSON Feed، RSS 2.0.

كل الصيغ مبنية على المكتبة القياسية، وتُنتَج من نفس دوال الاستعلام،
لتضمن الاتساق بين الواجهات والتصدير.
"""

import csv
import io
import json
import re
from datetime import datetime, timezone

from .taxonomy import (CATEGORIES, category_name, entity_kind_label, severity_label,
                       status_label)

SITE_TITLE = "مِرصد — منصة توثيق الانتهاكات"
SITE_URL = "https://example.org"
SITE_DESC = f"سجل مفتوح لتوثيق الانتهاكات في {len(CATEGORIES)} مجالًا."

CSV_COLUMNS = [
    ("id", "المعرّف"),
    ("title", "العنوان"),
    ("category", "المجال"),
    ("category_label", "المجال (عربي)"),
    ("severity", "الخطورة"),
    ("severity_label", "الخطورة (عربي)"),
    ("status", "الحالة"),
    ("status_label", "الحالة (عربي)"),
    ("country", "الدولة"),
    ("country_code", "رمز ISO3"),
    ("region", "المنطقة"),
    ("lat", "خط العرض"),
    ("lng", "خط الطول"),
    ("occurred_on", "تاريخ الواقعة"),
    ("reported_on", "تاريخ التوثيق"),
    ("verified", "موثّق"),
    ("source_name", "المصدر"),
    ("source_url", "رابط المصدر"),
    ("summary", "الملخّص"),
]


# محارف تُفسَّر كبداية صيغة في جداول البيانات (Excel/LibreOffice/Sheets):
# '=' و'+' و'-' و'@' إضافةً إلى TAB وCR. تُسبق بفاصلة عليا فتُقرأ الخلية نصًّا
# صِرفًا، وهذا يمنع تنفيذ صيغ مُخفاة (CSV/Formula Injection).
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def csv_cell(value) -> str:
    """يُحيّد قيمة خلية CSV لمنع تنفيذ الصيغ (CSV Injection)."""
    text = "" if value is None else str(value)
    if text and text[0] in _FORMULA_PREFIXES:
        return "'" + text
    return text


def _decorate(row: dict) -> dict:
    return {
        **row,
        "category_label": category_name(row.get("category", "")),
        "severity_label": severity_label(row.get("severity", "")),
        "status_label": status_label(row.get("status", "")),
        "verified": "نعم" if row.get("verified") else "لا",
    }


def to_csv(rows: list[dict]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow([label for _, label in CSV_COLUMNS])
    for row in rows:
        d = _decorate(row)
        writer.writerow([csv_cell(d.get(key, "")) for key, _ in CSV_COLUMNS])
    return buf.getvalue()


def to_json(rows: list[dict], meta: dict | None = None) -> str:
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "count": len(rows),
        "license": "CC BY 4.0",
        "source": SITE_TITLE,
        "items": [_decorate(r) for r in rows],
    }
    if meta:
        payload["meta"] = meta
    return json.dumps(payload, ensure_ascii=False, indent=2)


ENTITY_COLUMNS = [
    ("name", "الاسم"),
    ("kind", "النوع"),
    ("kind_label", "النوع (عربي)"),
    ("count", "عدد البلاغات"),
    ("wikidata_id", "معرّف ويكي بيانات"),
]

# أعمدة تصدير الأعضاء (بيانات عامة فقط — بلا أي حقول خاصّة).
MEMBER_COLUMNS = [
    ("handle", "المعرّف"),
    ("display_name", "الاسم"),
    ("role", "الدور"),
    ("status", "الحالة"),
    ("country", "الدولة"),
    ("langs", "اللغات"),
    ("interests", "المجالات"),
    ("org", "المنظّمة"),
    ("verified", "موثّق"),
]


def members_to_csv(rows: list[dict]) -> str:
    """يصدّر الأعضاء بصيغة CSV (حقول عامة فقط)."""
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow([label for _, label in MEMBER_COLUMNS])
    for row in rows:
        out = []
        for key, _ in MEMBER_COLUMNS:
            val = row.get(key, "")
            if key == "verified":
                val = "1" if val else "0"
            out.append(csv_cell(val if val is not None else ""))
        writer.writerow(out)
    return buf.getvalue()


def to_entities_csv(rows: list[dict]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow([label for _, label in ENTITY_COLUMNS])
    for row in rows:
        d = {**row, "kind_label": entity_kind_label(row.get("kind", ""))}
        writer.writerow([csv_cell(d.get(key, "")) for key, _ in ENTITY_COLUMNS])
    return buf.getvalue()


def to_entities_json(rows: list[dict], meta: dict | None = None) -> str:
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "count": len(rows),
        "license": "CC BY 4.0",
        "source": SITE_TITLE,
        "items": [
            {**r, "kind_label": entity_kind_label(r.get("kind", ""))} for r in rows
        ],
    }
    if meta:
        payload["meta"] = meta
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _iso(dt: str) -> str:
    """يحوّل تاريخاً نصياً إلى RFC 3339 (يُفترض أنه UTC)."""
    try:
        d = datetime.fromisoformat(dt)
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d.isoformat()
    except (ValueError, TypeError):
        return datetime.now(timezone.utc).isoformat()


def to_json_feed(rows: list[dict], feed_url: str) -> str:
    """JSON Feed 1.1 — https://www.jsonfeed.org/version/1.1/"""
    items = []
    for r in rows:
        items.append({
            "id": f"{SITE_URL}/reports/{r['id']}",
            "url": f"{SITE_URL}/reports/{r['id']}",
            "title": r["title"],
            "summary": r.get("summary", ""),
            "content_text": r.get("details") or r.get("summary", ""),
            "date_published": _iso(r.get("reported_on", "")),
            "tags": [category_name(r.get("category", "")), severity_label(r.get("severity", ""))],
            "authors": [{"name": r.get("source_name") or "مِرصد"}],
        })
    feed = {
        "version": "https://jsonfeed.org/version/1.1",
        "title": SITE_TITLE,
        "home_page_url": SITE_URL,
        "feed_url": feed_url,
        "description": SITE_DESC,
        "language": "ar",
        "items": items,
    }
    return json.dumps(feed, ensure_ascii=False, indent=2)


def _xml_escape(text: str) -> str:
    return (str(text or "")
            .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&apos;"))


def to_rss(rows: list[dict], feed_url: str) -> str:
    """RSS 2.0 مع امتداد Atom للروابط الذاتية."""
    now = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    parts = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">',
        '<channel>',
        f'<title>{_xml_escape(SITE_TITLE)}</title>',
        f'<link>{SITE_URL}</link>',
        f'<description>{_xml_escape(SITE_DESC)}</description>',
        '<language>ar</language>',
        f'<lastBuildDate>{now}</lastBuildDate>',
        f'<atom:link href="{_xml_escape(feed_url)}" rel="self" type="application/rss+xml"/>',
    ]
    for r in rows:
        link = f"{SITE_URL}/reports/{r['id']}"
        pub = _iso(r.get("reported_on", ""))
        parts += [
            "<item>",
            f"<title>{_xml_escape(r['title'])}</title>",
            f"<link>{link}</link>",
            f"<guid isPermaLink=\"true\">{link}</guid>",
            f"<pubDate>{pub}</pubDate>",
            f"<category>{_xml_escape(category_name(r.get('category','')))}</category>",
            f"<description>{_xml_escape(r.get('summary',''))}</description>",
            "</item>",
        ]
    parts += ["</channel>", "</rss>"]
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# الاستشهاد الأكاديمي (CSL: BibTeX / RIS / APA)
# ---------------------------------------------------------------------------

_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


def _plain(text) -> str:
    """يستبدل محارف التحكّم (سطر جديد/جدولة/… ) بمسافة.

    يمنع حقن أسطر جديدة داخل صيغ الاستشهاد (BibTeX/RIS) عبر حقول قابلة
    للتحرير من المستخدم (العنوان/المصدر/الرابط/الملخّص)، فلا يمكن إنهاء
    مدخل مزوَّر أو حقن مدخل إضافي.
    """
    return _CONTROL_RE.sub(" ", str(text if text is not None else ""))


def _year(row: dict) -> str:
    stamp = row.get("occurred_on") or row.get("reported_on") or ""
    return stamp[:4] if stamp else "ب.ت"


def _authors(row: dict) -> list[str]:
    src = _plain(row.get("source_name") or "").strip()
    return [src] if src else ["مِرصد"]


def to_bibtex(rows: list[dict], site_url: str = SITE_URL) -> str:
    """يُنتج مدخلات BibTeX لكل بلاغ (نوع misc)."""
    entries = []
    for r in rows:
        key = f"mirsad{r.get('id')}"
        fields = [
            ("title", r.get("title", "")),
            ("author", " and ".join(_authors(r))),
            ("year", _year(r)),
            ("howpublished", f"{SITE_TITLE}"),
            ("url", f"{_plain(site_url)}/reports/{r.get('id')}"),
            ("note", category_name(r.get("category", ""))),
        ]
        body = ",\n".join(f"  {k} = {{{_bib_escape(v)}}}" for k, v in fields)
        entries.append(f"@misc{{{key},\n{body}\n}}")
    return "\n\n".join(entries) + "\n"


def _bib_escape(text: str) -> str:
    return _plain(text).replace("{", "(").replace("}", ")").replace("\\", "")


def to_ris(rows: list[dict], site_url: str = SITE_URL) -> str:
    """يُنتج ملف RIS لكل بلاغ."""
    blocks = []
    for r in rows:
        lines = ["TY  - NEWS"]
        for a in _authors(r):
            lines.append(f"AU  - {a}")
        lines.append(f"TI  - {_plain(r.get('title',''))}")
        lines.append(f"PY  - {_plain(_year(r))}")
        lines.append(f"UR  - {_plain(site_url)}/reports/{r.get('id')}")
        lines.append(f"KW  - {_plain(category_name(r.get('category','')))}")
        if r.get("country"):
            lines.append(f"CY  - {_plain(r['country'])}")
        lines.append(f"AB  - {_plain(r.get('summary',''))}")
        lines.append("ER  - ")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks) + "\n"


def to_apa(rows: list[dict], site_url: str = SITE_URL) -> str:
    """يُنتج قائمة مراجع بنمط APA (سطر لكل بلاغ)."""
    lines = []
    for r in rows:
        authors = ", ".join(_authors(r))
        lines.append(
            f"{authors}. ({_year(r)}). {_plain(r.get('title',''))}. "
            f"{SITE_TITLE}. {_plain(site_url)}/reports/{r.get('id')}"
        )
    return "\n".join(lines) + "\n"


def to_mla(rows: list[dict], site_url: str = SITE_URL) -> str:
    """يُنتج قائمة مراجع بنمط MLA (سطر لكل بلاغ)."""
    lines = []
    for r in rows:
        author = (_authors(r) or [SITE_TITLE])[0]
        lines.append(
            f'"{_plain(r.get("title", ""))}." {SITE_TITLE}, {_year(r)}, '
            f"{_plain(site_url)}/reports/{r.get('id')}."
        )
    return "\n".join(lines) + "\n"


def to_chicago(rows: list[dict], site_url: str = SITE_URL) -> str:
    """يُنتج قائمة مراجع بنمط شيكاغو (سطر لكل بلاغ)."""
    lines = []
    for r in rows:
        author = (_authors(r) or [SITE_TITLE])[0]
        lines.append(
            f'{author}. "{_plain(r.get("title", ""))}." {SITE_TITLE} '
            f"({_year(r)}). {_plain(site_url)}/reports/{r.get('id')}."
        )
    return "\n".join(lines) + "\n"
