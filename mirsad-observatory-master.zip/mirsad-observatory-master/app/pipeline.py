"""خط المعالجة الموحّد (القسم 3).

كل عنصر يجمع من مصدر يمرّ عبر ثماني مراحل قبل أن يصبح سجلًا منشورًا:

1. الجمع (ingested): استخراج المحتوى + الرابط الأصلي + وقت الجلب + المعرّف.
2. التطبيع (normalized): تنظيف النص وتوحيد التواريخ/الروابط مع حفظ الأصل.
3. الاستخراج (extracted): العنوان، الملخص، التواريخ، الأشخاص/الجهات/المواقع، الأدلة.
4. التصنيف (classified): نوع المحتوى والقسم (متعدّد الوسوم + أساسي).
5. كشف التكرار وربط الوقائع (deduped): مقارنة بالقاعدة وربط المصادر بالواقعة.
6. التحقق (verified): تقييم موثوقية المصادر واستقلالها وتوافق التفاصيل.
7. الإجراء (actioned): سجل جديد / تحديث موجود / إرفاق مصدر / إحالة للمراجعة.
8. التدقيق (audited): حفظ نتيجة كل مرحلة وسبب القرار والتوقيت.

كل مرحلة **قابلة لإعادة التنفيذ** (idempotent): إعادة تشغيلها لا تُنشئ سجلات
مكرّرة ولا تُكرّر الآثار الجانبية (بفضل قيود `documents` الفريدة و`dedup`).
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
from datetime import date, datetime, timezone

from . import connectors, db, dedup, verification
from .actors import match_actors
from .importers import _guess_country, classify
from .taxonomy import CATEGORY_KEYS, DOCUMENT_TYPE_BY_KEY
from .textutils import normalize_arabic

log = logging.getLogger("mirsad.pipeline")

_TAGS = re.compile(r"<[^>]+>")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --- المرحلة 1: الجمع ---

def ingest(conn: sqlite3.Connection, source: dict, *,
           maxrecords: int = 12) -> dict:
    """يجمع عناصر مصدر ويُدرجها كمستندات (بلا تكرار). يعزل أخطاء المصدر.

    يعيد ملخّصًا: fetched / inserted / duplicates / error.
    """
    result = {"source": source.get("key") or source.get("name"),
              "fetched": 0, "inserted": 0, "duplicates": 0, "error": None}
    try:
        items = connectors.collect_source(source, maxrecords=maxrecords)
    except Exception as exc:  # noqa: BLE001 — مصدر معطّل لا يُفشل بقية المصادر
        result["error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
        return result

    for it in items:
        result["fetched"] += 1
        doc_id, is_dup = ingest_item(conn, source, it)
        if is_dup:
            result["duplicates"] += 1
        elif doc_id:
            result["inserted"] += 1
    return result


def ingest_item(conn: sqlite3.Connection, source: dict, item: dict) -> tuple[int, bool]:
    """يُدرج عنصرًا واحدًا كمستند. يعيد (المعرّف، هل هو مكرّر لنفس المصدر).

    منع التكرار على المستوى الدقيق: نفس المصدر + نفس المعرّف/الرابط (قيد فريد).
    أما المحتوى نفسه الوارد من **مصادر مختلفة** فيُحفظ كمستند مستقل لكل مصدر
    (ضروري لتقييم استقلال المصادر)، لكنه يُوسم `dup_of` بالمستند الأسبق، ويُربط
    بالسجل نفسه عبر كشف التكرار على مستوى الوقائع فلا يتكرّر السجل.
    """
    title = (item.get("title") or "").strip()[:300]
    body = (item.get("body") or item.get("summary") or "").strip()
    url = item.get("url") or ""
    if not title or not url:
        return 0, False
    external_id = str(item.get("external_id") or url)
    source_key = source.get("key") or source.get("name") or "unknown"
    digest = dedup.content_digest(title, body)

    # مكرّر لنفس المصدر (نفس المعرّف) → لا نُدرج مرّة أخرى.
    same = conn.execute(
        "SELECT id FROM documents WHERE source_key = ? AND external_id = ?",
        (source_key, external_id)).fetchone()
    if same:
        return int(same["id"]), True

    # نفس المحتوى من مصدر آخر: مستند مستقل مع وسم المرجع (للشفافية والاستقلال).
    dup_of = None
    others = db.documents_by_digest(conn, digest)
    if others:
        dup_of = int(others[0]["id"])

    doc_id = db.insert_document(conn, {
        "source_key": source_key,
        "source_name": source.get("name") or source_key,
        "source_url": source.get("url"),
        "url": url,
        "canonical_url": dedup.canonical_url(url),
        "external_id": external_id,
        "title": title,
        "summary": item.get("summary") or body[:600],
        "body": body,
        "raw": item.get("raw"),
        "content_digest": digest,
        "published_on": item.get("published_on") or None,
        "dup_of": dup_of,
        "dup_reason": "محتوى مطابق لمستند سابق من مصدر آخر" if dup_of else None,
        "stage": "ingested",
        "state": "pending",
    })
    return doc_id, False


# --- المرحلة 2: التطبيع ---

def normalize(doc: dict) -> dict:
    """ينظّف النص ويوحّد التواريخ واللغة مع الاحتفاظ بالأصل (`raw`)."""
    title = _TAGS.sub(" ", doc.get("title") or "").strip()
    body = _TAGS.sub(" ", doc.get("body") or "").strip()
    body = re.sub(r"\s+", " ", body)
    return {
        "title": title,
        "body": body,
        "summary": (doc.get("summary") or body[:600]),
        "lang": _detect_lang(f"{title} {body}"),
    }


def _detect_lang(text: str) -> str:
    arabic = sum(1 for ch in text if "\u0600" <= ch <= "\u06FF")
    return "ar" if arabic >= max(3, len(text) * 0.15) else "en"


# --- المرحلة 3: الاستخراج ---

def extract(doc: dict) -> dict:
    """يستخرج العنوان/الملخص/التواريخ/الجهات/المواقع/الأدلة."""
    text = f"{doc.get('title') or ''} {doc.get('body') or ''}"
    country, code, lat, lng = _guess_country(doc.get("title") or "")
    entities = [a["name"] for a in match_actors(text, limit=12)]
    urls = re.findall(r"https?://[^\s\"'<>]+", doc.get("body") or "")
    return {
        "occurred_on": _extract_date(text) or doc.get("occurred_on"),
        "published_on": doc.get("published_on"),
        "country": country,
        "country_code": code,
        "lat": lat, "lng": lng,
        "entities": entities,
        "evidence_links": urls[:10],
    }


_DATE_PATTERNS = [
    re.compile(r"(\d{4})-(\d{2})-(\d{2})"),
    re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})"),
]


def _extract_date(text: str) -> str | None:
    for pat in _DATE_PATTERNS:
        m = pat.search(text)
        if not m:
            continue
        try:
            if pat is _DATE_PATTERNS[0]:
                return f"{m.group(1)}-{m.group(2)}-{m.group(3)}"
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if 1 <= d <= 31 and 1 <= mo <= 12:
                return f"{y:04d}-{mo:02d}-{d:02d}"
        except ValueError:
            continue
    return None


# --- المرحلة 4: التصنيف ---

def classify_document(doc: dict, source: dict | None = None) -> dict:
    """يحدّد نوع المحتوى والقسم مع دعم تصنيف متعدّد الوسوم وأساسي للنشر."""
    text = f"{doc.get('title') or ''} {doc.get('body') or ''}"
    auto_cat, severity, confidence = classify(doc.get("title") or "")
    ref_cat = (source or {}).get("domain") or "human_rights"
    ref_sev = (source or {}).get("severity") or "medium"
    category = auto_cat if confidence > 0 and auto_cat in CATEGORY_KEYS else ref_cat
    if severity == "medium" and ref_sev in ("high", "critical"):
        severity = ref_sev

    doc_type, tags = _classify_type(text)
    return {"category": category, "severity": severity,
            "doc_type": doc_type, "tags": tags}


def _classify_type(text: str) -> tuple[str, list[str]]:
    """يصنّف نوع المستند (متعدّد الوسوم) ويعيد (الأساسي، كل الوسوم)."""
    tags: list[str] = []
    is_update, is_correction = dedup.detect_update(text)
    low = normalize_arabic(text)
    if is_correction:
        tags.append("correction")
    if any(w in low for w in ("تقرير", "تحقيق", "report", "investigation", "briefing")):
        tags.append("report")
    if any(w in low for w in ("بلاغ", "شكوى", "complaint", "testimony", "شهادة")):
        tags.append("claim")
    if any(w in low for w in ("اعتقال", "احتجاز", "تعذيب", "قصف", "انتهاك", "قتل",
                              "اعتقل", "detained", "torture", "abuse", "killed",
                              "violation", "attack", "استشهاد", "اختفاء")):
        tags.append("violation")
    if not tags or (not is_correction and not is_update):
        tags.append("news")
    # الأساسي: تصحيح > انتهاك > تقرير > بلاغ > خبر.
    for primary in ("correction", "violation", "report", "claim", "news"):
        if primary in tags:
            return primary, sorted(set(tags))
    return "news", sorted(set(tags))


# --- المرحلة 5-8: المعالجة الكاملة لعنصر ---

def process_document(conn: sqlite3.Connection, doc_id: int, *,
                     source: dict | None = None, index: dict | None = None,
                     task_id: str | None = None) -> dict:
    """يمرّر مستندًا عبر المراحل 2..8 ويعيد قراره.

    يُعيد: {document_id, decision, report_id, state, stages}
    """
    doc = db.document_by_id(conn, doc_id)
    if not doc:
        return {"document_id": doc_id, "decision": "missing"}
    source = source or _source_for(conn, doc.get("source_key"))
    stages = ["ingested"]

    # 2) التطبيع
    norm = normalize(doc)
    db.set_document_stage(conn, doc_id, "normalized")
    stages.append("normalized")

    # 3) الاستخراج
    ext = extract({**doc, **norm})
    db.set_document_stage(conn, doc_id, "extracted")
    stages.append("extracted")

    # 4) التصنيف
    cls = classify_document({**doc, **norm}, source)
    db.set_document_stage(conn, doc_id, "classified")
    stages.append("classified")

    # نحدّث المستند بالحقول المستخرجة والمصنّفة.
    conn.execute(
        """UPDATE documents SET title = ?, body = ?, summary = ?, lang = ?,
           occurred_on = ?, published_on = COALESCE(published_on, ?),
           category = ?, severity = ?, doc_type = ?, tags = ?, country = ?, region = ?,
           entities = ?, stage = 'classified' WHERE id = ?""",
        (norm["title"], norm["body"], norm["summary"], norm["lang"],
         ext.get("occurred_on"), ext.get("published_on"),
         cls["category"], cls["severity"], cls["doc_type"],
         json.dumps(cls["tags"], ensure_ascii=False), ext.get("country"),
         doc.get("region"),
         json.dumps(ext.get("entities") or [], ensure_ascii=False), doc_id))
    conn.commit()

    # 5) كشف التكرار وربط الوقائع
    candidate = {
        "title": norm["title"], "body": norm["body"],
        "url": doc.get("url"), "external_id": doc.get("external_id"),
        "content_digest": doc.get("content_digest"),
        "category": cls["category"], "country": ext.get("country"),
        "region": doc.get("region"), "occurred_on": ext.get("occurred_on"),
        "published_on": ext.get("published_on"), "entities": ext.get("entities"),
    }
    dup = dedup.find_duplicate(conn, candidate, index)
    db.set_document_stage(conn, doc_id, "deduped")
    stages.append("deduped")

    decision = dup.decision
    report_id = dup.report_id

    # 6-8) الإجراء حسب القرار
    if decision == dedup.NEW:
        report_id = _create_report(conn, doc, norm, ext, cls, source, task_id)
        _attach_evidence(conn, report_id, doc, source, supports="supports")
        db.set_document_stage(conn, doc_id, "actioned", state="processed")
        conn.execute("UPDATE documents SET report_id = ?, stage = 'audited' WHERE id = ?",
                     (report_id, doc_id))
        conn.commit()
        decision = "new"

    elif decision in (dedup.EXACT, dedup.UPDATE):
        if report_id:
            _attach_evidence(conn, report_id, doc, source,
                             supports="corrects" if dup.is_correction else "supports")
            conn.execute("UPDATE documents SET report_id = ?, dup_of = NULL, "
                         "dup_reason = ?, stage = 'audited', state = 'processed' "
                         "WHERE id = ?", (report_id, dup.reason, doc_id))
            conn.commit()
            db.log_change(conn, "documents", doc_id, field="linked_report",
                          new_value=report_id, reason=dup.reason,
                          source=doc.get("source_name"), task_id=task_id)
        db.set_document_stage(conn, doc_id, "audited", state="processed")
        decision = "update" if dup.is_update else "exact"

    else:
        # probable / uncertain: لا دمج نهائي — إحالة للمراجعة. نحفظ معرّف السجل
        # المرشّح في سبب التكرار للنظر فيه، ولا نربط المستند فعليًّا (منع دمج
        # سجلين عند الشك).
        reason = dup.reason
        if report_id:
            reason = f"{reason} (مرشّح للربط بالسجل #{report_id})"
        db.set_document_stage(conn, doc_id, "audited", state="review")
        conn.execute("UPDATE documents SET dup_of = NULL, dup_reason = ?, "
                     "stage = 'audited' WHERE id = ?", (reason, doc_id))
        conn.commit()
        report_id = None  # لم يُدمج فعليًّا
        decision = decision  # probable|uncertain

    # 6) التحقق على السجل المرتبط (إن وُجد)
    state = None
    if report_id and decision in ("new", "exact", "update"):
        vres = verification.apply(conn, report_id, actor="pipeline", task_id=task_id)
        state = vres.get("state")

    stages.append("verified")
    stages.append("actioned")
    stages.append("audited")
    return {"document_id": doc_id, "decision": decision, "report_id": report_id,
            "state": state, "dup": dup.as_dict(), "stages": stages,
            "doc_type": cls["doc_type"], "category": cls["category"]}


def _source_for(conn: sqlite3.Connection, source_key: str | None) -> dict | None:
    if not source_key:
        return None
    row = conn.execute("SELECT * FROM source_catalog WHERE key = ?",
                       (source_key,)).fetchone()
    return dict(row) if row else None


def _create_report(conn: sqlite3.Connection, doc: dict, norm: dict, ext: dict,
                   cls: dict, source: dict | None, task_id: str | None) -> int:
    """ينشئ سجلًا جديدًا مع حفظ وقت الرصد منفصلًا عن الوقوع/النشر."""
    occurred = ext.get("occurred_on") or doc.get("published_on") or date.today().isoformat()
    reported = doc.get("published_on") or occurred
    source_id = None
    if source:
        row = conn.execute("SELECT id FROM sources WHERE key = ?",
                           (source.get("key"),)).fetchone()
        source_id = row["id"] if row else None
    details = (f"سجل مجمّع آليًّا من «{doc.get('source_name')}» "
               f"(نوع المحتوى: {DOCUMENT_TYPE_BY_KEY.get(cls['doc_type'], {}).get('label', cls['doc_type'])}). "
               "يتطلّب مراجعة بشرية قبل التوثيق النهائي.")
    report_id = db.insert_report(conn, {
        "title": norm["title"][:240],
        "category": cls["category"],
        "severity": cls["severity"],
        "status": "new",
        "country": ext.get("country") or "غير محدّد",
        "country_code": ext.get("country_code"),
        "region": doc.get("region"),
        "lat": ext.get("lat"), "lng": ext.get("lng"),
        "occurred_on": occurred,
        "reported_on": reported,
        "dedup_key": db.compute_dedup_key(norm["title"], cls["category"],
                                          ext.get("country"), occurred),
        "summary": norm["summary"][:600],
        "details": details,
        "source_name": doc.get("source_name"),
        "source_url": doc.get("url"),
        "source_id": source_id,
        "external_id": f"doc:{doc['id']}",
        "verified": 0,
        "content_digest": doc.get("content_digest"),
    })
    conn.execute("UPDATE reports SET discovered_at = ?, updated_at = ?, "
                 "content_digest = ? WHERE id = ?",
                 (_now(), _now(), doc.get("content_digest"), report_id))
    # وسوم نوع المستند على السجل.
    conn.commit()
    db.log_change(conn, "reports", report_id, field="created",
                  new_value="auto", reason="واقعة جديدة عبر خط المعالجة",
                  source=doc.get("source_name"), task_id=task_id)
    return report_id


def _attach_evidence(conn: sqlite3.Connection, report_id: int, doc: dict,
                     source: dict | None, *, supports: str = "supports") -> None:
    """يربط مصدر المستند بالواقعة كدليل (مع تصنيف النوع والاستقلال الأولي)."""
    kind = "primary" if (source or {}).get("source_kind") in ("official", "primary") \
        else "secondary"
    reliability = verification.source_reliability(source)
    db.add_evidence(
        conn, report_id, source_name=doc.get("source_name") or "مصدر",
        source_url=doc.get("url"), source_key=doc.get("source_key"),
        document_id=doc["id"], source_kind=kind, reliability=reliability,
        independence="unknown", supports=supports, added_by="pipeline")


def process_pending(conn: sqlite3.Connection, *, limit: int = 20,
                    task_id: str | None = None) -> dict:
    """يعالج دفعة من المستندات المعلّقة عبر خط المعالجة الكامل."""
    pending = db.documents_pending(conn, limit=limit)
    index = dedup.build_index(conn)
    summary = {"processed": 0, "new": 0, "updates": 0, "exact": 0, "review": 0,
               "errors": 0}
    for doc in pending:
        try:
            res = process_document(conn, doc["id"], index=index, task_id=task_id)
        except Exception as exc:  # noqa: BLE001 — عنصر معطّل لا يُفشل الدفعة
            log.warning("فشل معالجة المستند %s: %s", doc["id"], exc)
            summary["errors"] += 1
            continue
        summary["processed"] += 1
        decision = res.get("decision")
        if decision == "new":
            summary["new"] += 1
        elif decision == "update":
            summary["updates"] += 1
        elif decision == "exact":
            summary["exact"] += 1
        else:
            summary["review"] += 1
        # تحديث الفهرس بالسجل الجديد كي لا تتكرّر الوقائع داخل الدفعة نفسها.
        if decision == "new" and res.get("report_id"):
            index = dedup.build_index(conn)
    return summary
