"""طبقة المنصّة الاجتماعية: الأعضاء (وسيط تعاون بين الناشطين).

هذا الملف هو المصدر الوحيد لبيانات أعضاء المنصّة التجريبية ودوال الاستعلام
عنهم. البيانات تجريبية بالكامل ولا تمثّل أشخاصًا حقيقيين؛ أسماء مستعارة فقط،
ولا تُخزَّن أي بيانات شخصية حسّاسة (بريد، هاتف، موقع دقيق).

الأدوار والحالات مُعرَّفة في `taxonomy` (MEMBER_ROLES/MEMBER_STATUSES).
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .taxonomy import (
    BADGE_BY_KEY,
    CLAIM_SOURCE_KIND_BY_KEY,
    MEMBER_ROLE_BY_KEY,
    MEMBER_STATUS_BY_KEY,
    MODERATION_ACTION_BY_KEY,
    REPORT_STATE_BY_KEY,
    SUBSCRIPTION_KIND_BY_KEY,
    trust_level_for_score,
)
from .textutils import build_search_text

# أسماء مستعارة تجريبية (handle, display_name, role, status, country, langs,
# interests, org, verified, published, bio_ar, bio_en)
SEED_MEMBERS: list[tuple] = [
    ("mirsad_admin", "إدارة مِرصد", "admin", "active", None, "ar,en", None,
     "مِرصد", 1, 1, "حساب إدارة المنصّة.", "Platform administration."),
    ("noor.mod", "نور", "moderator", "active", "الأردن", "ar,en", "human_rights,media",
     None, 1, 1, "مشرفة محتوى، تعمل على مراجعة البلاغات.", "Content moderator."),
    ("sami.verify", "سامي", "verifier", "active", "لبنان", "ar,fr", "human_rights",
     None, 1, 1, "مُحقّق حقائق، متخصّص في التحقّق من الصور والفيديو.", "Fact-checker."),
    ("hala.verify", "هالة", "verifier", "active", "مصر", "ar,en", "environment",
     None, 1, 1, "مُحقّقة بيئية، تتبّع التلوّث والمخالفات الصناعية.", "Environmental verifier."),
    ("yara.act", "يارا", "activist", "active", "فلسطين", "ar", "human_rights,children",
     None, 0, 1, "ناشطة ميدانية في حقوق الإنسان.", "Field activist."),
    ("omar.act", "عمر", "activist", "active", "العراق", "ar,en", "human_rights,media",
     None, 0, 1, "ناشط إعلامي يوثّق الانتهاكات.", "Media activist."),
    ("lina.act", "لينا", "activist", "active", "المغرب", "ar,fr", "animal_rights",
     None, 0, 1, "ناشطة في حقوق الحيوان.", "Animal-rights activist."),
    ("khaled.act", "خالد", "activist", "active", "السودان", "ar", "human_rights,environment",
     None, 0, 1, "ناشط في مجال البيئة وحقوق الأرض.", "Environment and land-rights activist."),
    ("dina.act", "دينا", "activist", "active", "تونس", "ar,fr,en", "media,labor",
     None, 1, 1, "صحفية مستقلة، تغطّي قضايا العمل.", "Independent journalist."),
    ("fadi.act", "فادي", "activist", "active", "سوريا", "ar", "human_rights",
     None, 0, 1, "ناشط في توثيق الاعتقالات التعسفية.", "Activist documenting arbitrary detention."),
    ("rana.act", "رنا", "activist", "active", "اليمن", "ar", "children,human_rights",
     None, 0, 1, "ناشطة في حماية الأطفال.", "Child-protection activist."),
    ("tariq.act", "طارق", "activist", "active", "ليبيا", "ar,en", "environment",
     None, 0, 1, "ناشط بيئي يرصد تسرّبات النفط.", "Environmental activist."),
    ("maya.act", "مايا", "activist", "active", "الكويت", "ar,en", "labor",
     None, 0, 1, "ناشطة عمالية.", "Labor-rights activist."),
    ("ziad.act", "زياد", "activist", "active", "قطر", "ar,en", "human_rights",
     None, 0, 1, "ناشط حقوقي.", "Rights activist."),
    ("salma.mem", "سلمى", "member", "active", "البحرين", "ar", "media",
     None, 0, 1, "مهتمّة بالإعلام والتوثيق.", "Interested in media and documentation."),
    ("adam.mem", "آدم", "member", "active", "الجزائر", "ar,fr", "environment",
     None, 0, 1, "مهتم بالبيئة.", "Interested in environment."),
    ("reem.mem", "ريم", "member", "active", "السعودية", "ar,en", "human_rights",
     None, 0, 1, "عضو جديد في المجتمع.", "New community member."),
    ("bilal.mem", "بلال", "member", "pending", "موريتانيا", "ar", "animal_rights",
     None, 0, 1, "بانتظار مراجعة الانضمام.", "Awaiting join review."),
    ("nadia.mem", "نادية", "member", "active", "الصومال", "ar,en", "children",
     None, 0, 1, "مهتمّة بقضايا الأطفال.", "Interested in children's issues."),
    ("hamza.mem", "حمزة", "member", "suspended", "لبنان", "ar", "media",
     None, 0, 0, "حساب موقوف مؤقّتًا (نموذج عرض).", "Temporarily suspended (demo)."),
    ("mona.mem", "منى", "member", "left", "مصر", "ar", "labor",
     None, 0, 1, "غادرت المجتمع (نموذج عرض).", "Left the community (demo)."),
    ("sara.act", "سارة", "activist", "active", "الأردن", "ar,en", "human_rights,children",
     "شبكة حقوق الطفل", 1, 1, "منسّقة تحالف حقوق الطفل.", "Child-rights coalition coordinator."),
    ("hussein.act", "حسين", "activist", "active", "العراق", "ar", "environment,human_rights",
     None, 0, 1, "ناشط في قضايا المياه والبيئة.", "Water and environment activist."),
    ("aya.mem", "آية", "member", "active", "تونس", "ar,fr,en", "media,human_rights",
     None, 0, 1, "طالبة صحافة متعاونة.", "Journalism student collaborator."),
]

# مرادفات عرض لبعض الدول (تُطبَّع عبر countries)
_VALID_ROLES = set(MEMBER_ROLE_BY_KEY)
_VALID_STATUSES = set(MEMBER_STATUS_BY_KEY)


def seed_members(conn: sqlite3.Connection) -> None:
    """يعبّئ جدول الأعضاء بالبيانات التجريبية (مرّة واحدة)."""
    existing = conn.execute("SELECT COUNT(*) AS n FROM members").fetchone()["n"]
    if existing:
        return
    rows = []
    for (handle, name, role, status, country, langs, interests, org,
         verified, published, bio, bio_en) in SEED_MEMBERS:
        rows.append((
            handle, name, role if role in _VALID_ROLES else "member",
            status if status in _VALID_STATUSES else "active",
            bio, bio_en, country, langs, interests, org, handle, verified, published, 1,
        ))
    conn.executemany(
        """INSERT OR IGNORE INTO members
           (handle, display_name, role, status, bio, bio_en, country, langs,
            interests, org, avatar_seed, verified, published, is_seed)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        rows,
    )
    conn.commit()


# ---------------------------------------------------------------------------
# الاستعلامات
# ---------------------------------------------------------------------------

_ROLE_ORDER = ("CASE role WHEN 'admin' THEN 6 WHEN 'moderator' THEN 5 "
               "WHEN 'verifier' THEN 4 WHEN 'activist' THEN 3 "
               "WHEN 'member' THEN 2 ELSE 1 END")


def query_members(
    conn: sqlite3.Connection,
    *,
    role: str | None = None,
    status: str | None = None,
    country: str | None = None,
    q: str | None = None,
    published_only: bool = True,
    sort: str = "role",
    limit: int | None = None,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """يعيد أعضاء مُصفّين. لا يكشف الحقول الخاصّة في الوضع العام."""
    where, params = [], []
    if published_only:
        where.append("published = 1")
    if role:
        where.append("role = ?"); params.append(role)
    if status:
        where.append("status = ?"); params.append(status)
    if country:
        where.append("country = ?"); params.append(country)
    if q and q.strip():
        like = f"%{q.strip()}%"
        where.append("(display_name LIKE ? OR handle LIKE ? OR org LIKE ? "
                     "OR interests LIKE ? OR bio LIKE ?)")
        params += [like, like, like, like, like]

    order = {
        "role": f"{_ROLE_ORDER} DESC, display_name ASC",
        "name": "display_name ASC",
        "recent": "created_at DESC, id DESC",
        "verified": "verified DESC, display_name ASC",
    }.get(sort, f"{_ROLE_ORDER} DESC, display_name ASC")

    sql = "SELECT * FROM members"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {order}"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def count_members(conn: sqlite3.Connection, *, published_only: bool = True,
                  **filters: Any) -> int:
    rows = query_members(conn, published_only=published_only, **filters)
    return len(rows)


def member_by_handle(conn: sqlite3.Connection, handle: str) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM members WHERE handle = ?", (handle,)
    ).fetchone()
    return dict(row) if row else None


def member_counts(conn: sqlite3.Connection) -> dict[str, dict[str, int]]:
    """عدّاد الأعضاء لكل دور ولكل حالة (لمرشّحات الواجهة)."""
    roles: dict[str, int] = {}
    for r in conn.execute(
        "SELECT role, COUNT(*) AS n FROM members WHERE published = 1 GROUP BY role"
    ):
        roles[r["role"]] = r["n"]
    statuses: dict[str, int] = {}
    for r in conn.execute(
        "SELECT status, COUNT(*) AS n FROM members WHERE published = 1 GROUP BY status"
    ):
        statuses[r["status"]] = r["n"]
    return {"role": roles, "status": statuses}


def member_countries(conn: sqlite3.Connection) -> list[str]:
    """الدول التي ينتمي إليها أعضاء منشورون (للترتيب الأبجدي)."""
    return [r["country"] for r in conn.execute(
        "SELECT DISTINCT country FROM members "
        "WHERE published = 1 AND country IS NOT NULL AND country != '' "
        "ORDER BY country"
    )]


def members_summary(conn: sqlite3.Connection, limit: int | None = None) -> list[dict]:
    """ملخّص مرتّب حسب الدور ثم الحالة (للعرض السريع)."""
    return query_members(conn, sort="role", limit=limit)


# ---------------------------------------------------------------------------
# منشورات المجتمع (الدفعة 2)
# ---------------------------------------------------------------------------

# (author_handle, kind, visibility, title, title_en, body, body_en, tags, days_ago)
SEED_POSTS: list[tuple] = [
    ("sami.verify", "analysis", "public",
     "تحليل: أنماط التحقّق من مقاطع الفيديو الميدانية",
     "Analysis: patterns in verifying field video",
     "رصدنا ثلاث إشارات موثوقة للتحقّق من مقاطع الفيديو الميدانية: زمن الظلّ، "
     "اتّساق الطقس، وتطابق المعالم الجغرافية. نوصي بمقارنة إطارين مستقلّين على الأقل.",
     "We track three reliable signals for verifying field video: shadow time, weather "
     "consistency, and matching landmarks. Compare at least two independent frames.",
     "verification,media", 1),
    ("hala.verify", "news", "public",
     "تسرّب صناعي جديد قرب مصبّ النهر — قيد التوثيق",
     "New industrial spill near the river mouth — under documentation",
     "وردتنا صور ومصادر محلية عن تسرّب قرب مصبّ النهر. نراجع تقارير الجهات البيئية "
     "ونطلب أي شهادات إضافية من السكان المجاورين.",
     "We received photos and local sources about a spill near the river mouth. We are "
     "reviewing environmental reports and asking nearby residents for testimony.",
     "environment,water", 2),
    ("yara.act", "testimony", "public",
     "شهادة ميدانية: اعتقال تعسّفي في الحي الشرقي",
     "Field testimony: arbitrary detention in the eastern district",
     "وثّقنا شهادات ثلاثة شهود عيان حول اعتقال تعسّفي. راجعنا أسماء الموقوفين مع "
     "المصادر المتاحة، ونحافظ على سرّية هوية الشهود.",
     "We documented three eyewitness testimonies about an arbitrary detention. We "
     "cross-checked the detainees' names with available sources and protect witnesses.",
     "human_rights,detention", 3),
    ("dina.act", "call", "public",
     "طلب مساعدة: ترجمة شهادات من الفرنسية",
     "Call for help: translating testimonies from French",
     "لدينا أربع شهادات بالفرنسية تحتاج ترجمة دقيقة إلى العربية والإنجليزية. "
     "من يستطيع المساعدة خلال هذا الأسبوع؟",
     "We have four testimonies in French needing accurate Arabic and English "
     "translation. Who can help this week?",
     "translation,collaboration", 4),
    ("omar.act", "update", "public",
     "تحديث: إعادة نشر المواد المصوّرة بعد التحقّق",
     "Update: republishing media material after verification",
     "أعدنا نشر حزمة المواد المصوّرة بعد استكمال التحقّق الثنائي، مع إخفاء أي "
     "بيانات تكشف هوية المصادر.",
     "We republished the media package after completing two-source verification, "
     "redacting anything that could expose source identities.",
     "media,verification", 5),
    ("lina.act", "campaign", "public",
     "حملة: إنهاء القسوة في مسالخ الدواجن",
     "Campaign: ending cruelty in poultry slaughterhouses",
     "أطلقنا حملة موثّقة بمقاطع قصيرة وتقارير ميدانية، ونطالب بتفتيش مستقلّ وشفافية "
     "في تقارير المخالفات.",
     "We launched a documented campaign with short clips and field reports, calling "
     "for independent inspection and transparent violation reporting.",
     "animal_rights,campaign", 6),
    ("khaled.act", "analysis", "members",
     "تحليل داخلي: خريطة مخالفات المياه",
     "Internal analysis: water-violations map",
     "مسودّة تحليلية أولية لخريطة مخالفات المياه عبر المحافظات. للمراجعة داخل "
     "المجموعة قبل النشر العام.",
     "A preliminary analytical draft mapping water violations across provinces. "
     "For in-group review before public release.",
     "environment,water,analysis", 7),
    ("sara.act", "news", "public",
     "خبر: تحالف حقوق الطفل يطلق خطّ إبلاغ مستقلًّا",
     "News: child-rights coalition launches an independent reporting line",
     "أطلق التحالف خطًّا مستقلًّا للإبلاغ عن انتهاكات حقوق الطفل، مع ضمانات "
     "لحماية المبلّغين.",
     "The coalition launched an independent reporting line for child-rights "
     "violations, with protections for reporters.",
     "children,human_rights", 8),
    ("fadi.act", "correction", "public",
     "تصحيح: تحديث اسم جهة وردت في بلاغ سابق",
     "Correction: updating an entity name in an earlier report",
     "صحّحنا اسم جهة وردت خطأً في بلاغ سابق بعد مراجعة السجل الرسمي، وأضفنا "
     "ملاحظة منهجية.",
     "We corrected an entity name misstated in an earlier report after reviewing "
     "official records, and added a methodology note.",
     "correction,methodology", 9),
    ("rana.act", "call", "public",
     "طلب مساعدة: توثيق أثر النزوح على الأطفال",
     "Call for help: documenting displacement impact on children",
     "نبحث عن متطوّعين لمسح أثر النزوح على تعليم الأطفال في المخيّمات، مع "
     "منهجية واضحة لحماية الخصوصية.",
     "We seek volunteers to survey displacement impact on children's education in "
     "camps, with a clear privacy-protecting methodology.",
     "children,displacement", 10),
    ("tariq.act", "update", "public",
     "تحديث: نتائج فحص عيّنات مياه بعد التسرّب",
     "Update: water-sample results after the spill",
     "أظهرت العيّنات ارتفاعًا في مؤشّرات التلوّث. ننتظر نتائج مختبر مستقلّ ثانٍ "
     "قبل نشر الاستنتاج النهائي.",
     "Samples showed elevated contamination indicators. Awaiting a second "
     "independent lab before publishing a final conclusion.",
     "environment,water", 11),
    ("hussein.act", "testimony", "members",
     "شهادة محلية: مخالفات في إدارة مياه الريّ",
     "Local testimony: violations in irrigation-water management",
     "جمعنا شهادات مزارعين حول مخالفات في توزيع مياه الريّ. الملف داخلي بانتظار "
     "تحقّق ميداني إضافي.",
     "We collected farmers' testimonies on violations in irrigation-water "
     "distribution. The file is internal pending further field verification.",
     "environment,water,testimony", 12),
    ("maya.act", "analysis", "public",
     "تحليل: مخالفات السلامة في مواقع العمل",
     "Analysis: safety violations at worksites",
     "رصدنا نمطًا متكرّرًا لتجاهل معايير السلامة في مواقع عمل موثّقة، مع دعوات "
     "لتفعيل الرقابة.",
     "We spotted a recurring pattern of ignoring safety standards at documented "
     "worksites, with calls to activate oversight.",
     "labor,safety", 13),
    ("noor.mod", "update", "public",
     "تحديث: سياسة المجتمع وتصنيف المنشورات",
     "Update: community policy and post classification",
     "نذكّر بأن المنشورات تُصنَّف إلى تحديث/خبر/تحليل/شهادة/طلب مساعدة/حملة/تصحيح، "
     "وأن الشهادات تُراجع قبل النشر العام.",
     "A reminder that posts are classified as update/news/analysis/testimony/call/"
     "campaign/correction, and testimonies are reviewed before public release.",
     "policy,moderation", 14),
    ("aya.mem", "news", "public",
     "خبر: ورشة تدريب على توثيق الانتهاكات",
     "News: training workshop on documenting violations",
     "تقيم المنصّة ورشة تدريب على المنهجية والتوثيق الرقمي. التسجيل مفتوح "
     "للأعضاء.",
     "The platform is holding a training workshop on methodology and digital "
     "documentation. Registration is open to members.",
     "training,media", 15),
    ("ziad.act", "call", "public",
     "طلب مساعدة: مصادر مستقلة عن حادثة موثّقة",
     "Call for help: independent sources on a documented incident",
     "نحتاج مصدرًا مستقلًّا ثانيًا لتوثيق حادثة وردت شهادات عنها، مع الحفاظ على "
     "سرّية المصادر.",
     "We need a second independent source to document an incident for which "
     "testimonies exist, while protecting source confidentiality.",
     "verification,collaboration", 16),
]


def _post_blob(title: str, body: str) -> str:
    return build_search_text(title or "", body or "")


def seed_posts(conn: sqlite3.Connection) -> None:
    """يعبّئ جدول المنشورات ببيانات عرض (مرّة واحدة، بعد الأعضاء)."""
    existing = conn.execute("SELECT COUNT(*) AS n FROM posts").fetchone()["n"]
    if existing:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    for (author, kind, vis, title, title_en, body, body_en, tags, days) in SEED_POSTS:
        if author not in handles:
            continue
        conn.execute(
            """INSERT INTO posts
               (author_handle, kind, visibility, status, title, title_en, body,
                body_en, report_id, tags, search_blob, is_seed, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?, datetime('now', ?))""",
            (author, kind, vis, "published", title, title_en, body, body_en,
             None, tags, _post_blob(title, body), 1, f"-{int(days)} days"),
        )
    conn.commit()


def query_posts(
    conn: sqlite3.Connection,
    *,
    author: str | None = None,
    kind: str | None = None,
    visibility: str | None = None,
    tag: str | None = None,
    report_id: int | None = None,
    search: str | None = None,
    include_hidden: bool = False,
    sort: str = "recent",
    limit: int | None = None,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """يعيد منشورات مُصفّين مع اسم الكاتب ودوره."""
    where, params = [], []
    if not include_hidden:
        where.append("p.status = 'published'")
    if author:
        where.append("p.author_handle = ?"); params.append(author)
    if kind:
        where.append("p.kind = ?"); params.append(kind)
    if visibility:
        where.append("p.visibility = ?"); params.append(visibility)
    if report_id is not None:
        where.append("p.report_id = ?"); params.append(report_id)
    if tag:
        where.append("p.tags LIKE ?"); params.append(f"%{tag}%")
    use_fts = bool(search and search.strip())
    if use_fts:
        where.append("posts_fts MATCH ?"); params.append(_posts_fts_query(search))

    order = {
        "recent": "p.created_at DESC, p.id DESC",
        "oldest": "p.created_at ASC, p.id ASC",
        "kind": "p.kind ASC, p.created_at DESC",
    }.get(sort, "p.created_at DESC, p.id DESC")

    if use_fts:
        base = ("SELECT p.*, m.display_name AS author_name, m.role AS author_role, "
                "m.verified AS author_verified "
                "FROM posts p JOIN members m ON m.handle = p.author_handle "
                "JOIN posts_fts ON posts_fts.rowid = p.id")
    else:
        base = ("SELECT p.*, m.display_name AS author_name, m.role AS author_role, "
                "m.verified AS author_verified "
                "FROM posts p JOIN members m ON m.handle = p.author_handle")
    sql = base
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {order}"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def _posts_fts_query(text: str) -> str:
    from .textutils import tokenize
    tokens = tokenize(text)
    if not tokens:
        return '""'
    return " AND ".join(f'"{t}"*' for t in tokens)


def count_posts(conn: sqlite3.Connection, **filters: Any) -> int:
    return len(query_posts(conn, **filters))


def post_by_id(conn: sqlite3.Connection, post_id: int) -> dict[str, Any] | None:
    row = conn.execute(
        """SELECT p.*, m.display_name AS author_name, m.role AS author_role,
                  m.verified AS author_verified, m.country AS author_country
           FROM posts p JOIN members m ON m.handle = p.author_handle
           WHERE p.id = ?""",
        (post_id,),
    ).fetchone()
    return dict(row) if row else None


def posts_by_author(conn: sqlite3.Connection, handle: str, limit: int = 20) -> list[dict]:
    return query_posts(conn, author=handle, limit=limit)


def insert_post(conn: sqlite3.Connection, *, author_handle: str, title: str,
                body: str, kind: str = "update", visibility: str = "public",
                tags: str | None = None, report_id: int | None = None,
                title_en: str | None = None, body_en: str | None = None,
                status: str = "published") -> int:
    """يُدرج منشورًا جديدًا ويعيد معرّفه."""
    cur = conn.execute(
        """INSERT INTO posts
           (author_handle, kind, visibility, status, title, title_en, body,
            body_en, report_id, tags, search_blob)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (author_handle, kind, visibility, status, title, title_en, body, body_en,
         report_id, tags, _post_blob(title, body)),
    )
    conn.commit()
    return cur.lastrowid


def hide_post(conn: sqlite3.Connection, post_id: int) -> bool:
    """حذف ناعم: يخفي المنشور بدل حذفه نهائيًّا."""
    cur = conn.execute("UPDATE posts SET status = 'hidden' WHERE id = ?", (post_id,))
    conn.commit()
    return cur.rowcount > 0


def post_counts(conn: sqlite3.Connection) -> dict[str, dict[str, int]]:
    """عدّاد المنشورات لكل نوع ولكل كاتب (للمرشّحات)."""
    kinds: dict[str, int] = {}
    for r in conn.execute(
        "SELECT kind, COUNT(*) AS n FROM posts WHERE status = 'published' GROUP BY kind"
    ):
        kinds[r["kind"]] = r["n"]
    authors: dict[str, int] = {}
    for r in conn.execute(
        "SELECT author_handle, COUNT(*) AS n FROM posts "
        "WHERE status = 'published' GROUP BY author_handle"
    ):
        authors[r["author_handle"]] = r["n"]
    return {"kind": kinds, "author": authors}


def posts_for_report(conn: sqlite3.Connection, report_id: int, limit: int = 10) -> list[dict]:
    return query_posts(conn, report_id=report_id, limit=limit)


def recent_posts(conn: sqlite3.Connection, limit: int = 5) -> list[dict]:
    return query_posts(conn, limit=limit, sort="recent")


def count_posts_since(conn: sqlite3.Connection, since: str) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM posts WHERE status='published' AND created_at > ?",
        (since,),
    ).fetchone()
    return row["n"] if row else 0


# ---------------------------------------------------------------------------
# التفاعل: إعجاب/تأييد/تعليقات/إبلاغ (الدفعة 3)
# ---------------------------------------------------------------------------

REACTION_KINDS = ("like", "support", "important")


def add_reaction(conn: sqlite3.Connection, post_id: int, handle: str,
                 kind: str = "like") -> bool:
    """يضيف تفاعلًا (idempotent) ويعيد True إن أُضيف جديد."""
    if kind not in REACTION_KINDS:
        kind = "like"
    cur = conn.execute(
        "INSERT OR IGNORE INTO reactions(post_id, member_handle, kind) VALUES (?,?,?)",
        (post_id, handle, kind),
    )
    conn.commit()
    return cur.rowcount > 0


def remove_reaction(conn: sqlite3.Connection, post_id: int, handle: str,
                    kind: str = "like") -> bool:
    cur = conn.execute(
        "DELETE FROM reactions WHERE post_id=? AND member_handle=? AND kind=?",
        (post_id, handle, kind),
    )
    conn.commit()
    return cur.rowcount > 0


def toggle_reaction(conn: sqlite3.Connection, post_id: int, handle: str,
                    kind: str = "like") -> dict[str, Any]:
    """يبدّل التفاعل ويعيد الحالة والعدّاد."""
    existing = conn.execute(
        "SELECT 1 FROM reactions WHERE post_id=? AND member_handle=? AND kind=?",
        (post_id, handle, kind),
    ).fetchone()
    if existing:
        remove_reaction(conn, post_id, handle, kind)
        active = False
    else:
        add_reaction(conn, post_id, handle, kind)
        active = True
    return {"active": active, "count": reaction_count(conn, post_id, kind)}


def reaction_count(conn: sqlite3.Connection, post_id: int,
                   kind: str | None = None) -> int:
    if kind:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM reactions WHERE post_id=? AND kind=?",
            (post_id, kind),
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM reactions WHERE post_id=?", (post_id,)
        ).fetchone()
    return row["n"] if row else 0


def reaction_summary(conn: sqlite3.Connection, post_id: int) -> dict[str, int]:
    out = {k: 0 for k in REACTION_KINDS}
    for r in conn.execute(
        "SELECT kind, COUNT(*) AS n FROM reactions WHERE post_id=? GROUP BY kind",
        (post_id,),
    ):
        out[r["kind"]] = r["n"]
    return out


def add_comment(conn: sqlite3.Connection, post_id: int, handle: str,
                body: str, parent_id: int | None = None) -> int:
    """يضيف تعليقًا (أو ردًّا). يعيد معرّفه."""
    if parent_id is not None:
        parent = conn.execute(
            "SELECT post_id FROM comments WHERE id=? AND state='visible'",
            (parent_id,),
        ).fetchone()
        if not parent or parent["post_id"] != post_id:
            parent_id = None
    cur = conn.execute(
        """INSERT INTO comments(post_id, author_handle, parent_id, body)
           VALUES (?,?,?,?)""",
        (post_id, handle, parent_id, body),
    )
    conn.commit()
    return cur.lastrowid


def comments_for_post(conn: sqlite3.Connection, post_id: int,
                      limit: int | None = None) -> list[dict]:
    """يعيد التعليقات المسطّحة مع اسم الكاتب ودوره (مرتّبة زمنيًّا)."""
    sql = ("""SELECT c.*, m.display_name AS author_name, m.role AS author_role,
                     m.verified AS author_verified
              FROM comments c JOIN members m ON m.handle = c.author_handle
              WHERE c.post_id = ? AND c.state = 'visible'
              ORDER BY c.created_at ASC, c.id ASC""")
    params: list[Any] = [post_id]
    if limit is not None:
        sql += " LIMIT ?"
        params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def comment_tree(conn: sqlite3.Connection, post_id: int) -> list[dict]:
    """يبني شجرة تعليقات (جذر → ردود) من القائمة المسطّحة."""
    flat = comments_for_post(conn, post_id)
    by_id = {c["id"]: {**c, "replies": []} for c in flat}
    roots: list[dict] = []
    for c in flat:
        node = by_id[c["id"]]
        parent = c.get("parent_id")
        if parent and parent in by_id:
            by_id[parent]["replies"].append(node)
        else:
            roots.append(node)
    return roots


def count_comments(conn: sqlite3.Connection, post_id: int) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM comments WHERE post_id=? AND state='visible'",
        (post_id,),
    ).fetchone()
    return row["n"] if row else 0


def comment_counts_bulk(conn: sqlite3.Connection, post_ids: list[int]) -> dict[int, int]:
    """عدّاد تعليقات لكل منشور في استعلام واحد (لتغذية القوائم)."""
    if not post_ids:
        return {}
    marks = ",".join("?" * len(post_ids))
    out = {pid: 0 for pid in post_ids}
    for r in conn.execute(
        f"SELECT post_id, COUNT(*) AS n FROM comments "
        f"WHERE state='visible' AND post_id IN ({marks}) GROUP BY post_id",
        post_ids,
    ):
        out[r["post_id"]] = r["n"]
    return out


def reaction_counts_bulk(conn: sqlite3.Connection, post_ids: list[int]) -> dict[int, int]:
    if not post_ids:
        return {}
    marks = ",".join("?" * len(post_ids))
    out = {pid: 0 for pid in post_ids}
    for r in conn.execute(
        f"SELECT post_id, COUNT(*) AS n FROM reactions "
        f"WHERE post_id IN ({marks}) GROUP BY post_id",
        post_ids,
    ):
        out[r["post_id"]] = r["n"]
    return out


def report_content(conn: sqlite3.Connection, target_kind: str, target_id: int,
                   reason: str, reporter_handle: str | None = None,
                   note: str | None = None) -> int:
    """يسجّل إبلاغًا عن محتوى (منشور/تعليق/عضو) في طابور الإشراف."""
    cur = conn.execute(
        """INSERT INTO content_reports(target_kind, target_id, reporter_handle,
                                       reason, note) VALUES (?,?,?,?,?)""",
        (target_kind, target_id, reporter_handle, reason, note),
    )
    conn.commit()
    return cur.lastrowid


def content_reports(conn: sqlite3.Connection, state: str = "open",
                    limit: int = 100) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM content_reports WHERE state=? ORDER BY created_at DESC LIMIT ?",
        (state, limit),
    ).fetchall()]


def count_content_reports(conn: sqlite3.Connection, state: str = "open") -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM content_reports WHERE state=?", (state,)
    ).fetchone()
    return row["n"] if row else 0


def block_member(conn: sqlite3.Connection, owner: str, target: str) -> bool:
    if owner == target:
        return False
    cur = conn.execute(
        "INSERT OR IGNORE INTO member_blocks(owner_handle, target_handle) VALUES (?,?)",
        (owner, target),
    )
    conn.commit()
    return cur.rowcount > 0


def unblock_member(conn: sqlite3.Connection, owner: str, target: str) -> bool:
    cur = conn.execute(
        "DELETE FROM member_blocks WHERE owner_handle=? AND target_handle=?",
        (owner, target),
    )
    conn.commit()
    return cur.rowcount > 0


def blocked_handles(conn: sqlite3.Connection, owner: str) -> list[str]:
    return [r["target_handle"] for r in conn.execute(
        "SELECT target_handle FROM member_blocks WHERE owner_handle=?", (owner,)
    )]


def attachments_for_post(conn: sqlite3.Connection, post_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM attachments WHERE post_id=? ORDER BY id", (post_id,)
    ).fetchall()]


# ---------------------------------------------------------------------------
# المجموعات والمجتمعات (الدفعة 4)
# ---------------------------------------------------------------------------

# (slug, name, name_en, kind, visibility, purpose, purpose_en, country, category,
#  rules, owner_handle, member_handles, post_indexes)
SEED_GROUPS: list[tuple] = [
    ("water-watch", "مرصد المياه", "Water Watch", "working", "public",
     "رصد مخالفات المياه والتلوّث ومتابعة تقارير الفحص المخبري.",
     "Tracking water violations, pollution and lab-test reports.",
     None, "environment",
     "نشر الأدلّة فقط، ذكر المصدر، واحترام سرّية الشهود.",
     "tariq.act", ["hala.verify", "khaled.act", "hussein.act", "sami.verify"], [2, 7, 11, 12]),
    ("verify-lab", "مختبر التحقّق", "Verification Lab", "verification", "public",
     "لجنة تحقّق ثنائي المصدر من الصور والفيديو والشهادات.",
     "Two-source verification committee for photos, video and testimonies.",
     None, None,
     "لا نشر قبل استكمال تحقّق مصدرين مستقلّين وتوثيق المنهجية.",
     "sami.verify", ["hala.verify", "ziad.act", "omar.act"], [1, 5, 16]),
    ("translation-desk", "مكتب الترجمة", "Translation Desk", "translation", "public",
     "ترجمة الشهادات والتقارير إلى العربية والإنجليزية والفرنسية.",
     "Translating testimonies and reports into Arabic, English and French.",
     None, None,
     "ترجمة أمينة بلا تحريف، والإشارة إلى أي غموض لغوي.",
     "dina.act", ["aya.mem", "sara.act"], [4]),
    ("child-rights", "تحالف حقوق الطفل", "Child Rights Coalition", "campaign", "public",
     "توثيق انتهاكات حقوق الطفل وحملات المناصرة لحمايتهم.",
     "Documenting child-rights violations and advocacy campaigns.",
     None, "children",
     "حماية هوية الأطفال، ومنع أي محتوى يكشف بياناتهم.",
     "sara.act", ["rana.act", "yara.act", "noor.mod"], [8, 10]),
    ("animal-welfare", "شبكة الرفق بالحيوان", "Animal Welfare Network", "campaign", "public",
     "رصد القسوة على الحيوان وحملات المساءلة.",
     "Monitoring animal cruelty and accountability campaigns.",
     None, "animal_rights",
     "توثيق بالصورة والفيديو، ودعوة للتفتيش المستقلّ.",
     "lina.act", ["aya.mem", "maya.act"], [6]),
    ("labour-safety", "سلامة العمل", "Labour Safety", "working", "private",
     "مخالفات السلامة في مواقع العمل وتوثيق الإصابات.",
     "Worksite safety violations and injury documentation.",
     None, "labor",
     "سرّية هوية العمّال، وعدم نشر ما يعرّضهم للانتقام.",
     "maya.act", ["dina.act", "khaled.act", "noor.mod"], [13]),
    ("moderation-council", "مجلس الإشراف", "Moderation Council", "committee", "private",
     "مراجعة الإبلاغات وسياسات المجتمع واتّخاذ قرارات الإشراف.",
     "Reviewing reports, community policy and moderation decisions.",
     None, None,
     "قرارات مبرَّرة، حقّ استئناف، وسجلّ تدقيق لكل إجراء.",
     "noor.mod", ["sami.verify", "hala.verify"], [14]),
    ("crisis-response", "فريق الاستجابة للطوارئ", "Crisis Response Team", "support", "secret",
     "تنسيق سريع عند الحوادث الطارئة ودعم الناشطين الميدانيين.",
     "Rapid coordination for emergencies and field-activist support.",
     None, None,
     "سرّية تامّة، وأقصى تقليل للبيانات، وتوثيق داخلي فقط.",
     "yara.act", ["ziad.act", "omar.act"], [3]),
]


def seed_groups(conn: sqlite3.Connection) -> None:
    """يعبّئ المجموعات وعضوياتها وربط المنشورات (مرّة واحدة، بعد المنشورات)."""
    if conn.execute("SELECT COUNT(*) AS n FROM groups").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    posts = [r["id"] for r in conn.execute("SELECT id FROM posts ORDER BY id")]
    for (slug, name, name_en, kind, vis, purpose, purpose_en, country, category,
         rules, owner, members, post_idx) in SEED_GROUPS:
        cur = conn.execute(
            """INSERT INTO groups
               (slug, name, name_en, kind, visibility, purpose, purpose_en, country,
                category, rules, status, is_seed)
               VALUES (?,?,?,?,?,?,?,?,?,?, 'active', 1)""",
            (slug, name, name_en, kind, vis, purpose, purpose_en, country, category, rules),
        )
        gid = cur.lastrowid
        people = [p for p in ([owner] + list(members)) if p in handles]
        for i, h in enumerate(people):
            conn.execute(
                "INSERT OR IGNORE INTO group_members(group_id, member_handle, role, status) "
                "VALUES (?,?,?, 'active')",
                (gid, h, "owner" if i == 0 else ("moderator" if i == 1 else "member")),
            )
        for idx in post_idx:
            if 1 <= idx <= len(posts):
                conn.execute(
                    "INSERT OR IGNORE INTO group_posts(group_id, post_id) VALUES (?,?)",
                    (gid, posts[idx - 1]),
                )
    conn.commit()


def query_groups(
    conn: sqlite3.Connection,
    *,
    kind: str | None = None,
    visibility: str | None = None,
    member: str | None = None,
    search: str | None = None,
    include_secret: bool = False,
    sort: str = "recent",
    limit: int | None = None,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """يعيد المجموعات مع عدّاد الأعضاء ودور العضو المطلوب إن وُجد."""
    where, params = ["g.status = 'active'"], []
    if not include_secret:
        where.append("g.visibility <> 'secret'")
    if kind:
        where.append("g.kind = ?"); params.append(kind)
    if visibility:
        where.append("g.visibility = ?"); params.append(visibility)
    if search and search.strip():
        like = f"%{search.strip()}%"
        where.append("(g.name LIKE ? OR g.purpose LIKE ? OR g.slug LIKE ?)")
        params += [like, like, like]
    order = {"recent": "g.created_at DESC, g.id DESC",
             "name": "g.name ASC",
             "size": "member_count DESC, g.id"}.get(sort, "g.created_at DESC, g.id DESC")
    sql = ("SELECT g.*, "
           "(SELECT COUNT(*) FROM group_members gm WHERE gm.group_id = g.id AND gm.status='active') AS member_count, "
           "(SELECT COUNT(*) FROM group_posts gp WHERE gp.group_id = g.id) AS post_count ")
    if member:
        sql += (", (SELECT gm2.role FROM group_members gm2 WHERE gm2.group_id=g.id "
                "AND gm2.member_handle=? AND gm2.status='active') AS viewer_role ")
        params = [member] + params
    else:
        sql += ", NULL AS viewer_role "
    sql += "FROM groups g"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {order}"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"
        params += [limit, offset]
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def count_groups(conn: sqlite3.Connection, **filters: Any) -> int:
    filters.pop("limit", None); filters.pop("offset", None)
    return len(query_groups(conn, **filters))


def group_by_slug(conn: sqlite3.Connection, slug: str) -> dict[str, Any] | None:
    row = conn.execute(
        """SELECT g.*,
                  (SELECT COUNT(*) FROM group_members gm WHERE gm.group_id=g.id AND gm.status='active') AS member_count,
                  (SELECT COUNT(*) FROM group_posts gp WHERE gp.group_id=g.id) AS post_count,
                  (SELECT gm3.member_handle FROM group_members gm3 WHERE gm3.group_id=g.id
                     AND gm3.role='owner' LIMIT 1) AS owner
           FROM groups g WHERE g.slug = ?""",
        (slug,),
    ).fetchone()
    return dict(row) if row else None


def group_members(conn: sqlite3.Connection, group_id: int,
                  status: str = "active") -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT gm.role, gm.status, gm.joined_at,
                  m.handle, m.display_name, m.role AS member_role, m.verified
           FROM group_members gm JOIN members m ON m.handle = gm.member_handle
           WHERE gm.group_id = ? AND gm.status = ?
           ORDER BY CASE gm.role WHEN 'owner' THEN 0 WHEN 'moderator' THEN 1 ELSE 2 END,
                    m.display_name""",
        (group_id, status),
    ).fetchall()]


def group_posts(conn: sqlite3.Connection, group_id: int, limit: int = 20) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT p.*, gp.created_at AS shared_at,
                  m.display_name AS author_name, m.role AS author_role, m.verified AS author_verified
           FROM group_posts gp
           JOIN posts p ON p.id = gp.post_id
           JOIN members m ON m.handle = p.author_handle
           WHERE gp.group_id = ? AND p.status = 'published'
           ORDER BY p.created_at DESC, p.id DESC LIMIT ?""",
        (group_id, limit),
    ).fetchall()]


def group_role(conn: sqlite3.Connection, group_id: int, handle: str) -> str | None:
    row = conn.execute(
        "SELECT role FROM group_members WHERE group_id=? AND member_handle=? AND status='active'",
        (group_id, handle),
    ).fetchone()
    return row["role"] if row else None


def group_member_status(conn: sqlite3.Connection, group_id: int, handle: str) -> str | None:
    row = conn.execute(
        "SELECT status FROM group_members WHERE group_id=? AND member_handle=?",
        (group_id, handle),
    ).fetchone()
    return row["status"] if row else None


def join_group(conn: sqlite3.Connection, group_id: int, handle: str) -> dict[str, Any]:
    """انضمام عضو: مباشر للعام، وبانتظار الموافقة للخاص/السرّي."""
    g = conn.execute("SELECT visibility FROM groups WHERE id=?", (group_id,)).fetchone()
    if not g:
        return {"ok": False, "error": "not_found"}
    status = "active" if g["visibility"] == "public" else "pending"
    cur = conn.execute(
        "INSERT OR IGNORE INTO group_members(group_id, member_handle, role, status) VALUES (?,?, 'member', ?)",
        (group_id, handle, status),
    )
    conn.commit()
    return {"ok": True, "joined": cur.rowcount > 0, "status": status}


def leave_group(conn: sqlite3.Connection, group_id: int, handle: str) -> bool:
    cur = conn.execute(
        "DELETE FROM group_members WHERE group_id=? AND member_handle=? AND role <> 'owner'",
        (group_id, handle),
    )
    conn.commit()
    return cur.rowcount > 0


def approve_group_member(conn: sqlite3.Connection, group_id: int, handle: str) -> bool:
    cur = conn.execute(
        "UPDATE group_members SET status='active' WHERE group_id=? AND member_handle=? AND status='pending'",
        (group_id, handle),
    )
    conn.commit()
    return cur.rowcount > 0


def group_counts(conn: sqlite3.Connection) -> dict[str, dict[str, int]]:
    """عدّاد المجموعات لكل نوع ولكل مستوى ظهور (للمرشّحات)."""
    kinds: dict[str, int] = {}
    for r in conn.execute(
        "SELECT kind, COUNT(*) AS n FROM groups WHERE status='active' GROUP BY kind"
    ):
        kinds[r["kind"]] = r["n"]
    vis: dict[str, int] = {}
    for r in conn.execute(
        "SELECT visibility, COUNT(*) AS n FROM groups WHERE status='active' GROUP BY visibility"
    ):
        vis[r["visibility"]] = r["n"]
    return {"kind": kinds, "visibility": vis}


def groups_for_member(conn: sqlite3.Connection, handle: str, limit: int = 20,
                      include_private: bool = False) -> list[dict]:
    """مجموعات العضو للعرض العام: العامّة فقط (تُستثنى الخاصّة والسرّية افتراضيًّا)."""
    vis_clause = "g.visibility = 'public'" if not include_private \
        else "g.visibility <> 'secret'"
    return [dict(r) for r in conn.execute(
        f"""SELECT g.slug, g.name, g.name_en, g.kind, g.visibility, gm.role, gm.status
           FROM group_members gm JOIN groups g ON g.id = gm.group_id
           WHERE gm.member_handle = ? AND g.status='active' AND {vis_clause}
           ORDER BY g.name LIMIT ?""",
        (handle, limit),
    ).fetchall()]


# ---------------------------------------------------------------------------
# المحادثات والرسائل (الدفعة 5)
# ---------------------------------------------------------------------------

# (kind, title, title_en, members, [(sender, body, minutes_ago)])
SEED_CONVERSATIONS: list[tuple] = [
    ("direct", None, None, ["sami.verify", "hala.verify"], [
        ("sami.verify", "هل راجعت صور التسرّب الجديدة؟", 180),
        ("hala.verify", "نعم، وأقارنها بإحداثيات المصدر الثاني الآن.", 175),
        ("sami.verify", "ممتاز، أوافيك بنتيجة مطابقة الطقس عند جهوزيتها.", 170),
    ]),
    ("group", "تنسيق فريق المياه", "Water team coordination",
     ["tariq.act", "hussein.act", "khaled.act", "hala.verify"], [
        ("tariq.act", "نحتاج توزيع مهام الفحص الميداني هذا الأسبوع.", 300),
        ("hussein.act", "أستطيع تغطية الموقع الشمالي غدًا صباحًا.", 290),
        ("khaled.act", "وأنا الموقع الجنوبي بعد الظهر.", 285),
    ]),
    ("group", "لجنة التحقّق — قائمة الانتظار", "Verification committee — queue",
     ["sami.verify", "ziad.act", "omar.act"], [
        ("ziad.act", "بقي عنصران في قائمة التحقّق يحتاجان مصدرًا ثانيًا.", 90),
        ("sami.verify", "سأتولّى الأوّل، وليتولَّ عمر الثاني.", 85),
    ]),
    ("direct", None, None, ["dina.act", "aya.mem"], [
        ("dina.act", "هل يمكنك ترجمة الشهادتين قبل الخميس؟", 240),
        ("aya.mem", "نعم، سأبدأ بالشهادة الأطول اليوم.", 235),
    ]),
    ("group", "دعم نفسي للناشطين", "Activist peer support",
     ["yara.act", "rana.act", "sara.act"], [
        ("yara.act", "جلسة الدعم الأسبوعية الخميس 6 مساءً.", 400),
        ("rana.act", "سأحضر، وشكرًا على التنظيم.", 395),
    ]),
]


def seed_conversations(conn: sqlite3.Connection) -> None:
    """يعبّئ محادثات ورسائل تجريبية (مرّة واحدة، بعد الأعضاء)."""
    if conn.execute("SELECT COUNT(*) AS n FROM conversations").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    for (kind, title, title_en, people, msgs) in SEED_CONVERSATIONS:
        people = [p for p in people if p in handles]
        if len(people) < 2:
            continue
        cur = conn.execute(
            "INSERT INTO conversations(kind, title, title_en, status, is_seed) "
            "VALUES (?,?,?, 'active', 1)",
            (kind, title, title_en),
        )
        cid = cur.lastrowid
        for i, h in enumerate(people):
            conn.execute(
                "INSERT OR IGNORE INTO conversation_members(conversation_id, member_handle, role) "
                "VALUES (?,?,?)",
                (cid, h, "owner" if i == 0 else "member"),
            )
        for (sender, body, mins) in msgs:
            if sender not in handles:
                continue
            conn.execute(
                "INSERT INTO messages(conversation_id, sender_handle, body, created_at) "
                "VALUES (?,?,?, datetime('now', ?))",
                (cid, sender, body, f"-{int(mins)} minutes"),
            )
    conn.commit()


def conversation_for_member(conn: sqlite3.Connection, cid: int,
                            handle: str) -> dict[str, Any] | None:
    """يعيد محادثة فقط إن كان العضو مشاركًا فيها (حماية الوصول)."""
    row = conn.execute(
        """SELECT c.*, (SELECT COUNT(*) FROM conversation_members cm2
                          WHERE cm2.conversation_id=c.id) AS member_count
           FROM conversations c
           JOIN conversation_members cm ON cm.conversation_id = c.id
           WHERE c.id = ? AND cm.member_handle = ? AND c.status='active'""",
        (cid, handle),
    ).fetchone()
    return dict(row) if row else None


def conversations_for_member(conn: sqlite3.Connection, handle: str) -> list[dict]:
    """محادثات العضو مع آخر رسالة وعدّاد الرسائل والطرف الآخر."""
    rows = conn.execute(
        """SELECT c.id, c.kind, c.title, c.title_en, c.created_at,
                  (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=c.id AND m.state='visible') AS message_count,
                  (SELECT m2.body FROM messages m2 WHERE m2.conversation_id=c.id AND m2.state='visible'
                     ORDER BY m2.created_at DESC, m2.id DESC LIMIT 1) AS last_body,
                  (SELECT m3.created_at FROM messages m3 WHERE m3.conversation_id=c.id AND m3.state='visible'
                     ORDER BY m3.created_at DESC, m3.id DESC LIMIT 1) AS last_at,
                  (SELECT GROUP_CONCAT(m4.display_name, ' · ') FROM conversation_members cm4
                     JOIN members m4 ON m4.handle = cm4.member_handle
                     WHERE cm4.conversation_id=c.id AND cm4.member_handle <> ?) AS others
           FROM conversations c
           JOIN conversation_members cm ON cm.conversation_id = c.id
           WHERE cm.member_handle = ? AND c.status='active'
           ORDER BY COALESCE(last_at, c.created_at) DESC""",
        (handle, handle),
    ).fetchall()
    return [dict(r) for r in rows]


def conversation_members(conn: sqlite3.Connection, cid: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT cm.role, m.handle, m.display_name, m.role AS member_role, m.verified
           FROM conversation_members cm JOIN members m ON m.handle = cm.member_handle
           WHERE cm.conversation_id = ?
           ORDER BY CASE cm.role WHEN 'owner' THEN 0 ELSE 1 END, m.display_name""",
        (cid,),
    ).fetchall()]


def conversation_messages(conn: sqlite3.Connection, cid: int,
                          limit: int = 100) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT msg.*, m.display_name AS sender_name, m.role AS sender_role, m.verified AS sender_verified
           FROM messages msg JOIN members m ON m.handle = msg.sender_handle
           WHERE msg.conversation_id = ? AND msg.state='visible'
           ORDER BY msg.created_at ASC, msg.id ASC LIMIT ?""",
        (cid, limit),
    ).fetchall()]


def send_message(conn: sqlite3.Connection, cid: int, sender: str, body: str) -> int | None:
    """يضيف رسالة إن كان المرسل مشاركًا؛ وإلا يعيد None."""
    if not conversation_for_member(conn, cid, sender):
        return None
    cur = conn.execute(
        "INSERT INTO messages(conversation_id, sender_handle, body) VALUES (?,?,?)",
        (cid, sender, body),
    )
    conn.commit()
    return cur.lastrowid


def count_messages(conn: sqlite3.Connection, cid: int) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM messages WHERE conversation_id=? AND state='visible'",
        (cid,),
    ).fetchone()
    return row["n"] if row else 0


def find_direct_conversation(conn: sqlite3.Connection, a: str, b: str) -> dict | None:
    """يبحث عن محادثة مباشرة تجمع العضوين."""
    row = conn.execute(
        """SELECT c.id FROM conversations c
           JOIN conversation_members x ON x.conversation_id=c.id AND x.member_handle=?
           JOIN conversation_members y ON y.conversation_id=c.id AND y.member_handle=?
           WHERE c.kind='direct' AND c.status='active'
           LIMIT 1""",
        (a, b),
    ).fetchone()
    return dict(row) if row else None


def start_direct_conversation(conn: sqlite3.Connection, a: str, b: str) -> int:
    """ينشئ محادثة مباشرة بين عضوين (أو يعيد الموجودة)."""
    existing = find_direct_conversation(conn, a, b)
    if existing:
        return existing["id"]
    cur = conn.execute("INSERT INTO conversations(kind, status) VALUES ('direct','active')")
    cid = cur.lastrowid
    conn.executemany(
        "INSERT OR IGNORE INTO conversation_members(conversation_id, member_handle, role) VALUES (?,?,?)",
        [(cid, a, "owner"), (cid, b, "member")],
    )
    conn.commit()
    return cid


# ---------------------------------------------------------------------------
# التحقّق من الحقائق والتوثيق (الدفعة 6)
# ---------------------------------------------------------------------------

# (ref, title, title_en, summary, summary_en, category, status, reporter,
#  assignee, [(kind, reliability, label, label_en, url, notes)])
SEED_CLAIMS: list[tuple] = [
    ("CLM-0001", "فيديو يزعم تصريف مياه ملوّثة ليلًا", "Video claims nighttime discharge of polluted water",
     "مقطع متداول يُظهر أنبوبًا يصبّ في مجرى مائي قرب منشأة صناعية.",
     "A circulating clip shows a pipe discharging into a stream near an industrial facility.",
     "environment", "verified", "hussein.act", "sami.verify", [
        ("primary", "5", "تسجيل أصلي ببيانات وقت", "Original timestamped recording", None,
         "طابق الطابع الزمني في الملف مع تاريخ الادّعاء."),
        ("secondary", "4", "تقرير صحفي محلي", "Local press report", None, None),
        ("testimony", "3", "شهادة ساكن مجاور", "Neighbour testimony", None, None),
     ]),
    ("CLM-0002", "صورة لانبعاث دخان من مكبّ نفايات", "Photo of smoke from a waste dump",
     "صورة تُظهر سحابة دخان كثيفة فوق مكبّ في ساعات الصباح.",
     "A photo showing dense smoke over a dump in the morning hours.",
     "environment", "pending", "khaled.act", "hala.verify", [
        ("primary", "4", "صورة أصلية", "Original photo", None, "بانتظار تحليل EXIF."),
        ("secondary", "3", "منشور محلي", "Local post", None, None),
     ]),
    ("CLM-0003", "ادّعاء إخلاء قسري لعائلات", "Claim of forced eviction of families",
     "ادّعاءات بإخلاء قسري لعشر عائلات دون إشعار قانوني.",
     "Claims of forced eviction of ten families without legal notice.",
     "housing", "disputed", "rana.act", "sami.verify", [
        ("testimony", "4", "شهادات عائلات", "Family testimonies", None, None),
        ("secondary", "2", "منشور متداول بلا مصدر", "Unsourced viral post", None,
         "لا يمكن تتبّع المصدر الأصلي."),
     ]),
    ("CLM-0004", "خبر تفشّي مرض في مخيّم", "Report of a disease outbreak in a camp",
     "تقرير عن ارتفاع حالات مرضية في مخيّم نازحين.",
     "A report of rising cases in a displacement camp.",
     "health", "verified", "sara.act", "ziad.act", [
        ("primary", "5", "بيان رسمي لجهة صحية", "Official health-authority statement", None, None),
        ("secondary", "4", "تقرير منظمة", "NGO report", None, None),
     ]),
    ("CLM-0005", "مزاعم تلوّث غذائي بمدرسة", "Allegations of food contamination at a school",
     "مزاعم بتلوّث وجبات مدرسية تسبّب حالات تسمّم.",
     "Allegations that school meals caused poisoning cases.",
     "children", "unverifiable", "aya.mem", None, [
        ("testimony", "2", "رواية غير مؤكّدة", "Unconfirmed account", None,
         "لا توجد عيّنات أو تقارير طبية متاحة."),
     ]),
    ("CLM-0006", "تكذيب: صورة قديمة تُنسب لحادثة حديثة", "Debunked: old photo attributed to a recent incident",
     "صورة متداولة تعود لحادثة سابقة وليست للحادثة المزعومة.",
     "A viral photo belongs to an earlier incident, not the claimed one.",
     "labor", "debunked", "omar.act", "hala.verify", [
        ("primary", "5", "أرشيف المصدر الأصلي", "Original source archive", None,
         "أثبت بحث عكسي أن الصورة نُشرت قبل الحادثة بعامين."),
        ("secondary", "4", "مصدر تكذيب مستقلّ", "Independent debunk", None, None),
     ]),
]


def _claim_reliability_score(sources: list[dict]) -> float:
    """درجة ثقة مركّبة: متوسط مرجّح لموثوقية المصادر ونوعها."""
    if not sources:
        return 0.0
    total_w = 0.0
    acc = 0.0
    for s in sources:
        kind = CLAIM_SOURCE_KIND_BY_KEY.get(s.get("kind", "secondary"), {})
        kw = float(kind.get("weight", 0.5))
        try:
            rel = float(s.get("reliability", "3"))
        except (TypeError, ValueError):
            rel = 3.0
        acc += kw * (rel / 5.0)
        total_w += kw
    return round((acc / total_w) * 100, 1) if total_w else 0.0


def _claim_confidence(status: str, sources: list[dict]) -> dict[str, Any]:
    """يترجم درجة الثقة إلى مستوى مفهوم (مرتفعة/متوسّطة/منخفضة)."""
    score = _claim_reliability_score(sources)
    if status == "debunked":
        level = "debunked"
    elif status == "unverifiable":
        level = "unverifiable"
    elif score >= 70:
        level = "high"
    elif score >= 45:
        level = "medium"
    else:
        level = "low"
    return {"score": score, "level": level, "sources": len(sources)}


def seed_claims(conn: sqlite3.Connection) -> None:
    """يعبّئ ادّعاءات التحقّق ومصادرها وسجلّها (مرّة واحدة، بعد الأعضاء)."""
    if conn.execute("SELECT COUNT(*) AS n FROM claims").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    reports = [r["id"] for r in conn.execute("SELECT id FROM reports ORDER BY id")]
    for i, (ref, title, title_en, summary, summary_en, category, status, reporter,
            assignee, sources) in enumerate(SEED_CLAIMS):
        report_id = reports[i] if i < len(reports) else None
        cur = conn.execute(
            """INSERT INTO claims(ref, title, title_en, summary, summary_en, category,
                                  status, reporter_handle, assignee_handle, report_id, is_seed)
               VALUES (?,?,?,?,?,?,?,?,?,?, 1)""",
            (ref, title, title_en, summary, summary_en, category, status,
             reporter if reporter in handles else None,
             assignee if assignee in handles else None, report_id),
        )
        cid = cur.lastrowid
        for (kind, rel, label, label_en, url, notes) in sources:
            conn.execute(
                """INSERT INTO claim_sources(claim_id, kind, reliability, label, label_en, url, notes)
                   VALUES (?,?,?,?,?,?,?)""",
                (cid, kind, rel, label, label_en, url, notes),
            )
        conn.execute(
            "INSERT INTO claim_timeline(claim_id, actor_handle, action, detail) VALUES (?,?,?,?)",
            (cid, reporter if reporter in handles else None, "created", title),
        )
        if status == "verified":
            for who in [assignee] if assignee in handles else []:
                conn.execute(
                    "INSERT INTO claim_reviews(claim_id, reviewer_handle, decision, note) "
                    "VALUES (?,?, 'approve', ?)",
                    (cid, who, "استوفى شرط مصدرين مستقلّين."),
                )
                conn.execute(
                    "INSERT INTO claim_timeline(claim_id, actor_handle, action, detail) VALUES (?,?,?,?)",
                    (cid, who, "verified", "تمّ التوثيق بعد مطابقة المصادر."),
                )
        elif status == "debunked":
            conn.execute(
                "INSERT INTO claim_timeline(claim_id, actor_handle, action, detail) VALUES (?,?,?,?)",
                (cid, assignee if assignee in handles else None, "debunked", "كُذِّب الادّعاء بأثر رجعي."),
            )
    conn.commit()


def query_claims(conn: sqlite3.Connection, *, status: str | None = None,
                 category: str | None = None, assignee: str | None = None,
                 q: str | None = None, sort: str = "recent",
                 limit: int | None = None, offset: int = 0) -> list[dict]:
    where, params = [], []
    if status:
        where.append("c.status = ?"); params.append(status)
    if category:
        where.append("c.category = ?"); params.append(category)
    if assignee:
        where.append("c.assignee_handle = ?"); params.append(assignee)
    if q and q.strip():
        like = f"%{q.strip()}%"
        where.append("(c.title LIKE ? OR c.summary LIKE ? OR c.ref LIKE ?)")
        params += [like, like, like]
    order = {"recent": "c.updated_at DESC, c.id DESC",
             "created": "c.created_at DESC, c.id DESC",
             "ref": "c.ref ASC"}.get(sort, "c.updated_at DESC, c.id DESC")
    sql = ("SELECT c.*, "
           "(SELECT COUNT(*) FROM claim_sources cs WHERE cs.claim_id=c.id) AS source_count, "
           "(SELECT COUNT(*) FROM claim_reviews cr WHERE cr.claim_id=c.id) AS review_count "
           "FROM claims c")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += f" ORDER BY {order}"
    if limit is not None:
        sql += " LIMIT ? OFFSET ?"; params += [limit, offset]
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def count_claims(conn: sqlite3.Connection, **filters: Any) -> int:
    filters.pop("limit", None); filters.pop("offset", None)
    return len(query_claims(conn, **filters))


def claim_by_ref(conn: sqlite3.Connection, ref: str) -> dict[str, Any] | None:
    row = conn.execute(
        """SELECT c.*,
                  (SELECT COUNT(*) FROM claim_sources cs WHERE cs.claim_id=c.id) AS source_count,
                  (SELECT COUNT(*) FROM claim_reviews cr WHERE cr.claim_id=c.id) AS review_count
           FROM claims c WHERE c.ref = ?""",
        (ref,),
    ).fetchone()
    return dict(row) if row else None


def claim_sources(conn: sqlite3.Connection, claim_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM claim_sources WHERE claim_id=? ORDER BY id", (claim_id,)
    ).fetchall()]


def claim_reviews(conn: sqlite3.Connection, claim_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT cr.*, m.display_name AS reviewer_name, m.verified AS reviewer_verified
           FROM claim_reviews cr JOIN members m ON m.handle = cr.reviewer_handle
           WHERE cr.claim_id=? ORDER BY cr.created_at DESC, cr.id DESC""",
        (claim_id,),
    ).fetchall()]


def claim_timeline(conn: sqlite3.Connection, claim_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM claim_timeline WHERE claim_id=? ORDER BY created_at ASC, id ASC",
        (claim_id,),
    ).fetchall()]


def add_claim_source(conn: sqlite3.Connection, claim_id: int, *, kind: str = "secondary",
                     reliability: str = "3", label: str = "", label_en: str | None = None,
                     url: str | None = None, notes: str | None = None) -> int:
    cur = conn.execute(
        """INSERT INTO claim_sources(claim_id, kind, reliability, label, label_en, url, notes)
           VALUES (?,?,?,?,?,?,?)""",
        (claim_id, kind, reliability, label, label_en, url, notes),
    )
    conn.execute("UPDATE claims SET updated_at=datetime('now') WHERE id=?", (claim_id,))
    conn.commit()
    return cur.lastrowid


def review_claim(conn: sqlite3.Connection, claim_id: int, reviewer: str,
                 decision: str, note: str = "") -> dict[str, Any]:
    """يضيف مراجعة ويحدّث حالة الادّعاء وفق القرار (يتطلّب مصدرين للتوثيق)."""
    row = conn.execute("SELECT status FROM claims WHERE id=?", (claim_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "not_found"}
    sources = claim_sources(conn, claim_id)
    new_status = row["status"]
    if decision == "approve":
        new_status = "verified" if len(sources) >= 2 else "pending"
    elif decision == "dispute":
        new_status = "disputed"
    elif decision == "debunk":
        new_status = "debunked"
    elif decision == "mark_unverifiable":
        new_status = "unverifiable"
    elif decision == "request_evidence":
        new_status = "pending"
    conn.execute(
        "INSERT INTO claim_reviews(claim_id, reviewer_handle, decision, note) VALUES (?,?,?,?)",
        (claim_id, reviewer, decision, note),
    )
    conn.execute(
        "UPDATE claims SET status=?, updated_at=datetime('now') WHERE id=?",
        (new_status, claim_id),
    )
    conn.execute(
        "INSERT INTO claim_timeline(claim_id, actor_handle, action, detail) VALUES (?,?,?,?)",
        (claim_id, reviewer, decision, note),
    )
    conn.commit()
    return {"ok": True, "status": new_status, "sources": len(sources)}


def assign_claim(conn: sqlite3.Connection, claim_id: int, assignee: str | None,
                 actor: str | None = None) -> bool:
    cur = conn.execute(
        "UPDATE claims SET assignee_handle=?, status=CASE WHEN status='unverified' "
        "THEN 'pending' ELSE status END, updated_at=datetime('now') WHERE id=?",
        (assignee, claim_id),
    )
    if cur.rowcount:
        conn.execute(
            "INSERT INTO claim_timeline(claim_id, actor_handle, action, detail) VALUES (?,?,?,?)",
            (claim_id, actor, "assigned", assignee or ""),
        )
        conn.commit()
    return cur.rowcount > 0


def claim_counts(conn: sqlite3.Connection) -> dict[str, dict[str, int]]:
    """عدّاد الادّعاءات لكل حالة ولكل مجال (للمرشّحات والمؤشّرات)."""
    by_status: dict[str, int] = {}
    for r in conn.execute("SELECT status, COUNT(*) AS n FROM claims GROUP BY status"):
        by_status[r["status"]] = r["n"]
    by_cat: dict[str, int] = {}
    for r in conn.execute("SELECT category, COUNT(*) AS n FROM claims GROUP BY category"):
        by_cat[r["category"] or ""] = r["n"]
    return {"status": by_status, "category": by_cat}


def claims_leaderboard(conn: sqlite3.Connection) -> list[dict]:
    """مؤشّرات أداء المحقّقين: عدد المراجعات والادّعاءات الموثّقة."""
    return [dict(r) for r in conn.execute(
        """SELECT m.handle, m.display_name, m.verified,
                  COUNT(cr.id) AS reviews,
                  SUM(CASE WHEN cr.decision='approve' THEN 1 ELSE 0 END) AS approvals
           FROM members m JOIN claim_reviews cr ON cr.reviewer_handle = m.handle
           GROUP BY m.handle ORDER BY reviews DESC, approvals DESC LIMIT 20"""
    ).fetchall()]


# ---------------------------------------------------------------------------
# الإشراف والحوكمة (الدفعة 7)
# ---------------------------------------------------------------------------

# (target_kind, target_id, target_handle, action, reason, moderator, days)
SEED_MOD_ACTIONS: list[tuple] = [
    ("member", 0, "omar.act", "warn", "لغة تصعيدية في تعليق عام.", "noor.mod", None),
    ("post", 0, "omar.act", "hide_content", "محتوى مضلّل بلا مصدر.", "noor.mod", None),
    ("member", 0, "khaled.act", "mute", "تكرار الإزعاج في النقاش.", "noor.mod", 7),
    ("comment", 0, "khaled.act", "hide_content", "إساءة شخصية.", "noor.mod", None),
    ("member", 0, "lina.act", "note", "تنبيه: انتحال سياق في تقرير.", "noor.mod", None),
]


def seed_moderation(conn: sqlite3.Connection) -> None:
    """يعبّئ قرارات إشراف تجريبية واستئنافًا وسجلّ تدقيق (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM moderation_actions").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    posts = [r["id"] for r in conn.execute("SELECT id FROM posts ORDER BY id")]
    comments = [r["id"] for r in conn.execute("SELECT id FROM comments ORDER BY id")]
    for i, (kind, _tid, th, action, reason, mod, days) in enumerate(SEED_MOD_ACTIONS):
        if th not in handles or mod not in handles:
            continue
        tid = (posts[i] if i < len(posts) else (i + 1)) if kind == "post" else (
            comments[i] if i < len(comments) else (i + 1))
        cur = conn.execute(
            """INSERT INTO moderation_actions(target_kind, target_id, target_handle, action,
                                              reason, moderator, expires_at)
               VALUES (?,?,?,?,?,?, CASE WHEN ? IS NULL THEN NULL
                       ELSE datetime('now', '+' || ? || ' days') END)""",
            (kind, tid, th, action, reason, mod, days, days),
        )
        _log(conn, mod, "moderation", f"{kind}:{tid}", action)
        if action in ("mute", "suspend", "ban"):
            conn.execute(
                "INSERT INTO appeals(action_id, member, statement) VALUES (?,?,?)",
                (cur.lastrowid, th, "أطلب مراجعة القرار؛ أرى أنّه غير متناسب."),
            )
    conn.commit()


def _log(conn: sqlite3.Connection, actor: str | None, action: str,
         target: str | None = None, detail: str | None = None) -> None:
    conn.execute(
        "INSERT INTO audit_log(actor, action, target, detail) VALUES (?,?,?,?)",
        (actor, action, target, detail),
    )


def moderation_actions_for(conn: sqlite3.Connection, target_kind: str,
                           target_id: int) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT ma.*, m.display_name AS moderator_name
           FROM moderation_actions ma JOIN members m ON m.handle = ma.moderator
           WHERE ma.target_kind=? AND ma.target_id=? ORDER BY ma.created_at DESC""",
        (target_kind, target_id),
    ).fetchall()]


def moderation_actions_by_handle(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT ma.*, m.display_name AS moderator_name
           FROM moderation_actions ma JOIN members m ON m.handle = ma.moderator
           WHERE ma.target_handle=? ORDER BY ma.created_at DESC""",
        (handle,),
    ).fetchall()]


def active_restriction(conn: sqlite3.Connection, handle: str) -> dict[str, Any] | None:
    """أقوى قيد فعّال على العضو (كتم/تعليق/حظر) مع احترام انتهاء المدّة."""
    row = conn.execute(
        """SELECT * FROM moderation_actions
           WHERE target_handle=? AND action IN ('mute','suspend','ban')
             AND (expires_at IS NULL OR expires_at > datetime('now'))
           ORDER BY CASE action WHEN 'ban' THEN 3 WHEN 'suspend' THEN 2 ELSE 1 END DESC,
                    created_at DESC LIMIT 1""",
        (handle,),
    ).fetchone()
    return dict(row) if row else None


def apply_moderation(conn: sqlite3.Connection, *, target_kind: str, target_id: int,
                     target_handle: str | None, action: str, reason: str,
                     moderator: str, report_id: int | None = None,
                     days: int | None = None) -> dict[str, Any]:
    """يطبّق إجراء إشراف متدرّجًا مع سبب إلزامي وتسجيل في التدقيق.

    - «educate-first»: التحذير الأول لا يرقى إلى حظر؛ الحظر يتطلّب سابقة أو خطورة عالية.
    - الحظر الدائم يتطلّب سببًا مطوّلًا (≥ 20 حرفًا).
    """
    if action not in MODERATION_ACTION_BY_KEY:
        return {"ok": False, "error": "invalid_action"}
    reason = (reason or "").strip()
    if len(reason) < 5:
        return {"ok": False, "error": "reason_required"}
    if action == "ban" and len(reason) < 20:
        return {"ok": False, "error": "ban_reason_too_short"}
    if action in ("suspend", "ban") and target_handle:
        prior = conn.execute(
            """SELECT COUNT(*) AS n FROM moderation_actions
               WHERE target_handle=? AND action IN ('warn','hide_content','mute')""",
            (target_handle,),
        ).fetchone()["n"]
        if prior == 0:
            return {"ok": False, "error": "escalation_required"}
    expires = None
    if days:
        expires = conn.execute(
            "SELECT datetime('now', '+' || ? || ' days') AS e", (days,)
        ).fetchone()["e"]
    cur = conn.execute(
        """INSERT INTO moderation_actions(target_kind, target_id, target_handle, action,
                                          reason, moderator, report_id, expires_at)
           VALUES (?,?,?,?,?,?,?,?)""",
        (target_kind, target_id, target_handle, action, reason, moderator, report_id, expires),
    )
    if report_id:
        state = "resolved" if action not in ("note",) else "reviewing"
        conn.execute("UPDATE content_reports SET state=? WHERE id=?", (state, report_id))
    _log(conn, moderator, "moderation", f"{target_kind}:{target_id}",
         f"{action}: {reason[:80]}")
    conn.commit()
    return {"ok": True, "id": cur.lastrowid, "expires_at": expires}


def set_report_state(conn: sqlite3.Connection, report_id: int, state: str,
                     moderator: str | None = None) -> bool:
    if state not in REPORT_STATE_BY_KEY:
        return False
    cur = conn.execute("UPDATE content_reports SET state=? WHERE id=?", (state, report_id))
    if cur.rowcount:
        _log(conn, moderator, "report_state", f"report:{report_id}", state)
        conn.commit()
    return cur.rowcount > 0


def file_appeal(conn: sqlite3.Connection, action_id: int, member: str,
                statement: str) -> dict[str, Any]:
    """يقدّم العضو استئنافًا على إجراء إشراف يخصّه."""
    action = conn.execute("SELECT * FROM moderation_actions WHERE id=?", (action_id,)).fetchone()
    if not action:
        return {"ok": False, "error": "not_found"}
    if action["target_handle"] != member:
        return {"ok": False, "error": "not_your_action"}
    statement = (statement or "").strip()
    if len(statement) < 10:
        return {"ok": False, "error": "statement_too_short"}
    dup = conn.execute(
        "SELECT 1 FROM appeals WHERE action_id=? AND member=? AND status='pending'",
        (action_id, member),
    ).fetchone()
    if dup:
        return {"ok": False, "error": "already_pending"}
    cur = conn.execute(
        "INSERT INTO appeals(action_id, member, statement) VALUES (?,?,?)",
        (action_id, member, statement),
    )
    _log(conn, member, "appeal", f"action:{action_id}", statement[:80])
    conn.commit()
    return {"ok": True, "id": cur.lastrowid}


def appeals(conn: sqlite3.Connection, status: str | None = None) -> list[dict]:
    sql = ("""SELECT a.*, m.display_name AS member_name, ma.action, ma.reason,
                     ma.target_handle
              FROM appeals a
              JOIN members m ON m.handle = a.member
              JOIN moderation_actions ma ON ma.id = a.action_id""")
    params: list[Any] = []
    if status:
        sql += " WHERE a.status=?"; params.append(status)
    sql += " ORDER BY a.created_at DESC, a.id DESC"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def review_appeal(conn: sqlite3.Connection, appeal_id: int, reviewer: str,
                  decision: str, note: str = "") -> dict[str, Any]:
    """يراجع استئنافًا؛ القبول يرفع الإجراء ويستعيد المحتوى."""
    if decision not in ("accepted", "rejected"):
        return {"ok": False, "error": "invalid_decision"}
    row = conn.execute("SELECT * FROM appeals WHERE id=?", (appeal_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "not_found"}
    if row["status"] != "pending":
        return {"ok": False, "error": "already_reviewed"}
    conn.execute(
        """UPDATE appeals SET status=?, reviewer=?, review_note=?, reviewed_at=datetime('now')
           WHERE id=?""",
        (decision, reviewer, note, appeal_id),
    )
    if decision == "accepted":
        action = conn.execute(
            "SELECT * FROM moderation_actions WHERE id=?", (row["action_id"],)
        ).fetchone()
        if action and action["target_kind"] in ("post", "comment"):
            conn.execute(
                "UPDATE moderation_actions SET action='note', reason=reason || ' (نُقض بالاستئناف)' "
                "WHERE id=?", (row["action_id"],),
            )
    _log(conn, reviewer, "appeal_review", f"appeal:{appeal_id}", decision)
    conn.commit()
    return {"ok": True, "status": decision}


def moderation_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    """مؤشّرات إشراف: عدّ الإجراءات لكل نوع، الإبلاغات المفتوحة، الاستئنافات."""
    by_action: dict[str, int] = {}
    for r in conn.execute("SELECT action, COUNT(*) AS n FROM moderation_actions GROUP BY action"):
        by_action[r["action"]] = r["n"]
    by_mod: list[dict] = [dict(r) for r in conn.execute(
        """SELECT m.handle, m.display_name, COUNT(ma.id) AS actions,
                  SUM(CASE WHEN ma.action='ban' THEN 1 ELSE 0 END) AS bans
           FROM members m JOIN moderation_actions ma ON ma.moderator = m.handle
           GROUP BY m.handle ORDER BY actions DESC"""
    ).fetchall()]
    open_reports = count_content_reports(conn, "open")
    pending_appeals = conn.execute(
        "SELECT COUNT(*) AS n FROM appeals WHERE status='pending'"
    ).fetchone()["n"]
    active_bans = conn.execute(
        """SELECT COUNT(*) AS n FROM moderation_actions
           WHERE action='ban' AND (expires_at IS NULL OR expires_at > datetime('now'))"""
    ).fetchone()["n"]
    return {"by_action": by_action, "by_moderator": by_mod,
            "open_reports": open_reports, "pending_appeals": pending_appeals,
            "active_bans": active_bans}


def recent_audit(conn: sqlite3.Connection, limit: int = 40) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM audit_log ORDER BY created_at DESC, id DESC LIMIT ?", (limit,)
    ).fetchall()]


def expiry_alerts(conn: sqlite3.Connection) -> list[dict]:
    """إجراءات مؤقّتة تنتهي خلال 3 أيام (تنبيه إشرافي)."""
    return [dict(r) for r in conn.execute(
        """SELECT * FROM moderation_actions
           WHERE expires_at IS NOT NULL AND expires_at > datetime('now')
             AND expires_at <= datetime('now', '+3 days')
           ORDER BY expires_at ASC"""
    ).fetchall()]


# ---------------------------------------------------------------------------
# السمعة والثقة (الدفعة 8)
# ---------------------------------------------------------------------------

def seed_reputation(conn: sqlite3.Connection) -> None:
    """يعبّئ تأييدات وضمانات وشارات تجريبية (مرّة واحدة، بعد الأعضاء)."""
    if conn.execute("SELECT COUNT(*) AS n FROM endorsements").fetchone()["n"]:
        return
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    # (member, endorser, dimension, weight, note)
    endorsements = [
        ("sami.verify", "noor.mod", "accuracy", 1.5, "دقّة عالية في التحقّق."),
        ("sami.verify", "hala.verify", "reliability", 1.2, None),
        ("hala.verify", "noor.mod", "accuracy", 1.5, None),
        ("ziad.act", "sami.verify", "cooperation", 1.0, "تعاون ممتاز في القضايا."),
        ("hussein.act", "sami.verify", "accuracy", 1.2, "مصادر ميدانية موثوقة."),
        ("omar.act", "yara.act", "cooperation", 0.8, None),
        ("dina.act", "yara.act", "cooperation", 1.0, None),
        ("rana.act", "khaled.act", "reliability", 1.0, None),
    ]
    for member, endorser, dim, weight, note in endorsements:
        if member in handles and endorser in handles and member != endorser:
            conn.execute(
                """INSERT OR IGNORE INTO endorsements(member, endorser, dimension, weight, note)
                   VALUES (?,?,?,?,?)""",
                (member, endorser, dim, weight, note),
            )
    # (member, voucher, kind, statement)
    vouches = [
        ("dina.act", "noor.mod", "peer", "أضمن تعاونها ومساهماتها."),
        ("hussein.act", "sami.verify", "peer", "ناشط ميداني موثوق."),
        ("yara.act", "mirsad_admin", "org", "شهادة من إدارة المنصّة."),
    ]
    for member, voucher, kind, statement in vouches:
        if member in handles and voucher in handles:
            conn.execute(
                """INSERT OR IGNORE INTO vouches(member, voucher, kind, statement)
                   VALUES (?,?,?,?)""",
                (member, voucher, kind, statement),
            )
    # (member, badge, awarded_by)
    badges = [
        ("sami.verify", "fact_checker", "mirsad_admin"),
        ("sami.verify", "verified_contributor", "mirsad_admin"),
        ("hala.verify", "fact_checker", "mirsad_admin"),
        ("noor.mod", "community_builder", "mirsad_admin"),
        ("noor.mod", "mentor", "mirsad_admin"),
        ("ziad.act", "verified_contributor", "mirsad_admin"),
        ("mirsad_admin", "veteran", "mirsad_admin"),
    ]
    for member, badge, awarded_by in badges:
        if member in handles:
            conn.execute(
                """INSERT OR IGNORE INTO member_badges(member, badge, awarded_by)
                   VALUES (?,?,?)""",
                (member, badge, awarded_by),
            )
    conn.commit()


def endorsements_for(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT e.*, m.display_name AS endorser_name, m.verified AS endorser_verified
           FROM endorsements e JOIN members m ON m.handle = e.endorser
           WHERE e.member=? ORDER BY e.created_at DESC""",
        (handle,),
    ).fetchall()]


def endorsements_by(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT e.*, m.display_name AS member_name
           FROM endorsements e JOIN members m ON m.handle = e.member
           WHERE e.endorser=? ORDER BY e.created_at DESC""",
        (handle,),
    ).fetchall()]


def _endorser_weight(conn: sqlite3.Connection, endorser: str) -> float:
    """وزن المُقيِّم: يرتفع مع موثوقيته وسمعته (لمنع التلاعب بالسمعة)."""
    m = conn.execute("SELECT verified FROM members WHERE handle=?", (endorser,)).fetchone()
    base = 1.0 if (m and m["verified"]) else 0.6
    # خصم إن كان المُقيِّم ضالعًا في دوائر تبادل مغلقة (نفسه يقيم من يقيمه)
    mutual = conn.execute(
        """SELECT COUNT(*) AS n FROM endorsements a JOIN endorsements b
           ON a.member=b.endorser AND a.endorser=b.member
           WHERE a.endorser=?""",
        (endorser,),
    ).fetchone()["n"]
    return round(base * (1.0 / (1.0 + 0.25 * mutual)), 3)


def add_endorsement(conn: sqlite3.Connection, member: str, endorser: str,
                    dimension: str = "accuracy", note: str = "") -> dict[str, Any]:
    """يضيف تأييدًا؛ يمنع التقييم الذاتي والتكرار (منع التلاعب)."""
    if member == endorser:
        return {"ok": False, "error": "self_endorsement"}
    if not conn.execute("SELECT 1 FROM members WHERE handle=?", (member,)).fetchone():
        return {"ok": False, "error": "unknown_member"}
    # منع التقييم الانتقامي المباشر: من قيّمك لا تقيّمه في نفس اليوم
    recent = conn.execute(
        """SELECT 1 FROM endorsements WHERE member=? AND endorser=?
           AND created_at > datetime('now','-1 day')""",
        (endorser, member),
    ).fetchone()
    if recent:
        return {"ok": False, "error": "retaliatory_blocked"}
    weight = _endorser_weight(conn, endorser)
    cur = conn.execute(
        """INSERT OR IGNORE INTO endorsements(member, endorser, dimension, weight, note)
           VALUES (?,?,?,?,?)""",
        (member, endorser, dimension, weight, note or None),
    )
    if cur.rowcount == 0:
        return {"ok": False, "error": "already_endorsed"}
    conn.commit()
    return {"ok": True, "weight": weight}


def vouches_for(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT v.*, m.display_name AS voucher_name, m.verified AS voucher_verified
           FROM vouches v JOIN members m ON m.handle = v.voucher
           WHERE v.member=? ORDER BY v.created_at DESC""",
        (handle,),
    ).fetchall()]


def add_vouch(conn: sqlite3.Connection, member: str, voucher: str,
              kind: str = "peer", statement: str = "") -> dict[str, Any]:
    """ضمان عضو من عضو موثوق؛ يتطلّب مُضمونًا موثوقًا (trust ≥ 2)."""
    if member == voucher:
        return {"ok": False, "error": "self_vouch"}
    if kind == "peer":
        score = trust_score(conn, voucher)["score"]
        if score < 40:
            return {"ok": False, "error": "voucher_not_trusted"}
    cur = conn.execute(
        """INSERT OR IGNORE INTO vouches(member, voucher, kind, statement)
           VALUES (?,?,?,?)""",
        (member, voucher, kind, statement or None),
    )
    if cur.rowcount == 0:
        return {"ok": False, "error": "already_vouched"}
    conn.commit()
    return {"ok": True}


def badges_for(conn: sqlite3.Connection, handle: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM member_badges WHERE member=? ORDER BY created_at DESC", (handle,)
    ).fetchall()]


def award_badge(conn: sqlite3.Connection, member: str, badge: str,
                awarded_by: str | None = None, note: str = "") -> bool:
    if badge not in BADGE_BY_KEY:
        return False
    cur = conn.execute(
        "INSERT OR IGNORE INTO member_badges(member, badge, awarded_by, note) VALUES (?,?,?,?)",
        (member, badge, awarded_by, note or None),
    )
    if cur.rowcount:
        _log(conn, awarded_by, "badge", member, badge)
        conn.commit()
    return cur.rowcount > 0


def trust_score(conn: sqlite3.Connection, handle: str) -> dict[str, Any]:
    """مركّب ثقة قابل للتفسير (0–100) من إشارات موضوعية.

    المكوّنات: التوثيق، عدد المساهمات، التأييدات الموزونة، الضمانات، الالتزام
    بالقواعد (سجلّ إشرافي نظيف)، والأقدمية. تُعيد التفصيل لشفافية الحساب.
    """
    m = conn.execute(
        "SELECT handle, role, verified, published, created_at FROM members WHERE handle=?",
        (handle,),
    ).fetchone()
    if not m:
        return {"score": 0.0, "level": "0", "breakdown": {}}
    posts = conn.execute(
        "SELECT COUNT(*) AS n FROM posts WHERE author_handle=?", (handle,)
    ).fetchone()["n"]
    comments = conn.execute(
        "SELECT COUNT(*) AS n FROM comments WHERE author_handle=?", (handle,)
    ).fetchone()["n"]
    verified_claims = conn.execute(
        """SELECT COUNT(*) AS n FROM claims
           WHERE (reporter_handle=? OR assignee_handle=?) AND status='verified'""",
        (handle, handle),
    ).fetchone()["n"]
    reviews = conn.execute(
        "SELECT COUNT(*) AS n FROM claim_reviews WHERE reviewer_handle=?", (handle,)
    ).fetchone()["n"]
    end_weight = conn.execute(
        "SELECT COALESCE(SUM(weight),0) AS w FROM endorsements WHERE member=?", (handle,)
    ).fetchone()["w"]
    vouch_n = conn.execute(
        "SELECT COUNT(*) AS n FROM vouches WHERE member=?", (handle,)
    ).fetchone()["n"]
    sanctions = conn.execute(
        """SELECT COUNT(*) AS n FROM moderation_actions
           WHERE target_handle=? AND action IN ('warn','hide_content','mute','suspend','ban')""",
        (handle,),
    ).fetchone()["n"]

    breakdown = {
        "verified": 12.0 if m["verified"] else 0.0,
        "posts": min(posts, 20) * 0.8,
        "comments": min(comments, 40) * 0.3,
        "verified_claims": min(verified_claims, 10) * 3.0,
        "reviews": min(reviews, 20) * 1.5,
        "endorsements": min(end_weight, 15) * 2.0,
        "vouches": min(vouch_n, 3) * 3.0,
        "tenure": 5.0 if m["created_at"] else 0.0,
        "penalty": -min(sanctions, 5) * 4.0,
    }
    raw = sum(breakdown.values())
    score = round(max(0.0, min(100.0, raw)), 1)
    return {"score": score, "level": trust_level_for_score(score), "breakdown": breakdown}


def save_trust_snapshot(conn: sqlite3.Connection, handle: str) -> dict[str, Any]:
    """يحفظ لقطة ثقة (للتاريخ) ويعيد النتيجة."""
    result = trust_score(conn, handle)
    conn.execute(
        "INSERT INTO trust_snapshots(member, score, level, breakdown) VALUES (?,?,?,?)",
        (handle, result["score"], result["level"], json.dumps(result["breakdown"], ensure_ascii=False)),
    )
    conn.commit()
    return result


def trust_history(conn: sqlite3.Connection, handle: str, limit: int = 10) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM trust_snapshots WHERE member=? ORDER BY created_at DESC LIMIT ?",
        (handle, limit),
    ).fetchall()]


def trust_leaderboard(conn: sqlite3.Connection, limit: int = 20) -> list[dict]:
    """لوحة متصدّرين اختيارية (يمكن للعضو إخفاء نفسه)."""
    rows = [dict(r) for r in conn.execute(
        "SELECT handle, display_name, verified FROM members "
        "WHERE published=1 AND status='active' ORDER BY handle"
    ).fetchall()]
    out = []
    for r in rows:
        t = trust_score(conn, r["handle"])
        r.update({"score": t["score"], "level": t["level"]})
        out.append(r)
    out.sort(key=lambda x: x["score"], reverse=True)
    return out[:limit]


def trust_network(conn: sqlite3.Connection, handle: str) -> dict[str, Any]:
    """شبكة ثقة محيطة بعضو: ضامنوه ومن يضمنهم (web of trust)."""
    inbound = [dict(r) for r in conn.execute(
        "SELECT voucher, kind FROM vouches WHERE member=?", (handle,)
    ).fetchall()]
    outbound = [dict(r) for r in conn.execute(
        "SELECT member, kind FROM vouches WHERE voucher=?", (handle,)
    ).fetchall()]
    return {"inbound": inbound, "outbound": outbound,
            "degree": len(inbound) + len(outbound)}


# ---------------------------------------------------------------------------
# الإشعارات والتنبيهات (الدفعة 9)
# ---------------------------------------------------------------------------

def seed_notifications(conn: sqlite3.Connection) -> None:
    """يعبّئ إشعارات واشتراكات وساعات هدوء تجريبية (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM notifications").fetchone()["n"]:
        return
    rows = [
        ("sami.verify", "tasks", "important", "inapp", "claim_assigned",
         "أُسند إليك ادّعاء للتحقّق", "ادّعاء جديد بانتظار مراجعتك.", "/verification", "noor.mod", "claim", 1),
        ("sami.verify", "interaction", "normal", "inapp", "comment_reply",
         "ردّ على تعليقك", "ردّ @hala.verify على تعليقك.", "/posts", "hala.verify", "post", 1),
        ("hala.verify", "security", "critical", "inapp", "new_device",
         "دخول من جهاز جديد", "سُجّل دخول من جهاز غير موثوق. راجعه فورًا.", "/notifications", None, None, None),
        ("noor.mod", "system", "important", "inapp", "report_new",
         "إبلاغ جديد في الطابور", "وصل إبلاغ جديد يحتاج قرارًا.", "/moderation", None, "post", 2),
        ("ziad.act", "interaction", "normal", "inapp", "mention",
         "أشار إليك أحدهم", "أشار @yara.act إليك في منشور.", "/posts", "yara.act", "post", 2),
        ("noor.mod", "tasks", "normal", "inapp", "appeal_pending",
         "استئناف بانتظار مراجعتك", "قدّم عضو استئنافًا على إجراء.", "/moderation", "fadi.act", None, None),
    ]
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    for member, cat, prio, ch, kind, title, body, link, actor, skind, sid in rows:
        if member in handles:
            conn.execute(
                """INSERT INTO notifications(member, category, priority, channel, kind,
                   title, body, link, actor, subject_kind, subject_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (member, cat, prio, ch, kind, title, body, link, actor, skind, sid),
            )
    subs = [
        ("sami.verify", "category", "disinformation"),
        ("sami.verify", "country", "SY"),
        ("noor.mod", "category", "hate_speech"),
        ("ziad.act", "member", "sami.verify"),
        ("hala.verify", "claim", "1"),
    ]
    for member, kind, value in subs:
        if member in handles:
            conn.execute(
                "INSERT OR IGNORE INTO subscriptions(member, kind, value) VALUES (?,?,?)",
                (member, kind, value),
            )
    if "noor.mod" in handles:
        conn.execute(
            "INSERT OR IGNORE INTO quiet_hours(member, start_hour, end_hour, tz) VALUES (?,?,?,?)",
            ("noor.mod", 22, 7, "Asia/Damascus"),
        )
    conn.commit()


def _notify_channel_for(conn: sqlite3.Connection, member: str, category: str) -> str:
    row = conn.execute(
        """SELECT enabled, muted_until FROM notification_prefs
           WHERE member=? AND category=? AND channel='inapp'""",
        (member, category),
    ).fetchone()
    return "inapp"


def notify(conn: sqlite3.Connection, member: str, kind: str, title: str, *,
           body: str = "", link: str = "", category: str = "system",
           priority: str = "normal", actor: str | None = None,
           subject_kind: str | None = None, subject_id: int | None = None,
           channel: str = "inapp") -> int | None:
    """ينشئ إشعارًا داخليًّا يحترم التفضيلات وساعات الهدوء (الإشعارات الحسّاسة لا تُكتم)."""
    if not member:
        return None
    pref = conn.execute(
        """SELECT enabled, muted_until FROM notification_prefs
           WHERE member=? AND category=? AND channel=?""",
        (member, category, channel),
    ).fetchone()
    if pref and not pref["enabled"]:
        return None
    # كتم مؤقّت حتى تاريخ محدّد (تفضيل صريح لكل تصنيف، مثل enabled)
    if pref and _muted_until_active(pref["muted_until"]):
        return None
    # «لا إزعاج» يُطبَّق على الإشعارات غير الحسّاسة فقط
    if category != "security" and _in_quiet_hours(conn, member):
        return None
    cur = conn.execute(
        """INSERT INTO notifications(member, category, priority, channel, kind, title,
           body, link, actor, subject_kind, subject_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (member, category, priority, channel, kind, title, body or None, link or None,
         actor, subject_kind, subject_id),
    )
    conn.commit()
    return cur.lastrowid


def _muted_until_active(muted_until: str | None) -> bool:
    """صحيح إذا كان الكتم المؤقّت ساريًا الآن (التاريخ اليوم أو لاحقًا).

    يقبل طابعًا زمنيًّا `YYYY-MM-DD` أو `YYYY-MM-DD HH:MM`؛ أي قيمة غير صالحة
    تُهمَل حتى لا تمنع الإشعارات بلا سبب.
    """
    if not muted_until:
        return False
    import datetime as _dt
    raw = str(muted_until).strip()
    try:
        if len(raw) > 10:
            deadline = _dt.datetime.strptime(raw[:19], "%Y-%m-%d %H:%M:%S")
        else:
            deadline = _dt.datetime.strptime(raw[:10], "%Y-%m-%d")
    except ValueError:
        return False
    return deadline >= _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None)


def _hour_in_tz(tz: str | None, now: datetime | None = None) -> int:
    """الساعة (0–23) للحظة المعطاة في المنطقة الزمنية `tz`، مع الرجوع إلى UTC
    عند غياب المنطقة أو تعذّر تحميلها (مثل قيمة تالفة في القاعدة)."""
    now = now or datetime.now(timezone.utc)
    try:
        zone = ZoneInfo(tz or "UTC")
    except (ZoneInfoNotFoundError, ValueError):
        zone = timezone.utc
    return now.astimezone(zone).hour


def _in_quiet_hours(conn: sqlite3.Connection, member: str, now_hour: int | None = None,
                    *, now: datetime | None = None) -> bool:
    """هل الوقت الحالي داخل نافذة «ساعات الهدوء» للعضو؟

    تُحسب الساعة بالمنطقة الزمنية المخزَّنة (`tz`) لا بـUTC؛ وعند غيابها أو
    تعذّر تحميلها نعود إلى UTC. يُقبل `now_hour` أو `now` صراحةً لتثبيت الساعة
    في الاختبارات. النافذة شاملة لطرفَيها `[s, e]`، و`(0, 23)` تغطّي اليوم كاملًا.
    """
    q = conn.execute(
        "SELECT start_hour, end_hour, tz FROM quiet_hours WHERE member=?", (member,)
    ).fetchone()
    if not q:
        return False
    hour = now_hour if now_hour is not None else _hour_in_tz(q["tz"], now)
    s, e = q["start_hour"], q["end_hour"]
    return (hour >= s or hour <= e) if s > e else (s <= hour <= e)


def set_quiet_hours(conn: sqlite3.Connection, member: str, start_hour: int,
                    end_hour: int, tz: str = "UTC") -> None:
    conn.execute(
        """INSERT INTO quiet_hours(member, start_hour, end_hour, tz, updated_at)
           VALUES (?,?,?,?, datetime('now'))
           ON CONFLICT(member) DO UPDATE SET
             start_hour=excluded.start_hour, end_hour=excluded.end_hour,
             tz=excluded.tz, updated_at=datetime('now')""",
        (member, start_hour % 24, end_hour % 24, tz),
    )
    conn.commit()


def quiet_hours_for(conn: sqlite3.Connection, member: str) -> dict | None:
    r = conn.execute("SELECT * FROM quiet_hours WHERE member=?", (member,)).fetchone()
    return dict(r) if r else None


def set_notification_pref(conn: sqlite3.Connection, member: str, category: str,
                          channel: str = "inapp", enabled: bool = True,
                          muted_until: str | None = None) -> None:
    conn.execute(
        """INSERT INTO notification_prefs(member, category, channel, enabled, muted_until)
           VALUES (?,?,?,?,?)
           ON CONFLICT(member, category, channel) DO UPDATE SET
             enabled=excluded.enabled, muted_until=excluded.muted_until""",
        (member, category, channel, 1 if enabled else 0, muted_until),
    )
    conn.commit()


def notification_prefs_for(conn: sqlite3.Connection, member: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM notification_prefs WHERE member=? ORDER BY category", (member,)
    ).fetchall()]


def mute_all(conn: sqlite3.Connection, member: str, until: str | None = None) -> None:
    """إيقاف كل الإشعارات بزر واحد (الإشعارات الأمنية تبقى فعّالة)."""
    for c in ("system", "interaction", "tasks"):
        set_notification_pref(conn, member, c, "inapp", enabled=False, muted_until=until)


def notifications_for(conn: sqlite3.Connection, member: str, *,
                      unread_only: bool = False, category: str | None = None,
                      limit: int = 100) -> list[dict]:
    q = "SELECT * FROM notifications WHERE member=?"
    args: list[Any] = [member]
    if unread_only:
        q += " AND read=0"
    if category:
        q += " AND category=?"
        args.append(category)
    q += " ORDER BY created_at DESC, id DESC LIMIT ?"
    args.append(limit)
    return [dict(r) for r in conn.execute(q, args).fetchall()]


def unread_count(conn: sqlite3.Connection, member: str) -> int:
    return conn.execute(
        "SELECT COUNT(*) AS n FROM notifications WHERE member=? AND read=0", (member,)
    ).fetchone()["n"]


def mark_read(conn: sqlite3.Connection, member: str, notification_id: int | None = None) -> int:
    if notification_id:
        cur = conn.execute(
            "UPDATE notifications SET read=1 WHERE id=? AND member=?", (notification_id, member)
        )
    else:
        cur = conn.execute("UPDATE notifications SET read=1 WHERE member=? AND read=0", (member,))
    conn.commit()
    return cur.rowcount


def digest(conn: sqlite3.Connection, member: str) -> dict[str, Any]:
    """ملخّص مجمّع لأهم ما فات العضو، مرتّبًا بالأولوية."""
    rows = notifications_for(conn, member, unread_only=True, limit=200)
    order = {"critical": 0, "important": 1, "normal": 2}
    rows.sort(key=lambda r: (order.get(r["priority"], 3), r["created_at"]), reverse=False)
    by_cat: dict[str, int] = {}
    for r in rows:
        by_cat[r["category"]] = by_cat.get(r["category"], 0) + 1
    return {"total": len(rows), "by_category": by_cat, "items": rows[:10]}


def subscribe(conn: sqlite3.Connection, member: str, kind: str, value: str,
              notify_enabled: bool = True) -> bool:
    if kind not in SUBSCRIPTION_KIND_BY_KEY or not value:
        return False
    cur = conn.execute(
        """INSERT OR IGNORE INTO subscriptions(member, kind, value, notify)
           VALUES (?,?,?,?)""",
        (member, kind, value, 1 if notify_enabled else 0),
    )
    conn.commit()
    return cur.rowcount > 0


def unsubscribe(conn: sqlite3.Connection, member: str, kind: str, value: str) -> bool:
    cur = conn.execute(
        "DELETE FROM subscriptions WHERE member=? AND kind=? AND value=?", (member, kind, value)
    )
    conn.commit()
    return cur.rowcount > 0


def subscriptions_for(conn: sqlite3.Connection, member: str) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM subscriptions WHERE member=? ORDER BY created_at DESC", (member,)
    ).fetchall()]


def subscribers_for(conn: sqlite3.Connection, kind: str, value: str) -> list[str]:
    return [r["member"] for r in conn.execute(
        "SELECT member FROM subscriptions WHERE kind=? AND value=? AND notify=1", (kind, value)
    ).fetchall()]


def notify_subscribers(conn: sqlite3.Connection, kind: str, value: str, *,
                       title: str, body: str = "", link: str = "",
                       category: str = "system", priority: str = "normal") -> int:
    """يُشعر كل مشتركي قيمة معيّنة (مجال/دولة/عضو...)."""
    n = 0
    for member in subscribers_for(conn, kind, value):
        if notify(conn, member, f"sub_{kind}", title, body=body, link=link,
                  category=category, priority=priority, subject_kind=kind):
            n += 1
    return n


def purge_old_notifications(conn: sqlite3.Connection, days: int = 90) -> int:
    cur = conn.execute(
        "DELETE FROM notifications WHERE read=1 AND created_at < datetime('now', ?)",
        (f"-{int(days)} days",),
    )
    conn.commit()
    return cur.rowcount


def notification_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    total = conn.execute("SELECT COUNT(*) AS n FROM notifications").fetchone()["n"]
    unread = conn.execute("SELECT COUNT(*) AS n FROM notifications WHERE read=0").fetchone()["n"]
    by_cat = {r["category"]: r["n"] for r in conn.execute(
        "SELECT category, COUNT(*) AS n FROM notifications GROUP BY category"
    ).fetchall()}
    by_prio = {r["priority"]: r["n"] for r in conn.execute(
        "SELECT priority, COUNT(*) AS n FROM notifications GROUP BY priority"
    ).fetchall()}
    subs = conn.execute("SELECT COUNT(*) AS n FROM subscriptions").fetchone()["n"]
    return {"total": total, "unread": unread, "by_category": by_cat,
            "by_priority": by_prio, "subscriptions": subs}


# بذور تفاعل تجريبية: (post_index، نوع التفاعل، أصحاب المعرّفات)
SEED_REACTIONS: list[tuple] = [
    (1, "support", ["hala.verify", "yara.act", "omar.act", "dina.act"]),
    (1, "like", ["sara.act", "maya.act"]),
    (2, "important", ["sami.verify", "tariq.act", "hussein.act"]),
    (2, "like", ["noor.mod"]),
    (3, "support", ["sami.verify", "dina.act", "sara.act", "rana.act", "ziad.act"]),
    (4, "like", ["aya.mem", "lina.act"]),
    (5, "support", ["hala.verify", "khaled.act"]),
    (6, "important", ["lina.act", "aya.mem", "noor.mod"]),
    (8, "support", ["yara.act", "rana.act", "sara.act"]),
    (10, "like", ["hussein.act", "tariq.act"]),
    (13, "support", ["maya.act", "dina.act", "noor.mod"]),
    (15, "important", ["ziad.act", "sami.verify"]),
]

# بذور تعليقات: (post_index، كاتب التعليق، النصّ، فهرس الأب إن وُجد)
SEED_COMMENTS: list[tuple] = [
    (1, "yara.act", "إشارة الظلّ أثبتت فاعليتها ميدانيًّا. شكرًا على التوثيق.", None),
    (1, "sami.verify", "أضفنا كذلك مطابقة الطقس بين مصدرين مستقلّين.", 1),
    (1, "dina.act", "هل يمكن مشاركة قائمة الأدوات المستخدمة؟", 1),
    (2, "sami.verify", "أراجع تقارير الجهات البيئية وأوافيكم بالنتيجة.", None),
    (3, "sara.act", "مهم جدًّا حماية هوية الشهود في هذه الحالة.", None),
    (3, "ziad.act", "أستطيع مراجعة الأسماء مع السجلات المتاحة.", 5),
    (4, "aya.mem", "أستطيع ترجمة شهادتين من الفرنسية هذا الأسبوع.", None),
    (6, "hala.verify", "سأنشر تقريرًا مستقلًّا عن نتائج الفحص المخبري.", None),
    (13, "dina.act", "وثّقنا ثلاث مخالفات سلامة مماثلة في موقع آخر.", None),
]


def seed_interactions(conn: sqlite3.Connection) -> None:
    """يعبّئ تفاعلات وتعليقات تجريبية (مرّة واحدة، بعد المنشورات)."""
    if conn.execute("SELECT COUNT(*) AS n FROM reactions").fetchone()["n"]:
        return
    posts = [r["id"] for r in conn.execute("SELECT id FROM posts ORDER BY id")]
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    if not posts:
        return
    for idx, kind, people in SEED_REACTIONS:
        if idx > len(posts):
            continue
        pid = posts[idx - 1]
        for h in people:
            if h in handles:
                conn.execute(
                    "INSERT OR IGNORE INTO reactions(post_id, member_handle, kind) VALUES (?,?,?)",
                    (pid, h, kind),
                )
    created_ids: list[int] = []
    for idx, author, body, parent_idx in SEED_COMMENTS:
        if idx > len(posts) or author not in handles:
            created_ids.append(-1)
            continue
        pid = posts[idx - 1]
        parent_id = created_ids[parent_idx - 1] if parent_idx and parent_idx <= len(created_ids) else None
        if parent_id == -1:
            parent_id = None
        cur = conn.execute(
            "INSERT INTO comments(post_id, author_handle, parent_id, body) VALUES (?,?,?,?)",
            (pid, author, parent_id, body),
        )
        created_ids.append(cur.lastrowid)
    conn.commit()
