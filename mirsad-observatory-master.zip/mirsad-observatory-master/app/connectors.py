"""موصلات المصادر: طبقة تجريد موحّدة لكل نوع مصدر (القسم 2.1).

كل نوع مصدر له موصل مستقل يجلب عناصر موحّدة الشكل، بحيث لا يؤدي اختلاف صيغة
مصدر إلى تعطيل الرصد في بقية المصادر. الموصل يُعيد قائمة عناصر (dict) أو يرفع
استثناءً يُلتقط لكل مصدر على حدة (`collect_source`).

شكل العنصر الموحّد:
    {title, url, summary, body, published_on, external_id, raw}
"""

from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

from .clients import get_json, get_text
from .rss_feeds import _clean, _feed_text, _localname, parse_feed, parse_iso_date

log = logging.getLogger("mirsad.connectors")

# أنواع الموصلات المدعومة (قابل للتوسّع).
CONNECTOR_KINDS = ("rss", "atom", "api", "json", "sitemap", "archive", "manual", "html")

_SITEMAP_NS = "{http://www.sitemaps.org/schemas/sitemap/0.9}"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connector_for(source: dict) -> str:
    """يحدّد نوع الموصل المناسب للمصدر انطلاقًا من حقوله."""
    kind = (source.get("source_kind") or source.get("kind") or "").lower()
    if kind in ("api", "json"):
        return "api"
    if kind == "sitemap":
        return "sitemap"
    if kind == "archive":
        return "archive"
    if kind == "html" or kind == "web":
        return "html"
    if kind in ("manual", "human", "field"):
        return "manual"
    if source.get("feed_url"):
        return "rss"
    if source.get("url"):
        return "html"
    return "manual"


def collect_source(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """يجمع عناصر مصدر واحد عبر الموصل المناسب. يرفع استثناءً عند الفشل.

    الهدف أن تُعزل أخطاء كل مصدر: المتصل (`monitoring`) يلتقط الاستثناء
    ويسجّله دون التأثير على بقية المصادر.
    """
    kind = connector_for(source)
    fn = _CONNECTORS.get(kind) or _collect_rss
    return fn(source, maxrecords=maxrecords)


def _collect_rss(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """RSS/Atom عبر محلّل التغذيات الموجود (يشمل التخزين المؤقّت والتقييد)."""
    url = source.get("feed_url") or source.get("url")
    if not url:
        raise ValueError("لا يوجد رابط تغذية")
    raw = _feed_text(url)
    items = parse_feed(raw)[:maxrecords]
    out = []
    for it in items:
        out.append({
            "title": it["title"],
            "url": it["link"],
            "summary": it.get("summary") or "",
            "body": it.get("summary") or "",
            "published_on": it.get("date") or "",
            "external_id": it["link"],
            "raw": raw[:2000],
        })
    return out


def _collect_api(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """واجهة API تُعيد JSON. يستخرج العناصر من مفاتيح شائعة (items/results/data)."""
    url = source.get("feed_url") or source.get("url")
    if not url:
        raise ValueError("لا يوجد رابط API")
    data = get_json(url, ttl=900, min_interval=1.0)
    rows = data
    if isinstance(data, dict):
        for key in ("items", "results", "data", "entries", "records", "hits"):
            if isinstance(data.get(key), list):
                rows = data[key]
                break
        else:
            rows = [data]
    if not isinstance(rows, list):
        raise ValueError("استجابة API غير متوقّعة")
    out = []
    for row in rows[:maxrecords]:
        if not isinstance(row, dict):
            continue
        title = (row.get("title") or row.get("name") or row.get("headline") or "").strip()
        link = (row.get("url") or row.get("link") or row.get("href") or "").strip()
        if not title or not link:
            continue
        summary = _clean(str(row.get("summary") or row.get("description")
                             or row.get("abstract") or ""))
        published = parse_iso_date(str(row.get("published") or row.get("date")
                                       or row.get("pubDate") or row.get("created_at") or ""))
        out.append({
            "title": title,
            "url": link,
            "summary": summary,
            "body": summary,
            "published_on": published,
            "external_id": str(row.get("id") or link),
            "raw": str(row)[:2000],
        })
    return out


def _collect_sitemap(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """خريطة موقع XML: يستخرج روابط الصفحات الحديثة (مع تواريخ آخر تعديل)."""
    url = source.get("feed_url") or source.get("url")
    if not url:
        raise ValueError("لا يوجد رابط خريطة الموقع")
    raw = get_text(url, ttl=1800, min_interval=1.0)
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise ValueError(f"خريطة موقع غير صالحة: {exc}") from exc
    out = []
    for node in root.iter():
        if _localname(node.tag) != "url":
            continue
        loc = lastmod = ""
        for child in node:
            cn = _localname(child.tag)
            if cn == "loc":
                loc = (child.text or "").strip()
            elif cn == "lastmod":
                lastmod = (child.text or "").strip()
        if not loc:
            continue
        out.append({
            "title": loc.rstrip("/").rsplit("/", 1)[-1].replace("-", " ")[:240] or loc,
            "url": loc,
            "summary": "",
            "body": "",
            "published_on": parse_iso_date(lastmod),
            "external_id": loc,
            "raw": "",
        })
        if len(out) >= maxrecords:
            break
    return out


def _collect_archive(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """أرشيف: يعتمد على رابط تغذية/خريطة موقع أرشيفية إن وُجد، وإلا فشل بوضوح."""
    archive_url = source.get("archive_url") or source.get("feed_url") or source.get("url")
    if not archive_url:
        raise ValueError("لا يوجد رابط أرشيف")
    if archive_url.endswith(".xml") or "sitemap" in archive_url:
        return _collect_sitemap({**source, "url": archive_url}, maxrecords=maxrecords)
    return _collect_rss({**source, "feed_url": archive_url}, maxrecords=maxrecords)


def _collect_html(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """صفحة HTML عامّة: يستخرج روابط الأخبار/التقارير من عناوين الصفحة.

    استخراج متحفّظ (لا محلّل DOM كامل) لتفادي الاعتماديات؛ يُستكمل لاحقًا
    بالجمع عبر التغذية إن توفّرت.
    """
    url = source.get("feed_url") or source.get("url")
    if not url:
        raise ValueError("لا يوجد رابط صفحة")
    raw = get_text(url, ttl=1800, min_interval=1.0)
    base = url
    out = []
    seen = set()
    for m in re.finditer(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', raw,
                         flags=re.IGNORECASE | re.DOTALL):
        href, text = m.group(1).strip(), _clean(m.group(2))
        if not href or href.startswith(("#", "javascript:", "mailto:")):
            continue
        if len(text) < 25:
            continue
        link = _absolutize(base, href)
        if not link or link in seen:
            continue
        seen.add(link)
        out.append({
            "title": text[:240],
            "url": link,
            "summary": "",
            "body": "",
            "published_on": "",
            "external_id": link,
            "raw": "",
        })
        if len(out) >= maxrecords:
            break
    return out


def _collect_manual(source: dict, *, maxrecords: int = 12) -> list[dict]:
    """مصدر يدوي/ميداني: لا جلب آلي (البلاغات الواردة عبر قنوات مرخّصة)."""
    return []


def _absolutize(base: str, href: str) -> str:
    from urllib.parse import urljoin
    try:
        return urljoin(base, href)
    except ValueError:
        return ""


_CONNECTORS = {
    "rss": _collect_rss,
    "atom": _collect_rss,
    "api": _collect_api,
    "json": _collect_api,
    "sitemap": _collect_sitemap,
    "archive": _collect_archive,
    "html": _collect_html,
    "manual": _collect_manual,
}
