"""المسح التاريخي والأرشيف القابل للاستئناف (القسم 2.3).

عند أول تشغيل يبدأ استيراد تاريخي للمحتوى المتاح، مقسّمًا إلى دفعات قابلة
للاستئناف مع حفظ موضع التقدّم لكل مصدر لاستكمال العملية بعد التعطل.

يميّز النظام بين:
- الأرشيف المُعالج كاملًا (`done`)،
- الأرشيف المتاح جزئيًّا (`partial`)،
- البيانات التي تعذّر الوصول إليها (`blocked`) مع تسجيل الفترات المتعذّرة.

لا يُفترض أن كل مصدر يتيح أرشيفًا كاملًا؛ ولذلك نُسجّل النطاق الذي جرى
والفترات التي تعذّرت، دون إسقاط العمل التاريخي.
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import date, datetime, timedelta, timezone

from . import db, pipeline

log = logging.getLogger("mirsad.backfill")

# حدّ العناصر لكل دفعة استيراد تاريخي.
BATCH_ITEMS = 40
# أقصى عدد دفعات لكل مصدر في الدورة الواحدة (سقف زمني للخلفية).
MAX_BATCHES_PER_SOURCE = 3


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_progress(conn: sqlite3.Connection, source: dict,
                    range_start: str | None = None) -> dict:
    """ينشئ صفّ تقدّم للاستيراد إن لم يوجد، ويعيده."""
    key = source.get("key") or source.get("name")
    row = db.archive_for_source(conn, key)
    if row is None:
        start = range_start or (date.today() - timedelta(days=365 * 3)).isoformat()
        db.upsert_archive_progress(conn, key, status="pending", range_start=start,
                                   range_end=date.today().isoformat(), batches_done=0,
                                   items_found=0, items_imported=0)
        row = db.archive_for_source(conn, key)
    return row


def backfill_source(conn: sqlite3.Connection, source: dict, *,
                    batch_items: int = BATCH_ITEMS,
                    max_batches: int = MAX_BATCHES_PER_SOURCE,
                    maxrecords: int = 40) -> dict:
    """يستورد أرشيف مصدر واحد على دفعات قابلة للاستئناف.

    يحفظ الموضع (`cursor`) وعدد الدفعات والنطاق المُغطّى، ويسجّل الفترات التي
    تعذّر الوصول إليها. يعيد ملخّصًا.
    """
    key = source.get("key") or source.get("name")
    prog = ensure_progress(conn, source)
    result = {"source": key, "status": prog["status"], "fetched": 0,
              "imported": 0, "batches": 0, "error": None}

    if prog["status"] in ("done",):
        return result  # مُكتمل سابقًا (idempotent)

    db.upsert_archive_progress(conn, key, status="running")
    started = date.today().isoformat()
    try:
        # الجمع مرّة واحدة ثم الاستيراد على دفعات (لا نُكرّر الطلب الشبكي).
        items = pipeline.connectors.collect_source(source, maxrecords=maxrecords)
    except Exception as exc:  # noqa: BLE001 — تعذّر الوصول يُسجّل بوضوح
        db.upsert_archive_progress(conn, key, status="blocked",
                                   inaccessible=[started],
                                   note=f"تعذّر الوصول: {type(exc).__name__}: {str(exc)[:140]}")
        result["status"] = "blocked"
        result["error"] = str(exc)[:160]
        return result

    result["fetched"] = len(items)
    # نستأنف من الموضع المحفوظ (`cursor`) بدل إعادة دفعة البداية.
    try:
        start_at = int(prog.get("cursor") or 0)
    except (TypeError, ValueError):
        start_at = 0
    imported = 0
    batches = 0
    covered_start = prog.get("covered_start") or started
    for i in range(start_at, len(items), batch_items):
        if batches >= max_batches:
            # توقف مؤقّت: يبقى الصف running ليُستأنف في دورة لاحقة.
            db.upsert_archive_progress(
                conn, key, status="running", cursor=str(i),
                batches_done=(prog["batches_done"] or 0) + batches,
                items_found=len(items),
                items_imported=(prog["items_imported"] or 0) + imported,
                covered_start=covered_start, covered_end=started)
            result.update({"status": "running", "imported": imported, "batches": batches})
            return result
        batch = items[i:i + batch_items]
        for it in batch:
            doc_id, is_dup = pipeline.ingest_item(conn, source, it)
            if doc_id and not is_dup:
                imported += 1
        batches += 1

    # اكتمل استيراد كل ما أمكن الوصول إليه.
    db.upsert_archive_progress(
        conn, key, status="done", cursor=None,
        batches_done=(prog["batches_done"] or 0) + batches,
        items_found=len(items),
        items_imported=(prog["items_imported"] or 0) + imported,
        covered_start=covered_start, covered_end=started, note="اكتمل الاستيراد المتاح")
    result.update({"status": "done", "imported": imported, "batches": batches})
    return result


def backfill_batch(conn: sqlite3.Connection, *, sources: int = 4,
                   batch_items: int = BATCH_ITEMS) -> dict:
    """يشغّل دفعة استيراد تاريخي لعدد من المصادر غير المكتملة (تناوب عادل)."""
    rows = conn.execute(
        """SELECT * FROM source_catalog
           WHERE enabled = 1 AND (feed_url IS NOT NULL OR url IS NOT NULL)
           ORDER BY COALESCE((SELECT updated_at FROM archive_progress ap
                              WHERE ap.source_key = source_catalog.key), '0') ASC
           LIMIT ?""", (int(sources),)).fetchall()
    total = {"sources": 0, "fetched": 0, "imported": 0, "blocked": 0, "done": 0}
    for src in rows:
        res = backfill_source(conn, dict(src), batch_items=batch_items)
        total["sources"] += 1
        total["fetched"] += res["fetched"]
        total["imported"] += res["imported"]
        if res["status"] == "blocked":
            total["blocked"] += 1
        elif res["status"] == "done":
            total["done"] += 1
    return total


def archive_report(conn: sqlite3.Connection) -> dict:
    """ملخّص حالة الأرشيف: مُعالج/جزئي/متعذّر + النطاقات المُغطّاة."""
    rows = db.archive_progress(conn)
    by_status: dict[str, int] = {}
    for r in rows:
        by_status[r["status"]] = by_status.get(r["status"], 0) + 1
    return {
        "sources": len(rows),
        "by_status": by_status,
        "items_found": sum(r["items_found"] or 0 for r in rows),
        "items_imported": sum(r["items_imported"] or 0 for r in rows),
        "progress": rows,
    }
