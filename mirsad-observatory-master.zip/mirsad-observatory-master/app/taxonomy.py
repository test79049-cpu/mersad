"""تصنيف الانتهاكات: الفئات، مستويات الخطورة، والحالات.

هذا الملف هو المصدر الوحيد للحقيقة بشأن التصنيف، وتستخدمه قاعدة البيانات
وواجهات العرض وواجهة البرمجة (API) معاً.
"""

# مستويات الخطورة مرتّبة من الأخفّ إلى الأشدّ
SEVERITIES = [
    {"key": "low", "label": "منخفض", "label_en": "Low", "weight": 1, "color": "#3f8f6b"},
    {"key": "medium", "label": "متوسط", "label_en": "Medium", "weight": 2, "color": "#c98a2b"},
    {"key": "high", "label": "مرتفع", "label_en": "High", "weight": 3, "color": "#d4622a"},
    {"key": "critical", "label": "حرج", "label_en": "Critical", "weight": 4, "color": "#a12b2b"},
]
SEVERITY_BY_KEY = {s["key"]: s for s in SEVERITIES}

# حالات المتابعة للبلاغ
STATUSES = [
    {"key": "new", "label": "جديد", "label_en": "New", "color": "#6b7280"},
    {"key": "under_review", "label": "قيد التحقق", "label_en": "Under review", "color": "#c98a2b"},
    {"key": "verified", "label": "موثّق", "label_en": "Verified", "color": "#2f6f8f"},
    {"key": "action_taken", "label": "تم اتخاذ إجراء", "label_en": "Action taken", "color": "#3f8f6b"},
    {"key": "closed", "label": "مغلق", "label_en": "Closed", "color": "#9ca3af"},
]
STATUS_BY_KEY = {s["key"]: s for s in STATUSES}

# فئات الانتهاكات. بعض المجالات حاويات (لها `parent` = None) وبعضها مجالات فرعية
# (`parent` = مفتاح الحاوية)، ويُعرض التسلسل الهرمي في الصفحة الرئيسية والتذييل.
CATEGORIES = [
    {
        "key": "human_rights",
        "name": "حقوق الإنسان",
        "name_en": "Human rights",
        "short": "إنسان",
        "short_en": "Human",
        "icon": "shield",
        "color": "#b23a48",
        "accent": "#e8c1c5",
        "parent": None,
        "description": "الاعتقال التعسفي، التعذيب، تقييد حرية التعبير والتجمّع، "
        "انتهاكات الحق في الحياة والمحاكمة العادلة.",
        "description_en": "Arbitrary detention, torture, restrictions on freedom of "
        "expression and assembly, violations of the right to life and fair trial.",
    },
    {
        "key": "animal_rights",
        "name": "حقوق الحيوان",
        "name_en": "Animal rights",
        "short": "حيوان",
        "short_en": "Animal",
        "icon": "paw",
        "color": "#3f8f6b",
        "accent": "#c2e0d1",
        "parent": None,
        "description": "القسوة في المزارع والمسالخ، سوء معاملة الحيوانات الأليفة، "
        "الاستغلال في الترفيه والتجارب، وتهريب الحياة الفطرية.",
        "description_en": "Cruelty on farms and in slaughterhouses, mistreatment of pets, "
        "exploitation in entertainment and experiments, and wildlife trafficking.",
    },
    {
        "key": "environment",
        "name": "البيئة والعدالة المناخية",
        "name_en": "Environment & climate justice",
        "short": "بيئة",
        "short_en": "Environment",
        "icon": "leaf",
        "color": "#2f7d5a",
        "accent": "#bfe3ce",
        "parent": None,
        "description": "التلوّث الصناعي، إزالة الغابات، الإفراط في استهلاك المياه، "
        "انبعاثات الكربون، والنفايات السامة.",
        "description_en": "Industrial pollution, deforestation, excessive water consumption, "
        "carbon emissions, and toxic waste.",
    },
    {
        "key": "ai_ethics",
        "name": "أخلاقيات الذكاء الاصطناعي والحقوق الرقمية",
        "name_en": "AI ethics & digital rights",
        "short": "ذكاء اصطناعي",
        "short_en": "AI",
        "icon": "cpu",
        "color": "#4b4fa8",
        "accent": "#c9cbf0",
        "parent": None,
        "description": "التحيّز الخوارزمي، المراقبة الجماعية، التلاعب بالمعلومات، "
        "استغلال بيانات الأفراد، والأنظمة ذاتية القرار غير الخاضعة للمساءلة.",
        "description_en": "Algorithmic bias, mass surveillance, information manipulation, "
        "exploitation of personal data, and unaccountable autonomous decision systems.",
    },
    {
        "key": "labor_rights",
        "name": "حقوق العمال",
        "name_en": "Labour rights",
        "short": "عمل",
        "short_en": "Labour",
        "icon": "hammer",
        "color": "#b06a2c",
        "accent": "#eccfa9",
        "parent": None,
        "description": "الأجور المنخفضة والعمل القسري، بيئات العمل غير الآمنة، "
        "التمييز في التوظيف، ومنع التنظيم النقابي.",
        "description_en": "Low wages and forced labour, unsafe working environments, "
        "employment discrimination, and prevention of union organising.",
    },
    {
        "key": "minorities",
        "name": "حقوق الأقليات والشعوب الأصلية",
        "name_en": "Minorities & indigenous rights",
        "short": "أقليات",
        "short_en": "Minorities",
        "icon": "people",
        "color": "#8a5aa8",
        "accent": "#dcc9ec",
        "parent": None,
        "description": "التمييز العرقي والعرقي-ديني، استهداف المجموعات الإثنية "
        "واللغوية، التهجير القسري، وحرمان الأقليات من الخدمات.",
        "description_en": "Racial and ethno-religious discrimination, targeting of ethnic and "
        "linguistic groups, forced displacement, and denial of services to minorities.",
    },
    {
        "key": "beliefs",
        "name": "حرية الفكر والمعتقد",
        "name_en": "Freedom of thought & belief",
        "short": "معتقد",
        "short_en": "Belief",
        "icon": "thought",
        "color": "#2f6f8f",
        "accent": "#bcd8e5",
        "parent": None,
        "description": "اضطهاد بسبب الدين أو المعتقد، تقييد حرية الرأي والفكر، "
        "إلزام المعتقدات، والتضييق على الملحدين واللادينيين.",
        "description_en": "Persecution for religion or belief, restrictions on freedom of "
        "opinion and thought, forced beliefs, and pressure on atheists and non-believers.",
    },
    {
        "key": "women_children",
        "name": "حقوق المرأة والطفل",
        "name_en": "Women & children's rights",
        "short": "امرأة وطفل",
        "short_en": "Women & children",
        "icon": "family",
        "color": "#a8477f",
        "accent": "#efc9e2",
        "parent": None,
        "description": "العنف الأسري والزواج القسري، العنف الجنسي، عمالة الأطفال، "
        "حرمان الفتيات من التعليم، وانتهاكات حقوق الطفل.",
        "description_en": "Domestic violence and forced marriage, sexual violence, child "
        "labour, denial of education to girls, and violations of children's rights.",
    },
    {
        "key": "refugees_migrants",
        "name": "حقوق اللاجئين والمهاجرين",
        "name_en": "Refugees & migrants' rights",
        "short": "لاجئون",
        "short_en": "Refugees",
        "icon": "route",
        "color": "#c07a2b",
        "accent": "#f0dcbb",
        "parent": None,
        "description": "الإعادة القسرية، احتجاز المهاجرين، الوفيات في البحر، "
        "الترحيل الجماعي، وحرمان النازحين من الحماية.",
        "description_en": "Forced return, detention of migrants, deaths at sea, mass "
        "deportation, and denial of protection to displaced people.",
    },
    {
        "key": "expression",
        "name": "حرية التعبير",
        "name_en": "Freedom of expression",
        "short": "تعبير",
        "short_en": "Expression",
        "icon": "megaphone",
        "color": "#2f7f8f",
        "accent": "#c2e2e8",
        "parent": None,
        "description": "قمع الصحافة والإعلام، حجب المواقع، محاكمة الصحفيين، "
        "تقييد حرية التجمّع السلمي والحق في الاحتجاج.",
        "description_en": "Suppression of the press and media, website blocking, prosecution "
        "of journalists, and restrictions on peaceful assembly and protest.",
    },
    {
        "key": "transitional_justice",
        "name": "العدالة الانتقالية",
        "name_en": "Transitional justice",
        "short": "انتقالية",
        "short_en": "Transitional",
        "icon": "scale",
        "color": "#6b5aa8",
        "accent": "#d6cfee",
        "parent": None,
        "description": "الإفلات من العقاب، حقوق ضحايا النزاعات، لجان الحقيقة، "
        "التعويضات وجبر الضرر، والمصالحة المجتمعية.",
        "description_en": "Impunity, the rights of conflict victims, truth commissions, "
        "reparations and redress, and community reconciliation.",
    },
    {
        "key": "economic_social",
        "name": "الحقوق الاقتصادية والاجتماعية",
        "name_en": "Economic & social rights",
        "short": "اقتصادية",
        "short_en": "Economic",
        "icon": "coin",
        "color": "#8f7a2f",
        "accent": "#e8dfbb",
        "parent": None,
        "description": "الحق في العمل والسكن اللائق، الحماية الاجتماعية، "
        "التمييز الاقتصادي، وحرمان الفئات المهمّشة من الخدمات.",
        "description_en": "The right to work and adequate housing, social protection, "
        "economic discrimination, and denial of services to marginalised groups.",
    },
    {
        "key": "health",
        "name": "الحق في الصحة",
        "name_en": "Health",
        "short": "صحة",
        "short_en": "Health",
        "icon": "medical",
        "color": "#b23a5c",
        "accent": "#ecc4d0",
        "parent": None,
        "description": "الحق في الرعاية الصحية، الأمن الصحي، حرمان الفئات الهشّة "
        "من العلاج، وانتهاكات الصحة العامة.",
        "description_en": "The right to healthcare, health security, denial of treatment to "
        "vulnerable groups, and violations of public health.",
    },
    {
        "key": "education_culture",
        "name": "التعليم والثقافة",
        "name_en": "Education & culture",
        "short": "تعليم",
        "short_en": "Education",
        "icon": "graduation",
        "color": "#3f7fa8",
        "accent": "#c6dcec",
        "parent": None,
        "description": "الحق في التعليم، محو الأمية، الحق في الهوية الثقافية، "
        "حماية التراث، والتضييق على اللغة والثقافة.",
        "description_en": "The right to education, literacy, the right to cultural identity, "
        "heritage protection, and pressure on language and culture.",
    },
    {
        "key": "poverty_food",
        "name": "الفقر والأمن الغذائي",
        "name_en": "Poverty & food security",
        "short": "فقر",
        "short_en": "Poverty",
        "icon": "bread",
        "color": "#a8873f",
        "accent": "#eadfbf",
        "parent": None,
        "description": "الحق في الغذاء والماء والسكن، مكافحة الفقر، وانعدام الأمن "
        "الغذائي والمجاعات.",
        "description_en": "The right to food, water and housing, poverty reduction, and "
        "food insecurity and famine.",
    },
    {
        "key": "criminal_justice",
        "name": "العدالة الجنائية وسيادة القانون",
        "name_en": "Criminal justice & rule of law",
        "short": "جنائية",
        "short_en": "Criminal justice",
        "icon": "gavel",
        "color": "#7a3b57",
        "accent": "#e0c6d2",
        "parent": None,
        "description": "المحاكمة العادلة، مناهضة التعذيب والاختفاء القسري، إلغاء عقوبة "
        "الإعدام، واستقلال القضاء.",
        "description_en": "Fair trial, the fight against torture and enforced disappearance, "
        "abolition of the death penalty, and judicial independence.",
    },
    {
        "key": "prisoners_rights",
        "name": "حقوق المحتجزين",
        "name_en": "Prisoners' rights",
        "short": "محتجزون",
        "short_en": "Prisoners",
        "icon": "lock",
        "color": "#5c5c7a",
        "accent": "#cfcfe0",
        "parent": "criminal_justice",
        "description": "ظروف احتجاز كريمة، الرعاية الصحية في السجون، إعادة التأهيل، "
        "ومناهضة المعاملة القاسية.",
        "description_en": "Humane detention conditions, healthcare in prisons, "
        "rehabilitation, and the fight against cruel treatment.",
    },
    {
        "key": "disability_rights",
        "name": "حقوق الأشخاص ذوي الإعاقة",
        "name_en": "Disability rights",
        "short": "إعاقة",
        "short_en": "Disability",
        "icon": "accessible",
        "color": "#2f8f7f",
        "accent": "#bfe6df",
        "parent": None,
        "description": "الإدماج وإمكانية الوصول، التمكين والعمل، مناهضة التمييز، "
        "وتكافؤ الفرص للأشخاص ذوي الإعاقة.",
        "description_en": "Inclusion and accessibility, empowerment and employment, "
        "anti-discrimination, and equal opportunity for persons with disabilities.",
    },
    {
        "key": "peace_security",
        "name": "السلام والأمن الإنساني",
        "name_en": "Peace & human security",
        "short": "سلام",
        "short_en": "Peace",
        "icon": "dove",
        "color": "#4f7fa8",
        "accent": "#c9dcec",
        "parent": None,
        "description": "نزع السلاح ومناهضة الحروب، حماية المدنيين، أسلحة الدمار الشامل، "
        "وانتهاكات القانون الدولي الإنساني.",
        "description_en": "Disarmament and anti-war efforts, protection of civilians, weapons "
        "of mass destruction, and violations of international humanitarian law.",
    },
    {
        "key": "elderly_rights",
        "name": "حقوق كبار السن",
        "name_en": "Rights of the elderly",
        "short": "كبار السن",
        "short_en": "Elderly",
        "icon": "elderly",
        "color": "#8f6a4f",
        "accent": "#e6d3c4",
        "parent": "inclusivity",
        "description": "الحماية الاجتماعية لكبار السن، الرعاية الصحية، ومناهضة "
        "التمييز العمري والإهمال.",
        "description_en": "Social protection for older people, healthcare, and the fight "
        "against age discrimination and neglect.",
    },
    {
        "key": "inclusivity",
        "name": "الحقوق الفئوية والتنوّع",
        "name_en": "Inclusivity & diversity",
        "short": "فئوية",
        "short_en": "Inclusivity",
        "icon": "handshake",
        "color": "#8a5aa8",
        "accent": "#dcc9ec",
        "parent": None,
        "description": "حقوق المجموعات الفئوية والتنوّع، مناهضة التمييز المتعدّد، "
        "والإدماج الاجتماعي للفئات المهمّشة.",
        "description_en": "The rights of identity groups and diversity, the fight against "
        "intersecting discrimination, and social inclusion of marginalised groups.",
    },
]
CATEGORY_BY_KEY = {c["key"]: c for c in CATEGORIES}
# المجالات الحاوية (بلا أب) والمجالات الفرعية، مشتقّة من الحقل `parent`.
PARENT_CATEGORIES = [c for c in CATEGORIES if not c.get("parent")]
CHILD_CATEGORIES = [c for c in CATEGORIES if c.get("parent")]
CATEGORY_KEYS = tuple(c["key"] for c in CATEGORIES)


# أنواع الكيانات (الجهات الفاعلة) التي يمكن ربطها بالبلاغات.
ENTITY_KINDS = [
    {"key": "person", "label": "أفراد", "label_en": "Individuals", "singular": "فرد",
     "singular_en": "Individual", "icon": "user", "color": "#8a5a44"},
    {"key": "company", "label": "شركات", "label_en": "Companies", "singular": "شركة",
     "singular_en": "Company", "icon": "building", "color": "#a1562b"},
    {"key": "organization", "label": "منظّمات", "label_en": "Organisations", "singular": "منظّمة",
     "singular_en": "Organisation", "icon": "network", "color": "#2f6f8f"},
    {"key": "government", "label": "جهات حكومية", "label_en": "Government bodies",
     "singular": "جهة حكومية", "singular_en": "Government body", "icon": "shield", "color": "#7a3b57"},
    {"key": "country", "label": "دول", "label_en": "Countries", "singular": "دولة",
     "singular_en": "Country", "icon": "globe", "color": "#3f8f6b"},
    {"key": "other", "label": "أخرى", "label_en": "Other", "singular": "كيان",
     "singular_en": "Entity", "icon": "dot", "color": "#6b7280"},
]
ENTITY_KIND_BY_KEY = {k["key"]: k for k in ENTITY_KINDS}


# أدوار أعضاء المنصّة الاجتماعية (من الأوسع صلاحية إلى الأضيق).
MEMBER_ROLES = [
    {"key": "admin", "label": "مدير", "label_en": "Admin", "weight": 6,
     "color": "#a12b2b", "icon": "shield",
     "description": "صلاحيات كاملة على الإدارة والإشراف والإعدادات."},
    {"key": "moderator", "label": "مشرف", "label_en": "Moderator", "weight": 5,
     "color": "#c98a2b", "icon": "sliders",
     "description": "يراجع المحتوى والإبلاغات ويتّخذ إجراءات إشرافية."},
    {"key": "verifier", "label": "مُحقّق حقائق", "label_en": "Verifier", "weight": 4,
     "color": "#2f6f8f", "icon": "check",
     "description": "يتحقّق من البلاغات والمصادر ويمنح وسم التوثيق."},
    {"key": "activist", "label": "ناشط", "label_en": "Activist", "weight": 3,
     "color": "#3f8f6b", "icon": "people",
     "description": "ينشر ويشارك في المجموعات والقضايا."},
    {"key": "member", "label": "عضو", "label_en": "Member", "weight": 2,
     "color": "#6b7280", "icon": "user",
     "description": "حساب أساسي للتفاعل والمتابعة."},
    {"key": "guest", "label": "زائر", "label_en": "Guest", "weight": 1,
     "color": "#9ca3af", "icon": "globe",
     "description": "اطّلاع محدود بلا صلاحيات نشر."},
]
MEMBER_ROLE_BY_KEY = {r["key"]: r for r in MEMBER_ROLES}

# حالات العضوية
MEMBER_STATUSES = [
    {"key": "active", "label": "نشط", "label_en": "Active", "color": "#3f8f6b"},
    {"key": "pending", "label": "بانتظار الموافقة", "label_en": "Pending", "color": "#c98a2b"},
    {"key": "suspended", "label": "موقوف", "label_en": "Suspended", "color": "#a12b2b"},
    {"key": "left", "label": "غادر", "label_en": "Left", "color": "#9ca3af"},
]
MEMBER_STATUS_BY_KEY = {s["key"]: s for s in MEMBER_STATUSES}


# أنواع منشورات المجتمع (نشر الحقائق والتعاون)
POST_KINDS = [
    {"key": "update", "label": "تحديث", "label_en": "Update", "icon": "edit", "color": "#2f6f8f"},
    {"key": "news", "label": "خبر", "label_en": "News", "icon": "book", "color": "#b23a48"},
    {"key": "analysis", "label": "تحليل", "label_en": "Analysis", "icon": "thought", "color": "#6b5b95"},
    {"key": "testimony", "label": "شهادة", "label_en": "Testimony", "icon": "people", "color": "#c98a2b"},
    {"key": "call", "label": "طلب مساعدة", "label_en": "Call for help", "icon": "alert", "color": "#d4622a"},
    {"key": "campaign", "label": "حملة", "label_en": "Campaign", "icon": "flag", "color": "#3f8f6b"},
    {"key": "correction", "label": "تصحيح", "label_en": "Correction", "icon": "check", "color": "#3f8f6b"},
]
POST_KIND_BY_KEY = {k["key"]: k for k in POST_KINDS}

# مستويات ظهور المنشور
POST_VISIBILITIES = [
    {"key": "public", "label": "عام", "label_en": "Public"},
    {"key": "members", "label": "للأعضاء فقط", "label_en": "Members only"},
]
POST_VISIBILITY_BY_KEY = {v["key"]: v for v in POST_VISIBILITIES}

POST_STATUSES = [
    {"key": "published", "label": "منشور", "label_en": "Published", "color": "#3f8f6b"},
    {"key": "draft", "label": "مسودّة", "label_en": "Draft", "color": "#c98a2b"},
    {"key": "hidden", "label": "مخفي", "label_en": "Hidden", "color": "#9ca3af"},
]
POST_STATUS_BY_KEY = {s["key"]: s for s in POST_STATUSES}

# أنواع المجموعات (تعاون الناشطين)
GROUP_KINDS = [
    {"key": "working", "label": "فريق عمل", "label_en": "Working group", "icon": "people", "color": "#2f6f8f"},
    {"key": "committee", "label": "لجنة", "label_en": "Committee", "icon": "shield", "color": "#6b5b95"},
    {"key": "campaign", "label": "حملة", "label_en": "Campaign", "icon": "flag", "color": "#3f8f6b"},
    {"key": "verification", "label": "لجنة تحقّق", "label_en": "Verification", "icon": "check", "color": "#2f6f8f"},
    {"key": "support", "label": "دعم", "label_en": "Support", "icon": "heart", "color": "#c98a2b"},
    {"key": "translation", "label": "ترجمة", "label_en": "Translation", "icon": "globe", "color": "#6b7280"},
    {"key": "regional", "label": "إقليمي", "label_en": "Regional", "icon": "location", "color": "#b23a48"},
    {"key": "open", "label": "مجتمع مفتوح", "label_en": "Open community", "icon": "globe", "color": "#3f8f6b"},
]
GROUP_KIND_BY_KEY = {k["key"]: k for k in GROUP_KINDS}

# مستويات خصوصية المجموعة
GROUP_VISIBILITIES = [
    {"key": "public", "label": "عام", "label_en": "Public"},
    {"key": "private", "label": "خاص", "label_en": "Private"},
    {"key": "secret", "label": "سرّي", "label_en": "Secret"},
]
GROUP_VISIBILITY_BY_KEY = {v["key"]: v for v in GROUP_VISIBILITIES}

# أدوار العضوية داخل المجموعة
GROUP_ROLES = [
    {"key": "owner", "label": "مالك", "label_en": "Owner", "weight": 3, "color": "#a12b2b"},
    {"key": "moderator", "label": "مشرف", "label_en": "Moderator", "weight": 2, "color": "#c98a2b"},
    {"key": "member", "label": "عضو", "label_en": "Member", "weight": 1, "color": "#6b7280"},
]
GROUP_ROLE_BY_KEY = {r["key"]: r for r in GROUP_ROLES}

# حالات عضوية المجموعة
GROUP_MEMBER_STATUSES = [
    {"key": "active", "label": "نشط", "label_en": "Active", "color": "#3f8f6b"},
    {"key": "pending", "label": "بانتظار الموافقة", "label_en": "Pending", "color": "#c98a2b"},
    {"key": "banned", "label": "محظور", "label_en": "Banned", "color": "#a12b2b"},
]
GROUP_MEMBER_STATUS_BY_KEY = {s["key"]: s for s in GROUP_MEMBER_STATUSES}

# --- التحقّق من الحقائق والتوثيق (الدفعة 6) ---
CLAIM_STATUSES = [
    {"key": "unverified", "label": "غير موثّق", "label_en": "Unverified", "color": "#9ca3af"},
    {"key": "pending", "label": "قيد المراجعة", "label_en": "Under review", "color": "#c98a2b"},
    {"key": "verified", "label": "موثّق", "label_en": "Verified", "color": "#3f8f6b"},
    {"key": "disputed", "label": "متنازع عليه", "label_en": "Disputed", "color": "#b23a48"},
    {"key": "debunked", "label": "مُكذَّب", "label_en": "Debunked", "color": "#a12b2b"},
    {"key": "unverifiable", "label": "غير قابل للتحقّق", "label_en": "Unverifiable", "color": "#6b7280"},
]
CLAIM_STATUS_BY_KEY = {s["key"]: s for s in CLAIM_STATUSES}

CLAIM_SOURCE_KINDS = [
    {"key": "primary", "label": "مصدر أولي", "label_en": "Primary", "weight": 1.0},
    {"key": "secondary", "label": "مصدر ثانوي", "label_en": "Secondary", "weight": 0.7},
    {"key": "testimony", "label": "شهادة", "label_en": "Testimony", "weight": 0.5},
    {"key": "expert", "label": "خبير", "label_en": "Expert", "weight": 0.8},
]
CLAIM_SOURCE_KIND_BY_KEY = {k["key"]: k for k in CLAIM_SOURCE_KINDS}

# تقييم المصدر بأسلوب Admiralty المبسّط (5 = الأقوى)
SOURCE_RELIABILITY = [
    {"key": "5", "label": "موثوق تمامًا", "label_en": "Completely reliable", "score": 5},
    {"key": "4", "label": "موثوق غالبًا", "label_en": "Usually reliable", "score": 4},
    {"key": "3", "label": "موثوق أحيانًا", "label_en": "Fairly reliable", "score": 3},
    {"key": "2", "label": "غير موثوق غالبًا", "label_en": "Not usually reliable", "score": 2},
    {"key": "1", "label": "غير موثوق", "label_en": "Unreliable", "score": 1},
]
SOURCE_RELIABILITY_BY_KEY = {r["key"]: r for r in SOURCE_RELIABILITY}

REVIEW_DECISIONS = [
    {"key": "approve", "label": "تأكيد التوثيق", "label_en": "Confirm", "icon": "check"},
    {"key": "dispute", "label": "طلب مراجعة", "label_en": "Dispute", "icon": "alert"},
    {"key": "debunk", "label": "تكذيب", "label_en": "Debunk", "icon": "alert"},
    {"key": "request_evidence", "label": "طلب أدلّة", "label_en": "Request evidence", "icon": "search"},
    {"key": "mark_unverifiable", "label": "غير قابل للتحقّق", "label_en": "Mark unverifiable", "icon": "eye"},
]
REVIEW_DECISION_BY_KEY = {d["key"]: d for d in REVIEW_DECISIONS}

# ===========================================================================
# منظومة الرصد والتحقق المستمر (Monitoring & Verification).
# ===========================================================================

# حالات التحقق الموحّدة للواقعة (القسم 8 من المواصفات).
VERIFICATION_STATES = [
    {"key": "new", "label": "جديد", "label_en": "New", "color": "#6b7280",
     "desc": "تم اكتشاف المحتوى ولم تكتمل معالجته.", "order": 0},
    {"key": "checking", "label": "قيد التحقق", "label_en": "Under verification",
     "color": "#c98a2b", "desc": "يتطلب جمع أدلة أو مصادر إضافية.", "order": 1},
    {"key": "multi_source", "label": "متعدد المصادر", "label_en": "Multi-source",
     "color": "#2f6f8f",
     "desc": "وردت معلومات مؤيدة من أكثر من مصدر، ولم يُحسم استقلالها أو كفايتها.",
     "order": 2},
    {"key": "verified", "label": "موثّق من مصادر مستقلة",
     "label_en": "Verified by independent sources", "color": "#3f8f6b",
     "desc": "اجتازت الأدلة المتاحة معايير التحقق المحددة.", "order": 3},
    {"key": "disputed", "label": "متعارض", "label_en": "Disputed", "color": "#b23a48",
     "desc": "توجد معلومات جوهرية متناقضة.", "order": 4},
    {"key": "corrected", "label": "مصحح", "label_en": "Corrected", "color": "#8a6d3b",
     "desc": "جرى تصحيح بعض المعلومات مع الاحتفاظ بالتاريخ السابق.", "order": 5},
    {"key": "withdrawn", "label": "مسحوب من مصدره", "label_en": "Withdrawn by source",
     "color": "#6b7280",
     "desc": "سحب المصدر الأصلي محتواه أو تراجع عنه، دون افتراض بطلان الواقعة.",
     "order": 6},
    {"key": "unresolved", "label": "غير محسوم", "label_en": "Unresolved",
     "color": "#9ca3af", "desc": "لم تتوفر أدلة كافية للوصول إلى نتيجة.", "order": 7},
]
VERIFICATION_STATE_BY_KEY = {s["key"]: s for s in VERIFICATION_STATES}

# معايير تقييم الثقة (القسم 8): قابلة للضبط وأوزانها صريحة.
TRUST_CRITERIA = [
    {"key": "source_reliability", "label": "موثوقية المصدر وسجله السابق",
     "label_en": "Source reliability & track record", "weight": 0.20},
    {"key": "independence", "label": "استقلال المصدر عن المصادر الأخرى",
     "label_en": "Independence from other sources", "weight": 0.20},
    {"key": "direct_witness", "label": "شاهد مباشر أو ناقل عن جهة أخرى",
     "label_en": "Direct witness vs. relayed", "weight": 0.10},
    {"key": "original_documents", "label": "وثائق أو أدلة أصلية قابلة للفحص",
     "label_en": "Original documents/evidence", "weight": 0.15},
    {"key": "detail_agreement", "label": "توافق التفاصيل الجوهرية بين المصادر",
     "label_en": "Agreement of core details", "weight": 0.15},
    {"key": "chronology", "label": "اتساق التسلسل الزمني والمكاني",
     "label_en": "Chronological/spatial consistency", "weight": 0.10},
    {"key": "counter_info", "label": "وجود نفي أو تصحيح أو معلومات مضادة",
     "label_en": "Denials/corrections/counter-info", "weight": 0.05},
    {"key": "recency", "label": "حداثة المعلومات واتصالها بالواقعة",
     "label_en": "Recency & relevance", "weight": 0.05},
]
TRUST_CRITERION_BY_KEY = {c["key"]: c for c in TRUST_CRITERIA}

# أنواع المستندات في خط المعالجة (القسم 4): تصنيف متعدّد الوسوم مع أساسي للنشر.
DOCUMENT_TYPES = [
    {"key": "violation", "label": "انتهاك", "label_en": "Violation", "color": "#a12b2b"},
    {"key": "claim", "label": "بلاغ", "label_en": "Claim/report", "color": "#c98a2b"},
    {"key": "report", "label": "تقرير", "label_en": "Report", "color": "#2f6f8f"},
    {"key": "news", "label": "خبر/تحديث عاجل", "label_en": "News/urgent update",
     "color": "#d4622a"},
    {"key": "correction", "label": "تصحيح/نفي/توضيح",
     "label_en": "Correction/retraction/clarification", "color": "#8a6d3b"},
]
DOCUMENT_TYPE_BY_KEY = {t["key"]: t for t in DOCUMENT_TYPES}

# مراحل خط المعالجة الموحّد (القسم 3).
PIPELINE_STAGES = [
    {"key": "ingested", "label": "الجمع", "label_en": "Collect", "order": 1},
    {"key": "normalized", "label": "التطبيع", "label_en": "Normalize", "order": 2},
    {"key": "extracted", "label": "الاستخراج", "label_en": "Extract", "order": 3},
    {"key": "classified", "label": "التصنيف", "label_en": "Classify", "order": 4},
    {"key": "deduped", "label": "كشف التكرار وربط الوقائع", "label_en": "Dedup & link",
     "order": 5},
    {"key": "verified", "label": "التحقق", "label_en": "Verify", "order": 6},
    {"key": "actioned", "label": "الإجراء", "label_en": "Action", "order": 7},
    {"key": "audited", "label": "التدقيق", "label_en": "Audit", "order": 8},
]
PIPELINE_STAGE_BY_KEY = {s["key"]: s for s in PIPELINE_STAGES}

# أنواع التنبيهات (القسم 11): أولوية التنبيه منفصلة عن حالة التحقق.
ALERT_KINDS = [
    {"key": "possible_violation", "label": "انتهاك محتمل عالي الأولوية",
     "label_en": "High-priority possible violation", "severity": "critical"},
    {"key": "new_claim", "label": "بلاغ جديد يحتاج معالجة",
     "label_en": "New claim awaiting processing", "severity": "warning"},
    {"key": "independent_source", "label": "مصدر مستقل يؤيد واقعة",
     "label_en": "Independent source supports a record", "severity": "info"},
    {"key": "conflict", "label": "معلومات متعارضة",
     "label_en": "Conflicting information", "severity": "warning"},
    {"key": "correction", "label": "تصحيح أو تراجع جوهري",
     "label_en": "Major correction or retraction", "severity": "warning"},
    {"key": "source_down", "label": "تعطل مصدر أو ارتفاع الأخطاء",
     "label_en": "Source down or error spike", "severity": "warning"},
    {"key": "backlog", "label": "تراكم المهام أو تجاوز وقت المعالجة",
     "label_en": "Task backlog / processing timeout", "severity": "warning"},
]
ALERT_KIND_BY_KEY = {a["key"]: a for a in ALERT_KINDS}

# أنواع المهام في طابور المهام (القسم 13).
TASK_KINDS = [
    {"key": "collect", "label": "جمع", "label_en": "Collect"},
    {"key": "process", "label": "معالجة", "label_en": "Process"},
    {"key": "verify", "label": "تحقق", "label_en": "Verify"},
    {"key": "reconcile", "label": "مصالحة", "label_en": "Reconcile"},
    {"key": "backfill", "label": "استيراد تاريخي", "label_en": "Backfill"},
]
TASK_KIND_BY_KEY = {k["key"]: k for k in TASK_KINDS}

# حالات تقدّم الاستيراد التاريخي (القسم 2.3).
ARCHIVE_STATUSES = [
    {"key": "pending", "label": "بالانتظار", "label_en": "Pending", "color": "#6b7280"},
    {"key": "running", "label": "جارٍ", "label_en": "Running", "color": "#c98a2b"},
    {"key": "done", "label": "مكتمل", "label_en": "Complete", "color": "#3f8f6b"},
    {"key": "partial", "label": "متاح جزئيًّا", "label_en": "Partial", "color": "#2f6f8f"},
    {"key": "blocked", "label": "تعذّر الوصول", "label_en": "Inaccessible", "color": "#a12b2b"},
]
ARCHIVE_STATUS_BY_KEY = {s["key"]: s for s in ARCHIVE_STATUSES}


def verification_state_label(key: str, lang: str = "ar") -> str:
    s = VERIFICATION_STATE_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def document_type_label(key: str, lang: str = "ar") -> str:
    t = DOCUMENT_TYPE_BY_KEY.get(key)
    if not t:
        return key
    return t.get("label_en" if lang == "en" else "label") or t["label"]


def alert_kind_label(key: str, lang: str = "ar") -> str:
    a = ALERT_KIND_BY_KEY.get(key)
    if not a:
        return key
    return a.get("label_en" if lang == "en" else "label") or a["label"]


def archive_status_label(key: str, lang: str = "ar") -> str:
    s = ARCHIVE_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


# --- الإشراف والحوكمة (الدفعة 7) ---
# إجراءات إشراف متدرّجة (تحذير → كتم → حظر)
MODERATION_ACTIONS = [
    {"key": "note", "label": "ملاحظة داخلية", "label_en": "Internal note", "severity": 1, "color": "#6b7280"},
    {"key": "warn", "label": "تحذير", "label_en": "Warning", "severity": 2, "color": "#c98a2b"},
    {"key": "hide_content", "label": "إخفاء المحتوى", "label_en": "Hide content", "severity": 3, "color": "#d4622a"},
    {"key": "mute", "label": "كتم مؤقّت", "label_en": "Temporary mute", "severity": 4, "color": "#b23a48"},
    {"key": "suspend", "label": "تعليق", "label_en": "Suspension", "severity": 5, "color": "#a12b2b"},
    {"key": "ban", "label": "حظر", "label_en": "Ban", "severity": 6, "color": "#7a1f1f"},
]
MODERATION_ACTION_BY_KEY = {a["key"]: a for a in MODERATION_ACTIONS}

# حالات طابور الإبلاغات
REPORT_STATES = [
    {"key": "open", "label": "مفتوح", "label_en": "Open", "color": "#c98a2b"},
    {"key": "reviewing", "label": "قيد المراجعة", "label_en": "Reviewing", "color": "#2f6f8f"},
    {"key": "resolved", "label": "معالَج", "label_en": "Resolved", "color": "#3f8f6b"},
    {"key": "dismissed", "label": "مرفوض", "label_en": "Dismissed", "color": "#9ca3af"},
]
REPORT_STATE_BY_KEY = {s["key"]: s for s in REPORT_STATES}

# حالات الاستئناف
APPEAL_STATUSES = [
    {"key": "pending", "label": "قيد النظر", "label_en": "Pending", "color": "#c98a2b"},
    {"key": "accepted", "label": "مقبول", "label_en": "Accepted", "color": "#3f8f6b"},
    {"key": "rejected", "label": "مرفوض", "label_en": "Rejected", "color": "#a12b2b"},
]
APPEAL_STATUS_BY_KEY = {s["key"]: s for s in APPEAL_STATUSES}

# أسباب الإبلاغ الشائعة
REPORT_REASONS = [
    {"key": "spam", "label": "إزعاج/تكرار", "label_en": "Spam"},
    {"key": "harassment", "label": "تحرّش/إساءة", "label_en": "Harassment"},
    {"key": "misinformation", "label": "معلومات مضلّلة", "label_en": "Misinformation"},
    {"key": "hate", "label": "خطاب كراهية", "label_en": "Hate speech"},
    {"key": "privacy", "label": "انتهاك خصوصية", "label_en": "Privacy violation"},
    {"key": "other", "label": "أخرى", "label_en": "Other"},
]
REPORT_REASON_BY_KEY = {r["key"]: r for r in REPORT_REASONS}


def moderation_action_label(key: str, lang: str = "ar") -> str:
    a = MODERATION_ACTION_BY_KEY.get(key)
    if not a:
        return key
    return a.get("label_en" if lang == "en" else "label") or a["label"]


def report_state_label(key: str, lang: str = "ar") -> str:
    s = REPORT_STATE_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def appeal_status_label(key: str, lang: str = "ar") -> str:
    s = APPEAL_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def report_reason_label(key: str, lang: str = "ar") -> str:
    r = REPORT_REASON_BY_KEY.get(key)
    if not r:
        return key
    return r.get("label_en" if lang == "en" else "label") or r["label"]


# --- السمعة والثقة (الدفعة 8) ---
# أبعاد السمعة (سياقية)
REPUTATION_DIMENSIONS = [
    {"key": "accuracy", "label": "الدقّة", "label_en": "Accuracy", "weight": 1.0},
    {"key": "cooperation", "label": "التعاون", "label_en": "Cooperation", "weight": 0.8},
    {"key": "reliability", "label": "الموثوقية", "label_en": "Reliability", "weight": 1.0},
]
REPUTATION_DIMENSION_BY_KEY = {d["key"]: d for d in REPUTATION_DIMENSIONS}

# مستويات الثقة (0–5) بصلاحيات متدرّجة
TRUST_LEVELS = [
    {"key": "0", "label": "مبتدئ", "label_en": "Newcomer", "color": "#9ca3af",
     "min": 0, "can": "read"},
    {"key": "1", "label": "مشارك", "label_en": "Contributor", "color": "#6b7280",
     "min": 20, "can": "comment"},
    {"key": "2", "label": "موثوق مبتدئ", "label_en": "Trusted I", "color": "#2f6f8f",
     "min": 40, "can": "post"},
    {"key": "3", "label": "موثوق", "label_en": "Trusted II", "color": "#3f8f6b",
     "min": 60, "can": "endorse"},
    {"key": "4", "label": "خبير", "label_en": "Expert", "color": "#c98a2b",
     "min": 80, "can": "verify"},
    {"key": "5", "label": "مرجع", "label_en": "Authority", "color": "#b23a48",
     "min": 95, "can": "moderate"},
]
TRUST_LEVEL_BY_KEY = {t["key"]: t for t in TRUST_LEVELS}

# شارات/اعترافات غير تنافسية
BADGES = [
    {"key": "verified_contributor", "label": "مساهم موثّق", "label_en": "Verified contributor", "icon": "check"},
    {"key": "mentor", "label": "مُرشد", "label_en": "Mentor", "icon": "user"},
    {"key": "trainee", "label": "متدرّب", "label_en": "Trainee", "icon": "book"},
    {"key": "fact_checker", "label": "مدقّق حقائق", "label_en": "Fact-checker", "icon": "search"},
    {"key": "community_builder", "label": "بانٍ للمجتمع", "label_en": "Community builder", "icon": "users"},
    {"key": "veteran", "label": "عضو مخضرم", "label_en": "Veteran", "icon": "clock"},
]
BADGE_BY_KEY = {b["key"]: b for b in BADGES}

# أنواع الضمان (vouching)
VOUCH_KINDS = [
    {"key": "peer", "label": "ضمان أقران", "label_en": "Peer vouching"},
    {"key": "org", "label": "شهادة منظّمة", "label_en": "Organization attestation"},
    {"key": "identity", "label": "تحقّق هوية", "label_en": "Identity check"},
]
VOUCH_KIND_BY_KEY = {k["key"]: k for k in VOUCH_KINDS}


def reputation_dimension_label(key: str, lang: str = "ar") -> str:
    d = REPUTATION_DIMENSION_BY_KEY.get(key)
    if not d:
        return key
    return d.get("label_en" if lang == "en" else "label") or d["label"]


def trust_level_label(key: str, lang: str = "ar") -> str:
    t = TRUST_LEVEL_BY_KEY.get(str(key))
    if not t:
        return str(key)
    return t.get("label_en" if lang == "en" else "label") or t["label"]


def badge_label(key: str, lang: str = "ar") -> str:
    b = BADGE_BY_KEY.get(key)
    if not b:
        return key
    return b.get("label_en" if lang == "en" else "label") or b["label"]


def vouch_kind_label(key: str, lang: str = "ar") -> str:
    k = VOUCH_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def trust_level_for_score(score: float) -> str:
    """يحدّد مستوى الثقة (0–5) من الدرجة المركّبة."""
    level = "0"
    for t in TRUST_LEVELS:
        if score >= t["min"]:
            level = t["key"]
    return level


# --- الإشعارات والتنبيهات (الدفعة 9) ---
# تصنيفات الإشعارات
NOTIFICATION_CATEGORIES = [
    {"key": "system", "label": "النظام", "label_en": "System", "icon": "alert", "color": "#6b7280"},
    {"key": "interaction", "label": "التفاعل", "label_en": "Interaction", "icon": "users", "color": "#2f6f8f"},
    {"key": "security", "label": "الأمن", "label_en": "Security", "icon": "lock", "color": "#b23a48"},
    {"key": "tasks", "label": "المهام", "label_en": "Tasks", "icon": "check", "color": "#3f8f6b"},
]
NOTIFICATION_CATEGORY_BY_KEY = {c["key"]: c for c in NOTIFICATION_CATEGORIES}

# أولويات الإشعارات
NOTIFICATION_PRIORITIES = [
    {"key": "normal", "label": "عادي", "label_en": "Normal", "rank": 1, "color": "#6b7280"},
    {"key": "important", "label": "مهم", "label_en": "Important", "rank": 2, "color": "#c98a2b"},
    {"key": "critical", "label": "حرج", "label_en": "Critical", "rank": 3, "color": "#b23a48"},
]
NOTIFICATION_PRIORITY_BY_KEY = {p["key"]: p for p in NOTIFICATION_PRIORITIES}

# قنوات الإشعارات (مع حالة التنفيذ: داخلي فعلي، والبقية تصدير/محاكاة)
NOTIFICATION_CHANNELS = [
    {"key": "inapp", "label": "داخل المنصّة", "label_en": "In-app", "live": True},
    {"key": "email", "label": "البريد", "label_en": "Email", "live": False},
    {"key": "push", "label": "التطبيق", "label_en": "Push", "live": False},
    {"key": "rss", "label": "RSS", "label_en": "RSS", "live": True},
    {"key": "webhook", "label": "Webhook", "label_en": "Webhook", "live": False},
    {"key": "sms", "label": "رسائل نصّية", "label_en": "SMS", "live": False},
]
NOTIFICATION_CHANNEL_BY_KEY = {c["key"]: c for c in NOTIFICATION_CHANNELS}

# أنواع الاشتراكات (متابعة مجالات/دول/أعضاء/ادّعاءات)
SUBSCRIPTION_KINDS = [
    {"key": "category", "label": "مجال", "label_en": "Category"},
    {"key": "country", "label": "دولة", "label_en": "Country"},
    {"key": "member", "label": "عضو", "label_en": "Member"},
    {"key": "claim", "label": "ادّعاء", "label_en": "Claim"},
    {"key": "group", "label": "مجموعة", "label_en": "Group"},
]
SUBSCRIPTION_KIND_BY_KEY = {k["key"]: k for k in SUBSCRIPTION_KINDS}


def notification_category_label(key: str, lang: str = "ar") -> str:
    c = NOTIFICATION_CATEGORY_BY_KEY.get(key)
    if not c:
        return key
    return c.get("label_en" if lang == "en" else "label") or c["label"]


def notification_priority_label(key: str, lang: str = "ar") -> str:
    p = NOTIFICATION_PRIORITY_BY_KEY.get(key)
    if not p:
        return key
    return p.get("label_en" if lang == "en" else "label") or p["label"]


def notification_channel_label(key: str, lang: str = "ar") -> str:
    c = NOTIFICATION_CHANNEL_BY_KEY.get(key)
    if not c:
        return key
    return c.get("label_en" if lang == "en" else "label") or c["label"]


def subscription_kind_label(key: str, lang: str = "ar") -> str:
    k = SUBSCRIPTION_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


# --- الحملات والمناصرة (الدفعة 11) ---
CAMPAIGN_STATUSES = [
    {"key": "draft", "label": "مسوّدة", "label_en": "Draft"},
    {"key": "active", "label": "نشطة", "label_en": "Active"},
    {"key": "paused", "label": "متوقّفة مؤقّتًا", "label_en": "Paused"},
    {"key": "won", "label": "تحقّق الهدف", "label_en": "Won"},
    {"key": "closed", "label": "مُغلقة", "label_en": "Closed"},
]
CAMPAIGN_STATUS_BY_KEY = {s["key"]: s for s in CAMPAIGN_STATUSES}

CAMPAIGN_ROLES = [
    {"key": "coordinator", "label": "منسّق", "label_en": "Coordinator"},
    {"key": "spokesperson", "label": "ناطق", "label_en": "Spokesperson"},
    {"key": "researcher", "label": "باحث", "label_en": "Researcher"},
    {"key": "legal", "label": "دعم قانوني", "label_en": "Legal"},
    {"key": "volunteer", "label": "متطوّع", "label_en": "Volunteer"},
]
CAMPAIGN_ROLE_BY_KEY = {r["key"]: r for r in CAMPAIGN_ROLES}

CAMPAIGN_TARGET_KINDS = [
    {"key": "official", "label": "مسؤول", "label_en": "Official"},
    {"key": "body", "label": "هيئة", "label_en": "Body"},
    {"key": "company", "label": "شركة", "label_en": "Company"},
    {"key": "media", "label": "جهة إعلامية", "label_en": "Media outlet"},
    {"key": "intl", "label": "منظّمة دولية", "label_en": "International body"},
]
CAMPAIGN_TARGET_KIND_BY_KEY = {k["key"]: k for k in CAMPAIGN_TARGET_KINDS}

CAMPAIGN_EVENT_KINDS = [
    {"key": "protest", "label": "وقفة", "label_en": "Protest"},
    {"key": "briefing", "label": "جلسة إحاطة", "label_en": "Briefing"},
    {"key": "meeting", "label": "اجتماع", "label_en": "Meeting"},
    {"key": "online", "label": "فعالية رقمية", "label_en": "Online event"},
    {"key": "hearing", "label": "استماع", "label_en": "Hearing"},
]
CAMPAIGN_EVENT_KIND_BY_KEY = {k["key"]: k for k in CAMPAIGN_EVENT_KINDS}

PLEDGE_STATES = [
    {"key": "pending", "label": "قيد المتابعة", "label_en": "Pending"},
    {"key": "kept", "label": "أُوفي به", "label_en": "Kept"},
    {"key": "broken", "label": "أُخلف", "label_en": "Broken"},
]
PLEDGE_STATE_BY_KEY = {s["key"]: s for s in PLEDGE_STATES}

WAVE_STATES = [
    {"key": "scheduled", "label": "مجدولة", "label_en": "Scheduled"},
    {"key": "sent", "label": "أُرسلت", "label_en": "Sent"},
    {"key": "measured", "label": "قِيست", "label_en": "Measured"},
]
WAVE_STATE_BY_KEY = {s["key"]: s for s in WAVE_STATES}

# ميثاق أخلاقيات المناصرة (1800)
ADVOCACY_CHARTER = [
    {"key": "accuracy", "label": "الدقّة والتوثيق", "label_en": "Accuracy and documentation"},
    {"key": "nonviolence", "label": "اللاعنف", "label_en": "Non-violence"},
    {"key": "consent", "label": "موافقة المشاركين", "label_en": "Participant consent"},
    {"key": "privacy", "label": "حماية هوية الموقّعين", "label_en": "Signer privacy"},
    {"key": "transparency", "label": "الشفافية المالية", "label_en": "Financial transparency"},
    {"key": "dignity", "label": "كرامة المتضرّرين", "label_en": "Survivor dignity"},
]


def campaign_status_label(key: str, lang: str = "ar") -> str:
    s = CAMPAIGN_STATUS_BY_KEY.get(key)
    return (s.get("label_en" if lang == "en" else "label") or s["label"]) if s else key


def campaign_role_label(key: str, lang: str = "ar") -> str:
    r = CAMPAIGN_ROLE_BY_KEY.get(key)
    return (r.get("label_en" if lang == "en" else "label") or r["label"]) if r else key


def campaign_target_kind_label(key: str, lang: str = "ar") -> str:
    k = CAMPAIGN_TARGET_KIND_BY_KEY.get(key)
    return (k.get("label_en" if lang == "en" else "label") or k["label"]) if k else key


def campaign_event_kind_label(key: str, lang: str = "ar") -> str:
    k = CAMPAIGN_EVENT_KIND_BY_KEY.get(key)
    return (k.get("label_en" if lang == "en" else "label") or k["label"]) if k else key


def pledge_state_label(key: str, lang: str = "ar") -> str:
    s = PLEDGE_STATE_BY_KEY.get(key)
    return (s.get("label_en" if lang == "en" else "label") or s["label"]) if s else key


def wave_state_label(key: str, lang: str = "ar") -> str:
    s = WAVE_STATE_BY_KEY.get(key)
    return (s.get("label_en" if lang == "en" else "label") or s["label"]) if s else key


# --- التكامل والأتمتة (الدفعة 12) ---
API_SCOPES = [
    {"key": "read", "label": "قراءة", "label_en": "Read"},
    {"key": "write", "label": "كتابة", "label_en": "Write"},
    {"key": "ingest", "label": "استيراد", "label_en": "Ingest"},
    {"key": "admin", "label": "إدارة", "label_en": "Admin"},
]
API_SCOPE_BY_KEY = {s["key"]: s for s in API_SCOPES}

API_VERSIONS = [
    {"key": "v1", "label": "v1 (مستقرّة)", "label_en": "v1 (stable)", "state": "stable"},
    {"key": "v2", "label": "v2 (تجريبية)", "label_en": "v2 (beta)", "state": "beta"},
    {"key": "v0", "label": "v0 (مهملة)", "label_en": "v0 (deprecated)", "state": "deprecated"},
]
API_VERSION_BY_KEY = {v["key"]: v for v in API_VERSIONS}

WEBHOOK_EVENTS = [
    {"key": "report.created", "label": "بلاغ جديد", "label_en": "Report created"},
    {"key": "claim.verified", "label": "تحقّق ادّعاء", "label_en": "Claim verified"},
    {"key": "campaign.signed", "label": "توقيع حملة", "label_en": "Campaign signed"},
    {"key": "moderation.action", "label": "إجراء إشراف", "label_en": "Moderation action"},
    {"key": "security.alert", "label": "تنبيه أمني", "label_en": "Security alert"},
]
WEBHOOK_EVENT_BY_KEY = {e["key"]: e for e in WEBHOOK_EVENTS}

CONNECTOR_KINDS = [
    {"key": "facts", "label": "منصّة تحقّق", "label_en": "Fact-check platform"},
    {"key": "archive", "label": "أرشيف ويب", "label_en": "Web archive"},
    {"key": "conflict", "label": "قاعدة بيانات نزاعات", "label_en": "Conflict database"},
    {"key": "satellite", "label": "أقمار صناعية", "label_en": "Satellite imagery"},
    {"key": "weather", "label": "طقس", "label_en": "Weather"},
    {"key": "translation", "label": "ترجمة", "label_en": "Translation"},
    {"key": "ocr", "label": "OCR", "label_en": "OCR"},
    {"key": "mediacheck", "label": "كشف تلاعب الوسائط", "label_en": "Media forensics"},
    {"key": "aicheck", "label": "كشف المحتوى المولّد", "label_en": "AI-content detection"},
]
CONNECTOR_KIND_BY_KEY = {k["key"]: k for k in CONNECTOR_KINDS}

RULE_TRIGGERS = [
    {"key": "report.created", "label": "عند إنشاء بلاغ", "label_en": "On report created"},
    {"key": "severity.critical", "label": "عند خطورة حرجة", "label_en": "On critical severity"},
    {"key": "claim.unverified", "label": "عند ادّعاء غير موثّق", "label_en": "On unverified claim"},
    {"key": "schedule.daily", "label": "جدولة يومية", "label_en": "Daily schedule"},
]
RULE_TRIGGER_BY_KEY = {t["key"]: t for t in RULE_TRIGGERS}

RULE_ACTIONS = [
    {"key": "notify", "label": "إشعار", "label_en": "Notify"},
    {"key": "tag", "label": "وسم", "label_en": "Tag"},
    {"key": "assign", "label": "إسناد", "label_en": "Assign"},
    {"key": "webhook", "label": "Webhook", "label_en": "Webhook"},
    {"key": "queue", "label": "إضافة للطابور", "label_en": "Enqueue"},
]
RULE_ACTION_BY_KEY = {a["key"]: a for a in RULE_ACTIONS}

JOB_STATES = [
    {"key": "queued", "label": "في الطابور", "label_en": "Queued"},
    {"key": "running", "label": "قيد التنفيذ", "label_en": "Running"},
    {"key": "done", "label": "مكتملة", "label_en": "Done"},
    {"key": "failed", "label": "فاشلة", "label_en": "Failed"},
]
JOB_STATE_BY_KEY = {s["key"]: s for s in JOB_STATES}

DELIVERY_STATES = [
    {"key": "pending", "label": "بالانتظار", "label_en": "Pending"},
    {"key": "delivered", "label": "سُلّم", "label_en": "Delivered"},
    {"key": "failed", "label": "فشل", "label_en": "Failed"},
]
DELIVERY_STATE_BY_KEY = {s["key"]: s for s in DELIVERY_STATES}


def _label(map_, key, lang):
    item = map_.get(key)
    if not item:
        return key
    return item.get("label_en" if lang == "en" else "label") or item["label"]


def api_scope_label(key: str, lang: str = "ar") -> str:
    return _label(API_SCOPE_BY_KEY, key, lang)


def webhook_event_label(key: str, lang: str = "ar") -> str:
    return _label(WEBHOOK_EVENT_BY_KEY, key, lang)


def connector_kind_label(key: str, lang: str = "ar") -> str:
    return _label(CONNECTOR_KIND_BY_KEY, key, lang)


def rule_trigger_label(key: str, lang: str = "ar") -> str:
    return _label(RULE_TRIGGER_BY_KEY, key, lang)


def rule_action_label(key: str, lang: str = "ar") -> str:
    return _label(RULE_ACTION_BY_KEY, key, lang)


def job_state_label(key: str, lang: str = "ar") -> str:
    return _label(JOB_STATE_BY_KEY, key, lang)


def delivery_state_label(key: str, lang: str = "ar") -> str:
    return _label(DELIVERY_STATE_BY_KEY, key, lang)


# --- الإدارة والتشغيل والتحليلات (الدفعة 13) ---
SERVICE_STATES = [
    {"key": "ok", "label": "سليمة", "label_en": "OK"},
    {"key": "degraded", "label": "متدهورة", "label_en": "Degraded"},
    {"key": "down", "label": "معطّلة", "label_en": "Down"},
]
SERVICE_STATE_BY_KEY = {s["key"]: s for s in SERVICE_STATES}

INCIDENT_STATES = [
    {"key": "open", "label": "مفتوح", "label_en": "Open"},
    {"key": "mitigated", "label": "مُخفَّف", "label_en": "Mitigated"},
    {"key": "resolved", "label": "مُعالج", "label_en": "Resolved"},
]
INCIDENT_STATE_BY_KEY = {s["key"]: s for s in INCIDENT_STATES}

RETENTION_CLASSES = [
    {"key": "reports", "label": "البلاغات", "label_en": "Reports", "days": 3650},
    {"key": "posts", "label": "المنشورات", "label_en": "Posts", "days": 1095},
    {"key": "notifications", "label": "الإشعارات", "label_en": "Notifications", "days": 180},
    {"key": "jobs", "label": "سجل المهام", "label_en": "Job log", "days": 90},
    {"key": "logs", "label": "سجلات الوصول", "label_en": "Access logs", "days": 365},
]
RETENTION_CLASS_BY_KEY = {c["key"]: c for c in RETENTION_CLASSES}

ALERT_LEVELS = [
    {"key": "info", "label": "معلومات", "label_en": "Info"},
    {"key": "warning", "label": "تحذير", "label_en": "Warning"},
    {"key": "critical", "label": "حرج", "label_en": "Critical"},
]
ALERT_LEVEL_BY_KEY = {a["key"]: a for a in ALERT_LEVELS}

ROADMAP_STATES = [
    {"key": "planned", "label": "مخطّط", "label_en": "Planned"},
    {"key": "in_progress", "label": "قيد التنفيذ", "label_en": "In progress"},
    {"key": "shipped", "label": "مُنجز", "label_en": "Shipped"},
]
ROADMAP_STATE_BY_KEY = {s["key"]: s for s in ROADMAP_STATES}


def service_state_label(key: str, lang: str = "ar") -> str:
    return _label(SERVICE_STATE_BY_KEY, key, lang)


def incident_state_label(key: str, lang: str = "ar") -> str:
    return _label(INCIDENT_STATE_BY_KEY, key, lang)


def alert_level_label(key: str, lang: str = "ar") -> str:
    return _label(ALERT_LEVEL_BY_KEY, key, lang)


def roadmap_state_label(key: str, lang: str = "ar") -> str:
    return _label(ROADMAP_STATE_BY_KEY, key, lang)


# --- الملفات الحسّاسة (الدفعة 14) — محاكاة فقط ---
SENSITIVE_KINDS = [
    {"key": "document", "label": "مستند", "label_en": "Document"},
    {"key": "image", "label": "صورة", "label_en": "Image"},
    {"key": "audio", "label": "تسجيل صوتي", "label_en": "Audio"},
    {"key": "video", "label": "مقطع مرئي", "label_en": "Video"},
    {"key": "dataset", "label": "مجموعة بيانات", "label_en": "Dataset"},
]
SENSITIVE_KIND_BY_KEY = {k["key"]: k for k in SENSITIVE_KINDS}

SENSITIVE_STATES = [
    {"key": "draft", "label": "مسودّة", "label_en": "Draft"},
    {"key": "sealed", "label": "مختوم", "label_en": "Sealed"},
    {"key": "shared", "label": "مُشارك", "label_en": "Shared"},
    {"key": "revoked", "label": "مسحوب", "label_en": "Revoked"},
]
SENSITIVE_STATE_BY_KEY = {s["key"]: s for s in SENSITIVE_STATES}

CLASSIFICATION_LEVELS = [
    {"key": "internal", "label": "داخلي", "label_en": "Internal"},
    {"key": "confidential", "label": "سرّي", "label_en": "Confidential"},
    {"key": "restricted", "label": "مقيَّد", "label_en": "Restricted"},
]
CLASSIFICATION_BY_KEY = {c["key"]: c for c in CLASSIFICATION_LEVELS}

ACCESS_STATES = [
    {"key": "pending", "label": "بانتظار الموافقة", "label_en": "Pending"},
    {"key": "approved", "label": "موافَق", "label_en": "Approved"},
    {"key": "denied", "label": "مرفوض", "label_en": "Denied"},
    {"key": "revoked", "label": "مسحوب", "label_en": "Revoked"},
]
ACCESS_STATE_BY_KEY = {s["key"]: s for s in ACCESS_STATES}

RECEIPT_KINDS = [
    {"key": "upload", "label": "إيداع", "label_en": "Upload"},
    {"key": "access", "label": "وصول", "label_en": "Access"},
    {"key": "revoke", "label": "سحب", "label_en": "Revoke"},
    {"key": "verify", "label": "تحقّق", "label_en": "Verify"},
]
RECEIPT_KIND_BY_KEY = {k["key"]: k for k in RECEIPT_KINDS}


def sensitive_kind_label(key: str, lang: str = "ar") -> str:
    return _label(SENSITIVE_KIND_BY_KEY, key, lang)


def sensitive_state_label(key: str, lang: str = "ar") -> str:
    return _label(SENSITIVE_STATE_BY_KEY, key, lang)


def classification_label(key: str, lang: str = "ar") -> str:
    return _label(CLASSIFICATION_BY_KEY, key, lang)


def access_state_label(key: str, lang: str = "ar") -> str:
    return _label(ACCESS_STATE_BY_KEY, key, lang)


def receipt_kind_label(key: str, lang: str = "ar") -> str:
    return _label(RECEIPT_KIND_BY_KEY, key, lang)


def claim_status_label(key: str, lang: str = "ar") -> str:
    s = CLAIM_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def claim_source_kind_label(key: str, lang: str = "ar") -> str:
    k = CLAIM_SOURCE_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def review_decision_label(key: str, lang: str = "ar") -> str:
    d = REVIEW_DECISION_BY_KEY.get(key)
    if not d:
        return key
    return d.get("label_en" if lang == "en" else "label") or d["label"]


def reliability_label(key: str, lang: str = "ar") -> str:
    r = SOURCE_RELIABILITY_BY_KEY.get(str(key))
    if not r:
        return str(key)
    return r.get("label_en" if lang == "en" else "label") or r["label"]


def group_kind_label(key: str, lang: str = "ar") -> str:
    k = GROUP_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def group_visibility_label(key: str, lang: str = "ar") -> str:
    v = GROUP_VISIBILITY_BY_KEY.get(key)
    if not v:
        return key
    return v.get("label_en" if lang == "en" else "label") or v["label"]


def group_role_label(key: str, lang: str = "ar") -> str:
    r = GROUP_ROLE_BY_KEY.get(key)
    if not r:
        return key
    return r.get("label_en" if lang == "en" else "label") or r["label"]


def group_member_status_label(key: str, lang: str = "ar") -> str:
    s = GROUP_MEMBER_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def post_kind_label(key: str, lang: str = "ar") -> str:
    k = POST_KIND_BY_KEY.get(key)
    if not k:
        return key
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def post_visibility_label(key: str, lang: str = "ar") -> str:
    v = POST_VISIBILITY_BY_KEY.get(key)
    if not v:
        return key
    return v.get("label_en" if lang == "en" else "label") or v["label"]


def post_status_label(key: str, lang: str = "ar") -> str:
    s = POST_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def member_role_label(key: str, lang: str = "ar") -> str:
    r = MEMBER_ROLE_BY_KEY.get(key)
    if not r:
        return key
    return r.get("label_en" if lang == "en" else "label") or r["label"]


def member_status_label(key: str, lang: str = "ar") -> str:
    s = MEMBER_STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def entity_kind_label(key: str, lang: str = "ar") -> str:
    k = ENTITY_KIND_BY_KEY.get(key)
    if not k:
        return "كيان" if lang == "ar" else "Entity"
    return k.get("label_en" if lang == "en" else "label") or k["label"]


def entity_kind_singular(key: str, lang: str = "ar") -> str:
    k = ENTITY_KIND_BY_KEY.get(key)
    if not k:
        return "كيان" if lang == "ar" else "Entity"
    return k.get("singular_en" if lang == "en" else "singular") or k.get("singular") or k["label"]


def category_name(key: str, lang: str = "ar") -> str:
    c = CATEGORY_BY_KEY.get(key)
    if not c:
        return key
    return c.get("name_en" if lang == "en" else "name") or c["name"]


def severity_label(key: str, lang: str = "ar") -> str:
    s = SEVERITY_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]


def status_label(key: str, lang: str = "ar") -> str:
    s = STATUS_BY_KEY.get(key)
    if not s:
        return key
    return s.get("label_en" if lang == "en" else "label") or s["label"]
