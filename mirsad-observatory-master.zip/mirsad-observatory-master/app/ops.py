"""الإدارة والتشغيل والتحليلات (الدفعة 13) — الدفعة الختامية.

لوحة إدارة مركزيّة، أعلام النظام (صيانة/قراءة فقط)، إعلانات عامّة، صحّة الخدمات وسجل الحوادث
وتقارير ما بعد العطل، سجل تدقيق، سياسات الاحتفاظ والأرشفة، تحليلات **مجمّعة بلا تتبّع شخصي**،
مؤشّرات KPI، خارطة طريق، قرارات حوكمة، وإدارة متطوّعين. كل البيانات تجريبية.
"""
from __future__ import annotations

import sqlite3
from typing import Any

from .taxonomy import (
    ALERT_LEVEL_BY_KEY,
    RETENTION_CLASS_BY_KEY,
)

FLAG_MAINTENANCE = "maintenance_mode"
FLAG_READONLY = "read_only"
DEFAULT_FLAGS = {
    FLAG_MAINTENANCE: "0",
    FLAG_READONLY: "0",
    "maintenance_notice": "",
    "spokesperson": "الناطق الرسمي — مِرصد",
}
# تحليلات بلا تتبّع شخصي: تجميع المسارات في حزم عامّة فقط.
PATH_BUCKETS = ["home", "reports", "map", "stats", "discover", "campaigns", "other"]
DEFAULT_BUCKET = "other"


def seed_admin(conn: sqlite3.Connection) -> None:
    """بيانات إدارة وتشغيل تجريبية (مرّة واحدة)."""
    if conn.execute("SELECT COUNT(*) AS n FROM system_flags").fetchone()["n"]:
        return
    for k, v in DEFAULT_FLAGS.items():
        conn.execute("INSERT OR IGNORE INTO system_flags(key, value) VALUES (?,?)", (k, v))
    for cls, meta in RETENTION_CLASS_BY_KEY.items():
        conn.execute(
            "INSERT OR IGNORE INTO retention_policies(class, days) VALUES (?,?)",
            (cls, meta["days"]))
    announcements = [
        ("info", "صيانة مخطّطة", "ستجري صيانة دورية يوم الجمعة 02:00–04:00."),
        ("warning", "تأخّر تحديث المصادر", "تأخّر سحب GDELT مؤقّتًا؛ البيانات الحالية سليمة."),
    ]
    for level, title, body in announcements:
        conn.execute(
            "INSERT INTO announcements(level, title, body, is_seed) VALUES (?,?,?,1)",
            (level, title, body))
    services = [
        ("الموقع", "ok", 120, 0.1), ("قاعدة البيانات", "ok", 8, 0.0),
        ("الخريطة", "degraded", 480, 1.2), ("البحث", "ok", 35, 0.2),
        ("الاستيراد", "degraded", 900, 3.5),
    ]
    for svc, state, lat, err in services:
        conn.execute(
            "INSERT INTO service_health(service, state, latency_ms, error_rate) VALUES (?,?,?,?)",
            (svc, state, lat, err))
    incidents = [
        ("تعطّل مؤقّت في الاستيراد", "critical", "resolved",
         "انقطاع مؤقّت في سحب المصادر الخارجية.", "تجاوز حدّ المعدّل؛ أُضيف تراجع أسّي.", 1),
        ("بطء في البحث", "warning", "mitigated",
         "بطء استعلامات FTS5 عند ذروة التحميل.", None, 1),
        ("انقطاع الخريطة", "warning", "open",
         "تعذّر تحميل بلاطات الخريطة لبعض المستخدمين.", None, 1),
    ]
    for title, sev, state, detail, pm, seed in incidents:
        conn.execute(
            """INSERT INTO incidents(title, severity, state, detail, postmortem, is_seed, resolved_at)
               VALUES (?,?,?,?,?,?, CASE WHEN ?='resolved' THEN datetime('now') ELSE NULL END)""",
            (title, sev, state, detail, pm, seed, state))
    roadmap = [
        ("لوحة تحليلات مجمّعة", "shipped", "2026-Q3"),
        ("تنبيهات الشذوذ", "in_progress", "2026-Q4"),
        ("تصدير تقارير PDF", "planned", "2027-Q1"),
        ("بوّابة موافقة بشرية للتنبؤات", "in_progress", "2026-Q4"),
    ]
    for title, state, q in roadmap:
        conn.execute(
            "INSERT INTO roadmap(title, state, quarter, is_seed) VALUES (?,?,?,1)",
            (title, state, q))
    decisions = [
        ("اعتماد سياسة الاحتفاظ", "احتفاظ البلاغات 10 سنوات، والإشعارات 180 يومًا."),
        ("قصر التحليلات على المجمّع", "لا تتبّع شخصي؛ إحصاءات مجمّعة فقط."),
    ]
    for title, dec in decisions:
        conn.execute(
            "INSERT INTO governance_decisions(title, decision, is_seed) VALUES (?,?,1)",
            (title, dec))
    handles = {r["handle"] for r in conn.execute("SELECT handle FROM members")}
    for handle, hours, cert in [("rana.act", 42.5, 1), ("adam.mem", 12.0, 0),
                                ("salma.mem", 27.5, 1)]:
        if handle in handles:
            conn.execute(
                "INSERT INTO volunteers(member, hours, certified, is_seed) VALUES (?,?,?,1)",
                (handle, hours, cert))
    # تحليلات مجمّعة بلا تتبّع شخصي (عدّاد يومي لكل حزمة مسار)
    import datetime as _dt
    today = _dt.date.today()
    for i in range(14):
        day = (today - _dt.timedelta(days=i)).isoformat()
        for bucket, n in [("home", 120 - i), ("reports", 80 - i * 2),
                          ("map", 40), ("stats", 22), ("discover", 31), ("other", 15)]:
            if n > 0:
                conn.execute(
                    """INSERT OR IGNORE INTO page_views(day, path_bucket, count)
                       VALUES (?,?,?)""", (day, bucket, n))
    conn.commit()


# ---------------------------------------------------------------------------
# أعلام النظام
# ---------------------------------------------------------------------------

def get_flag(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    r = conn.execute("SELECT value FROM system_flags WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default


def set_flag(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        """INSERT INTO system_flags(key, value) VALUES (?,?)
           ON CONFLICT(key) DO UPDATE SET value=?, updated_at=datetime('now')""",
        (key, value, value))
    conn.commit()


def all_flags(conn: sqlite3.Connection) -> dict[str, str]:
    return {r["key"]: r["value"] for r in conn.execute("SELECT * FROM system_flags")}


def in_maintenance(conn: sqlite3.Connection) -> bool:
    return get_flag(conn, FLAG_MAINTENANCE, "0") == "1"


def read_only(conn: sqlite3.Connection) -> bool:
    return get_flag(conn, FLAG_READONLY, "0") == "1"


# ---------------------------------------------------------------------------
# الإعلانات
# ---------------------------------------------------------------------------

def query_announcements(conn: sqlite3.Connection, *, active_only: bool = False) -> list[dict]:
    sql = "SELECT * FROM announcements"
    if active_only:
        sql += " WHERE active=1"
    sql += " ORDER BY created_at DESC, id DESC"
    return [dict(r) for r in conn.execute(sql).fetchall()]


def post_announcement(conn: sqlite3.Connection, level: str, title: str,
                      body: str = "") -> int:
    lvl = level if level in ALERT_LEVEL_BY_KEY else "info"
    cur = conn.execute(
        "INSERT INTO announcements(level, title, body) VALUES (?,?,?)", (lvl, title, body))
    conn.commit()
    return cur.lastrowid


# ---------------------------------------------------------------------------
# صحّة الخدمات والحوادث
# ---------------------------------------------------------------------------

def query_service_health(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM service_health ORDER BY service").fetchall()]


def record_health(conn: sqlite3.Connection, service: str, state: str,
                  latency_ms: int = 0, error_rate: float = 0.0) -> int:
    cur = conn.execute(
        """INSERT INTO service_health(service, state, latency_ms, error_rate)
           VALUES (?,?,?,?)""", (service, state, latency_ms, error_rate))
    conn.commit()
    return cur.lastrowid


def system_status(conn: sqlite3.Connection) -> dict[str, Any]:
    """لوحة حالة النظام: أسوأ حالة خدمة + الأعلام + الحوادث المفتوحة."""
    rows = query_service_health(conn)
    order = {"ok": 0, "degraded": 1, "down": 2}
    worst = "ok"
    for r in rows:
        if order.get(r["state"], 0) > order.get(worst, 0):
            worst = r["state"]
    open_incidents = conn.execute(
        "SELECT COUNT(*) AS n FROM incidents WHERE state != 'resolved'").fetchone()["n"]
    return {"state": worst, "services": rows, "open_incidents": open_incidents,
            "maintenance": in_maintenance(conn), "read_only": read_only(conn),
            "alerts": [a for a in query_announcements(conn, active_only=True)]}


def query_incidents(conn: sqlite3.Connection, *, state: str | None = None) -> list[dict]:
    sql = "SELECT * FROM incidents"
    params: list[Any] = []
    if state:
        sql += " WHERE state=?"; params.append(state)
    sql += " ORDER BY created_at DESC, id DESC"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def update_incident(conn: sqlite3.Connection, iid: int, state: str,
                    postmortem: str | None = None) -> bool:
    resolved = "datetime('now')" if state == "resolved" else "NULL"
    cur = conn.execute(
        f"""UPDATE incidents SET state=?, postmortem=COALESCE(?, postmortem),
            resolved_at={resolved} WHERE id=?""",
        (state, postmortem, iid))
    conn.commit()
    return cur.rowcount > 0


# ---------------------------------------------------------------------------
# سجل التدقيق
# ---------------------------------------------------------------------------

def audit(conn: sqlite3.Connection, actor: str | None, action: str,
          target: str = "", detail: str = "") -> int:
    cur = conn.execute(
        "INSERT INTO audit_log(actor, action, target, detail) VALUES (?,?,?,?)",
        (actor, action, target, detail))
    conn.commit()
    return cur.lastrowid


def query_audit(conn: sqlite3.Connection, *, action: str | None = None,
                limit: int = 50) -> list[dict]:
    sql = "SELECT * FROM audit_log"
    params: list[Any] = []
    if action:
        sql += " WHERE action=?"; params.append(action)
    sql += " ORDER BY created_at DESC, id DESC LIMIT ?"; params.append(limit)
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


# ---------------------------------------------------------------------------
# الاحتفاظ والأرشفة
# ---------------------------------------------------------------------------

def retention_policies(conn: sqlite3.Connection) -> list[dict]:
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM retention_policies ORDER BY class").fetchall()]
    for r in rows:
        meta = RETENTION_CLASS_BY_KEY.get(r["class"], {})
        r["label"] = meta.get("label", r["class"])
    return rows


def set_retention(conn: sqlite3.Connection, cls: str, days: int) -> bool:
    if cls not in RETENTION_CLASS_BY_KEY:
        return False
    conn.execute(
        """INSERT INTO retention_policies(class, days) VALUES (?,?)
           ON CONFLICT(class) DO UPDATE SET days=?, updated_at=datetime('now')""",
        (cls, days, days))
    conn.commit()
    return True


def retention_report(conn: sqlite3.Connection) -> list[dict]:
    """تقرير امتثال الاحتفاظ: العمر الأقصى المسموح مقابل الأقدم فعليًّا."""
    out = []
    for p in retention_policies(conn):
        cls = p["class"]
        table = {"reports": "reports", "posts": "posts", "notifications": "notifications",
                 "jobs": "jobs", "logs": "audit_log"}.get(cls)
        if not table:
            continue
        row = conn.execute(
            f"SELECT MIN(created_at) AS oldest, COUNT(*) AS n FROM {table}").fetchone()
        oldest = row["oldest"]
        days_old = conn.execute(
            "SELECT CAST(julianday('now') - julianday(?) AS INTEGER) AS d", (oldest,)
        ).fetchone()["d"] if oldest else 0
        out.append({"class": cls, "label": p["label"], "limit_days": p["days"],
                    "oldest": oldest, "age_days": days_old or 0,
                    "compliant": (days_old or 0) <= p["days"], "count": row["n"]})
    return out


def archive_candidates(conn: sqlite3.Connection) -> dict[str, int]:
    """عدد السجلات القابلة للأرشفة وفق كل سياسة احتفاظ."""
    out = {}
    for p in retention_policies(conn):
        table = {"reports": "reports", "posts": "posts", "notifications": "notifications",
                 "jobs": "jobs", "logs": "audit_log"}.get(p["class"])
        if not table:
            continue
        n = conn.execute(
            f"SELECT COUNT(*) AS n FROM {table} WHERE created_at < date('now', ?)",
            (f"-{p['days']} days",)).fetchone()["n"]
        out[p["class"]] = n
    return out


# ---------------------------------------------------------------------------
# تحليلات مجمّعة (بلا تتبّع شخصي)
# ---------------------------------------------------------------------------

def record_view(conn: sqlite3.Connection, bucket: str, n: int = 1) -> None:
    """تسجيل عرض مجمّع لحزمة مسار عامّة فقط (لا معرّفات ولا IP)."""
    bucket = bucket if bucket in PATH_BUCKETS else DEFAULT_BUCKET
    conn.execute(
        """INSERT INTO page_views(day, path_bucket, count) VALUES (date('now'), ?, ?)
           ON CONFLICT(day, path_bucket) DO UPDATE SET count = count + ?""",
        (bucket, n, n))
    conn.commit()


def analytics_summary(conn: sqlite3.Connection, days: int = 14) -> dict[str, Any]:
    rows = conn.execute(
        """SELECT day, SUM(count) AS n FROM page_views
           WHERE day >= date('now', ?) GROUP BY day ORDER BY day""",
        (f"-{days} days",)).fetchall()
    by_bucket = conn.execute(
        """SELECT path_bucket, SUM(count) AS n FROM page_views
           WHERE day >= date('now', ?) GROUP BY path_bucket ORDER BY n DESC""",
        (f"-{days} days",)).fetchall()
    return {"by_day": [dict(r) for r in rows],
            "by_bucket": [dict(r) for r in by_bucket],
            "total": sum(r["n"] for r in rows)}


def kpis(conn: sqlite3.Connection) -> dict[str, Any]:
    """مؤشّرات رئيسية: نمو، تفاعل، قضايا، تحقّق، أمن، أداء."""
    def scalar(sql: str) -> int:
        return conn.execute(sql).fetchone()["n"]
    reports = scalar("SELECT COUNT(*) AS n FROM reports")
    members = scalar("SELECT COUNT(*) AS n FROM members")
    posts = scalar("SELECT COUNT(*) AS n FROM posts")
    verified = scalar("SELECT COUNT(*) AS n FROM reports WHERE verified=1")
    open_claims = scalar("SELECT COUNT(*) AS n FROM claims WHERE status NOT IN ('verified','rejected')")
    total_claims = scalar("SELECT COUNT(*) AS n FROM claims")
    security_alerts = scalar("SELECT COUNT(*) AS n FROM incidents WHERE severity='critical'")
    audit_events = scalar("SELECT COUNT(*) AS n FROM audit_log")
    failed_jobs = scalar("SELECT COUNT(*) AS n FROM jobs WHERE state='failed'")
    return {
        "growth": {"reports": reports, "members": members, "posts": posts},
        "engagement": {"posts": posts, "posts_per_member": round(posts / members, 2) if members else 0},
        "cases": {"open_claims": open_claims, "total_claims": total_claims},
        "verification": {"verified": verified,
                         "rate": round(100.0 * verified / reports, 1) if reports else 0.0},
        "security": {"critical_incidents": security_alerts, "audit_events": audit_events},
        "performance": {"failed_jobs": failed_jobs},
    }


def detect_anomalies(conn: sqlite3.Connection) -> list[dict]:
    """كشف الشذوذ في البيانات: أيام بتدفّق بلاغات أعلى بكثير من المتوسط."""
    rows = conn.execute(
        """SELECT reported_on AS day, COUNT(*) AS n FROM reports
           WHERE reported_on IS NOT NULL GROUP BY reported_on ORDER BY n DESC""").fetchall()
    if not rows:
        return []
    counts = [r["n"] for r in rows]
    avg = sum(counts) / len(counts)
    out = []
    for r in rows:
        if avg and r["n"] >= max(avg * 2.5, avg + 3):
            out.append({"day": r["day"], "count": r["n"],
                        "ratio": round(r["n"] / avg, 1),
                        "reason": "تدفّق أعلى من المتوسط"})
    return out[:5]


def trends(conn: sqlite3.Connection, months: int = 6) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT substr(reported_on,1,7) AS month, COUNT(*) AS n FROM reports
           WHERE reported_on IS NOT NULL
           GROUP BY month ORDER BY month DESC LIMIT ?""", (months,)).fetchall()]


def compare_periods(conn: sqlite3.Connection, days: int = 30) -> dict[str, Any]:
    cur = conn.execute(
        "SELECT COUNT(*) AS n FROM reports WHERE reported_on >= date('now', ?)",
        (f"-{days} days",)).fetchone()["n"]
    prev = conn.execute(
        """SELECT COUNT(*) AS n FROM reports
           WHERE reported_on >= date('now', ?) AND reported_on < date('now', ?)""",
        (f"-{2 * days} days", f"-{days} days")).fetchone()["n"]
    delta = cur - prev
    return {"current": cur, "previous": prev, "delta": delta,
            "change_pct": round(100.0 * delta / prev, 1) if prev else 0.0}


# ---------------------------------------------------------------------------
# خارطة الطريق والحوكمة والمتطوّعون
# ---------------------------------------------------------------------------

def query_roadmap(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM roadmap ORDER BY id").fetchall()]


def query_governance(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        "SELECT * FROM governance_decisions ORDER BY created_at DESC, id DESC").fetchall()]


def query_volunteers(conn: sqlite3.Connection) -> list[dict]:
    return [dict(r) for r in conn.execute(
        """SELECT v.*, m.display_name FROM volunteers v
           JOIN members m ON m.handle = v.member ORDER BY v.hours DESC""").fetchall()]


def log_volunteer_hours(conn: sqlite3.Connection, member: str, hours: float) -> bool:
    r = conn.execute("SELECT id FROM volunteers WHERE member=?", (member,)).fetchone()
    if r:
        conn.execute("UPDATE volunteers SET hours = hours + ? WHERE id=?", (hours, r["id"]))
    else:
        conn.execute("INSERT INTO volunteers(member, hours) VALUES (?,?)", (member, hours))
    conn.commit()
    return True


def certify_volunteer(conn: sqlite3.Connection, member: str) -> bool:
    cur = conn.execute(
        "UPDATE volunteers SET certified=1 WHERE member=?", (member,))
    conn.commit()
    return cur.rowcount > 0


def volunteer_stats(conn: sqlite3.Connection) -> dict[str, Any]:
    r = conn.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(hours),0) AS h, COALESCE(SUM(certified),0) AS c FROM volunteers"
    ).fetchone()
    return {"volunteers": r["n"], "hours": r["h"], "certified": r["c"]}


def ops_summary(conn: sqlite3.Connection) -> dict[str, Any]:
    """تقرير ختامي شامل: أثر، شفافية، وصحّة تشغيلية."""
    return {"kpis": kpis(conn), "status": system_status(conn),
            "analytics": analytics_summary(conn),
            "volunteers": volunteer_stats(conn),
            "retention": retention_report(conn),
            "incidents_open": len(query_incidents(conn, state="open")),
            "roadmap": query_roadmap(conn)}
