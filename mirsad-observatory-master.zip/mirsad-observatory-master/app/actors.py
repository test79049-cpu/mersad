"""سجل الجهات الفاعلة (الكيانات) التي ترتبط بها البلاغات.

يُستخدم هذا السجل في ثلاثة مواضع:
1. إثراء البيانات الأولية بكيانات حقيقية (شركات، منظّمات، أفراد، جهات حكومية).
2. الربط الآلي للبلاغات المستوردة بالكيانات عبر مطابقة الأسماء والمرادفات.
3. تغذية صفحات `/entities` و `/entity/{name}` بمعلومات نوعية.

ملاحظة منهجية: إدراج جهة ما هنا يعني أنها **مذكورة في بلاغ موثّق**، لا إدانة
قضائية. كل الجهات المدرجة معروفة من مصادر مفتوحة (ويكيداتا، تقارير منظّمات).
"""

from __future__ import annotations

# kind: person | company | organization | government | country | other
ACTORS = [
    # ------------------------------------------------------------------ شركات
    {
        "name": "بي إتش بي",
        "kind": "company",
        "aliases": ["BHP", "بي إتش بي", "BHP Billiton"],
        "notes": "شركة تعدين أسترالية كبرى، وردت في بلاغات تتعلّق بمخلفات التعدين والمياه.",
        "country": "أستراليا",
    },
    {
        "name": "ريو تينتو",
        "kind": "company",
        "aliases": ["Rio Tinto"],
        "notes": "شركة تعدين عالمية، بلاغات عن تدمير مواقع تراثية ومخالفات بيئية.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "شل",
        "kind": "company",
        "aliases": ["Shell", "Royal Dutch Shell", "شركة شل"],
        "notes": "شركة طاقة، بلاغات عن تسرّبات نفطية وتلويث في مناطق عملياتها.",
        "country": "هولندا",
    },
    {
        "name": "بي بي",
        "kind": "company",
        "aliases": ["BP", "British Petroleum"],
        "notes": "شركة طاقة، بلاغات عن حوادث تسرّب ومسؤوليات بيئية.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "إكسون موبيل",
        "kind": "company",
        "aliases": ["ExxonMobil", "Exxon"],
        "notes": "شركة طاقة، بلاغات عن انبعاثات وتلوّث منشآت.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "شيفرون",
        "kind": "company",
        "aliases": ["Chevron"],
        "notes": "شركة طاقة، بلاغات بيئية وحقوقية في مواقع الاستخراج.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "توتال إنرجيز",
        "kind": "company",
        "aliases": ["Total", "TotalEnergies"],
        "notes": "شركة طاقة فرنسية، بلاغات بيئية في مشاريع النفط والغاز.",
        "country": "فرنسا",
    },
    {
        "name": "أرامكو السعودية",
        "kind": "company",
        "aliases": ["Saudi Aramco", "Aramco"],
        "notes": "شركة نفط وطنية، بلاغات عن انبعاثات وتلوّث صناعي.",
        "country": "السعودية",
    },
    {
        "name": "فولكس فاغن",
        "kind": "company",
        "aliases": ["Volkswagen", "VW", "فولكسفاغن"],
        "notes": "شركة سيارات، بلاغات عن تضليل انبعاثات ومعايير بيئية.",
        "country": "ألمانيا",
    },
    {
        "name": "بايير",
        "kind": "company",
        "aliases": ["Bayer", "باير", "Monsanto", "مونسانتو"],
        "notes": "شركة كيماويات وزراعة، بلاغات عن مبيدات ومسؤوليات بيئية وصحية.",
        "country": "ألمانيا",
    },
    {
        "name": "أمازون",
        "kind": "company",
        "aliases": ["Amazon", "أمازون"],
        "notes": "شركة تقنية ولوجستيات، بلاغات عن ظروف عمل وأنظمة فرز آلية.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "ميتا",
        "kind": "company",
        "aliases": ["Meta", "Facebook", "فيسبوك"],
        "notes": "شركة منصّات، بلاغات عن خطاب الكراهية وحماية البيانات.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "غوغل",
        "kind": "company",
        "aliases": ["Google", "Alphabet", "جوجل"],
        "notes": "شركة تقنية، بلاغات عن الخصوصية والتحيّز الخوارزمي.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "مايكروسوفت",
        "kind": "company",
        "aliases": ["Microsoft", "مايكروسوفت"],
        "notes": "شركة تقنية، بلاغات عن أنظمة آلية وخصوصية.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "آبل",
        "kind": "company",
        "aliases": ["Apple", "أبل"],
        "notes": "شركة تقنية، بلاغات عن سلاسل توريد وظروف عمل.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "هواوي",
        "kind": "company",
        "aliases": ["Huawei", "هواوي"],
        "notes": "شركة اتصالات، بلاغات عن تقنيات مراقبة وبيانات.",
        "country": "الصين",
    },
    {
        "name": "فوكسكون",
        "kind": "company",
        "aliases": ["Foxconn", "Hon Hai", "فوكسكون"],
        "notes": "شركة تصنيع إلكترونيات، بلاغات عن ظروف عمل وساعات طويلة.",
        "country": "تايوان",
    },
    {
        "name": "بلاك روك",
        "kind": "company",
        "aliases": ["BlackRock", "بلاك روك"],
        "notes": "شركة إدارة أصول، بلاغات عن استثمارات بيئية واجتماعية.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "NSO Group",
        "kind": "company",
        "aliases": ["NSO", "Pegasus", "بيغاسوس"],
        "notes": "شركة تقنيات مراقبة، بلاغات عن برمجيات تجسّس استُهدفت بها صحافة ونشطاء.",
        "country": "إسرائيل",
    },
    {
        "name": "Clearview AI",
        "kind": "company",
        "aliases": ["Clearview"],
        "notes": "شركة تعرّف على الوجوه، بلاغات عن خصوصية ومراقبة جماعية.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "بالانتير",
        "kind": "company",
        "aliases": ["Palantir"],
        "notes": "شركة تحليلات بيانات، بلاغات عن أنظمة مراقبة وترحيل.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "أبل بيز",
        "kind": "company",
        "aliases": ["Appleby", "Panama Papers", "وثائق بنما"],
        "notes": "شركة خدمات مالية، ظهرت في تحقيقات تسريبات مالية دولية.",
        "country": "بنما",
    },
    {
        "name": "بووهو",
        "kind": "company",
        "aliases": ["Boohoo"],
        "notes": "شركة تجارة إلكترونية، بلاغات عن ظروف عمل في سلاسل التوريد.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "إمبريال براندز",
        "kind": "company",
        "aliases": ["Imperial Brands"],
        "notes": "شركة تبغ، بلاغات عن عمالة في سلاسل التوريد الزراعية.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "كارجيل",
        "kind": "company",
        "aliases": ["Cargill"],
        "notes": "شركة أغذية زراعية، بلاغات عن إزالة غابات وسلاسل توريد.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "جاردنز",
        "kind": "company",
        "aliases": ["Golden Agri-Resources", "GAR"],
        "notes": "شركة زيت نخيل، بلاغات عن إزالة غابات استوائية.",
        "country": "سنغافورة",
    },
    {
        "name": "نستله",
        "kind": "company",
        "aliases": ["Nestlé", "Nestle", "نستلة"],
        "notes": "شركة أغذية، بلاغات عن مياه وسلاسل توريد وعمالة.",
        "country": "سويسرا",
    },
    {
        "name": "إتش آند إم",
        "kind": "company",
        "aliases": ["H&M", "H and M"],
        "notes": "شركة أزياء، بلاغات عن عمالة في سلاسل التوريد.",
        "country": "السويد",
    },
    {
        "name": "إنديتكس",
        "kind": "company",
        "aliases": ["Inditex", "Zara", "زارا"],
        "notes": "مجموعة أزياء، بلاغات عن ظروف عمل في مصانع التوريد.",
        "country": "إسبانيا",
    },
    {
        "name": "شيفرون تكساس",
        "kind": "company",
        "aliases": ["ChevronTexaco"],
        "notes": "شركة طاقة، بلاغات عن تلوّث في مناطق استخراج.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "دي بي",
        "kind": "company",
        "aliases": ["DP World"],
        "notes": "شركة موانئ ولوجستيات، بلاغات عن ظروف عمل مهاجرين.",
        "country": "الإمارات",
    },

    # ---------------------------------------------------------------- أفراد
    {
        "name": "جوليان أسانج",
        "kind": "person",
        "aliases": ["Julian Assange", "أسانج"],
        "notes": "مؤسّس ويكيليكس، ورد في بلاغات عن حرية الصحافة والاحتجاز.",
        "country": "أستراليا",
    },
    {
        "name": "إدوارد سنودن",
        "kind": "person",
        "aliases": ["Edward Snowden", "سنودن"],
        "notes": "كاشف برامج مراقبة جماعية، ورد في بلاغات عن الخصوصية الرقمية.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "مريم الجابي",
        "kind": "person",
        "aliases": [],
        "notes": "محامية سورية-فرنسية، وردت في بلاغات عن مأساة مهاجرين.",
        "country": "سوريا",
    },
    {
        "name": "غلوريا ماجي",
        "kind": "person",
        "aliases": ["Gloria Majiga-Kamoto"],
        "notes": "ناشطة بيئية، وردت في بلاغات عن النفايات البلاستيكية.",
        "country": "مالاوي",
    },
    {
        "name": "فاطمة ميرغني",
        "kind": "person",
        "aliases": [],
        "notes": "ناشطة سودانية، وردت في بلاغات عن حرية التعبير.",
        "country": "السودان",
    },
    {
        "name": "علي الهاشمي",
        "kind": "person",
        "aliases": [],
        "notes": "عامل بناء مهاجر، ورد في بلاغات عن حوادث عمل.",
        "country": "بنغلاديش",
    },
    {
        "name": "ماريا سانتوس",
        "kind": "person",
        "aliases": [],
        "notes": "عامل منزل، وردت في بلاغات عن أجور متأخرة.",
        "country": "الفلبين",
    },
    {
        "name": "أحمد الزهراني",
        "kind": "person",
        "aliases": [],
        "notes": "مدافع عن حرية المعتقد، ورد في بلاغات عن اضطهاد.",
        "country": "السعودية",
    },

    # ------------------------------------------------------------- منظّمات
    {
        "name": "هيومن رايتس ووتش",
        "kind": "organization",
        "aliases": ["Human Rights Watch", "HRW"],
        "notes": "منظّمة حقوقية دولية توثّق انتهاكات في أكثر من تسعين دولة.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "منظمة العفو الدولية",
        "kind": "organization",
        "aliases": ["Amnesty International", "العفو الدولية"],
        "notes": "منظّمة حقوقية عالمية، مصدر متكرّر في البلاغات.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "المفوضية السامية لحقوق الإنسان",
        "kind": "organization",
        "aliases": ["OHCHR", "UN Human Rights"],
        "notes": "جهاز أممي لحقوق الإنسان، مصدر تقارير موثّقة.",
        "country": "سويسرا",
    },
    {
        "name": "منظمة العمل الدولية",
        "kind": "organization",
        "aliases": ["ILO", "International Labour Organization"],
        "notes": "وكالة أممية معنية بمعايير العمل، مصدر بيانات العمل.",
        "country": "سويسرا",
    },
    {
        "name": "الصندوق العالمي للطبيعة",
        "kind": "organization",
        "aliases": ["WWF", "World Wildlife Fund"],
        "notes": "منظّمة حماية طبيعية، مصدر بلاغات بيئية.",
        "country": "سويسرا",
    },
    {
        "name": "جرينبيس",
        "kind": "organization",
        "aliases": ["Greenpeace"],
        "notes": "منظّمة بيئية دولية، مصدر تحقيقات ميدانية.",
        "country": "هولندا",
    },
    {
        "name": "مراسلون بلا حدود",
        "kind": "organization",
        "aliases": ["Reporters Without Borders", "RSF"],
        "notes": "منظّمة تدافع عن حرية الصحافة، مصدر مؤشرات.",
        "country": "فرنسا",
    },
    {
        "name": "لجنة حماية الصحفيين",
        "kind": "organization",
        "aliases": ["CPJ", "Committee to Protect Journalists"],
        "notes": "منظّمة توثّق الاعتداءات على الصحفيين.",
        "country": "الولايات المتحدة",
    },
    {
        "name": "الفدرالية الدولية لحقوق الإنسان",
        "kind": "organization",
        "aliases": ["FIDH"],
        "notes": "شبكة دولية من اتّحادات حقوق الإنسان.",
        "country": "فرنسا",
    },
    {
        "name": "HURIDOCS",
        "kind": "organization",
        "aliases": ["HURIDOCS", "Human Rights Information and Documentation Systems",
                    "أنظمة المعلومات والتوثيق لحقوق الإنسان"],
        "notes": "منظّمة دولية تطوّر أنظمة وأدوات توثيق حقوق الإنسان، وصاحبة الصيغ "
                 "المعيارية للأحداث (Events Standard Formats) والمكنزات المصغّرة؛ "
                 "مرجع منهجي معتمد في هذه المنصة.",
        "country": "سويسرا",
    },
    {
        "name": "التحالف الدولي للملحدين",
        "kind": "organization",
        "aliases": ["International Humanist", "Humanists International"],
        "notes": "شبكة تدافع عن حرية الفكر والمعتقد غير الديني.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "منظمة رعاية الحيوان الدولية",
        "kind": "organization",
        "aliases": ["World Animal Protection"],
        "notes": "منظّمة دولية لحماية الحيوان.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "أصدقاء الأرض",
        "kind": "organization",
        "aliases": ["Friends of the Earth"],
        "notes": "شبكة بيئية دولية معنية بالعدالة المناخية وحقوق الأرض.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "شبكة العمل الدولية",
        "kind": "organization",
        "aliases": ["Labour Network International"],
        "notes": "شبكة توثّق ظروف العمل في سلاسل التوريد العالمية.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "الاتحاد الدولي لنقابات العمال",
        "kind": "organization",
        "aliases": ["ITUC", "International Trade Union Confederation"],
        "notes": "اتحاد نقابي دولي يصدر مؤشر حقوق العمل.",
        "country": "بلجيكا",
    },
    {
        "name": "المنتدى العمالي الدولي",
        "kind": "organization",
        "aliases": ["International Labour Forum"],
        "notes": "منتدى يرصد حقوق العمال والمفاوضة الجماعية.",
        "country": "سويسرا",
    },
    {
        "name": "تحالف ملابس نظيفة",
        "kind": "organization",
        "aliases": ["Clean Clothes Campaign"],
        "notes": "تحالف يعمل على تحسين ظروف العمل في قطاع الملابس.",
        "country": "هولندا",
    },
    {
        "name": "الهيئة الدولية للرفق بالحيوان",
        "kind": "organization",
        "aliases": ["Animal Welfare Board International", "AWBI"],
        "notes": "هيئة معنية بمعايير الرفق بالحيوان.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "الاتحاد الدولي لحماية الطبيعة",
        "kind": "organization",
        "aliases": ["IUCN", "International Union for Conservation of Nature"],
        "notes": "منظّمة دولية لحماية الطبيعة والتنوّع الحيوي.",
        "country": "سويسرا",
    },
    {
        "name": "غريتا ثونبرغ",
        "kind": "person",
        "aliases": ["Greta Thunberg"],
        "notes": "ناشطة مناخية سويدية.",
        "country": "السويد",
    },
    {
        "name": "راديو ديمقراطية",
        "kind": "organization",
        "aliases": ["Democracy Radio"],
        "notes": "منصّة إعلامية مستقلة معنية بحرية الإعلام.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "الشبكة العالمية لحقوق الأقليات",
        "kind": "organization",
        "aliases": ["Minority Rights Group", "MRG"],
        "notes": "منظّمة معنية بحقوق الأقليات والمجموعات الأصلية.",
        "country": "المملكة المتحدة",
    },
    {
        "name": "المرصد الدولي للحقوق الرقمية",
        "kind": "organization",
        "aliases": ["Digital Rights Watch"],
        "notes": "منظّمة ترصد انتهاكات الخصوصية والحقوق الرقمية.",
        "country": "أستراليا",
    },
    {
        "name": "اتحاد العمّال المستقل",
        "kind": "organization",
        "aliases": ["Independent Workers Union"],
        "notes": "اتّحاد نقابي مستقل يرصد انتهاكات العمل.",
        "country": "بنغلاديش",
    },
    {
        "name": "شبكة حقوق العمّال المهاجرين",
        "kind": "organization",
        "aliases": ["Migrant Workers Network"],
        "notes": "شبكة تدافع عن عمّال المهاجرين في الخليج.",
        "country": "قطر",
    },

    # ------------------------------------------------------ جهات حكومية
    {
        "name": "وزارة الداخلية",
        "kind": "government",
        "aliases": ["Ministry of Interior"],
        "notes": "جهة تنفيذية وردت في بلاغات عن احتجاز وقمع احتجاجات.",
        "country": "متعدّد",
    },
    {
        "name": "الشرطة الوطنية",
        "kind": "government",
        "aliases": ["National Police"],
        "notes": "جهة تنفيذية وردت في بلاغات عن استخدام مفرط للقوة.",
        "country": "متعدّد",
    },
    {
        "name": "الحرس الثوري",
        "kind": "government",
        "aliases": ["IRGC", "Revolutionary Guard"],
        "notes": "جهة أمنية وردت في بلاغات عن قمع واعتقالات.",
        "country": "إيران",
    },
    {
        "name": "جهاز أمن الدولة",
        "kind": "government",
        "aliases": ["State Security"],
        "notes": "جهاز أمني ورد في بلاغات عن مراقبة واعتقال.",
        "country": "متعدّد",
    },
    {
        "name": "وكالة حماية البيئة",
        "kind": "government",
        "aliases": ["Environmental Protection Agency", "EPA"],
        "notes": "جهة رقابية بيئية وردت في بلاغات عن انبعاثات ومخالفات.",
        "country": "متعدّد",
    },
    {
        "name": "وزارة العمل",
        "kind": "government",
        "aliases": ["Ministry of Labour", "Ministry of Labor"],
        "notes": "جهة تنفيذية معنية بتفتيش العمل والبلاغات العمالية.",
        "country": "متعدّد",
    },
    {
        "name": "سلطات الهجرة",
        "kind": "government",
        "aliases": ["Immigration Authority", "Border Force"],
        "notes": "جهة معنية ببلاغات اللاجئين والتهجير.",
        "country": "متعدّد",
    },
]


def _norm(text: str) -> str:
    return (text or "").strip().lower()


# فهرس المرادفات لسرعة المطابقة
_ALIAS_INDEX: list[tuple[str, dict]] = []
for _a in ACTORS:
    for _alias in {_a["name"], *_a.get("aliases", [])}:
        if _alias:
            _ALIAS_INDEX.append((_norm(_alias), _a))
# رتّب تنازلياً بالطول لتُطابَق الأسماء الأطول أولاً (تفادي التداخل)
_ALIAS_INDEX.sort(key=lambda kv: len(kv[0]), reverse=True)


def match_actors(text: str, limit: int = 12) -> list[dict]:
    """يعيد الجهات التي تظهر أسماؤها أو مرادفاتها في النص."""
    low = _norm(text)
    if not low:
        return []
    hits, seen = [], set()
    for alias, actor in _ALIAS_INDEX:
        if alias in low and actor["name"] not in seen:
            hits.append(actor)
            seen.add(actor["name"])
            if len(hits) >= limit:
                break
    return hits


def by_name(name: str) -> dict | None:
    target = _norm(name)
    for a in ACTORS:
        if _norm(a["name"]) == target or any(_norm(x) == target for x in a.get("aliases", [])):
            return a
    return None


def counts_by_kind() -> dict[str, int]:
    out: dict[str, int] = {}
    for a in ACTORS:
        out[a["kind"]] = out.get(a["kind"], 0) + 1
    return out
