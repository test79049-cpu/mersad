@echo off
chcp 65001 >nul
cd /d "%~dp0"
setlocal enabledelayedexpansion
set "LOG=mirsad-check.log"
echo ===== تشخيص %DATE% %TIME% ===== > "%LOG%"
echo المجلد: %CD% >> "%LOG%"

cls
echo.
echo ============================================================
echo               مِرصد - تشخيص المشكلة
echo ============================================================
echo.
echo   المجلد الحالي:
echo   %CD%
echo.

echo ------------------------------------------------------------
echo  [1] فحص ملفات المشروع
echo ------------------------------------------------------------
set "MISSING=0"
for %%F in (app requirements.txt run.sh) do (
  if exist "%%F" (
    echo    [موجود]  %%F
  ) else (
    echo    [ناقص!]  %%F
    set "MISSING=1"
  )
)
echo.
if "!MISSING!"=="1" (
  echo    ^>^> المشروع غير مكتمل.
  echo    ^>^> نزّل المشروع كاملا وفك ضغطه:
  echo       https://gitlab.com/test79049/mirsad-observatory/-/archive/master/mirsad-observatory-master.zip
  echo.
)

echo ------------------------------------------------------------
echo  [2] فحص Python
echo ------------------------------------------------------------
set "PY="
py -3 --version >nul 2>>"%LOG%" && set "PY=py -3"
if not defined PY ( python --version >nul 2>>"%LOG%" && set "PY=python" )
if not defined PY ( python3 --version >nul 2>>"%LOG%" && set "PY=python3" )
if defined PY (
  echo    [موجود]  Python عبر: !PY!
  !PY! --version
) else (
  echo    [ناقص!]  لم يوجد Python.
  echo    ^>^> ثبّت Python 3.10+ من:
  echo       https://www.python.org/downloads/
  echo    ^>^> مهم جدا: فعّل خيار "Add python.exe to PATH"
)

echo.
echo ------------------------------------------------------------
echo  [3] فحص البيئة الجاهزة
echo ------------------------------------------------------------
if exist ".venv\Scripts\python.exe" (
  echo    [موجود]  البيئة .venv جاهزة.
) else (
  echo    [ناقص]  البيئة .venv غير منشأة.
  echo            ستنشأ تلقائيا عند تشغيل start-windows.bat
)

echo.
echo ============================================================
echo               الخلاصة
echo ============================================================
if "!MISSING!"=="1" echo   [1] ملفات المشروع ناقصة
if not defined PY  echo   [2] Python غير مثبّت
if "!MISSING!"=="0" if defined PY echo   كل شيء جاهز! شغّل start-windows.bat
echo.
echo   تم حفظ التقرير في: %LOG%
echo.
echo ------------------------------------------------------------
echo   لن تُغلق هذه النافذة. انسخ محتواها لي إن احتجت مساعدة.
echo ------------------------------------------------------------
echo.
pause
